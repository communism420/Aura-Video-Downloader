#!/usr/bin/env python3
"""Aura Video Downloader — entry point."""
from aura.app import main
if __name__ == "__main__":
    main()
