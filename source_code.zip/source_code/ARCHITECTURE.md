# Architecture

This document describes the architecture of Aura Video Downloader — a modular desktop application built with Python, PySide6 (Qt6), and yt-dlp.

---

## Design principles

1. **Modular monolith** — single package, clean module boundaries, no circular imports
2. **UI ↔ Logic separation** — workers and core modules have zero UI dependencies
3. **Never block the main thread** — all subprocess/network work runs in QThread workers
4. **Crash resilience** — atomic writes, .bak backups, atexit subprocess cleanup, session recovery
5. **Backward compatibility** — settings migration preserves user config across versions

---

## Dependency graph

```
                    ┌─────────────────────────────────┐
                    │           app.py                 │  Entry point
                    │  (QApplication + startup flow)   │
                    └───────────────┬─────────────────┘
                                    │
                    ┌───────────────▼─────────────────┐
                    │        main_window.py            │  UI + orchestration
                    │       (AuraDownloader)           │
                    └─┬───┬───┬───┬───┬───┬───┬───┬──┘
                      │   │   │   │   │   │   │   │
        ┌─────────────┘   │   │   │   │   │   │   └──────────────┐
        │                 │   │   │   │   │   │                  │
   ┌────▼────┐    ┌───────▼──┐│ ┌─▼───▼─┐│ ┌─▼──────────┐  ┌───▼──────┐
   │ workers │    │ dialogs  ││ │widgets ││ │   core     │  │ themes   │
   │         │    │          ││ │        ││ │            │  │          │
   │download │    │format    ││ │speed   ││ │models     │  │THEMES    │
   │deps     │    │preview   ││ │graph   ││ │download   │  │build_qss │
   │formats  │    │player    ││ │        ││ │queue      │  │          │
   │preview  │    │cookie    ││ └────────┘│ └─────┬─────┘  └────┬─────┘
   │subscrip.│    │selectors ││           │       │             │
   └────┬────┘    │config_loc││           │       │             │
        │         └──────────┘│           │       │             │
        │                     │           │       │             │
   ┌────▼─────────────────────▼───────────▼───────▼─────────────▼──┐
   │                    FOUNDATION LAYER                            │
   │  constants.py │ utils.py │ platforms.py │ translations/       │
   │  database.py  │ settings.py                                   │
   └───────────────────────────────────────────────────────────────┘
```

**Rule: arrows point downward only.** No module imports from a layer above it. `main_window.py` is the only module that imports from all layers.

---

## Module responsibilities

### Foundation (no Qt dependency)

| Module | Responsibility |
|--------|---------------|
| `constants.py` | Regex patterns, subprocess flags, quality/format tables, auth methods |
| `utils.py` | File paths, encoding fixes, subprocess env, atomic JSON write, error logging, process tracking |
| `platforms.py` | 17 platform configs (domains, login URLs, capabilities, UI labels) |
| `translations/` | JSON-based i18n loader with `{current_year}` substitution |
| `database.py` | SQLite layer: downloads table, subscriptions table, session recovery table |
| `settings.py` | Per-platform JSON config with auto-migration and corruption recovery |

### Core (business logic, no Qt)

| Module | Responsibility |
|--------|---------------|
| `core/models.py` | Typed dataclasses: `DownloadEntry`, `FormatInfo`, `VideoMetadata`, `ParallelWorkerState`, `DownloadParams` |
| `core/download_queue.py` | Priority download queue: `HIGH` (user) > `NORMAL` (queued) > `LOW` (subscriptions) |

### Workers (QThread, no UI widgets)

| Module | Responsibility |
|--------|---------------|
| `workers/download.py` | Runs yt-dlp subprocess with real-time stdout streaming |
| `workers/deps.py` | Checks yt-dlp/ffmpeg/aria2c/node availability in background |
| `workers/formats.py` | Fetches format list via `yt-dlp --dump-json` |
| `workers/preview.py` | Fetches video metadata + downloads thumbnails |
| `workers/subscriptions.py` | Checks channel for new videos via `--flat-playlist` |

### Dialogs (Qt, self-contained)

| Module | Responsibility |
|--------|---------------|
| `dialogs/format_dialog.py` | Tree widget for format selection |
| `dialogs/preview_dialog.py` | Metadata display with thumbnail |
| `dialogs/player_dialog.py` | QMediaPlayer-based video player |
| `dialogs/cookie_browser.py` | QWebEngine login for cookie extraction |
| `dialogs/selectors.py` | Language, theme, platform selection dialogs |
| `dialogs/config_location.py` | First-run settings path selection |

### Main window

`main_window.py` (AuraDownloader) — the orchestration layer. Builds UI, wires signals, delegates to workers. Split into 16 `_build_section_*` methods for maintainability.

---

## Threading model

```
Main thread (Qt event loop)
├── UI rendering + event handling
├── Signal delivery (all slots run here)
├── Timer callbacks (_flush_progress_ui, _flush_log_buffer, _scheduler_tick)
│
├── QThread: DownloadWorker (1 per download)
│   └── subprocess.Popen(yt-dlp) → stdout line-by-line → log_signal/progress_signal
│
├── QThread: DownloadWorker ×N (parallel mode, N=1..5)
│   └── Each with own Popen and signal connections
│
├── QThread: FormatListWorker, PreviewWorker, SubCheckWorker
│   └── subprocess.run() → result_signal/error_signal
│
├── QThread: DepsWorker
│   └── Checks binary paths → results_ready signal
│
└── threading.Thread: _download_with_restart
    └── Sequential Popen runs → cross-thread signals (_sig_log, _sig_progress)
```

**Signal safety:** All worker→UI communication uses Qt signals (thread-safe). The only `threading.Thread` (`_download_with_restart`) emits signals via `_sig_log`/`_sig_progress` — safe because Qt serializes cross-thread signal delivery.

**Process tracking:** All `subprocess.Popen` objects are registered in `utils.tracked_processes`. An `atexit` handler terminates them on interpreter exit (prevents zombie yt-dlp processes).

---

## Performance optimizations

| Optimization | Mechanism | Impact |
|---|---|---|
| Progress UI throttle | Buffer values, flush at 10 Hz via QTimer | ~10× fewer widget repaints |
| Log batching | Buffer lines, flush every 150ms | ~30× fewer QPlainTextEdit inserts |
| Download queue | `DownloadQueue` with priority ordering | No UI blocking when queueing |
| Parallel downloads | N interleaved DownloadWorkers with archive splitting | Linear speedup for playlists |

---

## Data persistence

```
settings_dir/
├── config_youtube.json      Per-platform settings (atomic write + .bak)
├── config_vk.json
├── history_youtube.json     Legacy download history (atomic write + .bak)
├── aura_downloads.db        SQLite database (downloads + subscriptions + sessions)
├── archive_youtube.txt      yt-dlp download archive (skip already-downloaded)
├── cookies_youtube.txt      Extracted cookies (Netscape format)
├── presets_youtube.json     Smart Mode presets
└── yt-dlp.conf              yt-dlp configuration file
```

**Crash safety chain:**
1. Before download: session auto-saved to `session_queue` table
2. During download: process tracked in `utils.tracked_processes`
3. After download: session cleared, history saved atomically
4. On crash: `atexit` kills subprocesses; next startup offers session recovery

---

## Adding a new platform

1. Add entry to `PLATFORM_CONFIGS` in `platforms.py`:
   ```python
   "newplatform": {
       "name": "NewPlatform", "icon": "🆕", "color": "#FF0000", "hover": "#CC0000",
       "category": CAT_VIDEO,
       "domains": ["newplatform.com"],
       "login_url": "https://newplatform.com/login",
       "has_channels": True, "has_playlists": True,
       "url_examples": { "channel": "...", "video": "..." },
   }
   ```
2. Run `python -m pytest aura/tests/test_platforms.py -v` — all schema checks pass automatically
3. Run `python -m pytest aura/tests/test_smoke.py -v` — UI creation verified

No other code changes needed — yt-dlp handles the actual extraction.

---

## Adding a new translation

1. Copy `translations/en.json` → `translations/xx.json`
2. Translate all 536 values
3. The loader auto-discovers new JSON files — no code changes needed
4. Run `python -m pytest aura/tests/test_translations.py -v` to verify key parity
