#!/usr/bin/env python3
from __future__ import annotations

"""Visual themes and QSS stylesheet generation."""

import json

from aura.utils import atomic_write_json, get_settings_dir, is_debug_mode, resource_path

THEMES = {
    "dark": {
        "name_ru": "Ночная студия",
        "name_en": "Night Studio",
        "btn_color": "#1c2333",
        "btn_hover": "#26314a",
        "selector_bg": "#101723",
        "selector_fg": "#eef4ff",
        "colors": {
            "bg_deep": "#0b1220",
            "bg_main": "#121a2b",
            "bg_card": "#182235",
            "bg_entry": "#0f1727",
            "bg_button": "#21304a",
            "bg_hover": "#2a3d5d",
            "accent": "#10b981",
            "accent2": "#38bdf8",
            "green": "#10b981",
            "green_hover": "#059669",
            "red": "#ef4444",
            "red_hover": "#dc2626",
            "text": "#eef4ff",
            "text_dim": "#b5c3d9",
            "text_hint": "#7b8ba7",
            "border": "#2a3953",
            "select": "#214263",
            "log_bg": "#09101d",
            "log_fg": "#dce8ff",
        },
    },
    "gray": {
        "name_ru": "Стальной лаунж",
        "name_en": "Steel Lounge",
        "btn_color": "#505764",
        "btn_hover": "#626b79",
        "selector_bg": "#313844",
        "selector_fg": "#f5f7fb",
        "colors": {
            "bg_deep": "#252a33",
            "bg_main": "#313844",
            "bg_card": "#3a4351",
            "bg_entry": "#2d3440",
            "bg_button": "#566171",
            "bg_hover": "#657286",
            "accent": "#f59e0b",
            "accent2": "#22c55e",
            "green": "#22c55e",
            "green_hover": "#16a34a",
            "red": "#ef4444",
            "red_hover": "#dc2626",
            "text": "#f5f7fb",
            "text_dim": "#d2dae6",
            "text_hint": "#c3cedd",
            "border": "#697587",
            "select": "#5f738d",
            "log_bg": "#20262f",
            "log_fg": "#edf2fb",
        },
    },
    "light": {
        "name_ru": "Премиум-холст",
        "name_en": "Canvas Pro",
        "btn_color": "#eef2f7",
        "btn_hover": "#dde4ee",
        "selector_bg": "#f6f8fb",
        "selector_fg": "#1f2937",
        "colors": {
            "bg_deep": "#eef2f7",
            "bg_main": "#f8fafc",
            "bg_card": "#ffffff",
            "bg_entry": "#ffffff",
            "bg_button": "#eef2f7",
            "bg_hover": "#dde5f0",
            "accent": "#0f766e",
            "accent2": "#0284c7",
            "green": "#16a34a",
            "green_hover": "#15803d",
            "red": "#dc2626",
            "red_hover": "#b91c1c",
            "text": "#142033",
            "text_dim": "#475569",
            "text_hint": "#5b6f87",
            "border": "#d8e0ea",
            "select": "#c9e7e4",
            "log_bg": "#f4f7fb",
            "log_fg": "#162032",
        },
    },
}

DEFAULT_THEME = "light"


def get_theme_config() -> str:
    """Load saved theme from shared config."""
    try:
        general_config = get_settings_dir() / "general.json"
        if general_config.exists():
            data = json.loads(general_config.read_text(encoding="utf-8"))
            theme = data.get("theme", DEFAULT_THEME)
            if theme in THEMES:
                return theme
    except Exception:
        pass
    return DEFAULT_THEME


def save_theme_config(theme_id):
    """Save chosen theme to shared config."""
    if is_debug_mode():
        return
    if theme_id not in THEMES:
        return
    try:
        general_config = get_settings_dir() / "general.json"
        general_config.parent.mkdir(parents=True, exist_ok=True)
        data = {}
        if general_config.exists():
            try:
                data = json.loads(general_config.read_text(encoding="utf-8"))
            except Exception:
                pass
        data["theme"] = theme_id
        atomic_write_json(general_config, data)
    except Exception:
        pass


def build_qss(C):
    """Generate premium-looking Qt stylesheet from theme colors."""
    check_icon = resource_path("aura/assets/checkmark.svg").replace("\\", "/")
    return f"""
    QMainWindow, QDialog {{
        background-color: {C['bg_main']};
        color: {C['text']};
    }}

    QWidget {{
        color: {C['text']};
        font-family: 'Segoe UI Variable Display', 'Segoe UI', 'Helvetica Neue', sans-serif;
        font-size: 10pt;
    }}

    QWidget#appChrome, QWidget#workspaceSurface, QWidget#workspaceContent,
    QWidget#logSurface, QWidget#activityContent, QWidget#statusChrome {{
        background: {C['bg_main']};
    }}

    QFrame#topBar, QToolBar {{
        background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
            stop:0 {C['bg_card']}, stop:1 {C['bg_main']});
        border: none;
        border-bottom: 1px solid {C['border']};
    }}

    QFrame#topBar QLabel, QToolBar QLabel {{
        color: {C['accent']};
        font-size: 12pt;
        font-weight: 800;
    }}

    QLabel#toolbarBrand {{
        color: {C['text']};
        font-size: 11.4pt;
        font-weight: 800;
    }}

    QLabel#toolbarMeta {{
        color: {C['text_dim']};
        font-size: 8.5pt;
        font-weight: 600;
    }}

    QLineEdit#toolbarUrlField {{
        background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
            stop:0 {C['bg_entry']}, stop:1 {C['bg_card']});
        border: 1px solid {C['border']};
        border-radius: 14px;
        padding: 9px 12px;
        font-size: 10.2pt;
    }}

    QLineEdit#toolbarUrlField:hover {{
        border-color: {C['accent2']};
        background: {C['bg_card']};
    }}

    QLineEdit#toolbarUrlField:focus {{
        border: 1px solid {C['accent']};
        background: {C['bg_card']};
    }}

    QLabel#toolbarChip, QLabel#panelStatus {{
        background: {C['bg_button']};
        color: {C['accent']};
        border: 1px solid {C['border']};
        border-radius: 12px;
        padding: 4px 10px;
        font-size: 8.8pt;
        font-weight: 700;
    }}

    QFrame#sidebarCard {{
        background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
            stop:0 {C['bg_card']}, stop:1 {C['bg_deep']});
        border: 1px solid {C['border']};
        border-radius: 18px;
    }}

    QLabel#sidebarEyebrow {{
        color: {C['accent']};
        font-size: 10px;
        font-weight: 800;
        letter-spacing: 0.08em;
    }}

    QLabel#sidebarTitle {{
        color: {C['text']};
        font-size: 14.2pt;
        font-weight: 800;
    }}

    QLabel#sidebarMeta {{
        color: {C['text_dim']};
        font-size: 8.5pt;
    }}

    QLabel#sidebarChip {{
        background: {C['bg_button']};
        color: {C['accent']};
        border: 1px solid {C['border']};
        border-radius: 14px;
        padding: 5px 10px;
        font-size: 9pt;
        font-weight: 700;
    }}

    QFrame#sidebarSection {{
        background: {C['bg_card']};
        border: 1px solid {C['border']};
        border-radius: 13px;
    }}

    QLabel#sidebarSectionTitle {{
        color: {C['text']};
        font-size: 10pt;
        font-weight: 700;
    }}

    QLabel#sidebarInsightValue {{
        color: {C['accent2']};
        font-size: 14pt;
        font-weight: 800;
    }}

    QLabel#sidebarInsightMeta {{
        color: {C['text_hint']};
        font-size: 8.2pt;
    }}

    QFrame#sidebarInsightCard {{
        background: {C['bg_button']};
        border: 1px solid {C['border']};
        border-radius: 12px;
    }}

    QPushButton#sidebarQuickBtn {{
        background: {C['bg_button']};
        color: {C['text']};
        border: 1px solid {C['border']};
        border-radius: 10px;
        padding: 8px 11px;
        text-align: left;
        font-weight: 700;
    }}

    QPushButton#sidebarQuickBtn:hover {{
        background: {C['bg_hover']};
        border-color: {C['accent']};
    }}

    QPushButton#sidebarNavBtn {{
        background: {C['bg_main']};
        color: {C['text_dim']};
        border: 1px solid {C['border']};
        border-radius: 12px;
        padding: 7px 10px;
        text-align: left;
        font-weight: 600;
    }}

    QPushButton#sidebarNavBtn:hover {{
        background: {C['bg_button']};
        color: {C['text']};
        border-color: {C['border']};
    }}

    QPushButton#sidebarNavBtn:checked {{
        background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
            stop:0 {C['accent']}, stop:1 {C['accent2']});
        color: white;
        border-color: transparent;
    }}

    QFrame#heroCard {{
        background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
            stop:0 {C['bg_card']}, stop:0.58 {C['bg_main']}, stop:1 {C['bg_deep']});
        border: 1px solid {C['border']};
        border-radius: 18px;
    }}

    QLabel#heroTitle {{
        color: {C['text']};
        font-size: 16.5pt;
        font-weight: 800;
        letter-spacing: 0.1px;
    }}

    QLabel#heroSubtitle {{
        color: {C['text_dim']};
        font-size: 9.1pt;
    }}

    QLabel#heroGuide {{
        background: {C['bg_card']};
        border: 1px solid {C['border']};
        border-radius: 14px;
        padding: 8px 10px;
        color: {C['text_dim']};
    }}

    QFrame#workflowCard {{
        background: {C['bg_card']};
        border: 1px solid {C['border']};
        border-radius: 16px;
    }}

    QLabel#workflowStep {{
        color: {C['accent']};
        font-size: 14pt;
        font-weight: 800;
    }}

    QLabel#workflowTitle {{
        color: {C['text']};
        font-size: 10pt;
        font-weight: 700;
    }}

    QLabel#workflowBody {{
        color: {C['text_dim']};
        font-size: 8.8pt;
    }}

    QPushButton#heroAction {{
        background: {C['bg_button']};
        border: 1px solid {C['border']};
        border-radius: 10px;
        padding: 7px 9px;
        font-weight: 700;
    }}

    QPushButton#heroAction:hover {{
        background: {C['bg_hover']};
        border-color: {C['accent']};
    }}

    QLabel#heroChip {{
        background: {C['accent']};
        color: white;
        border-radius: 12px;
        padding: 5px 12px;
        font-weight: 700;
    }}

    QLabel#heroChipAlt {{
        background: {C['bg_button']};
        color: {C['text']};
        border: 1px solid {C['border']};
        border-radius: 12px;
        padding: 5px 12px;
        font-weight: 600;
    }}

    QFrame#heroStats {{
        background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
            stop:0 {C['bg_card']}, stop:1 {C['bg_button']});
        border: 1px solid {C['border']};
        border-radius: 16px;
    }}

    QFrame#heroSmartCard {{
        background: {C['bg_card']};
        border: 1px solid {C['border']};
        border-radius: 16px;
    }}

    QLabel#heroSmartTitle {{
        color: {C['accent']};
        font-size: 8.8pt;
        font-weight: 800;
        letter-spacing: 0.04em;
    }}

    QLabel#heroSmartValue {{
        color: {C['text']};
        font-size: 10pt;
        font-weight: 700;
    }}

    QLabel#heroSmartMeta {{
        color: {C['text_dim']};
        font-size: 8.6pt;
    }}

    QLabel#heroStatValue {{
        color: {C['text']};
        font-size: 13.5pt;
        font-weight: 800;
    }}

    QLabel#heroStatLabel {{
        color: {C['text_dim']};
        font-size: 8.4pt;
    }}

    QPushButton {{
        background: {C['bg_button']};
        color: {C['text']};
        border: 1px solid {C['border']};
        border-radius: 9px;
        padding: 7px 12px;
        font-weight: 600;
    }}

    QPushButton:hover {{
        background: {C['bg_hover']};
    }}

    QPushButton:pressed {{
        background: {C['bg_hover']};
        color: {C['text']};
        border-color: {C['accent']};
    }}

    QPushButton:disabled {{
        background: {C['bg_deep']};
        color: {C['text_hint']};
        border-color: {C['bg_deep']};
    }}

    QPushButton#navPill {{
        background: {C['bg_card']};
        color: {C['text_dim']};
        border: 1px solid {C['border']};
        border-radius: 16px;
        padding: 8px 15px;
        font-weight: 700;
    }}

    QPushButton#navPill:hover {{
        background: {C['bg_hover']};
        color: {C['text']};
        border-color: {C['accent2']};
    }}

    QPushButton#navPill:checked {{
        background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
            stop:0 {C['accent']}, stop:1 {C['accent2']});
        color: white;
        border-color: transparent;
    }}

    QFrame#workspaceSubnav {{
        background: {C['bg_main']};
        border: none;
    }}

    QTabWidget#workspaceTabs::pane {{
        border: none;
        background: {C['bg_main']};
        margin-top: 8px;
    }}

    QTabWidget#workspaceTabs QTabBar::tab {{
        background: {C['bg_button']};
        color: {C['text_dim']};
        border: 1px solid {C['border']};
        border-top-left-radius: 12px;
        border-top-right-radius: 12px;
        padding: 6px 9px;
        min-width: 64px;
        font-weight: 700;
        margin-right: 4px;
    }}

    QTabWidget#workspaceTabs QTabBar::tab:hover {{
        background: {C['bg_hover']};
        color: {C['text']};
        border-color: {C['accent']};
    }}

    QTabWidget#workspaceTabs QTabBar::tab:selected {{
        background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
            stop:0 {C['accent']}, stop:1 {C['accent2']});
        color: white;
        border-color: transparent;
    }}

    QWidget#workspacePage {{
        background: {C['bg_main']};
    }}

    QWidget#workspaceColumns, QWidget#workspaceColumn {{
        background: {C['bg_main']};
    }}

    QPushButton#startBtn {{
        background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
            stop:0 {C['green']}, stop:1 {C['accent2']});
        color: white;
        font-weight: 800;
        font-size: 10.2pt;
        padding: 8px 18px;
        border: none;
        border-radius: 10px;
    }}

    QPushButton#startBtn:hover {{
        background: {C['green_hover']};
    }}

    QPushButton#startBtn:pressed {{
        background: {C['green_hover']};
        color: white;
    }}

    QPushButton#stopBtn {{
        background: {C['red']};
        color: white;
        font-weight: 800;
        padding: 8px 14px;
        border: none;
        border-radius: 10px;
    }}

    QPushButton#stopBtn:hover {{
        background: {C['red_hover']};
    }}

    QPushButton#stopBtn:pressed,
    QPushButton#dangerBtn:pressed {{
        background: {C['red_hover']};
        color: white;
    }}

    QPushButton#accentBtn {{
        background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
            stop:0 {C['accent']}, stop:1 {C['accent2']});
        color: white;
        border: none;
        border-radius: 10px;
        font-weight: 700;
    }}

    QPushButton#dangerBtn {{
        background: {C['red']};
        color: white;
        border: none;
        border-radius: 10px;
        font-weight: 700;
    }}

    QPushButton#dangerBtn:hover {{
        background: {C['red_hover']};
    }}

    QPushButton#accentBtn:pressed, QPushButton#navPill:pressed, QPushButton#navPill:checked {{
        background: {C['accent']};
        color: white;
        border-color: {C['accent']};
    }}

    QPushButton#ghostBtn, QPushButton#iconBtn {{
        background: {C['bg_card']};
        border: 1px solid {C['border']};
    }}

    QPushButton#ghostBtn:hover, QPushButton#iconBtn:hover {{
        background: {C['bg_hover']};
        border-color: {C['accent']};
    }}

    QLineEdit, QToolBar QLineEdit {{
        background: {C['bg_entry']};
        color: {C['text']};
        border: 1px solid {C['border']};
        border-radius: 9px;
        padding: 7px 10px;
        selection-background-color: {C['select']};
    }}

    QLineEdit:hover {{
        border-color: {C['accent2']};
    }}

    QLineEdit:focus, QComboBox:focus {{
        border-color: {C['accent']};
    }}

    QLineEdit#pathField {{
        background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
            stop:0 {C['bg_entry']}, stop:1 {C['bg_card']});
        border-radius: 12px;
        padding: 9px 12px;
        font-family: 'Cascadia Code', 'Consolas', monospace;
    }}

    QLineEdit#pathField:hover {{
        border-color: {C['accent2']};
        background: {C['bg_hover']};
    }}

    QLineEdit#pathField:focus {{
        border: 1px solid {C['accent']};
        background: {C['bg_main']};
    }}

    QLineEdit#proxyField {{
        border-radius: 12px;
        padding: 9px 12px;
    }}

    QLineEdit#searchField {{
        border-radius: 999px;
        padding: 8px 14px;
        background: {C['bg_card']};
    }}

    QScrollArea#workspaceScroll {{
        border: none;
        background: {C['bg_main']};
    }}

    QScrollArea#workspaceScroll > QWidget > QWidget {{
        background: {C['bg_main']};
    }}

    QLineEdit#compactField, QComboBox#compactCombo {{
        border-radius: 999px;
        min-height: 18px;
    }}

    QLineEdit#compactField {{
        padding: 7px 10px;
        background: {C['bg_card']};
        font-family: 'Cascadia Code', 'Consolas', monospace;
    }}

    QComboBox#compactCombo {{
        padding: 6px 28px 6px 12px;
        background: {C['bg_card']};
    }}

    QComboBox {{
        background: {C['bg_entry']};
        color: {C['text']};
        border: 1px solid {C['border']};
        border-radius: 9px;
        padding: 7px 28px 7px 10px;
        min-height: 22px;
    }}

    QComboBox::drop-down {{
        border: none;
        width: 24px;
    }}

    QComboBox QAbstractItemView {{
        background: {C['bg_card']};
        color: {C['text']};
        selection-background-color: {C['accent']};
        selection-color: white;
        border: 1px solid {C['border']};
    }}

    QRadioButton, QCheckBox {{
        spacing: 7px;
        color: {C['text']};
        padding: 3px 0;
    }}

    QRadioButton::indicator, QCheckBox::indicator {{
        width: 18px;
        height: 18px;
    }}

    QRadioButton::indicator {{
        border: 2px solid {C['border']};
        border-radius: 9px;
        background: {C['bg_entry']};
    }}

    QRadioButton::indicator:checked {{
        border-color: {C['accent']};
        background: {C['accent']};
    }}

    QCheckBox::indicator {{
        border: 2px solid {C['border']};
        border-radius: 6px;
        background: {C['bg_entry']};
    }}

    QCheckBox::indicator:checked {{
        border-color: {C['accent']};
        background: {C['accent']};
        image: url("{check_icon}");
    }}

    QRadioButton:hover, QCheckBox:hover {{
        color: {C['accent']};
    }}

    QGroupBox {{
        background: {C['bg_card']};
        border: 1px solid {C['border']};
        border-radius: 16px;
        margin-top: 14px;
        padding: 20px 14px 12px 14px;
        font-weight: 700;
    }}

    QGroupBox::title {{
        subcontrol-origin: margin;
        left: 14px;
        padding: 0 8px;
        color: {C['accent']};
        font-size: 10pt;
    }}

    QGroupBox#featureCard {{
        background: {C['bg_card']};
    }}

    QPlainTextEdit {{
        background: {C['log_bg']};
        color: {C['log_fg']};
        border: 1px solid {C['border']};
        border-bottom-left-radius: 16px;
        border-bottom-right-radius: 16px;
        font-family: 'Cascadia Code', 'Consolas', monospace;
        font-size: 10pt;
    }}

    QFrame#commandCenter {{
        background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
            stop:0 {C['bg_card']}, stop:1 {C['bg_main']});
        border: 1px solid {C['border']};
        border-top-left-radius: 16px;
        border-top-right-radius: 16px;
        border-bottom: none;
    }}

    QWidget#panelHeaderBlock {{
        background: {C['bg_card']};
        border: 1px solid {C['border']};
        border-radius: 14px;
    }}

    QWidget#logFileBlock {{
        background: {C['bg_card']};
        border-left: 1px solid {C['border']};
        border-right: 1px solid {C['border']};
    }}

    QLabel#panelTitle {{
        color: {C['text']};
        font-size: 11.5pt;
        font-weight: 800;
    }}

    QLabel#panelMeta {{
        color: {C['text_dim']};
        font-size: 8.8pt;
    }}

    QLabel#panelMetric {{
        color: {C['text_dim']};
        background: {C['bg_button']};
        border: 1px solid {C['border']};
        border-radius: 9px;
        padding: 5px 9px;
        font-size: 8.6pt;
        font-weight: 700;
    }}

    QPushButton#panelAction {{
        background: {C['bg_button']};
        border-radius: 10px;
        padding: 6px 10px;
        font-size: 8.8pt;
    }}

    QFrame#executionPreviewCard {{
        background: {C['bg_card']};
        border: 1px solid {C['border']};
        border-radius: 14px;
    }}

    QLabel#executionTitle {{
        color: {C['text']};
        font-size: 10.5pt;
        font-weight: 800;
    }}

    QLabel#executionBody {{
        color: {C['text_dim']};
        font-size: 9.2pt;
    }}

    QLabel#executionChip {{
        background: {C['bg_button']};
        color: {C['text']};
        border: 1px solid {C['border']};
        border-radius: 10px;
        padding: 5px 9px;
        font-size: 8.6pt;
        font-weight: 700;
    }}

    QLabel#executionHint {{
        color: {C['text_dim']};
        font-size: 8.8pt;
    }}

    QPlainTextEdit#commandPreviewBox {{
        background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
            stop:0 {C['log_bg']}, stop:1 {C['bg_deep']});
        color: {C['log_fg']};
        border: 1px solid {C['border']};
        border-radius: 12px;
        padding: 5px 7px;
        font-family: 'Cascadia Code', 'Consolas', monospace;
        font-size: 8.8pt;
    }}

    QTreeWidget {{
        background: {C['bg_entry']};
        alternate-background-color: {C['bg_main']};
        border: 1px solid {C['border']};
        border-radius: 12px;
        color: {C['text']};
    }}

    QTreeWidget#dataTree {{
        background: {C['bg_card']};
        border-radius: 14px;
    }}

    QTreeWidget::item {{
        padding: 7px 8px;
    }}

    QTreeWidget::item:selected {{
        background: {C['accent']};
        color: white;
    }}

    QTreeWidget::item:hover {{
        background: {C['bg_hover']};
    }}

    QHeaderView::section {{
        background: {C['bg_button']};
        color: {C['text']};
        padding: 7px 8px;
        border: none;
        border-right: 1px solid {C['border']};
        font-weight: 700;
    }}

    QProgressBar {{
        background: {C['bg_deep']};
        border: none;
        border-radius: 5px;
        height: 8px;
        text-align: center;
    }}

    QProgressBar::chunk {{
        background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
            stop:0 {C['green']}, stop:1 {C['accent2']});
        border-radius: 5px;
    }}

    QStatusBar {{
        background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
            stop:0 {C['bg_card']}, stop:1 {C['bg_main']});
        border-top: 1px solid {C['border']};
        color: {C['text_dim']};
        font-size: 9pt;
    }}

    QSplitter::handle:vertical {{
        background: {C['bg_button']};
        height: 8px;
        margin: 1px 16px;
        border-radius: 4px;
        border: 1px solid {C['border']};
    }}

    QSplitter::handle:vertical:hover {{
        background: {C['accent']};
    }}

    QScrollBar:vertical {{
        background: {C['bg_deep']};
        width: 10px;
        border: none;
    }}

    QScrollBar::handle:vertical {{
        background: {C['bg_button']};
        border-radius: 5px;
        min-height: 30px;
    }}

    QScrollBar::handle:vertical:hover {{
        background: {C['accent']};
    }}

    QScrollBar:horizontal {{
        background: {C['bg_deep']};
        height: 10px;
        border: none;
    }}

    QScrollBar::handle:horizontal {{
        background: {C['bg_button']};
        border-radius: 5px;
        min-width: 30px;
    }}

    QScrollBar::handle:horizontal:hover {{
        background: {C['accent']};
    }}

    QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical,
    QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {{
        width: 0px;
        height: 0px;
    }}

    QToolTip {{
        background: {C['bg_card']};
        color: {C['text']};
        border: 1px solid {C['accent']};
        border-radius: 6px;
        padding: 6px 10px;
    }}

    QLabel#sectionLabel {{
        font-size: 11pt;
        font-weight: 700;
        color: {C['accent']};
    }}

    QLabel#hintLabel {{
        color: {C['text_hint']};
        font-size: 8.6pt;
    }}

    QLabel#depStatus {{
        color: {C['text_hint']};
        background: {C['bg_button']};
        border: 1px solid {C['border']};
        border-radius: 999px;
        padding: 4px 10px;
        font-size: 9pt;
        font-weight: 700;
    }}

    QLabel#depStatus[status="pending"] {{
        color: {C['text_hint']};
    }}

    QLabel#depStatus[status="ok"] {{
        color: {C['green']};
        border-color: {C['green_hover']};
    }}

    QLabel#depStatus[status="error"] {{
        color: {C['red']};
        border-color: {C['red_hover']};
    }}

    QLabel#depStatus[status="warning"] {{
        color: {C['accent2']};
        border-color: {C['accent2']};
    }}

    QLabel#depStatus[status="optional"] {{
        color: {C['text_dim']};
        border-color: {C['border']};
    }}

    QLabel#sectionNote {{
        color: {C['text_dim']};
        font-size: 8.7pt;
        padding-bottom: 2px;
    }}

    QLabel#sectionBadge {{
        color: {C['accent']};
        background: {C['bg_button']};
        border: 1px solid {C['border']};
        border-radius: 999px;
        padding: 3px 9px;
        font-size: 8.5pt;
        font-weight: 700;
    }}

    QFrame#exampleCard {{
        background: {C['bg_card']};
        border: 1px solid {C['border']};
        border-radius: 12px;
    }}

    QLabel#exampleTitle {{
        color: {C['accent']};
        font-size: 8.7pt;
        font-weight: 700;
    }}

    QLabel#exampleText {{
        color: {C['text_dim']};
        font-size: 8.7pt;
    }}

    QLabel#statusLabel {{
        color: {C['accent']};
        font-family: 'Cascadia Code', 'Consolas', monospace;
        font-weight: 700;
    }}

    QFrame#separator {{
        background: {C['border']};
        max-height: 1px;
    }}
    """
