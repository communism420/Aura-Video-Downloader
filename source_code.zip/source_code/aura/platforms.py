#!/usr/bin/env python3
from __future__ import annotations

"""Platform configurations for all supported video sites."""

from typing import Any

# Категории платформ
CAT_VIDEO = "video"
CAT_SOCIAL = "social"
CAT_ADULT = "adult"

CATEGORY_INFO = {
    CAT_VIDEO:     {"icon": "🎬", "name_ru": "Видеоплатформы",   "name_en": "Video Platforms"},
    CAT_SOCIAL:    {"icon": "📱", "name_ru": "Социальные сети",  "name_en": "Social Media"},
    CAT_ADULT:     {"icon": "🔞", "name_ru": "Для взрослых",     "name_en": "Adult"},
}

# Порядок категорий в селекторе
CATEGORY_ORDER = [CAT_VIDEO, CAT_SOCIAL, CAT_ADULT]

PLATFORM_CONFIGS = {
    # ── VIDEO ─────────────────────────────────────────────────────────────
    "youtube": {
        "name": "YouTube", "icon": "▶️", "color": "#FF0000", "hover": "#CC0000",
        "category": CAT_VIDEO,
        "domains": ["youtube.com", "youtu.be", "m.youtube.com"],
        "browse_url": "https://www.youtube.com/",
        "search_url": "https://www.youtube.com/results?search_query={query}",
        "search_prefix": "ytsearch",
        "login_url": "https://accounts.google.com/ServiceLogin?service=youtube&continue=https://www.youtube.com/",
        "has_channels": True, "has_playlists": True,
        "has_audio_lang": True, "needs_nodejs": True,
        "use_ytdlp_config": True, "normalize_channel_url": True,
        "channel_label":  {"ru": "📺 Канал",              "en": "📺 Channel"},
        "channel_desc":   {"ru": "Все видео с канала",     "en": "All videos from channel"},
        "url_label_channel": {"ru": "🔗 URL канала:",      "en": "🔗 Channel URL:"},
        "url_examples": {
            "channel":  "youtube.com/@handle  |  youtube.com/channel/UCxxxxxx",
            "playlist": "youtube.com/playlist?list=PLxxxxxx",
            "video":    "youtube.com/watch?v=xxxxxx  |  youtu.be/xxxxxx",
            "search":   "funny cats 2026  |  lo-fi beats mix  |  https://www.youtube.com/results?search_query=python+tutorial",
        },
        "warn_mass_audio": {
            "ru": "⚠️ Аудио со всего канала...\n\n🤔 А вы задумывались, что 90% видео на YouTube\nбез картинки — это просто странные звуки\nи фраза «как вы видите на экране»?\n\nНо кто я такой, чтобы вас останавливать.\nПродолжить?",
            "en": "⚠️ Audio from the entire channel...\n\n🤔 Have you considered that 90% of YouTube videos\nwithout the picture are just weird sounds\nand the phrase \"as you can see on the screen\"?\n\nBut who am I to stop you.\nContinue?",
        },
    },
    "vk": {
        "name": "VK Video", "icon": "📹", "color": "#0077FF", "hover": "#0059CC",
        "category": CAT_VIDEO,
        "domains": ["vk.com", "vkvideo.ru", "vk.ru", "m.vk.com"],
        "login_url": "https://id.vk.com/auth",
        "has_channels": True, "has_playlists": True,
        "channel_label":  {"ru": "👥 Сообщество",                        "en": "👥 Community"},
        "channel_desc":   {"ru": "Все видео сообщества / пользователя",  "en": "All videos from community / user"},
        "url_label_channel": {"ru": "🔗 URL страницы с видео:",          "en": "🔗 Video page URL:"},
        "url_examples": {
            "channel":  "vk.com/videos-123456  |  vkvideo.ru/@user/videos",
            "playlist": "vk.com/video/playlist/-123456_1  |  vkvideo.ru/playlist/-123456_1",
            "video":    "vk.com/video-123456_789  |  vk.com/clip-123456_789",
        },
    },
    "rutube": {
        "name": "Rutube", "icon": "🔴", "color": "#1B1F3B", "hover": "#2B2F5B",
        "category": CAT_VIDEO,
        "domains": ["rutube.ru"],
        "login_url": "https://rutube.ru/signin/",
        "has_channels": True, "has_playlists": True,
        "channel_label": {"ru": "📺 Канал",            "en": "📺 Channel"},
        "channel_desc":  {"ru": "Все видео с канала",   "en": "All videos from channel"},
        "url_examples": {
            "channel":  "rutube.ru/channel/123456/videos/",
            "playlist": "rutube.ru/plst/123456/",
            "video":    "rutube.ru/video/xxxxxxxxxxxxxxxx/",
        },
    },
    "twitch": {
        "name": "Twitch", "icon": "🟣", "color": "#9146FF", "hover": "#7B2FFF",
        "category": CAT_VIDEO,
        "domains": ["twitch.tv"],
        "login_url": "https://www.twitch.tv/login",
        "has_channels": True, "has_playlists": True,
        "channel_label": {"ru": "📺 Канал",             "en": "📺 Channel"},
        "channel_desc":  {"ru": "Все VOD записи канала", "en": "All VODs from channel"},
        "url_examples": {
            "channel":  "twitch.tv/username/videos",
            "playlist": "twitch.tv/collections/xxxxxxxx",
            "video":    "twitch.tv/videos/123456789",
        },
    },
    "dailymotion": {
        "name": "Dailymotion", "icon": "🎬", "color": "#00A2E8", "hover": "#0082C8",
        "category": CAT_VIDEO,
        "domains": ["dailymotion.com", "dai.ly"],
        "login_url": "https://www.dailymotion.com/signin",
        "has_channels": True, "has_playlists": True,
        "channel_label": {"ru": "📺 Канал",           "en": "📺 Channel"},
        "channel_desc":  {"ru": "Все видео с канала",  "en": "All videos from channel"},
        "url_examples": {
            "channel":  "dailymotion.com/username",
            "playlist": "dailymotion.com/playlist/xxxxxx",
            "video":    "dailymotion.com/video/xxxxxx  |  dai.ly/xxxxxx",
        },
    },
    "vimeo": {
        "name": "Vimeo", "icon": "🎥", "color": "#1AB7EA", "hover": "#0EA0D0",
        "category": CAT_VIDEO,
        "domains": ["vimeo.com"],
        "login_url": "https://vimeo.com/log_in",
        "has_channels": True, "has_playlists": True,
        "channel_label": {"ru": "📺 Пользователь",        "en": "📺 User"},
        "channel_desc":  {"ru": "Все видео пользователя",  "en": "All user videos"},
        "url_examples": {
            "channel":  "vimeo.com/user123456",
            "playlist": "vimeo.com/album/123456  |  vimeo.com/showcase/123456",
            "video":    "vimeo.com/123456789",
        },
    },
    "bilibili": {
        "name": "Bilibili / Bilibili TV", "icon": "📺", "color": "#00A1D6", "hover": "#0081B6",
        "category": CAT_VIDEO,
        "domains": ["bilibili.com", "www.bilibili.com", "b23.tv", "bilibili.tv", "www.bilibili.tv"],
        "browse_url": "https://www.bilibili.com/",
        "search_url": "https://search.bilibili.com/all?keyword={query}",
        "login_url": "https://passport.bilibili.com/login",
        "has_channels": True, "has_playlists": True,
        "channel_label": {"ru": "👤 Пользователь",        "en": "👤 User"},
        "channel_desc":  {"ru": "Все видео пользователя",  "en": "All user videos"},
        "url_examples": {
            "channel":  "space.bilibili.com/123456",
            "playlist": "bilibili.com/medialist/detail/ml123456",
            "video":    "bilibili.com/video/BVxxxxxx  |  bilibili.tv/en/video/2041865230",
        },
    },
    "ok": {
        "name": "OK.ru", "icon": "🟠", "color": "#EE8208", "hover": "#CC6A00",
        "category": CAT_VIDEO,
        "domains": ["ok.ru"],
        "login_url": "https://connect.ok.ru/dk?cmd=AnonymLogin&st.redirect=https://ok.ru/",
        "has_channels": True, "has_playlists": True,
        "channel_label": {"ru": "👤 Профиль",                   "en": "👤 Profile"},
        "channel_desc":  {"ru": "Все видео профиля / группы",   "en": "All videos from profile / group"},
        "url_examples": {
            "channel":  "ok.ru/video/c123456",
            "playlist": "ok.ru/video/c123456/album/123456",
            "video":    "ok.ru/video/123456789",
        },
    },
    "dzen": {
        "name": "Дзен", "icon": "🔍", "color": "#FC3F1D", "hover": "#DC2F0D",
        "category": CAT_VIDEO,
        "domains": ["dzen.ru", "zen.yandex.ru"],
        "login_url": "https://passport.yandex.ru/auth?retpath=https://dzen.ru/",
        "has_channels": True, "has_playlists": False,
        "channel_label": {"ru": "📺 Канал",                "en": "📺 Channel"},
        "channel_desc":  {"ru": "Все видео с канала Дзен",  "en": "All Dzen channel videos"},
        "url_examples": {
            "channel": "dzen.ru/id/xxxxxx  |  dzen.ru/username",
            "video":   "dzen.ru/video/watch/xxxxxx",
        },
    },
    "rumble": {
        "name": "Rumble", "icon": "🟢", "color": "#85C742", "hover": "#6EAA35",
        "category": CAT_VIDEO,
        "domains": ["rumble.com"],
        "browse_url": "https://rumble.com/",
        "search_url": "https://rumble.com/search/video?q={query}",
        "search_prefix": "rbsearch",
        "login_url": "https://rumble.com/login.php",
        "has_channels": True, "has_playlists": False,
        "channel_label": {"ru": "📺 Канал", "en": "📺 Channel"},
        "channel_desc":  {"ru": "Все видео канала", "en": "All channel videos"},
        "url_examples": {
            "channel": "rumble.com/c/channelname",
            "video":   "rumble.com/vxxxxxx-title.html",
            "search":  "news recap 2026  |  rumble creators",
        },
    },
    "bitchute": {
        "name": "BitChute", "icon": "B", "color": "#F15B2A", "hover": "#D84B20",
        "category": CAT_VIDEO,
        "domains": ["bitchute.com", "www.bitchute.com"],
        "browse_url": "https://www.bitchute.com/",
        "search_url": "https://www.bitchute.com/search/?query={query}",
        "search_prefix": "bcsearch",
        "login_url": "https://www.bitchute.com/accounts/login/",
        "has_channels": True, "has_playlists": False,
        "channel_label": {"ru": "📺 Канал", "en": "📺 Channel"},
        "channel_desc":  {"ru": "Все видео канала", "en": "All channel videos"},
        "url_examples": {
            "channel": "bitchute.com/channel/abcdef/",
            "video":   "bitchute.com/video/abcdef/",
            "search":  "tech roundup  |  documentary clips",
        },
    },
    # ── SOCIAL ────────────────────────────────────────────────────────────
    "naver": {
        "name": "Naver TV / Blog", "icon": "N", "color": "#03C75A", "hover": "#029749",
        "category": CAT_VIDEO,
        "domains": ["tv.naver.com", "blog.naver.com"],
        "browse_url": "https://tv.naver.com/",
        "search_url": "https://search.naver.com/search.naver?where=video&query={query}",
        "login_url": "https://nid.naver.com/nidlogin.login",
        "has_channels": True, "has_playlists": False,
        "channel_label": {"ru": "Channel", "en": "Channel"},
        "channel_desc":  {"ru": "All clips from channel", "en": "All clips from channel"},
        "url_examples": {
            "channel": "tv.naver.com/channel/123456",
            "video":   "tv.naver.com/v/12345678  |  blog.naver.com/creator/223456789012",
        },
    },
    "soundcloud": {
        "name": "SoundCloud", "icon": "SC", "color": "#FF5500", "hover": "#D94800",
        "category": CAT_SOCIAL,
        "domains": ["soundcloud.com", "on.soundcloud.com"],
        "browse_url": "https://soundcloud.com/discover",
        "search_url": "https://soundcloud.com/search?q={query}",
        "login_url": "https://soundcloud.com/signin",
        "has_channels": True, "has_playlists": True,
        "channel_label": {"ru": "Artist", "en": "Artist"},
        "channel_desc":  {"ru": "All tracks from artist", "en": "All tracks from artist"},
        "url_examples": {
            "channel":  "soundcloud.com/artistname",
            "playlist": "soundcloud.com/artistname/sets/playlist-name",
            "video":    "soundcloud.com/artistname/track-name",
        },
    },
    "tiktok": {
        "name": "TikTok", "icon": "🎵", "color": "#111111", "hover": "#333333",
        "category": CAT_SOCIAL,
        "domains": ["tiktok.com"],
        "login_url": "https://www.tiktok.com/login",
        "has_channels": True, "has_playlists": False,
        "channel_label": {"ru": "👤 Пользователь",        "en": "👤 User"},
        "channel_desc":  {"ru": "Все видео пользователя",  "en": "All user videos"},
        "url_examples": {
            "channel": "tiktok.com/@username",
            "video":   "tiktok.com/@user/video/123456789",
        },
    },
    "instagram": {
        "name": "Instagram", "icon": "📸", "color": "#E1306C", "hover": "#C1104C",
        "category": CAT_SOCIAL,
        "domains": ["instagram.com"],
        "login_url": "https://www.instagram.com/accounts/login/",
        "has_channels": True, "has_playlists": False,
        "needs_cookies_recommended": True,
        "channel_label": {"ru": "👤 Профиль",           "en": "👤 Profile"},
        "channel_desc":  {"ru": "Все видео профиля",     "en": "All profile videos"},
        "url_examples": {
            "channel": "instagram.com/username/reels/",
            "video":   "instagram.com/reel/xxxxxx  |  instagram.com/p/xxxxxx",
        },
    },
    "twitter": {
        "name": "Twitter / X", "icon": "🐦", "color": "#1DA1F2", "hover": "#0D91E2",
        "category": CAT_SOCIAL,
        "domains": ["twitter.com", "x.com"],
        "login_url": "https://x.com/i/flow/login",
        "has_channels": False, "has_playlists": False,
        "url_examples": {
            "video": "x.com/user/status/123456  |  twitter.com/user/status/123456",
        },
    },
    "facebook": {
        "name": "Facebook", "icon": "📘", "color": "#1877F2", "hover": "#0857D2",
        "category": CAT_SOCIAL,
        "domains": ["facebook.com", "fb.watch", "fb.com"],
        "login_url": "https://www.facebook.com/login/",
        "has_channels": True, "has_playlists": True,
        "needs_cookies_recommended": True,
        "channel_label": {"ru": "📄 Страница",               "en": "📄 Page"},
        "channel_desc":  {"ru": "Все видео со страницы",      "en": "All videos from page"},
        "url_examples": {
            "channel":  "facebook.com/pagename/videos/",
            "playlist": "facebook.com/watch/123456789/",
            "video":    "facebook.com/watch?v=123456  |  fb.watch/xxxxx",
        },
    },
    "reddit": {
        "name": "Reddit", "icon": "🤖", "color": "#FF4500", "hover": "#DD3500",
        "category": CAT_SOCIAL,
        "domains": ["reddit.com", "old.reddit.com"],
        "login_url": "https://www.reddit.com/login/",
        "has_channels": True, "has_playlists": False,
        "channel_label": {"ru": "📋 Subreddit",              "en": "📋 Subreddit"},
        "channel_desc":  {"ru": "Все видео из сабреддита",    "en": "All videos from subreddit"},
        "url_examples": {
            "channel": "reddit.com/r/subreddit/",
            "video":   "reddit.com/r/sub/comments/xxxxx/title/",
        },
    },
    # ── ADULT ─────────────────────────────────────────────────────────────
    "flickr": {
        "name": "Flickr", "icon": "F", "color": "#FF0084", "hover": "#CC006A",
        "category": CAT_SOCIAL,
        "domains": ["flickr.com", "www.flickr.com"],
        "browse_url": "https://www.flickr.com/explore",
        "search_url": "https://www.flickr.com/search/?text={query}",
        "login_url": "https://identity.flickr.com/login",
        "has_channels": True, "has_playlists": True,
        "channel_label": {"ru": "Photostream", "en": "Photostream"},
        "channel_desc":  {"ru": "All media from profile", "en": "All media from profile"},
        "url_examples": {
            "channel":  "flickr.com/photos/username",
            "playlist": "flickr.com/photos/username/albums/72177700000000000",
            "video":    "flickr.com/photos/username/12345678901",
        },
    },
    "tumblr": {
        "name": "Tumblr", "icon": "T", "color": "#001935", "hover": "#102945",
        "category": CAT_SOCIAL,
        "domains": ["tumblr.com", "www.tumblr.com"],
        "browse_url": "https://www.tumblr.com/explore/trending",
        "search_url": "https://www.tumblr.com/search/{query}",
        "login_url": "https://www.tumblr.com/login",
        "has_channels": True, "has_playlists": False,
        "channel_label": {"ru": "Blog", "en": "Blog"},
        "channel_desc":  {"ru": "All posts from blog", "en": "All posts from blog"},
        "url_examples": {
            "channel": "username.tumblr.com",
            "video":   "username.tumblr.com/post/123456789012/title",
        },
    },
    "pornhub": {
        "name": "Pornhub", "icon": "🔞", "color": "#FFA31A", "hover": "#DD8300",
        "category": CAT_ADULT,
        "domains": ["pornhub.com"],
        "login_url": "https://www.pornhub.com/login",
        "has_channels": True, "has_playlists": True,
        "channel_label": {"ru": "👤 Модель / Канал",        "en": "👤 Model / Channel"},
        "channel_desc":  {"ru": "Все видео канала / модели", "en": "All channel / model videos"},
        "url_examples": {
            "channel":  "pornhub.com/model/name  |  pornhub.com/channels/name",
            "playlist": "pornhub.com/playlist/123456",
            "video":    "pornhub.com/view_video.php?viewkey=xxxxxx",
        },
    },
    "xvideos": {
        "name": "XVideos", "icon": "🔞", "color": "#C80000", "hover": "#A00000",
        "category": CAT_ADULT,
        "domains": ["xvideos.com"],
        "login_url": "https://www.xvideos.com/account",
        "has_channels": True, "has_playlists": False,
        "channel_label": {"ru": "👤 Профиль",            "en": "👤 Profile"},
        "channel_desc":  {"ru": "Все видео профиля",      "en": "All profile videos"},
        "url_examples": {
            "channel": "xvideos.com/profiles/username",
            "video":   "xvideos.com/video.xxxxx/title",
        },
    },
    "xhamster": {
        "name": "xHamster", "icon": "🔞", "color": "#F05922", "hover": "#D04912",
        "category": CAT_ADULT,
        "domains": ["xhamster.com", "xhamster2.com", "xhamster3.com", "xhamster.desi"],
        "login_url": "https://xhamster.com/login",
        "has_channels": True, "has_playlists": True,
        "channel_label": {"ru": "👤 Пользователь",        "en": "👤 User"},
        "channel_desc":  {"ru": "Все видео пользователя",  "en": "All user videos"},
        "url_examples": {
            "channel":  "xhamster.com/users/username",
            "playlist": "xhamster.com/my/favorites/videos/123456",
            "video":    "xhamster.com/videos/title-123456",
        },
    },
    # ── UNIVERSAL removed — each platform has its own template ──────────
}

# Archive suffix per platform
for _pid, _pc in PLATFORM_CONFIGS.items():
    if "archive_suffix" not in _pc:
        _pc["archive_suffix"] = _pid  # archive_youtube.txt, archive_vk.txt, etc.

def get_platform_name(platform_id: str, lang: str = "en") -> str:
    """Получить отображаемое имя платформы с учётом языка."""
    pc: dict[str, Any] = PLATFORM_CONFIGS[platform_id]
    if lang == "ru" and "name_ru" in pc:
        return str(pc["name_ru"])
    if lang == "en" and "name_en" in pc:
        return str(pc["name_en"])
    return str(pc["name"])

def get_all_domains() -> set[str]:
    """Собрать все известные домены из всех платформ."""
    domains: set[str] = set()
    for pc in PLATFORM_CONFIGS.values():
        raw_domains = pc.get("domains", [])
        if isinstance(raw_domains, list):
            domains.update(str(domain) for domain in raw_domains)
    return domains
