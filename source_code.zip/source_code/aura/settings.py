#!/usr/bin/env python3
from __future__ import annotations

"""Settings manager — per-platform JSON configuration with auto-migration."""
import json
import os
import shutil
from typing import Any

from aura.settings_schema import (
    SETTINGS_DEFAULTS,
    build_default_settings,
    normalize_settings,
)
from aura.utils import get_settings_dir, is_debug_mode


# ══════════════════════════════════════════════════════════════════════════════
class SettingsManager:
    """Менеджер сохранения и загрузки настроек (per-platform).
    
    Smart migration: when the app adds new settings (or removes old ones),
    the config file on disk is automatically updated on next load.
    User's existing values are NEVER overwritten — only missing keys
    get their defaults, stale keys are cleaned up, and invalid value
    types are repaired back to schema defaults.
    """

    DEFAULT_SETTINGS = SETTINGS_DEFAULTS

    def __init__(self, platform: str = "youtube") -> None:
        # Per-platform config: config_youtube.json, config_vk.json, etc.
        # Always resolve dynamically — settings dir may change after config location dialog
        self.platform = platform
        self.last_migration: dict[str, Any] | None = None  # Set by load() if migration occurred
        self._resolve_path()

    def _resolve_path(self) -> None:
        settings_dir = get_settings_dir()
        if settings_dir.exists() and not settings_dir.is_dir():
            settings_dir.unlink()
        settings_dir.mkdir(parents=True, exist_ok=True)
        self.config_path = settings_dir / f"config_{self.platform}.json"

    @classmethod
    def default_settings(cls) -> dict[str, Any]:
        """Return a detached copy of the canonical settings defaults."""
        return build_default_settings()

    @classmethod
    def sanitize_settings(cls, settings: Any) -> dict[str, Any]:
        """Return a complete, schema-normalized settings payload."""
        normalized, _ = normalize_settings(settings, defaults=cls.default_settings())
        return normalized

    def load(self) -> dict:
        """Load settings from file with automatic migration.
        
        - Missing file → created automatically from schema defaults
        - Keys present in DEFAULT but missing from file → added with default value
        - Keys present in file but missing from DEFAULT → removed (stale)
        - Values with incompatible types → reset to schema defaults
        - If any changes → file is re-saved immediately
        - Migration report stored in self.last_migration
        """
        self.last_migration = None
        saved: Any = None
        loaded_from_backup = False

        try:
            if self.config_path.exists():
                try:
                    with open(self.config_path, 'r', encoding='utf-8') as f:
                        saved = json.load(f)
                except (json.JSONDecodeError, UnicodeDecodeError):
                    # Corrupted file — try backup
                    bak = self.config_path.with_suffix('.bak')
                    if bak.exists():
                        with open(bak, 'r', encoding='utf-8') as f:
                            saved = json.load(f)
                        loaded_from_backup = True
        except Exception:
            saved = None

        if saved is None:
            settings = self.default_settings()
            if not is_debug_mode():
                self.save(settings)
            return settings

        settings, migration = normalize_settings(saved, defaults=self.default_settings())
        if migration:
            self.last_migration = migration
        if (loaded_from_backup or migration) and not is_debug_mode():
            self.save(settings)

        return settings

    def save(self, settings: dict) -> bool:
        """Сохранить настройки в файл (atomic write — crash-safe)."""
        try:
            normalized = self.sanitize_settings(settings)
            self.config_path.parent.mkdir(parents=True, exist_ok=True)
            # Backup existing config before overwrite
            if self.config_path.exists():
                try:
                    shutil.copy2(str(self.config_path), str(self.config_path.with_suffix('.bak')))
                except Exception:
                    pass
            # Write to temp file first, then atomically replace.
            tmp_path = self.config_path.with_suffix('.tmp')
            with open(tmp_path, 'w', encoding='utf-8') as f:
                json.dump(normalized, f, ensure_ascii=False, indent=2)
            # os.replace is atomic on same filesystem (Windows NTFS + Linux ext4)
            os.replace(str(tmp_path), str(self.config_path))
            return True
        except Exception as e:
            from aura.utils import log_error
            log_error("settings_save", e)
            return False
