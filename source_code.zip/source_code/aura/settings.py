#!/usr/bin/env python3
from __future__ import annotations

"""Settings manager — per-platform JSON configuration with auto-migration."""
import json
import os
from typing import Any

from aura.utils import get_settings_dir, is_debug_mode


# ══════════════════════════════════════════════════════════════════════════════
class SettingsManager:
    """Менеджер сохранения и загрузки настроек (per-platform).
    
    Smart migration: when the app adds new settings (or removes old ones),
    the config file on disk is automatically updated on next load.
    User's existing values are NEVER overwritten — only missing keys
    get their defaults, and stale keys are cleaned up.
    """

    DEFAULT_SETTINGS = {
        "mode": "video",
        "url": "",
        "outdir": "",
        "cookies": "",
        "proxy": "",
        "search_results_limit": "25",
        "video_quality": "max",
        "audio_format": "wav",
        "audio_bitrate": "max",
        "audio_source": "audio_video",
        "audio_language": "any",
        "download_all_audio_tracks": False,
        "dubbed_audio_export": False,
        "dubbed_audio_mode": "selected",
        "dubbed_audio_languages": "",
        "dubbed_audio_format": "best",
        "meta_language": "any",
        "restart_each_video": False,
        "notify_on_finish": True,
        "no_numbering": False,
        "reverse_playlist": True,
        "use_archive": True,
        "download_subtitles": False,
        "subtitle_language": "all",
        "embed_subtitles": False,
        "subtitle_format": "srt",
        "auth_method": "none",
        "use_aria2c": False,
        "aria2c_threads": "8",
        "concurrent_videos": "1",
        "smart_auto_apply": False,
        "smart_auto_preset": "",
        "manual_item_selection": False,
        "sb_enabled": False,
        "sb_action": "mark",
        "sb_categories": ["sponsor", "intro", "outro", "selfpromo"],
        "sb_force_keyframes": False,
        "speed_limit": 0,
        "speed_limit_unit": "mbs",
        "output_container": "auto",
        "video_codec_policy": "auto",
        "playback_target": "auto",
        "immersive_safe_container": True,
        "generate_m3u": False,
        "history_auto_remove_completed": False,
        "speed_graph_enabled": False,
        "background_mode": False,
        "scheduler_enabled": False,
        "scheduler_mode": "daily",
        "scheduler_interval": 60,
        "log_file_enabled": False,
        "log_file_path": "",
        "auto_remove_completed": False,
    }

    def __init__(self, platform: str = "youtube") -> None:
        # Per-platform config: config_youtube.json, config_vk.json, etc.
        # Always resolve dynamically — settings dir may change after config location dialog
        self.platform = platform
        self.last_migration: dict[str, Any] | None = None  # Set by load() if migration occurred
        self._resolve_path()

    def _resolve_path(self) -> None:
        settings_dir = get_settings_dir()
        if settings_dir.exists() and not settings_dir.is_dir():
            settings_dir.unlink()
        settings_dir.mkdir(parents=True, exist_ok=True)
        self.config_path = settings_dir / f"config_{self.platform}.json"

    def load(self) -> dict:
        """Load settings from file with automatic migration.
        
        - Keys present in DEFAULT but missing from file → added with default value
        - Keys present in file but missing from DEFAULT → removed (stale)
        - If any changes → file is re-saved immediately
        - Migration report stored in self.last_migration
        """
        self.last_migration = None
        saved = {}
        is_new_file = True

        try:
            if self.config_path.exists():
                try:
                    with open(self.config_path, 'r', encoding='utf-8') as f:
                        saved = json.load(f)
                    is_new_file = False
                except (json.JSONDecodeError, UnicodeDecodeError):
                    # Corrupted file — try backup
                    bak = self.config_path.with_suffix('.bak')
                    if bak.exists():
                        with open(bak, 'r', encoding='utf-8') as f:
                            saved = json.load(f)
                        is_new_file = False
        except Exception:
            saved = {}

        if is_new_file:
            # First run for this platform — no migration needed
            return self.DEFAULT_SETTINGS.copy()

        # Detect differences
        default_keys = set(self.DEFAULT_SETTINGS.keys())
        saved_keys = set(saved.keys())

        added_keys = default_keys - saved_keys    # New settings not in file
        removed_keys = saved_keys - default_keys  # Stale settings no longer used

        # Build merged result: defaults + saved values for known keys
        settings = self.DEFAULT_SETTINGS.copy()
        for key in default_keys:
            if key in saved:
                settings[key] = saved[key]

        # If something changed — save the clean, complete file
        if added_keys or removed_keys:
            self.last_migration = {
                "added": {k: self.DEFAULT_SETTINGS[k] for k in sorted(added_keys)},
                "removed": sorted(removed_keys),
            }
            # Re-save so the file on disk is always complete and clean
            if not is_debug_mode():
                self.save(settings)

        return settings

    def save(self, settings: dict) -> bool:
        """Сохранить настройки в файл (atomic write — crash-safe)."""
        try:
            self.config_path.parent.mkdir(parents=True, exist_ok=True)
            # Backup existing config before overwrite
            if self.config_path.exists():
                try:
                    import shutil
                    shutil.copy2(str(self.config_path), str(self.config_path.with_suffix('.bak')))
                except Exception:
                    pass
            # Write to temp file first, then atomically replace.
            tmp_path = self.config_path.with_suffix('.tmp')
            with open(tmp_path, 'w', encoding='utf-8') as f:
                json.dump(settings, f, ensure_ascii=False, indent=2)
            # os.replace is atomic on same filesystem (Windows NTFS + Linux ext4)
            os.replace(str(tmp_path), str(self.config_path))
            return True
        except Exception as e:
            from aura.utils import log_error
            log_error("settings_save", e)
            return False
