#!/usr/bin/env python3
from __future__ import annotations

"""Dialog for pasting multiple media URLs at once."""

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QDialog,
    QFrame,
    QHBoxLayout,
    QLabel,
    QPlainTextEdit,
    QPushButton,
    QVBoxLayout,
)

from aura.dialogs.ui_chrome import (
    build_dialog_chrome_qss,
    configure_wrap_label,
    resolve_dialog_colors,
    resolve_dialog_translations,
)


class BatchLinksDialog(QDialog):
    def __init__(self, parent=None, t=None, theme_id=None):
        super().__init__(parent)
        self.t = resolve_dialog_translations(parent, t=t)
        self.setWindowTitle(self.t.get("batch_links_title", "Batch links"))
        self.setMinimumSize(620, 360)
        self.resize(780, 480)
        self.setSizeGripEnabled(True)
        self.setStyleSheet(build_dialog_chrome_qss(resolve_dialog_colors(parent, theme_id)))

        layout = QVBoxLayout(self)
        layout.setContentsMargins(18, 18, 18, 18)
        layout.setSpacing(12)

        hero = QFrame()
        hero.setObjectName("dialogHeroCard")
        hero_layout = QVBoxLayout(hero)
        hero_layout.setContentsMargins(22, 18, 22, 18)
        hero_layout.setSpacing(6)

        eyebrow = QLabel("AURA VIDEO DOWNLOADER")
        eyebrow.setObjectName("dialogEyebrow")
        hero_layout.addWidget(eyebrow)

        title = QLabel(self.t.get("batch_links_title", "Batch links"))
        title.setObjectName("dialogTitle")
        title.setWordWrap(True)
        configure_wrap_label(title)
        hero_layout.addWidget(title)

        info = QLabel(
            self.t.get(
                "batch_links_hint",
                "Paste one link per line. CSV first-column links are supported too.",
            )
        )
        info.setObjectName("dialogSubtitle")
        info.setWordWrap(True)
        configure_wrap_label(info)
        hero_layout.addWidget(info)
        layout.addWidget(hero)

        panel = QFrame()
        panel.setObjectName("dialogPanelCard")
        panel_layout = QVBoxLayout(panel)
        panel_layout.setContentsMargins(18, 16, 18, 18)
        panel_layout.setSpacing(10)

        self.editor = QPlainTextEdit()
        self.editor.setObjectName("dialogEditor")
        self.editor.setPlaceholderText(
            self.t.get(
                "batch_links_placeholder",
                "https://example.com/video-1\nhttps://example.com/video-2",
            )
        )
        panel_layout.addWidget(self.editor, 1)
        layout.addWidget(panel, 1)

        footer = QFrame()
        footer.setObjectName("dialogFooterCard")
        footer_layout = QHBoxLayout(footer)
        footer_layout.setContentsMargins(14, 10, 14, 10)
        footer_layout.setSpacing(10)
        footer_layout.addStretch()

        btn_cancel = QPushButton(self.t.get("batch_links_cancel", "Cancel"))
        btn_cancel.setObjectName("dialogGhostBtn")
        btn_cancel.setCursor(Qt.PointingHandCursor)
        btn_cancel.clicked.connect(self.reject)
        footer_layout.addWidget(btn_cancel)

        btn_queue = QPushButton(self.t.get("batch_links_queue", "Queue links"))
        btn_queue.setObjectName("dialogPrimaryBtn")
        btn_queue.setCursor(Qt.PointingHandCursor)
        btn_queue.clicked.connect(self._accept_if_any)
        footer_layout.addWidget(btn_queue)
        layout.addWidget(footer)

    @staticmethod
    def parse_links(raw_text):
        urls = []
        seen = set()
        for line in (raw_text or "").splitlines():
            text = line.strip()
            if not text or text.startswith("#"):
                continue
            first_part = text.split(",", 1)[0].strip()
            if first_part and first_part not in seen:
                seen.add(first_part)
                urls.append(first_part)
        return urls

    def links(self):
        return self.parse_links(self.editor.toPlainText())

    def _accept_if_any(self):
        if self.links():
            self.accept()
