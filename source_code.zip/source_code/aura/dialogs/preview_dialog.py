#!/usr/bin/env python3
"""Video preview dialog with thumbnail and metadata."""

from PySide6.QtCore import Qt
from PySide6.QtGui import QPixmap
from PySide6.QtWidgets import QDialog, QFrame, QGridLayout, QLabel, QPushButton, QSizePolicy, QVBoxLayout

from aura.dialogs.ui_chrome import build_dialog_chrome_qss, configure_wrap_label, resolve_dialog_colors
from aura.utils import log_error
from aura.workers.preview import ThumbnailWorker


def _dialog_qss(colors):
    return (
        build_dialog_chrome_qss(colors)
        + f"""
        QDialog {{
            background: {colors['bg_main']};
        }}
        QLabel#previewThumb {{
            background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                stop:0 {colors['log_bg']}, stop:1 {colors['bg_deep']});
            color: {colors['text_hint']};
            border: 1px solid {colors['border']};
            border-radius: 16px;
            padding: 16px;
            font-size: 13px;
            font-weight: 700;
        }}
        QLabel#previewKey {{
            color: {colors['text']};
            font-size: 9.5pt;
            font-weight: 700;
        }}
        QLabel#previewValue {{
            color: {colors['text_dim']};
            font-size: 9.5pt;
        }}
        QPushButton#previewAction {{
            min-height: 36px;
            background: {colors['bg_button']};
            color: {colors['text']};
            border: 1px solid {colors['border']};
            border-radius: 12px;
            padding: 0 16px;
            font-size: 10pt;
            font-weight: 700;
        }}
        QPushButton#previewAction:hover {{
            background: {colors['bg_hover']};
            border-color: {colors['accent']};
        }}
        QLabel#previewSectionTitle {{
            color: {colors['text']};
            font-size: 12px;
            font-weight: 700;
        }}
        """
    )


def _format_upload_date(value):
    text = str(value or "").strip()
    if len(text) == 8 and text.isdigit():
        return f"{text[:4]}-{text[4:6]}-{text[6:]}"
    return text or "—"


class PreviewDialog(QDialog):
    """Video metadata preview dialog with thumbnail."""

    def __init__(self, parent, t, theme_id=None):
        super().__init__(parent)
        self.setWindowTitle(t.get("preview_title", "Video Preview"))
        self.setMinimumSize(560, 560)
        self.resize(680, 620)
        self.setSizeGripEnabled(True)
        self.setStyleSheet(_dialog_qss(resolve_dialog_colors(parent, theme_id)))
        self.t = t
        self._thumb_worker = None
        self._thumb_pixmap = None

        layout = QVBoxLayout(self)
        layout.setContentsMargins(18, 18, 18, 18)
        layout.setSpacing(12)

        hero = QFrame()
        hero.setObjectName("dialogHeroCard")
        hero_layout = QVBoxLayout(hero)
        hero_layout.setContentsMargins(22, 18, 22, 18)
        hero_layout.setSpacing(6)

        eyebrow = QLabel("AURA VIDEO DOWNLOADER")
        eyebrow.setObjectName("dialogEyebrow")
        hero_layout.addWidget(eyebrow)

        title = QLabel(t.get("preview_title", "Video Preview"))
        title.setObjectName("dialogTitle")
        title.setWordWrap(True)
        configure_wrap_label(title)
        hero_layout.addWidget(title)

        subtitle = QLabel(
            t.get(
                "preview_dialog_hint",
                "Inspect thumbnail, duration, uploader, languages, and subtitles before you start the download.",
            )
        )
        subtitle.setObjectName("dialogSubtitle")
        subtitle.setWordWrap(True)
        configure_wrap_label(subtitle)
        hero_layout.addWidget(subtitle)
        layout.addWidget(hero)

        thumb_panel = QFrame()
        thumb_panel.setObjectName("dialogPanelCard")
        thumb_layout = QVBoxLayout(thumb_panel)
        thumb_layout.setContentsMargins(16, 16, 16, 16)
        thumb_layout.setSpacing(10)

        thumb_title = QLabel(t.get("preview_section_thumbnail", "Thumbnail"))
        thumb_title.setObjectName("previewSectionTitle")
        thumb_layout.addWidget(thumb_title)

        self.thumb_label = QLabel()
        self.thumb_label.setObjectName("previewThumb")
        self.thumb_label.setAlignment(Qt.AlignCenter)
        self.thumb_label.setMinimumHeight(110)
        self.thumb_label.setWordWrap(True)
        self._configure_wrap_label(self.thumb_label)
        self._set_empty_thumbnail_state(
            t.get("preview_thumb_empty_title", t.get("preview_loading", "Loading...")),
            t.get(
                "preview_thumb_empty_hint",
                "The selected item did not provide a preview image yet.",
            ),
        )
        thumb_layout.addWidget(self.thumb_label, 1)
        layout.addWidget(thumb_panel)

        info_panel = QFrame()
        info_panel.setObjectName("dialogPanelCard")
        info_layout = QVBoxLayout(info_panel)
        info_layout.setContentsMargins(16, 16, 16, 16)
        info_layout.setSpacing(10)

        info_title = QLabel(t.get("preview_section_details", "Details"))
        info_title.setObjectName("previewSectionTitle")
        info_layout.addWidget(info_title)

        info = QGridLayout()
        info.setHorizontalSpacing(12)
        info.setVerticalSpacing(8)
        self._info_labels = {}
        for i, key in enumerate(["name", "duration", "size", "uploader", "date", "views", "media", "audio_tracks", "subtitles"]):
            lbl_key = QLabel(t.get(f"preview_{key}", key))
            lbl_key.setObjectName("previewKey")
            lbl_key.setAlignment(Qt.AlignTop | Qt.AlignLeft)
            lbl_val = QLabel("—")
            lbl_val.setObjectName("previewValue")
            lbl_val.setWordWrap(True)
            self._configure_wrap_label(lbl_val)
            lbl_val.setTextInteractionFlags(Qt.TextSelectableByMouse)
            lbl_val.setAlignment(Qt.AlignTop | Qt.AlignLeft)
            info.addWidget(lbl_key, i, 0)
            info.addWidget(lbl_val, i, 1)
            self._info_labels[key] = lbl_val
        info.setColumnStretch(1, 1)
        info_layout.addLayout(info)
        layout.addWidget(info_panel, 1)

        footer = QFrame()
        footer.setObjectName("dialogFooterCard")
        footer_layout = QVBoxLayout(footer)
        footer_layout.setContentsMargins(14, 10, 14, 10)
        footer_layout.setSpacing(8)

        self.preview_meta_label = QLabel(t.get("preview_ready_badge", "Metadata preview"))
        self.preview_meta_label.setObjectName("dialogMeta")
        footer_layout.addWidget(self.preview_meta_label)

        btn = QPushButton(self.t.get("close", "Close"))
        btn.setObjectName("previewAction")
        btn.setCursor(Qt.PointingHandCursor)
        btn.clicked.connect(self.accept)
        footer_layout.addWidget(btn, 0, Qt.AlignRight)
        layout.addWidget(footer)

    def _clear_thumb_worker_ref(self, worker):
        if self._thumb_worker is worker:
            self._thumb_worker = None

    def _shutdown_thumb_worker(self, wait_ms=1000):
        worker = self._thumb_worker
        self._thumb_worker = None
        if worker is None:
            return

        try:
            stop = getattr(worker, "stop", None)
            if callable(stop):
                stop()
            else:
                request_interruption = getattr(worker, "requestInterruption", None)
                if callable(request_interruption):
                    request_interruption()
        except Exception as exc:
            log_error("preview_thumb_stop", exc)

        try:
            if worker.isRunning():
                worker.wait(wait_ms)
                if worker.isRunning():
                    worker.terminate()
                    worker.wait(wait_ms)
        except Exception as exc:
            log_error("preview_thumb_wait", exc)

    @staticmethod
    def _configure_wrap_label(label):
        policy = label.sizePolicy()
        policy.setHorizontalPolicy(QSizePolicy.Ignored)
        policy.setVerticalPolicy(QSizePolicy.Minimum)
        policy.setHeightForWidth(True)
        label.setSizePolicy(policy)

    def _set_empty_thumbnail_state(self, title_text, hint_text=""):
        body = title_text if not hint_text else f"{title_text}\n{hint_text}"
        self._thumb_pixmap = None
        self.thumb_label.setPixmap(QPixmap())
        self.thumb_label.setText(body)

    def set_metadata(self, data):
        """Populate dialog with video metadata dict from yt-dlp."""
        self._info_labels["name"].setText(data.get("title", "—"))
        self.preview_meta_label.setText(
            data.get("uploader")
            or self.t.get("preview_ready_badge", "Metadata preview")
        )

        dur = data.get("duration", 0)
        if dur:
            m, s = divmod(int(dur), 60)
            h, m = divmod(m, 60)
            self._info_labels["duration"].setText(f"{h}:{m:02d}:{s:02d}" if h else f"{m}:{s:02d}")

        fsize = data.get("filesize") or data.get("filesize_approx", 0)
        if fsize:
            mb = fsize / (1024 * 1024)
            self._info_labels["size"].setText(f"~{mb:.1f} MB")

        self._info_labels["uploader"].setText(data.get("uploader", "—"))
        self._info_labels["date"].setText(_format_upload_date(data.get("upload_date")))

        views = data.get("view_count", 0)
        if views:
            self._info_labels["views"].setText(f"{views:,}")

        immersive = data.get("_aura_immersive") or {}
        projection = (immersive.get("projection") or "").strip()
        media_text = immersive.get("label", "—")
        if projection:
            media_text = f"{media_text} ({projection})"
        self._info_labels["media"].setText(media_text)

        audio_tracks = data.get("_aura_audio_languages") or []
        self._info_labels["audio_tracks"].setText(self._format_language_codes(audio_tracks) if audio_tracks else "—")

        subtitle_tracks = []
        manual_subs = data.get("_aura_subtitle_languages") or []
        auto_subs = data.get("_aura_auto_subtitle_languages") or []
        if manual_subs:
            subtitle_tracks.append(self.t.get("preview_subtitles_manual", "manual") + ": " + self._format_language_codes(manual_subs))
        if auto_subs:
            subtitle_tracks.append(self.t.get("preview_subtitles_auto", "auto") + ": " + self._format_language_codes(auto_subs))
        self._info_labels["subtitles"].setText(" | ".join(subtitle_tracks) if subtitle_tracks else "—")

        thumb_url = data.get("thumbnail", "")
        if thumb_url:
            self._shutdown_thumb_worker(wait_ms=250)
            worker = ThumbnailWorker(thumb_url)
            try:
                worker.setParent(self)
            except Exception as exc:
                log_error("preview_thumb_parent", exc)
            worker.result_signal.connect(self._set_thumbnail)
            worker.finished.connect(lambda worker=worker: self._clear_thumb_worker_ref(worker))
            self._thumb_worker = worker
            worker.start()
        else:
            self._set_empty_thumbnail_state(
                self.t.get("preview_no_thumbnail", "No thumbnail"),
                self.t.get(
                    "preview_thumb_empty_hint",
                    "The selected item did not provide a preview image yet.",
                ),
            )

    def _set_thumbnail(self, img_data):
        """Display downloaded thumbnail image data."""
        if img_data:
            pm = QPixmap()
            pm.loadFromData(img_data)
            if not pm.isNull():
                self._thumb_pixmap = pm
                self._render_thumbnail()
                return
        self._set_empty_thumbnail_state(
            self.t.get("preview_no_thumbnail", "No thumbnail"),
            self.t.get(
                "preview_thumb_empty_hint",
                "The selected item did not provide a preview image yet.",
            ),
        )

    def _render_thumbnail(self):
        if self._thumb_pixmap is None:
            return
        scaled = self._thumb_pixmap.scaled(
            self.thumb_label.width() - 20,
            self.thumb_label.height() - 20,
            Qt.KeepAspectRatio,
            Qt.SmoothTransformation,
        )
        self.thumb_label.setPixmap(scaled)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._render_thumbnail()

    def closeEvent(self, event):
        self._shutdown_thumb_worker()
        super().closeEvent(event)

    def _format_language_codes(self, codes):
        labels = []
        for code in codes:
            normalized = str(code or "").strip().lower().replace("_", "-")
            base = normalized.split("-", 1)[0]
            labels.append(
                self.t.get(f"lang_{normalized}")
                or self.t.get(f"sub_lang_{normalized}")
                or self.t.get(f"lang_{base}")
                or self.t.get(f"sub_lang_{base}")
                or str(code)
            )
        return ", ".join(labels)
