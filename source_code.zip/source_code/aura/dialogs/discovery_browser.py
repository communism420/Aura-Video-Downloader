#!/usr/bin/env python3
"""Built-in media browser with in-app search and quick URL capture."""

from __future__ import annotations

import re
from urllib.parse import quote_plus

from PySide6.QtCore import QUrl, Qt
from PySide6.QtGui import QKeySequence, QShortcut
from PySide6.QtWidgets import (
    QDialog,
    QFrame,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QVBoxLayout,
)

from aura.dialogs.cookie_browser import _HAS_WEBENGINE, _dialog_qss, _resolve_colors
from aura.translations import get_translations

if _HAS_WEBENGINE:
    from PySide6.QtWebEngineCore import QWebEnginePage, QWebEngineProfile
    from PySide6.QtWebEngineWidgets import QWebEngineView


_URL_SCHEME_RE = re.compile(r"^[a-zA-Z][a-zA-Z0-9+.-]*://")


class DiscoveryBrowserDialog(QDialog):
    """In-app browser for finding supported media without leaving the app."""

    def __init__(
        self,
        parent,
        platform_name,
        start_url,
        home_url=None,
        search_url_template="",
        domain_hint="",
        lang="en",
        theme_id="light",
        profile=None,
    ):
        if not _HAS_WEBENGINE:
            raise RuntimeError("PySide6-WebEngine is required for DiscoveryBrowserDialog")

        super().__init__(parent)
        self.selected_url = ""
        self.download_requested = False
        self._home_url = home_url or start_url
        self._search_url_template = search_url_template or ""
        self._domain_hint = domain_hint or ""
        t = get_translations(lang)

        colors = _resolve_colors(parent, theme_id)
        self.setWindowTitle(
            t.get("discovery_browser_title", "Browser - {platform}").format(platform=platform_name)
        )
        self.setMinimumSize(720, 520)
        self.resize(1040, 760)
        self.setSizeGripEnabled(True)
        self.setStyleSheet(_dialog_qss(colors))

        layout = QVBoxLayout(self)
        layout.setContentsMargins(18, 18, 18, 18)
        layout.setSpacing(12)

        hint_card = QFrame()
        hint_card.setObjectName("browserHintCard")
        hint_layout = QVBoxLayout(hint_card)
        hint_layout.setContentsMargins(16, 14, 16, 14)
        hint_layout.setSpacing(4)

        hint = QLabel(
            t.get(
                "discovery_browser_hint",
                "Find media inside the app, open any page, then use the current page URL or start a download.",
            )
        )
        hint.setObjectName("browserHint")
        hint.setWordWrap(True)
        hint_layout.addWidget(hint)

        meta = QLabel(
            t.get(
                "discovery_browser_meta",
                "Type a direct URL or a search phrase. Search opens inside the selected platform when a native search URL is known.",
            )
        )
        meta.setObjectName("browserMeta")
        meta.setWordWrap(True)
        hint_layout.addWidget(meta)
        layout.addWidget(hint_card)

        nav_frame = QFrame()
        nav_frame.setObjectName("browserFooter")
        nav_layout = QHBoxLayout(nav_frame)
        nav_layout.setContentsMargins(14, 10, 14, 10)
        nav_layout.setSpacing(8)

        self.btn_back = self._make_button("<", "browserAction")
        self.btn_back.setAccessibleName(t.get("discovery_browser_back_accessible", "Go back"))
        self.btn_back.clicked.connect(self._go_back)
        nav_layout.addWidget(self.btn_back)

        self.btn_forward = self._make_button(">", "browserAction")
        self.btn_forward.setAccessibleName(t.get("discovery_browser_forward_accessible", "Go forward"))
        self.btn_forward.clicked.connect(self._go_forward)
        nav_layout.addWidget(self.btn_forward)

        self.btn_reload = self._make_button(
            t.get("discovery_browser_reload", "Reload"),
            "browserAction",
        )
        self.btn_reload.setAccessibleName(t.get("discovery_browser_reload_accessible", "Reload current page"))
        self.btn_reload.clicked.connect(self._reload_page)
        nav_layout.addWidget(self.btn_reload)

        self.btn_home = self._make_button(
            t.get("discovery_browser_home", "Home"),
            "browserAction",
        )
        self.btn_home.setAccessibleName(t.get("discovery_browser_home_accessible", "Open browser home page"))
        self.btn_home.clicked.connect(self._go_home)
        nav_layout.addWidget(self.btn_home)

        self.address_input = QLineEdit()
        self.address_input.setObjectName("browserField")
        self.address_input.setPlaceholderText(
            t.get("discovery_browser_address", "Paste URL or search query")
        )
        self.address_input.setAccessibleName(
            t.get("discovery_browser_address_accessible", "Browser address and search field")
        )
        self.address_input.returnPressed.connect(self._navigate_from_input)
        nav_layout.addWidget(self.address_input, 1)

        btn_go = self._make_button(
            t.get("discovery_browser_go", "Go"),
            "browserPrimaryAction",
        )
        btn_go.setAccessibleName(t.get("discovery_browser_go_accessible", "Open typed address or search"))
        btn_go.clicked.connect(self._navigate_from_input)
        nav_layout.addWidget(btn_go)

        layout.addWidget(nav_frame)

        self.profile = profile or QWebEngineProfile(self)
        if profile is None:
            self.profile.setPersistentCookiesPolicy(QWebEngineProfile.NoPersistentCookies)
        self.page = QWebEnginePage(self.profile, self)
        self.view = QWebEngineView(self)
        self.view.setAccessibleName(t.get("discovery_browser_view_accessible", "Embedded browser view"))
        self.view.setPage(self.page)
        self.view.urlChanged.connect(self._on_url_changed)
        self.view.titleChanged.connect(self._on_title_changed)
        self.view.loadFinished.connect(self._update_nav_buttons)

        browser_frame = QFrame()
        browser_frame.setObjectName("browserFrame")
        browser_layout = QVBoxLayout(browser_frame)
        browser_layout.setContentsMargins(1, 1, 1, 1)
        browser_layout.addWidget(self.view)
        layout.addWidget(browser_frame, 1)

        footer = QFrame()
        footer.setObjectName("browserFooter")
        footer_layout = QHBoxLayout(footer)
        footer_layout.setContentsMargins(14, 10, 14, 10)
        footer_layout.setSpacing(10)

        current_label = QLabel(t.get("discovery_browser_current", "Current page:"))
        current_label.setObjectName("browserMeta")
        footer_layout.addWidget(current_label)

        self.current_url_label = QLineEdit()
        self.current_url_label.setObjectName("browserUrlField")
        self.current_url_label.setReadOnly(True)
        self.current_url_label.setAccessibleName(
            t.get("discovery_browser_current_accessible", "Current page URL")
        )
        self.current_url_label.setCursorPosition(0)
        footer_layout.addWidget(self.current_url_label, 1)

        btn_use = self._make_button(
            t.get("discovery_browser_use", "Use page URL"),
            "browserAction",
        )
        btn_use.setAccessibleName(t.get("discovery_browser_use_accessible", "Use current page URL"))
        btn_use.clicked.connect(self._use_current_page)
        footer_layout.addWidget(btn_use)

        btn_download = self._make_button(
            t.get("discovery_browser_download", "Download page"),
            "browserPrimaryAction",
        )
        btn_download.setAccessibleName(t.get("discovery_browser_download_accessible", "Download current page"))
        btn_download.clicked.connect(self._download_current_page)
        footer_layout.addWidget(btn_download)

        btn_close = self._make_button(
            t.get("discovery_browser_close", "Close"),
            "browserAction",
        )
        btn_close.setAccessibleName(t.get("discovery_browser_close_accessible", "Close browser"))
        btn_close.clicked.connect(self.reject)
        footer_layout.addWidget(btn_close)

        layout.addWidget(footer)

        self._shortcut_focus_address = QShortcut(QKeySequence("Ctrl+L"), self)
        self._shortcut_focus_address.activated.connect(self.address_input.setFocus)
        self._shortcut_back = QShortcut(QKeySequence("Alt+Left"), self)
        self._shortcut_back.activated.connect(self._go_back)
        self._shortcut_forward = QShortcut(QKeySequence("Alt+Right"), self)
        self._shortcut_forward.activated.connect(self._go_forward)
        self._shortcut_download = QShortcut(QKeySequence("Ctrl+Return"), self)
        self._shortcut_download.activated.connect(self._download_current_page)

        self.view.load(QUrl(self._resolve_entry_to_url(start_url)))
        self._update_nav_buttons()

    @staticmethod
    def _make_button(text, object_name):
        btn = QPushButton(text)
        btn.setObjectName(object_name)
        btn.setCursor(Qt.PointingHandCursor)
        btn.setAutoDefault(False)
        btn.setDefault(False)
        return btn

    def _resolve_entry_to_url(self, raw_text):
        text = (raw_text or "").strip()
        if not text:
            return self._home_url
        if _URL_SCHEME_RE.match(text):
            return text
        if "." in text and " " not in text:
            return f"https://{text}"
        if self._search_url_template:
            return self._search_url_template.format(query=quote_plus(text))
        query = text
        if self._domain_hint:
            query = f"site:{self._domain_hint} {text}"
        return f"https://www.google.com/search?q={quote_plus(query)}"

    def _current_http_url(self):
        url = self.view.url().toString().strip()
        if url.startswith(("http://", "https://")):
            return url
        return ""

    def _go_back(self):
        self.view.back()

    def _go_forward(self):
        self.view.forward()

    def _reload_page(self):
        self.view.reload()

    def _go_home(self):
        self.view.load(QUrl(self._home_url))

    def _navigate_from_input(self):
        self.view.load(QUrl(self._resolve_entry_to_url(self.address_input.text())))

    def _on_url_changed(self, url):
        current = url.toString().strip()
        self.address_input.setText(current)
        self.current_url_label.setText(current)
        self.current_url_label.setToolTip(current)
        self.current_url_label.setCursorPosition(0)
        self._update_nav_buttons()

    def _on_title_changed(self, title):
        if title:
            self.setWindowTitle(title)

    def _update_nav_buttons(self, *_args):
        history = self.page.history()
        self.btn_back.setEnabled(history.canGoBack())
        self.btn_forward.setEnabled(history.canGoForward())

    def _use_current_page(self):
        current = self._current_http_url()
        if not current:
            return
        self.selected_url = current
        self.download_requested = False
        self.accept()

    def _download_current_page(self):
        current = self._current_http_url()
        if not current:
            return
        self.selected_url = current
        self.download_requested = True
        self.accept()

    def closeEvent(self, event):
        try:
            self.view.setPage(None)
        except Exception:
            pass
        super().closeEvent(event)
