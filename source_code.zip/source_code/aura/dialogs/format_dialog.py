#!/usr/bin/env python3
"""Format selection dialog."""

from __future__ import annotations

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QDialog,
    QFrame,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QPushButton,
    QTreeWidget,
    QTreeWidgetItem,
    QVBoxLayout,
)

from aura.dialogs.ui_chrome import (
    build_dialog_chrome_qss,
    configure_wrap_label,
    resolve_dialog_colors,
)


class FormatDialog(QDialog):
    """Dialog showing all available formats for a URL."""

    format_selected = Signal(str, dict)

    def __init__(self, parent, payload, t, mode="video", container="auto", theme_id=None):
        super().__init__(parent)
        self.setWindowTitle(t.get("format_panel_title", "Available Formats"))
        self.setMinimumSize(720, 460)
        self.resize(980, 620)
        self.setSizeGripEnabled(True)
        self.selected_id = ""
        self.selected_format = {}
        self.t = t
        self.mode = mode
        self.container = container
        self.setStyleSheet(build_dialog_chrome_qss(resolve_dialog_colors(parent, theme_id)))

        if isinstance(payload, dict):
            formats = payload.get("formats", [])
            self.audio_languages = payload.get("audio_languages", [])
            self.subtitle_languages = payload.get("subtitle_languages", [])
            self.auto_subtitle_languages = payload.get("auto_subtitle_languages", [])
        else:
            formats = payload or []
            self.audio_languages = []
            self.subtitle_languages = []
            self.auto_subtitle_languages = []

        layout = QVBoxLayout(self)
        layout.setContentsMargins(18, 18, 18, 18)
        layout.setSpacing(12)

        hero = QFrame()
        hero.setObjectName("dialogHeroCard")
        hero_layout = QVBoxLayout(hero)
        hero_layout.setContentsMargins(22, 18, 22, 18)
        hero_layout.setSpacing(6)

        eyebrow = QLabel("AURA VIDEO DOWNLOADER")
        eyebrow.setObjectName("dialogEyebrow")
        hero_layout.addWidget(eyebrow)

        title = QLabel(t.get("format_panel_title", "Available Formats"))
        title.setObjectName("dialogTitle")
        title.setWordWrap(True)
        configure_wrap_label(title)
        hero_layout.addWidget(title)

        subtitle = QLabel(t.get("format_panel_hint", "Select a format and click Select."))
        subtitle.setObjectName("dialogSubtitle")
        subtitle.setWordWrap(True)
        configure_wrap_label(subtitle)
        hero_layout.addWidget(subtitle)
        layout.addWidget(hero)

        panel = QFrame()
        panel.setObjectName("dialogPanelCard")
        panel_layout = QVBoxLayout(panel)
        panel_layout.setContentsMargins(18, 16, 18, 18)
        panel_layout.setSpacing(10)

        summary_row = QHBoxLayout()
        summary_row.setSpacing(10)
        summary_row.addWidget(self._make_badge(self._summary_line(t.get("format_audio_tracks", "Audio tracks:"), self.audio_languages, t.get("format_none", "none"))))
        summary_row.addWidget(
            self._make_badge(
                self._subtitle_summary_text(),
                object_name="dialogMeta",
            ),
            1,
        )
        panel_layout.addLayout(summary_row)

        self.selection_summary = QLabel(
            t.get(
                "format_guardrail_default",
                "Video-only selections will be merged with best audio automatically. WebM/VP9/Opus formats work best with MKV.",
            )
        )
        self.selection_summary.setObjectName("dialogMeta")
        self.selection_summary.setWordWrap(True)
        configure_wrap_label(self.selection_summary)
        panel_layout.addWidget(self.selection_summary)

        self.tree = QTreeWidget()
        self.tree.setObjectName("dialogTree")
        self.tree.setAlternatingRowColors(True)
        self.tree.setRootIsDecorated(False)
        self.tree.setUniformRowHeights(True)
        self.tree.setSortingEnabled(True)
        headers = [
            t.get(f"format_col_{column}", column)
            for column in ["id", "ext", "kind", "language", "resolution", "fps", "codec", "bitrate", "size", "note"]
        ]
        self.tree.setHeaderLabels(headers)
        self.tree.setMinimumHeight(140)
        self.tree.currentItemChanged.connect(self._on_selection_changed)
        self.tree.itemDoubleClicked.connect(lambda *_args: self._on_select())
        panel_layout.addWidget(self.tree, 1)

        for fmt in formats:
            item = QTreeWidgetItem(
                [
                    fmt.get("id", ""),
                    fmt.get("ext", ""),
                    self._kind_label(fmt.get("kind", "")),
                    self._language_label(fmt.get("language", "")),
                    fmt.get("resolution", ""),
                    fmt.get("fps", ""),
                    fmt.get("codec", ""),
                    fmt.get("bitrate", ""),
                    fmt.get("size", ""),
                    fmt.get("note", ""),
                ]
            )
            item.setData(0, Qt.UserRole, fmt)
            self.tree.addTopLevelItem(item)

        header = self.tree.header()
        header.setSectionResizeMode(QHeaderView.Interactive)
        self.tree.setColumnWidth(0, 76)
        self.tree.setColumnWidth(1, 76)
        self.tree.setColumnWidth(2, 118)
        self.tree.setColumnWidth(3, 108)
        self.tree.setColumnWidth(4, 122)
        self.tree.setColumnWidth(5, 72)
        self.tree.setColumnWidth(6, 220)
        self.tree.setColumnWidth(7, 96)
        self.tree.setColumnWidth(8, 108)
        header.setStretchLastSection(True)
        self.tree.sortItems(0, Qt.AscendingOrder)
        layout.addWidget(panel, 1)

        footer = QFrame()
        footer.setObjectName("dialogFooterCard")
        footer_layout = QHBoxLayout(footer)
        footer_layout.setContentsMargins(14, 10, 14, 10)
        footer_layout.setSpacing(10)
        footer_layout.addStretch()

        btn_clear = QPushButton(t.get("format_clear_btn", "Clear"))
        btn_clear.setObjectName("dialogGhostBtn")
        btn_clear.setCursor(Qt.PointingHandCursor)
        btn_clear.clicked.connect(self._on_clear)
        footer_layout.addWidget(btn_clear)

        btn_select = QPushButton(t.get("format_select_btn", "Select"))
        btn_select.setObjectName("dialogPrimaryBtn")
        btn_select.setCursor(Qt.PointingHandCursor)
        btn_select.clicked.connect(self._on_select)
        btn_select.setDefault(True)
        footer_layout.addWidget(btn_select)

        layout.addWidget(footer)

    def _make_badge(self, text, object_name="dialogBadge"):
        label = QLabel(text)
        label.setObjectName(object_name)
        label.setWordWrap(True)
        configure_wrap_label(label)
        return label

    def _subtitle_summary_text(self):
        chunks = []
        if self.subtitle_languages:
            chunks.append(
                self._summary_line(
                    self.t.get("format_subtitle_tracks", "Subtitles:"),
                    self.subtitle_languages,
                    self.t.get("format_none", "none"),
                )
            )
        if self.auto_subtitle_languages:
            chunks.append(
                self._summary_line(
                    self.t.get("format_auto_subtitle_tracks", "Auto subtitles:"),
                    self.auto_subtitle_languages,
                    self.t.get("format_none", "none"),
                )
            )
        if not chunks:
            return self._summary_line(
                self.t.get("format_subtitle_tracks", "Subtitles:"),
                [],
                self.t.get("format_none", "none"),
            )
        return "   ".join(chunks)

    def _on_select(self):
        item = self.tree.currentItem()
        if item:
            self.selected_id = item.text(0)
            self.selected_format = item.data(0, Qt.UserRole) or {}
            self.format_selected.emit(self.selected_id, self.selected_format)
            self.accept()

    def _on_clear(self):
        self.selected_id = ""
        self.selected_format = {}
        self.format_selected.emit("", {})
        self.accept()

    def _language_label(self, code):
        code = (code or "").strip()
        if not code:
            return "—"
        normalized = code.lower().replace("_", "-")
        base = normalized.split("-", 1)[0]
        return (
            self.t.get(f"lang_{normalized}")
            or self.t.get(f"sub_lang_{normalized}")
            or self.t.get(f"lang_{base}")
            or self.t.get(f"sub_lang_{base}")
            or code
        )

    def _summary_line(self, title, codes, empty_text):
        if not codes:
            return f"{title} {empty_text}"
        return f"{title} {', '.join(self._language_label(code) for code in codes)}"

    def _kind_label(self, kind):
        mapping = {
            "combined": self.t.get("format_kind_combined", "Video + audio"),
            "video-only": self.t.get("format_kind_video_only", "Video only"),
            "audio-only": self.t.get("format_kind_audio_only", "Audio only"),
            "other": self.t.get("format_kind_other", "Other"),
        }
        return mapping.get(kind, kind or "—")

    @staticmethod
    def _prefers_mkv(fmt):
        codec_blob = " ".join(
            [
                str(fmt.get("ext", "")),
                str(fmt.get("codec", "")),
                str(fmt.get("vcodec", "")),
                str(fmt.get("acodec", "")),
            ]
        ).lower()
        return "webm" in codec_blob or "vp9" in codec_blob or "vp8" in codec_blob or "opus" in codec_blob or "vorbis" in codec_blob

    def _on_selection_changed(self, current, previous):
        if not current:
            self.selection_summary.setText(
                self.t.get(
                    "format_guardrail_default",
                    "Video-only selections will be merged with best audio automatically. WebM/VP9/Opus formats work best with MKV.",
                )
            )
            return

        fmt = current.data(0, Qt.UserRole) or {}
        kind = fmt.get("kind", "")
        notes = []
        if kind == "video-only":
            notes.append(
                self.t.get(
                    "format_guardrail_video_only",
                    "This format contains only video. Aura will add the best audio track automatically in video modes.",
                )
            )
        elif kind == "audio-only":
            notes.append(
                self.t.get(
                    "format_guardrail_audio_only",
                    "This format contains only audio. It fits best in Audio mode.",
                )
            )
        else:
            notes.append(
                self.t.get(
                    "format_guardrail_combined",
                    "This format already contains both video and audio.",
                )
            )

        if self._prefers_mkv(fmt):
            notes.append(
                self.t.get(
                    "format_guardrail_mkv",
                    "This codec/container combination is safer with MKV or Auto container.",
                )
            )
        elif self.container == "mp4":
            notes.append(
                self.t.get(
                    "format_guardrail_mp4_ok",
                    "Current MP4 container choice looks acceptable for this format.",
                )
            )

        self.selection_summary.setText(" ".join(notes))
