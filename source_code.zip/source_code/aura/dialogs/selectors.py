#!/usr/bin/env python3
"""Selection dialogs for language, theme, and platform."""

from PySide6.QtCore import Qt
from PySide6.QtGui import QPixmap
from PySide6.QtWidgets import (
    QDialog,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QScrollArea,
    QSizePolicy,
    QVBoxLayout,
    QWidget,
)

from aura.platforms import CATEGORY_INFO, CATEGORY_ORDER, PLATFORM_CONFIGS, get_platform_name
from aura.themes import THEMES, get_theme_config, save_theme_config
from aura.translations import get_all_translations

TRANSLATIONS = get_all_translations()


def _configure_wrap_label(label):
    policy = label.sizePolicy()
    policy.setHorizontalPolicy(QSizePolicy.Ignored)
    policy.setVerticalPolicy(QSizePolicy.Minimum)
    policy.setHeightForWidth(True)
    label.setSizePolicy(policy)


def _configure_card_button(button):
    button.setAttribute(Qt.WA_StyledBackground, True)
    button.setAutoDefault(False)
    button.setDefault(False)


def _configure_card_child(widget):
    widget.setAttribute(Qt.WA_TransparentForMouseEvents, True)


def _dialog_qss(colors):
    return f"""
        QDialog {{
            background: {colors['bg_main']};
        }}
        QFrame#heroCard {{
            background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                stop:0 {colors['bg_card']}, stop:1 {colors['bg_deep']});
            border: 1px solid {colors['border']};
            border-radius: 22px;
        }}
        QLabel#dialogEyebrow {{
            color: {colors['accent']};
            font-size: 11px;
            font-weight: 700;
            letter-spacing: 0.08em;
        }}
        QLabel#dialogTitle {{
            color: {colors['text']};
            font-size: 20px;
            font-weight: 700;
        }}
        QLabel#dialogSubtitle {{
            color: {colors['text_hint']};
            font-size: 12px;
        }}
        QPushButton#choiceCard, QPushButton#themeCard, QPushButton#platformCard {{
            background: {colors['bg_card']};
            color: {colors['text']};
            border: 1px solid {colors['border']};
            border-radius: 18px;
            padding: 0;
            text-align: left;
        }}
        QPushButton#choiceCard:hover, QPushButton#themeCard:hover, QPushButton#platformCard:hover {{
            background: {colors['bg_hover']};
            border: 1px solid {colors['accent']};
        }}
        QPushButton#choiceCard:pressed, QPushButton#themeCard:pressed, QPushButton#platformCard:pressed {{
            background: {colors['bg_button']};
        }}
        QLabel#choiceTitle {{
            color: {colors['text']};
            font-size: 14px;
            font-weight: 700;
        }}
        QLabel#choiceText {{
            color: {colors['text_hint']};
            font-size: 11px;
        }}
        QLabel#choiceBadge {{
            color: {colors['accent']};
            background: {colors['bg_button']};
            border: 1px solid {colors['border']};
            border-radius: 999px;
            padding: 4px 10px;
            font-size: 10px;
            font-weight: 700;
        }}
        QLabel#platformCategory {{
            color: {colors['accent']};
            font-size: 12px;
            font-weight: 700;
            padding: 6px 0 0 2px;
        }}
        QLabel#themePreview {{
            border-radius: 12px;
            min-height: 72px;
        }}
        QScrollArea {{
            border: none;
            background: {colors['bg_main']};
        }}
        QScrollArea#selectorScroll,
        QScrollArea#selectorScroll > QWidget > QWidget,
        QWidget#selectorScrollHost {{
            background: {colors['bg_main']};
        }}
        QScrollBar:vertical {{
            background: {colors['bg_deep']};
            width: 10px;
            border-radius: 5px;
            margin: 6px 0;
        }}
        QScrollBar::handle:vertical {{
            background: {colors['bg_button']};
            min-height: 34px;
            border-radius: 5px;
        }}
        QScrollBar::handle:vertical:hover {{
            background: {colors['accent']};
        }}
        QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{
            height: 0px;
        }}
    """


def _build_header(layout, colors, eyebrow, title_text, subtitle_text):
    hero = QFrame()
    hero.setObjectName("heroCard")
    hero_layout = QVBoxLayout(hero)
    hero_layout.setContentsMargins(22, 20, 22, 18)
    hero_layout.setSpacing(8)

    eyebrow_lbl = QLabel(eyebrow)
    eyebrow_lbl.setObjectName("dialogEyebrow")
    hero_layout.addWidget(eyebrow_lbl)

    title = QLabel(title_text)
    title.setObjectName("dialogTitle")
    title.setWordWrap(True)
    _configure_wrap_label(title)
    hero_layout.addWidget(title)

    subtitle = QLabel(subtitle_text)
    subtitle.setObjectName("dialogSubtitle")
    subtitle.setWordWrap(True)
    _configure_wrap_label(subtitle)
    hero_layout.addWidget(subtitle)

    layout.addWidget(hero)


def _build_card_button(title_text, body_text, badge_text):
    button = QPushButton()
    button.setObjectName("choiceCard")
    button.setCursor(Qt.PointingHandCursor)
    _configure_card_button(button)

    card_layout = QVBoxLayout(button)
    card_layout.setContentsMargins(18, 16, 18, 16)
    card_layout.setSpacing(8)

    title = QLabel(title_text)
    title.setObjectName("choiceTitle")
    title.setWordWrap(True)
    _configure_wrap_label(title)
    _configure_card_child(title)
    card_layout.addWidget(title)

    body = QLabel(body_text)
    body.setObjectName("choiceText")
    body.setWordWrap(True)
    _configure_wrap_label(body)
    _configure_card_child(body)
    card_layout.addWidget(body)

    badge = QLabel(badge_text)
    badge.setObjectName("choiceBadge")
    _configure_card_child(badge)
    card_layout.addWidget(badge, 0, Qt.AlignLeft)
    card_layout.addStretch()
    return button


def _preview_pixmap():
    pixmap = QPixmap(220, 72)
    pixmap.fill(Qt.transparent)
    return pixmap


class LanguageSelector(QDialog):
    def __init__(self, parent=None, theme_id=None):
        super().__init__(parent)
        resolved_theme = theme_id or getattr(parent, "theme_id", None) or get_theme_config()
        colors = THEMES.get(resolved_theme, THEMES["light"])["colors"]
        self.setWindowTitle("Aura Video Downloader")
        self.setMinimumSize(560, 320)
        self.resize(620, 360)
        self.setSizeGripEnabled(True)
        self._selection = None
        self.setStyleSheet(_dialog_qss(colors))

        layout = QVBoxLayout(self)
        layout.setContentsMargins(18, 18, 18, 18)
        layout.setSpacing(14)

        _build_header(
            layout,
            colors,
            "AURA VIDEO DOWNLOADER",
            "Choose language / Выберите язык",
            "Pick the interface language for the next launches. / Выберите язык интерфейса для следующих запусков.",
        )

        cards = QHBoxLayout()
        cards.setSpacing(12)

        ru_btn = _build_card_button(
            "Русский",
            "Полный интерфейс, подсказки и системные сообщения на русском.",
            "Основной вариант",
        )
        ru_btn.setMinimumHeight(156)
        ru_btn.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.MinimumExpanding)
        ru_btn.clicked.connect(lambda checked=False: self._select("ru"))
        cards.addWidget(ru_btn)

        en_btn = _build_card_button(
            "English",
            "Full interface, hints, and system messages in English.",
            "International",
        )
        en_btn.setMinimumHeight(156)
        en_btn.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.MinimumExpanding)
        en_btn.clicked.connect(lambda checked=False: self._select("en"))
        cards.addWidget(en_btn)

        layout.addLayout(cards)
        layout.addStretch()

    def _select(self, lang):
        self._selection = lang
        self.accept()

    def run(self):
        self.exec()
        return self._selection


class ThemeSelector(QDialog):
    def __init__(self, lang="en", parent=None):
        super().__init__(parent)
        self.lang = lang
        self.t = TRANSLATIONS.get(lang, TRANSLATIONS["en"])
        resolved_theme = getattr(parent, "theme_id", "light")
        colors = THEMES.get(resolved_theme, THEMES["light"])["colors"]

        self.setWindowTitle("Aura Video Downloader - " + self.t.get("theme_title", "Theme"))
        self.setMinimumSize(640, 360)
        self.resize(840, 520)
        self.setSizeGripEnabled(True)
        self._selection = None
        self.setStyleSheet(_dialog_qss(colors))

        layout = QVBoxLayout(self)
        layout.setContentsMargins(18, 18, 18, 18)
        layout.setSpacing(14)

        _build_header(
            layout,
            colors,
            "AURA VIDEO DOWNLOADER",
            self.t.get("theme_title", "Theme"),
            self.t.get(
                "theme_dialog_subtitle",
                "Choose the visual style that matches your workspace. All functionality stays available.",
            ),
        )

        scroll = QScrollArea()
        scroll.setObjectName("selectorScroll")
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        cards_host = QWidget()
        cards_host.setObjectName("selectorScrollHost")
        cards = QGridLayout(cards_host)
        cards.setContentsMargins(0, 0, 0, 0)
        cards.setHorizontalSpacing(12)
        cards.setVerticalSpacing(12)
        for index, theme_id in enumerate(("dark", "gray", "light")):
            theme = THEMES[theme_id]
            theme_colors = theme["colors"]
            card = QPushButton()
            card.setObjectName("themeCard")
            card.setCursor(Qt.PointingHandCursor)
            card.setMinimumSize(220, 196)
            card.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.MinimumExpanding)
            _configure_card_button(card)

            card_layout = QVBoxLayout(card)
            card_layout.setContentsMargins(16, 16, 16, 16)
            card_layout.setSpacing(10)

            preview = QLabel()
            preview.setObjectName("themePreview")
            preview.setPixmap(_preview_pixmap())
            _configure_card_child(preview)
            preview.setStyleSheet(
                f"background: qlineargradient(x1:0, y1:0, x2:1, y2:1, "
                f"stop:0 {theme_colors['bg_card']}, stop:1 {theme_colors['accent']}); "
                f"border: 1px solid {theme_colors['border']};"
            )
            card_layout.addWidget(preview)

            title = QLabel(theme.get(f"name_{lang}", theme["name_en"]))
            title.setObjectName("choiceTitle")
            title.setWordWrap(True)
            _configure_wrap_label(title)
            _configure_card_child(title)
            card_layout.addWidget(title)

            desc = QLabel(
                self.t.get(
                    f"theme_{theme_id}_desc",
                    {
                        "dark": "Deep contrast, premium focus, and the strongest cinematic feel.",
                        "gray": "Balanced metallic workspace with restrained accents and maximum readability.",
                        "light": "Bright studio look with airy spacing and polished business contrast.",
                    }[theme_id],
                )
            )
            desc.setObjectName("choiceText")
            desc.setWordWrap(True)
            _configure_wrap_label(desc)
            _configure_card_child(desc)
            card_layout.addWidget(desc)
            card_layout.addStretch()

            card.clicked.connect(lambda checked=False, t_id=theme_id: self._select(t_id))
            cards.addWidget(card, index // 2, index % 2)

        cards.setColumnStretch(0, 1)
        cards.setColumnStretch(1, 1)

        scroll.setWidget(cards_host)
        layout.addWidget(scroll, 1)

    def _select(self, theme_id):
        save_theme_config(theme_id)
        self._selection = theme_id
        self.accept()

    def run(self):
        self.exec()
        return self._selection


class PlatformSelector(QDialog):
    def __init__(self, lang="en", theme_id="light", parent=None):
        super().__init__(parent)
        self.lang = lang
        self.t = TRANSLATIONS.get(lang, TRANSLATIONS["en"])
        colors = THEMES.get(theme_id, THEMES["light"])["colors"]

        self.setWindowTitle("Aura Video Downloader - " + self.t.get("platform_title", "Choose platform"))
        self.setMinimumSize(720, 560)
        self.resize(920, 720)
        self.setSizeGripEnabled(True)
        self._selection = None
        self.setStyleSheet(_dialog_qss(colors))

        layout = QVBoxLayout(self)
        layout.setContentsMargins(18, 18, 18, 18)
        layout.setSpacing(14)

        _build_header(
            layout,
            colors,
            "AURA VIDEO DOWNLOADER",
            self.t.get("platform_title", "Choose platform"),
            self.t.get(
                "platform_dialog_subtitle",
                "Switch platform presets without losing the rest of the downloader features.",
            ),
        )

        scroll = QScrollArea()
        scroll.setObjectName("selectorScroll")
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        scroll_widget = QWidget()
        scroll_widget.setObjectName("selectorScrollHost")

        grid = QGridLayout(scroll_widget)
        grid.setContentsMargins(0, 0, 0, 0)
        grid.setHorizontalSpacing(12)
        grid.setVerticalSpacing(12)

        category_titles = {
            "video": "Video Platforms" if lang == "en" else "Видеоплатформы",
            "social": "Social Media" if lang == "en" else "Социальные сети",
            "adult": "Adult Content" if lang == "en" else "Контент 18+",
        }

        row = 0
        active_categories = [
            category
            for category in CATEGORY_ORDER
            if any(pc.get("category", "video") == category for pc in PLATFORM_CONFIGS.values())
        ]

        for category in active_categories:
            category_label = QLabel(category_titles.get(category, category.title()))
            category_label.setObjectName("platformCategory")
            grid.addWidget(category_label, row, 0, 1, 2)
            row += 1

            col = 0
            for platform_id, platform_config in PLATFORM_CONFIGS.items():
                if platform_config.get("category", "video") != category:
                    continue

                card = QPushButton()
                card.setObjectName("platformCard")
                card.setCursor(Qt.PointingHandCursor)
                card.setMinimumHeight(118)
                card.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.MinimumExpanding)
                _configure_card_button(card)

                card_layout = QVBoxLayout(card)
                card_layout.setContentsMargins(16, 16, 16, 16)
                card_layout.setSpacing(8)

                title = QLabel(get_platform_name(platform_id, lang))
                title.setObjectName("choiceTitle")
                title.setWordWrap(True)
                _configure_wrap_label(title)
                _configure_card_child(title)
                card_layout.addWidget(title)

                category_info = CATEGORY_INFO.get(category, {})
                desc_text = (
                    platform_config.get(f"description_{lang}")
                    or platform_config.get("description_en")
                    or category_info.get(f"description_{lang}")
                    or category_info.get("description_en")
                    or self.t.get("platform_card_default", "Download video and audio with platform-specific presets.")
                )
                desc = QLabel(desc_text)
                desc.setObjectName("choiceText")
                desc.setWordWrap(True)
                _configure_wrap_label(desc)
                _configure_card_child(desc)
                card_layout.addWidget(desc)

                domains = platform_config.get("domains", [])[:2]
                if domains:
                    badge = QLabel(" / ".join(domains))
                    badge.setObjectName("choiceBadge")
                    _configure_card_child(badge)
                    card_layout.addWidget(badge, 0, Qt.AlignLeft)

                card_layout.addStretch()
                card.clicked.connect(lambda checked=False, pid=platform_id: self._select(pid))
                grid.addWidget(card, row, col)

                col += 1
                if col >= 2:
                    col = 0
                    row += 1

            if col != 0:
                row += 1

        scroll.setWidget(scroll_widget)
        layout.addWidget(scroll)

    def _select(self, platform_id):
        self._selection = platform_id
        self.accept()

    def run(self):
        self.exec()
        return self._selection
