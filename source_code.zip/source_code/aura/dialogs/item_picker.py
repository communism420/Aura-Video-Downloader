#!/usr/bin/env python3
from __future__ import annotations

"""Dialog for manual selection of playlist/channel/search items."""

from PySide6.QtCore import Qt
from PySide6.QtGui import QKeySequence, QShortcut
from PySide6.QtWidgets import (
    QDialog,
    QFrame,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QTreeWidget,
    QTreeWidgetItem,
    QVBoxLayout,
)

from aura.dialogs.ui_chrome import (
    build_dialog_chrome_qss,
    configure_wrap_label,
    resolve_dialog_colors,
    resolve_dialog_translations,
)


def _fmt_duration(seconds):
    try:
        total = int(seconds or 0)
    except (TypeError, ValueError):
        return ""
    if total <= 0:
        return ""
    hours, rem = divmod(total, 3600)
    minutes, secs = divmod(rem, 60)
    if hours:
        return f"{hours}:{minutes:02d}:{secs:02d}"
    return f"{minutes}:{secs:02d}"


class ItemPickerDialog(QDialog):
    """Checkable list of extracted entries."""

    def __init__(self, parent=None, title=None, t=None, theme_id=None):
        super().__init__(parent)
        self.t = resolve_dialog_translations(parent, t=t)
        self._source_title = ""
        resolved_title = title or self.t.get("manual_selection_title", "Manual selection")

        self.setWindowTitle(resolved_title)
        self.setMinimumSize(760, 520)
        self.resize(920, 640)
        self.setSizeGripEnabled(True)
        self.setStyleSheet(build_dialog_chrome_qss(resolve_dialog_colors(parent, theme_id)))

        layout = QVBoxLayout(self)
        layout.setContentsMargins(18, 18, 18, 18)
        layout.setSpacing(12)

        hero = QFrame()
        hero.setObjectName("dialogHeroCard")
        hero_layout = QVBoxLayout(hero)
        hero_layout.setContentsMargins(22, 18, 22, 18)
        hero_layout.setSpacing(6)

        eyebrow = QLabel("AURA VIDEO DOWNLOADER")
        eyebrow.setObjectName("dialogEyebrow")
        hero_layout.addWidget(eyebrow)

        headline = QLabel(resolved_title)
        headline.setObjectName("dialogTitle")
        headline.setWordWrap(True)
        configure_wrap_label(headline)
        hero_layout.addWidget(headline)

        subtitle = QLabel(
            self.t.get(
                "manual_selection_dialog_hint",
                "Choose which items should be downloaded. Filter first if you only want a subset.",
            )
        )
        subtitle.setObjectName("dialogSubtitle")
        subtitle.setWordWrap(True)
        configure_wrap_label(subtitle)
        hero_layout.addWidget(subtitle)
        layout.addWidget(hero)

        panel = QFrame()
        panel.setObjectName("dialogPanelCard")
        panel_layout = QVBoxLayout(panel)
        panel_layout.setContentsMargins(18, 16, 18, 18)
        panel_layout.setSpacing(10)

        toolbar = QHBoxLayout()
        toolbar.setSpacing(8)
        self.filter_input = QLineEdit()
        self.filter_input.setObjectName("dialogField")
        self.filter_input.setPlaceholderText(
            self.t.get("manual_selection_filter_placeholder", "Filter items")
        )
        self.filter_input.setAccessibleName(
            self.t.get("manual_selection_filter_accessible", "Manual selection filter")
        )
        self.filter_input.textChanged.connect(self._apply_filter)
        toolbar.addWidget(self.filter_input, 1)

        self.btn_all = QPushButton(self.t.get("manual_selection_select_all", "Select all"))
        self.btn_all.setObjectName("dialogSecondaryBtn")
        self.btn_all.setCursor(Qt.PointingHandCursor)
        self.btn_all.setAccessibleName(
            self.t.get("manual_selection_select_all_accessible", "Select all visible items")
        )
        self.btn_all.clicked.connect(lambda: self._set_all(Qt.Checked))
        toolbar.addWidget(self.btn_all)

        self.btn_clear = QPushButton(self.t.get("manual_selection_clear", "Clear"))
        self.btn_clear.setObjectName("dialogGhostBtn")
        self.btn_clear.setCursor(Qt.PointingHandCursor)
        self.btn_clear.setAccessibleName(
            self.t.get("manual_selection_clear_accessible", "Clear visible selection")
        )
        self.btn_clear.clicked.connect(lambda: self._set_all(Qt.Unchecked))
        toolbar.addWidget(self.btn_clear)
        panel_layout.addLayout(toolbar)

        self.summary_label = QLabel()
        self.summary_label.setObjectName("dialogMeta")
        self.summary_label.setWordWrap(True)
        configure_wrap_label(self.summary_label)
        panel_layout.addWidget(self.summary_label)

        self.tree = QTreeWidget()
        self.tree.setObjectName("dialogTree")
        self.tree.setRootIsDecorated(False)
        self.tree.setAlternatingRowColors(True)
        self.tree.setAccessibleName(
            self.t.get("manual_selection_tree_accessible", "Manual selection item list")
        )
        self.tree.setHeaderLabels(
            [
                "#",
                self.t.get("manual_selection_col_title", "Title"),
                self.t.get("manual_selection_col_duration", "Duration"),
                self.t.get("manual_selection_col_uploader", "Uploader"),
            ]
        )
        self.tree.setSortingEnabled(True)
        self.tree.itemChanged.connect(self._update_summary)
        self.tree.setColumnWidth(0, 70)
        self.tree.setColumnWidth(1, 420)
        self.tree.setColumnWidth(2, 110)
        self.tree.setColumnWidth(3, 200)
        panel_layout.addWidget(self.tree, 1)
        layout.addWidget(panel, 1)

        footer = QFrame()
        footer.setObjectName("dialogFooterCard")
        footer_layout = QHBoxLayout(footer)
        footer_layout.setContentsMargins(14, 10, 14, 10)
        footer_layout.setSpacing(10)
        footer_layout.addStretch()

        self.btn_cancel = QPushButton(self.t.get("manual_selection_cancel", "Cancel"))
        self.btn_cancel.setObjectName("dialogGhostBtn")
        self.btn_cancel.setCursor(Qt.PointingHandCursor)
        self.btn_cancel.setAccessibleName(
            self.t.get("manual_selection_cancel_accessible", "Cancel manual selection")
        )
        self.btn_cancel.clicked.connect(self.reject)
        footer_layout.addWidget(self.btn_cancel)

        self.btn_accept = QPushButton(
            self.t.get("manual_selection_download_selected", "Download selected")
        )
        self.btn_accept.setObjectName("dialogPrimaryBtn")
        self.btn_accept.setCursor(Qt.PointingHandCursor)
        self.btn_accept.setAccessibleName(
            self.t.get("manual_selection_accept_accessible", "Download selected items")
        )
        self.btn_accept.clicked.connect(self._accept_if_selected)
        footer_layout.addWidget(self.btn_accept)
        layout.addWidget(footer)

        self._shortcut_focus_filter = QShortcut(QKeySequence("Ctrl+F"), self)
        self._shortcut_focus_filter.activated.connect(self.filter_input.setFocus)
        self._shortcut_select_all = QShortcut(QKeySequence("Ctrl+A"), self)
        self._shortcut_select_all.activated.connect(lambda: self._set_all(Qt.Checked))
        self._shortcut_clear_all = QShortcut(QKeySequence("Ctrl+Shift+A"), self)
        self._shortcut_clear_all.activated.connect(lambda: self._set_all(Qt.Unchecked))
        self._shortcut_accept = QShortcut(QKeySequence("Ctrl+Return"), self)
        self._shortcut_accept.activated.connect(self._accept_if_selected)

    def set_entries(self, entries, source_title=""):
        self.tree.clear()
        self._source_title = source_title or ""
        for entry in entries or []:
            item = QTreeWidgetItem(
                [
                    str(entry.get("index", "")),
                    entry.get("title", ""),
                    _fmt_duration(entry.get("duration")),
                    entry.get("uploader", ""),
                ]
            )
            item.setData(0, Qt.UserRole, int(entry.get("index", 0) or 0))
            item.setData(1, Qt.UserRole, entry)
            item.setFlags(item.flags() | Qt.ItemIsUserCheckable)
            item.setCheckState(0, Qt.Checked)
            item.setToolTip(1, entry.get("webpage_url", "") or entry.get("id", ""))
            self.tree.addTopLevelItem(item)
        self.tree.sortItems(0, Qt.AscendingOrder)
        self._update_summary()

    def selected_indices(self):
        indices = []
        for i in range(self.tree.topLevelItemCount()):
            item = self.tree.topLevelItem(i)
            if item.isHidden():
                continue
            if item.checkState(0) == Qt.Checked:
                index = int(item.data(0, Qt.UserRole) or 0)
                if index > 0:
                    indices.append(index)
        return indices

    def _set_all(self, state):
        for i in range(self.tree.topLevelItemCount()):
            item = self.tree.topLevelItem(i)
            if not item.isHidden():
                item.setCheckState(0, state)
        self._update_summary()

    def _apply_filter(self, text):
        needle = (text or "").strip().lower()
        for i in range(self.tree.topLevelItemCount()):
            item = self.tree.topLevelItem(i)
            haystack = " ".join(item.text(col).lower() for col in range(4))
            item.setHidden(bool(needle) and needle not in haystack)
        self._update_summary()

    def _update_summary(self, *_args):
        visible = 0
        selected = 0
        for i in range(self.tree.topLevelItemCount()):
            item = self.tree.topLevelItem(i)
            if item.isHidden():
                continue
            visible += 1
            if item.checkState(0) == Qt.Checked:
                selected += 1

        parts = []
        if self._source_title:
            parts.append(self._source_title)
        parts.append(
            self.t.get("manual_selection_selected_summary", "Selected: {selected} / {visible}").format(
                selected=selected,
                visible=visible,
            )
        )
        self.summary_label.setText("\n".join(parts))

    def _accept_if_selected(self):
        if self.selected_indices():
            self.accept()
