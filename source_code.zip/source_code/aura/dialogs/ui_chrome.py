#!/usr/bin/env python3
from __future__ import annotations

"""Shared dialog styling helpers."""

from PySide6.QtWidgets import QSizePolicy

from aura.themes import THEMES
from aura.translations import get_translations


def resolve_dialog_colors(parent=None, theme_id=None):
    resolved_theme = theme_id or getattr(parent, "theme_id", "light")
    return THEMES.get(resolved_theme, THEMES["light"])["colors"]


def resolve_dialog_translations(parent=None, t=None, lang=None):
    if isinstance(t, dict):
        return t
    parent_t = getattr(parent, "t", None)
    if isinstance(parent_t, dict):
        return parent_t
    return get_translations(lang or getattr(parent, "lang", "en"))


def configure_wrap_label(label):
    policy = label.sizePolicy()
    policy.setHorizontalPolicy(QSizePolicy.Ignored)
    policy.setVerticalPolicy(QSizePolicy.Minimum)
    policy.setHeightForWidth(True)
    label.setSizePolicy(policy)


def build_dialog_chrome_qss(colors):
    text_dim = colors.get("text_dim", colors["text_hint"])
    return f"""
        QDialog {{
            background: {colors['bg_main']};
        }}
        QFrame#dialogHeroCard {{
            background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                stop:0 {colors['bg_card']}, stop:1 {colors['bg_deep']});
            border: 1px solid {colors['border']};
            border-radius: 22px;
        }}
        QFrame#dialogPanelCard, QFrame#dialogFooterCard {{
            background: {colors['bg_card']};
            border: 1px solid {colors['border']};
            border-radius: 18px;
        }}
        QLabel#dialogEyebrow {{
            color: {colors['accent']};
            font-size: 11px;
            font-weight: 700;
            letter-spacing: 0.08em;
        }}
        QLabel#dialogTitle {{
            color: {colors['text']};
            font-size: 18px;
            font-weight: 700;
        }}
        QLabel#dialogSubtitle {{
            color: {colors['text_hint']};
            font-size: 11px;
        }}
        QLabel#dialogMeta {{
            color: {text_dim};
            font-size: 10px;
        }}
        QLabel#dialogBadge {{
            color: {colors['accent']};
            background: {colors['bg_button']};
            border: 1px solid {colors['border']};
            border-radius: 999px;
            padding: 4px 10px;
            font-size: 10px;
            font-weight: 700;
        }}
        QLabel#dialogSectionTitle {{
            color: {colors['text']};
            font-size: 12px;
            font-weight: 700;
        }}
        QLineEdit#dialogField, QPlainTextEdit#dialogEditor, QTreeWidget#dialogTree {{
            background: {colors['bg_entry']};
            color: {colors['text']};
            border: 1px solid {colors['border']};
            border-radius: 14px;
            padding: 8px 10px;
            selection-background-color: {colors['select']};
            alternate-background-color: {colors['bg_main']};
        }}
        QTreeWidget#dialogTree {{
            padding: 6px;
        }}
        QTreeWidget#dialogTree::item {{
            padding: 6px 4px;
        }}
        QTreeWidget#dialogTree::item:hover {{
            background: {colors['bg_hover']};
        }}
        QTreeWidget#dialogTree::item:selected {{
            background: {colors['accent']};
            color: {colors['bg_main']};
        }}
        QHeaderView::section {{
            background: {colors['bg_button']};
            color: {colors['text']};
            border: none;
            border-bottom: 1px solid {colors['border']};
            padding: 8px 10px;
            font-weight: 700;
        }}
        QScrollBar:vertical, QScrollBar:horizontal {{
            background: {colors['bg_deep']};
            border: none;
            border-radius: 5px;
        }}
        QScrollBar:vertical {{
            width: 10px;
            margin: 6px 0;
        }}
        QScrollBar:horizontal {{
            height: 10px;
            margin: 0 6px;
        }}
        QScrollBar::handle:vertical, QScrollBar::handle:horizontal {{
            background: {colors['bg_button']};
            border-radius: 5px;
            min-height: 28px;
            min-width: 28px;
        }}
        QScrollBar::handle:vertical:hover, QScrollBar::handle:horizontal:hover {{
            background: {colors['accent']};
        }}
        QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical,
        QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {{
            width: 0px;
            height: 0px;
        }}
        QPushButton#dialogPrimaryBtn, QPushButton#dialogSecondaryBtn, QPushButton#dialogGhostBtn {{
            min-height: 38px;
            border-radius: 12px;
            padding: 0 16px;
            font-size: 10pt;
            font-weight: 700;
        }}
        QPushButton#dialogPrimaryBtn {{
            background: {colors['accent']};
            color: {colors['bg_main']};
            border: none;
        }}
        QPushButton#dialogPrimaryBtn:hover {{
            background: {colors['bg_hover']};
        }}
        QPushButton#dialogSecondaryBtn {{
            background: {colors['bg_button']};
            color: {colors['text']};
            border: 1px solid {colors['border']};
        }}
        QPushButton#dialogSecondaryBtn:hover, QPushButton#dialogGhostBtn:hover {{
            background: {colors['bg_hover']};
            border-color: {colors['accent']};
        }}
        QPushButton#dialogGhostBtn {{
            background: {colors['bg_card']};
            color: {colors['text']};
            border: 1px solid {colors['border']};
        }}
    """
