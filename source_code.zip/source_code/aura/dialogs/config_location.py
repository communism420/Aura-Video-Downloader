#!/usr/bin/env python3
"""Config location dialog for first-run settings path selection."""
import time
from pathlib import Path

from PySide6.QtCore import Qt, QTimer
from PySide6.QtWidgets import (
    QDialog,
    QFileDialog,
    QFrame,
    QHBoxLayout,
    QLabel,
    QMessageBox,
    QPushButton,
    QScrollArea,
    QSizePolicy,
    QVBoxLayout,
)

import aura.utils as aura_utils
from aura.constants import SETTINGS_FOLDER_NAME
from aura.themes import THEMES, get_theme_config
from aura.utils import get_pointer_file


def _dialog_qss(colors):
    return f"""
        QDialog {{
            background: {colors['bg_main']};
        }}
        QScrollArea, QScrollArea > QWidget > QWidget, QWidget#configScrollHost {{
            background: {colors['bg_main']};
            border: none;
        }}
        QFrame#heroCard, QFrame#choiceCard, QFrame#noteCard {{
            background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                stop:0 {colors['bg_card']}, stop:1 {colors['bg_deep']});
            border: 1px solid {colors['border']};
            border-radius: 22px;
        }}
        QLabel#eyebrow {{
            color: {colors['accent']};
            font-size: 11px;
            font-weight: 700;
            letter-spacing: 0.08em;
        }}
        QLabel#title {{
            color: {colors['text']};
            font-size: 22px;
            font-weight: 700;
        }}
        QLabel#subtitle, QLabel#choiceText, QLabel#noteText {{
            color: {colors['text_hint']};
            font-size: 12px;
        }}
        QLabel#choiceTitle {{
            color: {colors['text']};
            font-size: 15px;
            font-weight: 700;
        }}
        QLabel#choicePathBlock {{
            color: {colors['accent']};
            background: {colors['bg_entry']};
            border: 1px solid {colors['border']};
            border-radius: 14px;
            padding: 8px 10px;
            font-size: 10px;
            font-weight: 600;
        }}
        QLabel#choiceBadge {{
            color: {colors['accent']};
            background: {colors['bg_button']};
            border: 1px solid {colors['border']};
            border-radius: 999px;
            padding: 4px 10px;
            font-size: 10px;
            font-weight: 700;
        }}
        QLabel#noteTitle {{
            color: {colors['text']};
            font-size: 13px;
            font-weight: 700;
        }}
        QPushButton#primaryBtn, QPushButton#secondaryBtn {{
            min-height: 40px;
            border-radius: 14px;
            padding: 0 16px;
            font-size: 12px;
            font-weight: 700;
        }}
        QPushButton#primaryBtn {{
            background: {colors['accent']};
            color: {colors['bg_main']};
            border: none;
        }}
        QPushButton#primaryBtn:hover {{
            background: {colors['bg_hover']};
        }}
        QPushButton#secondaryBtn {{
            background: {colors['bg_button']};
            color: {colors['text']};
            border: 1px solid {colors['border']};
        }}
        QPushButton#secondaryBtn:hover {{
            background: {colors['bg_hover']};
            border-color: {colors['accent']};
        }}
    """


class ConfigLocationDialog(QDialog):
    """Ask the user where to store settings on first run."""

    def __init__(self, lang="en", parent=None, theme_id=None):
        super().__init__(parent)
        self.lang = lang
        self.result_path = None
        self._key1_held_since = None
        self._debug_timer = QTimer(self)
        self._debug_timer.setInterval(500)
        self._debug_timer.timeout.connect(self._check_debug_hold)

        self.setWindowFlags(self.windowFlags() & ~Qt.WindowCloseButtonHint)

        texts = {
            "ru": {
                "title": "Где хранить настройки",
                "eyebrow": "AURA VIDEO DOWNLOADER",
                "headline": "Выберите папку для сохранения данных программы",
                "subtitle": "Настройки, история, cookies, база загрузок и служебные файлы будут храниться в отдельной папке. Позже это можно полностью сбросить из интерфейса.",
                "home_title": "Домашняя папка",
                "home_text": "Стандартный вариант. Папка создаётся в профиле пользователя и подходит для обычного использования.",
                "home_btn": "Использовать домашнюю папку",
                "custom_title": "Своя папка",
                "custom_text": "Подходит, если хотите держать все данные рядом со скриптом, на другом диске или в отдельном каталоге.",
                "custom_btn": "Выбрать свою папку",
                "home_badge": "Рекомендуется",
                "custom_badge": "Гибкий вариант",
                "note_title": "Что именно будет создано",
                "note_text": "Программа создаст только папку настроек Aura Video Downloader внутри выбранного места и не будет менять другие системные каталоги.",
                "error_folder": "Не удалось создать папку настроек:\n{e}",
            },
            "en": {
                "title": "Settings Location",
                "eyebrow": "AURA VIDEO DOWNLOADER",
                "headline": "Choose where the app should keep its data",
                "subtitle": "Settings, history, cookies, the downloads database, and service files are stored in a separate folder. This can be fully reset later from the interface.",
                "home_title": "Home folder",
                "home_text": "Recommended default. The app creates its data folder inside your user profile and keeps things predictable.",
                "home_btn": "Use home folder",
                "custom_title": "Custom folder",
                "custom_text": "Use this if you want all app data next to the script, on another drive, or inside your own directory.",
                "custom_btn": "Choose custom folder",
                "home_badge": "Recommended",
                "custom_badge": "Flexible option",
                "note_title": "What will be created",
                "note_text": "The app creates only the Aura Video Downloader settings folder inside the selected location and does not modify other system directories.",
                "error_folder": "Cannot create settings folder:\n{e}",
            },
        }
        self._t = texts.get(lang, texts["en"])
        resolved_theme = theme_id or getattr(parent, "theme_id", None) or get_theme_config()
        colors = THEMES.get(resolved_theme, THEMES["light"])["colors"]

        self.setWindowTitle(f"Aura Video Downloader - {self._t['title']}")
        self.setMinimumSize(620, 420)
        self.resize(820, 620)
        self.setSizeGripEnabled(True)
        self.setStyleSheet(_dialog_qss(colors))

        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(14)

        scroll = QScrollArea()
        scroll.setObjectName("configLocationScroll")
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        content = QFrame()
        content.setObjectName("configScrollHost")
        content_layout = QVBoxLayout(content)
        content_layout.setContentsMargins(0, 0, 0, 0)
        content_layout.setSpacing(14)
        content_layout.addWidget(self._build_header())
        content_layout.addWidget(self._build_choice_cards())
        content_layout.addWidget(self._build_note_card())
        content_layout.addStretch()
        scroll.setWidget(content)
        layout.addWidget(scroll, 1)

    def _build_header(self):
        hero = QFrame()
        hero.setObjectName("heroCard")
        hero_layout = QVBoxLayout(hero)
        hero_layout.setContentsMargins(22, 20, 22, 18)
        hero_layout.setSpacing(8)

        eyebrow = QLabel(self._t["eyebrow"])
        eyebrow.setObjectName("eyebrow")
        hero_layout.addWidget(eyebrow)

        title = QLabel(self._t["headline"])
        title.setObjectName("title")
        title.setWordWrap(True)
        self._configure_wrap_label(title)
        hero_layout.addWidget(title)

        subtitle = QLabel(self._t["subtitle"])
        subtitle.setObjectName("subtitle")
        subtitle.setWordWrap(True)
        self._configure_wrap_label(subtitle)
        hero_layout.addWidget(subtitle)
        return hero

    def _build_choice_cards(self):
        container = QFrame()
        container_layout = QVBoxLayout(container)
        container_layout.setContentsMargins(0, 0, 0, 0)
        container_layout.setSpacing(14)
        container_layout.addWidget(
            self._build_choice_card(
                self._t["home_title"],
                self._t["home_text"],
                str(Path.home() / SETTINGS_FOLDER_NAME),
                self._t["home_badge"],
                self._t["home_btn"],
                self._use_home,
                True,
            )
        )
        container_layout.addWidget(
            self._build_choice_card(
                self._t["custom_title"],
                self._t["custom_text"],
                f".../{SETTINGS_FOLDER_NAME}",
                self._t["custom_badge"],
                self._t["custom_btn"],
                self._use_custom,
                False,
            )
        )
        return container

    def _build_choice_card(self, title_text, body_text, path_text, badge_text, button_text, handler, primary):
        card = QFrame()
        card.setObjectName("choiceCard")
        card.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.MinimumExpanding)
        card_layout = QVBoxLayout(card)
        card_layout.setContentsMargins(18, 18, 18, 18)
        card_layout.setSpacing(10)

        title = QLabel(title_text)
        title.setObjectName("choiceTitle")
        title.setWordWrap(True)
        self._configure_wrap_label(title)
        card_layout.addWidget(title)

        body = QLabel(body_text)
        body.setObjectName("choiceText")
        body.setWordWrap(True)
        self._configure_wrap_label(body)
        card_layout.addWidget(body)

        path_badge = QLabel(path_text)
        path_badge.setObjectName("choicePathBlock")
        path_badge.setWordWrap(True)
        self._configure_wrap_label(path_badge)
        path_badge.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Minimum)
        path_badge.setTextInteractionFlags(Qt.TextSelectableByMouse)
        card_layout.addWidget(path_badge)

        option_badge = QLabel(badge_text)
        option_badge.setObjectName("choiceBadge")
        card_layout.addWidget(option_badge, 0, Qt.AlignLeft)

        card_layout.addStretch()

        button = QPushButton(button_text)
        button.setObjectName("primaryBtn" if primary else "secondaryBtn")
        button.setCursor(Qt.PointingHandCursor)
        button.clicked.connect(handler)
        card_layout.addWidget(button)
        return card

    def _build_note_card(self):
        note = QFrame()
        note.setObjectName("noteCard")
        note_layout = QVBoxLayout(note)
        note_layout.setContentsMargins(18, 16, 18, 16)
        note_layout.setSpacing(8)

        title = QLabel(self._t["note_title"])
        title.setObjectName("noteTitle")
        note_layout.addWidget(title)

        body = QLabel(f"{self._t['note_text']}\n\n📁 {SETTINGS_FOLDER_NAME}")
        body.setObjectName("noteText")
        body.setWordWrap(True)
        self._configure_wrap_label(body)
        note_layout.addWidget(body)
        return note

    @staticmethod
    def _configure_wrap_label(label):
        policy = label.sizePolicy()
        policy.setHorizontalPolicy(QSizePolicy.Ignored)
        policy.setVerticalPolicy(QSizePolicy.Minimum)
        policy.setHeightForWidth(True)
        label.setSizePolicy(policy)

    def keyPressEvent(self, event):
        if event.key() == Qt.Key_1 and not event.isAutoRepeat():
            self._key1_held_since = time.monotonic()
            self._debug_timer.start()
        super().keyPressEvent(event)

    def keyReleaseEvent(self, event):
        if event.key() == Qt.Key_1 and not event.isAutoRepeat():
            self._key1_held_since = None
            self._debug_timer.stop()
        super().keyReleaseEvent(event)

    def _check_debug_hold(self):
        if self._key1_held_since and (time.monotonic() - self._key1_held_since) >= 12.0:
            self._debug_timer.stop()
            self._key1_held_since = None
            self._activate_debug()

    def _use_home(self):
        try:
            settings_dir = Path.home() / SETTINGS_FOLDER_NAME
            settings_dir.mkdir(parents=True, exist_ok=True)
            get_pointer_file().write_text("default", encoding="utf-8")
            self.result_path = settings_dir
            self.accept()
        except Exception as exc:
            QMessageBox.critical(self, self._t["title"], self._t["error_folder"].format(e=exc))

    def _use_custom(self):
        folder = QFileDialog.getExistingDirectory(self, self._t["title"], str(Path.home()))
        if folder:
            try:
                settings_dir = Path(folder) / SETTINGS_FOLDER_NAME
                settings_dir.mkdir(parents=True, exist_ok=True)
                get_pointer_file().write_text(folder, encoding="utf-8")
                self.result_path = settings_dir
                self.accept()
            except Exception as exc:
                QMessageBox.critical(self, self._t["title"], self._t["error_folder"].format(e=exc))

    def _activate_debug(self):
        """Developer debug mode: nothing is written to disk."""
        self.result_path = aura_utils.activate_debug_mode()
        self.accept()

    def reject(self):
        """Prevent closing with Escape: user must choose a location."""
        pass

    def run(self):
        self.exec()
        return self.result_path
