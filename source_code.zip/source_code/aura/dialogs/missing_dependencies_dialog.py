#!/usr/bin/env python3
from __future__ import annotations

"""Startup dialog that explains missing dependencies and their impact."""

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QDialog, QFrame, QHBoxLayout, QLabel, QPushButton, QVBoxLayout

from aura.dialogs.ui_chrome import (
    build_dialog_chrome_qss,
    configure_wrap_label,
    resolve_dialog_colors,
    resolve_dialog_translations,
)


def _dialog_qss(colors):
    return (
        build_dialog_chrome_qss(colors)
        + f"""
        QFrame#dependencyRow {{
            background: {colors['bg_entry']};
            border: 1px solid {colors['border']};
            border-radius: 16px;
        }}
        QLabel#dependencyName {{
            color: {colors['text']};
            font-size: 12px;
            font-weight: 700;
        }}
        QLabel#dependencyImpact {{
            color: {colors['text_dim']};
            font-size: 10px;
        }}
        QLabel#dependencyBadge {{
            border-radius: 999px;
            padding: 4px 10px;
            font-size: 10px;
            font-weight: 700;
        }}
        """
    )


def _severity_palette(colors, severity):
    if severity == "critical":
        return colors.get("red", "#ef4444"), "#ffffff", colors.get("red_hover", "#dc2626")
    if severity == "high":
        return "#f59e0b", colors["bg_main"], "#d97706"
    if severity == "medium":
        return colors.get("accent2", "#38bdf8"), colors["bg_main"], colors.get("accent2", "#38bdf8")
    return colors["bg_button"], colors["text"], colors["border"]


class MissingDependenciesDialog(QDialog):
    """Explain what is missing at startup and how serious each gap is."""

    def __init__(self, parent=None, items=None, t=None, theme_id=None):
        super().__init__(parent)
        self.t = resolve_dialog_translations(parent, t=t)
        self.open_system = False
        self._items = list(items or [])
        colors = resolve_dialog_colors(parent, theme_id)

        self.setWindowTitle(self.t.get("deps_startup_title", "Missing dependencies"))
        self.setMinimumSize(620, 420)
        self.resize(760, max(440, 260 + 92 * len(self._items)))
        self.setSizeGripEnabled(True)
        self.setStyleSheet(_dialog_qss(colors))

        layout = QVBoxLayout(self)
        layout.setContentsMargins(18, 18, 18, 18)
        layout.setSpacing(12)

        hero = QFrame()
        hero.setObjectName("dialogHeroCard")
        hero_layout = QVBoxLayout(hero)
        hero_layout.setContentsMargins(22, 18, 22, 18)
        hero_layout.setSpacing(6)

        eyebrow = QLabel("AURA VIDEO DOWNLOADER")
        eyebrow.setObjectName("dialogEyebrow")
        hero_layout.addWidget(eyebrow)

        title = QLabel(self.t.get("deps_startup_title", "Missing dependencies"))
        title.setObjectName("dialogTitle")
        title.setWordWrap(True)
        configure_wrap_label(title)
        hero_layout.addWidget(title)

        subtitle = QLabel(
            self.t.get(
                "deps_startup_hint",
                "Aura can start, but some tools are unavailable. Review how serious each missing dependency is before continuing.",
            )
        )
        subtitle.setObjectName("dialogSubtitle")
        subtitle.setWordWrap(True)
        configure_wrap_label(subtitle)
        hero_layout.addWidget(subtitle)
        layout.addWidget(hero)

        panel = QFrame()
        panel.setObjectName("dialogPanelCard")
        panel_layout = QVBoxLayout(panel)
        panel_layout.setContentsMargins(18, 16, 18, 18)
        panel_layout.setSpacing(10)

        for item in self._items:
            row = QFrame()
            row.setObjectName("dependencyRow")
            row_layout = QHBoxLayout(row)
            row_layout.setContentsMargins(14, 12, 14, 12)
            row_layout.setSpacing(12)

            text_col = QVBoxLayout()
            text_col.setSpacing(4)

            name = QLabel(item.get("name", ""))
            name.setObjectName("dependencyName")
            text_col.addWidget(name)

            impact = QLabel(item.get("impact", ""))
            impact.setObjectName("dependencyImpact")
            impact.setWordWrap(True)
            configure_wrap_label(impact)
            text_col.addWidget(impact)
            row_layout.addLayout(text_col, 1)

            badge = QLabel(
                self.t.get(
                    f"deps_startup_severity_{item.get('severity', 'low')}",
                    item.get("severity", "low").title(),
                )
            )
            badge.setObjectName("dependencyBadge")
            bg, fg, border = _severity_palette(colors, item.get("severity", "low"))
            badge.setStyleSheet(f"background: {bg}; color: {fg}; border: 1px solid {border};")
            badge.setAlignment(Qt.AlignCenter)
            row_layout.addWidget(badge, 0, Qt.AlignTop)

            panel_layout.addWidget(row)

        note = QLabel(
            self.t.get(
                "deps_startup_footer_note",
                "Open the System page if you want install buttons and detailed status badges.",
            )
        )
        note.setObjectName("dialogMeta")
        note.setWordWrap(True)
        configure_wrap_label(note)
        panel_layout.addWidget(note)
        layout.addWidget(panel, 1)

        footer = QFrame()
        footer.setObjectName("dialogFooterCard")
        footer_layout = QHBoxLayout(footer)
        footer_layout.setContentsMargins(14, 10, 14, 10)
        footer_layout.setSpacing(10)
        footer_layout.addStretch()

        open_system = QPushButton(self.t.get("deps_startup_open_system", "Open System page"))
        open_system.setObjectName("dialogGhostBtn")
        open_system.setCursor(Qt.PointingHandCursor)
        open_system.clicked.connect(self._accept_open_system)
        footer_layout.addWidget(open_system)

        continue_btn = QPushButton(self.t.get("deps_startup_continue", "Continue"))
        continue_btn.setObjectName("dialogPrimaryBtn")
        continue_btn.setCursor(Qt.PointingHandCursor)
        continue_btn.clicked.connect(self.accept)
        continue_btn.setDefault(True)
        footer_layout.addWidget(continue_btn)
        layout.addWidget(footer)

    def _accept_open_system(self):
        self.open_system = True
        self.accept()
