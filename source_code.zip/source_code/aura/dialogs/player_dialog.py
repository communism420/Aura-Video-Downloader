#!/usr/bin/env python3
"""Built-in video player."""

from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QDialog,
    QFrame,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QFileDialog,
    QStackedLayout,
    QVBoxLayout,
)

from aura.dialogs.ui_chrome import (
    build_dialog_chrome_qss,
    configure_wrap_label,
    resolve_dialog_colors,
)

_HAS_MULTIMEDIA = False
try:
    from PySide6.QtMultimedia import QAudioOutput, QMediaPlayer
    from PySide6.QtMultimediaWidgets import QVideoWidget

    _HAS_MULTIMEDIA = True
except ImportError:
    pass


def _dialog_qss(colors):
    return (
        build_dialog_chrome_qss(colors)
        + f"""
        QFrame#playerStage {{
            background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                stop:0 {colors['bg_entry']}, stop:1 {colors['bg_deep']});
            border: 1px solid {colors['border']};
            border-radius: 16px;
        }}
        QLabel#playerEmptyIcon {{
            color: {colors['accent2']};
            font-size: 38px;
            font-weight: 800;
        }}
        QLabel#playerEmptyTitle {{
            color: {colors['text']};
            font-size: 15px;
            font-weight: 700;
        }}
        QLabel#playerEmptyHint {{
            color: {colors['text_hint']};
            font-size: 11px;
        }}
        """
    )


class VideoPlayerDialog(QDialog):
    """Simple built-in video player using QMediaPlayer."""

    def __init__(self, parent, t, filepath=None, theme_id=None):
        super().__init__(parent)
        self.t = t
        self._current_media_label = t.get("player_status_idle", "No media loaded")
        self.setWindowTitle(t.get("player_title", "Video Player"))
        self.setMinimumSize(720, 480)
        self.resize(860, 560)
        self.setSizeGripEnabled(True)
        colors = resolve_dialog_colors(parent, theme_id)
        self.setStyleSheet(_dialog_qss(colors))

        layout = QVBoxLayout(self)
        layout.setContentsMargins(18, 18, 18, 18)
        layout.setSpacing(12)

        hero = QFrame()
        hero.setObjectName("dialogHeroCard")
        hero_layout = QVBoxLayout(hero)
        hero_layout.setContentsMargins(22, 18, 22, 18)
        hero_layout.setSpacing(6)

        eyebrow = QLabel("AURA VIDEO DOWNLOADER")
        eyebrow.setObjectName("dialogEyebrow")
        hero_layout.addWidget(eyebrow)

        title = QLabel(t.get("player_title", "Video Player"))
        title.setObjectName("dialogTitle")
        title.setWordWrap(True)
        configure_wrap_label(title)
        hero_layout.addWidget(title)

        subtitle = QLabel(
            t.get(
                "player_dialog_hint",
                "Preview downloaded media without leaving Aura.",
            )
        )
        subtitle.setObjectName("dialogSubtitle")
        subtitle.setWordWrap(True)
        configure_wrap_label(subtitle)
        hero_layout.addWidget(subtitle)
        layout.addWidget(hero)

        if not _HAS_MULTIMEDIA:
            fallback = QFrame()
            fallback.setObjectName("dialogPanelCard")
            fallback_layout = QVBoxLayout(fallback)
            fallback_layout.setContentsMargins(18, 16, 18, 16)
            fallback_layout.setSpacing(8)

            message = QLabel(t.get("player_no_multimedia", "PySide6-Multimedia required"))
            message.setObjectName("dialogSubtitle")
            message.setWordWrap(True)
            configure_wrap_label(message)
            fallback_layout.addWidget(message)
            layout.addWidget(fallback)
            return

        player_panel = QFrame()
        player_panel.setObjectName("dialogPanelCard")
        player_layout = QVBoxLayout(player_panel)
        player_layout.setContentsMargins(12, 12, 12, 12)
        player_layout.setSpacing(10)

        stage = QFrame()
        stage.setObjectName("playerStage")
        stage_layout = QStackedLayout(stage)
        stage_layout.setContentsMargins(0, 0, 0, 0)

        placeholder = QFrame()
        placeholder_layout = QVBoxLayout(placeholder)
        placeholder_layout.setContentsMargins(24, 24, 24, 24)
        placeholder_layout.setSpacing(8)
        placeholder_layout.addStretch()

        empty_icon = QLabel("▶")
        empty_icon.setObjectName("playerEmptyIcon")
        empty_icon.setAlignment(Qt.AlignCenter)
        placeholder_layout.addWidget(empty_icon)

        empty_title = QLabel(self.t.get("player_empty_title", "Open a file to start playback"))
        empty_title.setObjectName("playerEmptyTitle")
        empty_title.setAlignment(Qt.AlignCenter)
        empty_title.setWordWrap(True)
        configure_wrap_label(empty_title)
        placeholder_layout.addWidget(empty_title)

        empty_hint = QLabel(
            self.t.get(
                "player_empty_hint",
                "Use the button below to load a local video or audio file into Aura's player.",
            )
        )
        empty_hint.setObjectName("playerEmptyHint")
        empty_hint.setAlignment(Qt.AlignCenter)
        empty_hint.setWordWrap(True)
        configure_wrap_label(empty_hint)
        placeholder_layout.addWidget(empty_hint)
        placeholder_layout.addStretch()

        self.video_widget = QVideoWidget()
        stage_layout.addWidget(placeholder)
        stage_layout.addWidget(self.video_widget)
        self._stage_layout = stage_layout
        self._placeholder_widget = placeholder
        player_layout.addWidget(stage, 1)
        layout.addWidget(player_panel, 1)

        self.audio_output = QAudioOutput()
        self.player = QMediaPlayer()
        self.player.setAudioOutput(self.audio_output)
        self.player.setVideoOutput(self.video_widget)

        footer = QFrame()
        footer.setObjectName("dialogFooterCard")
        ctrl = QHBoxLayout(footer)
        ctrl.setContentsMargins(14, 10, 14, 10)
        ctrl.setSpacing(10)

        self.btn_play = QPushButton(t.get("player_play", "▶"))
        self.btn_play.setObjectName("dialogPrimaryBtn")
        self.btn_play.setFixedWidth(74)
        self.btn_play.setCursor(Qt.PointingHandCursor)
        self.btn_play.clicked.connect(self._toggle_play)
        ctrl.addWidget(self.btn_play)

        btn_stop = QPushButton(t.get("player_stop", "⏹"))
        btn_stop.setObjectName("dialogSecondaryBtn")
        btn_stop.setFixedWidth(74)
        btn_stop.setCursor(Qt.PointingHandCursor)
        btn_stop.clicked.connect(self.player.stop)
        self.btn_stop = btn_stop
        ctrl.addWidget(btn_stop)

        self.position_label = QLabel("0:00 / 0:00")
        self.position_label.setObjectName("dialogBadge")
        ctrl.addWidget(self.position_label)

        self.file_status_label = QLabel(self._current_media_label)
        self.file_status_label.setObjectName("dialogMeta")
        self.file_status_label.setTextInteractionFlags(Qt.TextSelectableByMouse)
        ctrl.addWidget(self.file_status_label)

        ctrl.addStretch()

        btn_open = QPushButton(t.get("player_open_file", "Open"))
        btn_open.setObjectName("dialogSecondaryBtn")
        btn_open.setCursor(Qt.PointingHandCursor)
        btn_open.clicked.connect(self._open_file)
        ctrl.addWidget(btn_open)

        layout.addWidget(footer)

        self.player.positionChanged.connect(self._update_position)
        self.player.durationChanged.connect(self._update_position)
        self.player.playbackStateChanged.connect(self._sync_play_button)
        self._set_media_state(False)

        if filepath and Path(filepath).exists():
            from PySide6.QtCore import QUrl

            self.player.setSource(QUrl.fromLocalFile(str(filepath)))
            self._set_media_state(True, str(filepath))
            self.player.play()
            self._sync_play_button()

    def _toggle_play(self):
        if not _HAS_MULTIMEDIA:
            return
        if self.player.playbackState() == QMediaPlayer.PlayingState:
            self.player.pause()
        else:
            self.player.play()
        self._sync_play_button()

    def _sync_play_button(self, *_args):
        if not _HAS_MULTIMEDIA:
            return
        if self.player.playbackState() == QMediaPlayer.PlayingState:
            self.btn_play.setText(self.t.get("player_pause", "⏸"))
        else:
            self.btn_play.setText(self.t.get("player_play", "▶"))

    def _set_media_state(self, has_media, filepath=""):
        if not _HAS_MULTIMEDIA:
            return
        self._stage_layout.setCurrentWidget(self.video_widget if has_media else self._placeholder_widget)
        self.btn_play.setEnabled(has_media)
        self.btn_stop.setEnabled(has_media)
        self.file_status_label.setText(
            Path(filepath).name if filepath else self.t.get("player_status_idle", "No media loaded")
        )

    def _open_file(self):
        if not _HAS_MULTIMEDIA:
            return
        filename, _ = QFileDialog.getOpenFileName(
            self,
            self.t.get("player_open_dialog_title", self.t.get("player_open_file", "Open")),
            str(Path.home()),
            self.t.get(
                "player_open_dialog_filter",
                "Video (*.mp4 *.mkv *.webm *.avi *.mov);;Audio (*.mp3 *.wav *.flac *.opus *.m4a);;All files (*)",
            ),
        )
        if filename:
            from PySide6.QtCore import QUrl

            self.player.setSource(QUrl.fromLocalFile(filename))
            self._set_media_state(True, filename)
            self.player.play()
            self._sync_play_button()

    def _update_position(self):
        if not _HAS_MULTIMEDIA:
            return
        pos = self.player.position() // 1000
        dur = self.player.duration() // 1000
        self.position_label.setText(f"{pos//60}:{pos%60:02d} / {dur//60}:{dur%60:02d}")

    def closeEvent(self, event):
        if _HAS_MULTIMEDIA and hasattr(self, "player"):
            self.player.stop()
        super().closeEvent(event)
