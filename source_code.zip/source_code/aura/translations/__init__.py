#!/usr/bin/env python3
from __future__ import annotations

"""Translation system — loads translations from JSON files."""
import datetime
import json
import os
from typing import Any

_CACHE: dict[str, dict[str, Any]] = {}
_CATALOG_CACHE: list[dict[str, Any]] | None = None

_LANGUAGE_METADATA_FALLBACKS: dict[str, dict[str, str]] = {
    "af": {"name": "Afrikaans", "native_name": "Afrikaans"},
    "ar": {"name": "Arabic", "native_name": "العربية"},
    "az": {"name": "Azerbaijani", "native_name": "Azərbaycanca"},
    "be": {"name": "Belarusian", "native_name": "Беларуская"},
    "bg": {"name": "Bulgarian", "native_name": "Български"},
    "bn": {"name": "Bengali", "native_name": "বাংলা"},
    "ca": {"name": "Catalan", "native_name": "Català"},
    "cs": {"name": "Czech", "native_name": "Čeština"},
    "da": {"name": "Danish", "native_name": "Dansk"},
    "de": {"name": "German", "native_name": "Deutsch"},
    "el": {"name": "Greek", "native_name": "Ελληνικά"},
    "en": {"name": "English", "native_name": "English"},
    "es": {"name": "Spanish", "native_name": "Español"},
    "et": {"name": "Estonian", "native_name": "Eesti"},
    "eu": {"name": "Basque", "native_name": "Euskara"},
    "fa": {"name": "Persian", "native_name": "فارسی"},
    "fi": {"name": "Finnish", "native_name": "Suomi"},
    "fr": {"name": "French", "native_name": "Français"},
    "gl": {"name": "Galician", "native_name": "Galego"},
    "he": {"name": "Hebrew", "native_name": "עברית"},
    "hi": {"name": "Hindi", "native_name": "हिन्दी"},
    "hr": {"name": "Croatian", "native_name": "Hrvatski"},
    "hu": {"name": "Hungarian", "native_name": "Magyar"},
    "hy": {"name": "Armenian", "native_name": "Հայերեն"},
    "id": {"name": "Indonesian", "native_name": "Bahasa Indonesia"},
    "it": {"name": "Italian", "native_name": "Italiano"},
    "ja": {"name": "Japanese", "native_name": "日本語"},
    "ka": {"name": "Georgian", "native_name": "ქართული"},
    "kk": {"name": "Kazakh", "native_name": "Қазақша"},
    "ko": {"name": "Korean", "native_name": "한국어"},
    "lt": {"name": "Lithuanian", "native_name": "Lietuvių"},
    "lv": {"name": "Latvian", "native_name": "Latviešu"},
    "mr": {"name": "Marathi", "native_name": "मराठी"},
    "ms": {"name": "Malay", "native_name": "Bahasa Melayu"},
    "nl": {"name": "Dutch", "native_name": "Nederlands"},
    "no": {"name": "Norwegian", "native_name": "Norsk"},
    "pl": {"name": "Polish", "native_name": "Polski"},
    "pt": {"name": "Portuguese", "native_name": "Português"},
    "ro": {"name": "Romanian", "native_name": "Română"},
    "ru": {"name": "Russian", "native_name": "Русский"},
    "sk": {"name": "Slovak", "native_name": "Slovenčina"},
    "sr": {"name": "Serbian", "native_name": "Српски"},
    "sv": {"name": "Swedish", "native_name": "Svenska"},
    "sw": {"name": "Swahili", "native_name": "Kiswahili"},
    "ta": {"name": "Tamil", "native_name": "தமிழ்"},
    "te": {"name": "Telugu", "native_name": "తెలుగు"},
    "th": {"name": "Thai", "native_name": "ไทย"},
    "tl": {"name": "Tagalog", "native_name": "Tagalog"},
    "tr": {"name": "Turkish", "native_name": "Türkçe"},
    "uk": {"name": "Ukrainian", "native_name": "Українська"},
    "ur": {"name": "Urdu", "native_name": "اردو"},
    "uz": {"name": "Uzbek", "native_name": "Oʻzbek"},
    "vi": {"name": "Vietnamese", "native_name": "Tiếng Việt"},
    "zh": {"name": "Chinese", "native_name": "中文"},
}


def _translation_dir() -> str:
    return os.path.dirname(os.path.abspath(__file__))


def _apply_dynamic_placeholders(data: dict[str, Any], year: str) -> dict[str, Any]:
    for k, v in data.items():
        if isinstance(v, str) and "{current_year}" in v:
            data[k] = v.replace("{current_year}", year)
        elif isinstance(v, list):
            data[k] = [
                s.replace("{current_year}", year) if isinstance(s, str) and "{current_year}" in s else s
                for s in v
            ]
    return data


def _count_public_translation_keys(data: dict[str, Any]) -> int:
    return sum(1 for key in data if not key.startswith("_meta_"))


def _build_language_entry(code: str, data: dict[str, Any]) -> dict[str, Any]:
    base_code = code.split("-", 1)[0].split("_", 1)[0]
    meta = _LANGUAGE_METADATA_FALLBACKS.get(code, _LANGUAGE_METADATA_FALLBACKS.get(base_code, {}))
    name = data.get("_meta_language_name") or meta.get("name") or code.upper()
    native_name = data.get("_meta_language_native_name") or meta.get("native_name") or name
    tagline = data.get("_meta_language_tagline")
    if not isinstance(tagline, str) or not tagline.strip():
        if native_name != name:
            tagline = f"{name} interface translation."
        else:
            tagline = f"Interface translation loaded from {code}.json."
    return {
        "code": code,
        "name": name,
        "native_name": native_name,
        "tagline": tagline,
        "key_count": _count_public_translation_keys(data),
    }

def get_all_translations() -> dict[str, dict]:
    """Load and return all translations as {lang: {key: value}}."""
    if _CACHE:
        return _CACHE
    tr_dir = _translation_dir()
    year = str(datetime.datetime.now().year)
    for fname in sorted(os.listdir(tr_dir)):
        if fname.endswith('.json'):
            lang = fname[:-5]
            with open(os.path.join(tr_dir, fname), 'r', encoding='utf-8') as f:
                data = json.load(f)
            _CACHE[lang] = _apply_dynamic_placeholders(data, year)
    return _CACHE

def get_translations(lang: str = "en") -> dict:
    """Get translations for a specific language."""
    return get_all_translations().get(lang, get_all_translations().get("en", {}))


def get_translation_catalog() -> list[dict[str, Any]]:
    """Return available translation packs with UI metadata."""
    global _CATALOG_CACHE
    if _CATALOG_CACHE is not None:
        return [dict(item) for item in _CATALOG_CACHE]

    preferred_order = {"ru": 0, "en": 1}
    catalog = [
        _build_language_entry(code, data)
        for code, data in get_all_translations().items()
    ]
    catalog.sort(
        key=lambda item: (
            preferred_order.get(item["code"], 99),
            item["native_name"].casefold(),
            item["code"],
        )
    )
    _CATALOG_CACHE = catalog
    return [dict(item) for item in _CATALOG_CACHE]

# Backward compatibility alias
TRANSLATIONS = None  # Use get_all_translations() instead
