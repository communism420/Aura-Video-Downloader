#!/usr/bin/env python3
from __future__ import annotations

"""Translation system — loads translations from JSON files."""
import datetime
import json
import os
from typing import Any

_CACHE: dict[str, dict[str, Any]] = {}

def get_all_translations() -> dict[str, dict]:
    """Load and return all translations as {lang: {key: value}}."""
    if _CACHE:
        return _CACHE
    tr_dir = os.path.dirname(os.path.abspath(__file__))
    year = str(datetime.datetime.now().year)
    for fname in sorted(os.listdir(tr_dir)):
        if fname.endswith('.json'):
            lang = fname[:-5]
            with open(os.path.join(tr_dir, fname), 'r', encoding='utf-8') as f:
                data = json.load(f)
            # Replace dynamic placeholders
            for k, v in data.items():
                if isinstance(v, str) and '{current_year}' in v:
                    data[k] = v.replace('{current_year}', year)
                elif isinstance(v, list):
                    data[k] = [s.replace('{current_year}', year) if isinstance(s, str) and '{current_year}' in s else s for s in v]
            _CACHE[lang] = data
    return _CACHE

def get_translations(lang: str = "en") -> dict:
    """Get translations for a specific language."""
    return get_all_translations().get(lang, get_all_translations().get("en", {}))

# Backward compatibility alias
TRANSLATIONS = None  # Use get_all_translations() instead
