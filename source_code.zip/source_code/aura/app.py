#!/usr/bin/env python3
"""Application entry point."""
import os
import sys
from PySide6.QtWidgets import QApplication
from PySide6.QtGui import QIcon
from aura.utils import get_app_icon_path, get_settings_dir, get_pointer_file, is_debug_mode
from aura.themes import get_theme_config
from aura.dialogs.selectors import LanguageSelector, ThemeSelector, PlatformSelector
from aura.dialogs.config_location import ConfigLocationDialog
from aura.main_window import AuraDownloader


def ask_config_location(lang):
    """Show config-location dialog only on first run."""
    if get_pointer_file().exists():
        return get_settings_dir()
    dlg = ConfigLocationDialog(lang)
    result = dlg.run()
    if result is None:
        if is_debug_mode():
            return get_settings_dir()
        sys.exit(0)
    return result


def main():
    # Windows-specific setup — MUST be done BEFORE QApplication
    if sys.platform == 'win32':
        try:
            from ctypes import windll
            # NOTE: Do NOT call SetProcessDpiAwareness() here — Qt6/PySide6
            # already sets DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2 internally.
            # Calling it manually causes a "SetProcessDpiAwarenessContext() failed" warning.
            # AppUserModelID — proper taskbar icon grouping
            windll.shell32.SetCurrentProcessExplicitAppUserModelID("Aura Video Downloader")
        except Exception:
            pass
    
    app = QApplication(sys.argv)
    app.setApplicationName("Aura Video Downloader")
    app.setStyle("Fusion")
    
    # App icon — used for all windows, taskbar, and tray
    _icon_path = get_app_icon_path()
    if os.path.exists(_icon_path):
        app.setWindowIcon(QIcon(_icon_path))
    
    # 1. Language selection
    lang_dlg = LanguageSelector()
    lang = lang_dlg.run()
    if not lang:
        sys.exit(0)
    
    # 2. Config location (FIRST! — must know WHERE to save before saving anything)
    #    Shows dialog only when pointer.txt doesn't exist (first run or after reset)
    ask_config_location(lang)
    
    # 3. Theme: first run (no general.json) → show picker, otherwise → load saved
    general_config = get_settings_dir() / "general.json"
    if not general_config.exists():
        theme_dlg = ThemeSelector(lang)
        theme_id = theme_dlg.run()
        if not theme_id:
            sys.exit(0)
    else:
        theme_id = get_theme_config()
    
    # 4. Platform selection
    plat_dlg = PlatformSelector(lang, theme_id)
    platform = plat_dlg.run()
    if not platform:
        sys.exit(0)
    
    # 5. Main window — loop allows platform switching without full restart
    while True:
        window = AuraDownloader(lang=lang, platform=platform, theme_id=theme_id)
        window.show()
        app.exec()
        
        # Check if user requested a platform switch
        next_platform = getattr(window, '_next_platform', None)
        if not next_platform:
            break
        platform = next_platform
    
    sys.exit(0)


if __name__ == "__main__":
    main()
