#!/usr/bin/env python3
"""python -m aura"""
from aura.app import main
if __name__ == "__main__":
    main()
