#!/usr/bin/env python3
"""Real-time download speed graph (QPainter-based, no external deps)."""
from PySide6.QtWidgets import QSizePolicy, QWidget
from PySide6.QtCore import QSize, Qt, QPointF
from PySide6.QtGui import QColor, QFontMetrics, QPainter, QPolygonF, QPen

# ══════════════════════════════════════════════════════════════════════════════
#  SPEED GRAPH WIDGET (custom QPainter — no external dependencies)
# ══════════════════════════════════════════════════════════════════════════════

class SpeedGraphWidget(QWidget):
    """Real-time download speed graph using QPainter."""
    
    def __init__(self, parent=None, max_points=120):
        super().__init__(parent)
        self.max_points = max_points
        self.data_points = []  # list of float (bytes/sec)
        self.setMinimumHeight(120)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.MinimumExpanding)
        self._bg_color = QColor("#0a0a14")
        self._line_color = QColor("#00cec9")
        self._grid_color = QColor("#1c1c30")
        self._text_color = QColor("#8888aa")
        self._fill_color = QColor(0, 206, 201, 40)
        self._painting = False

    def sizeHint(self):
        return QSize(480, 180)
    
    def set_colors(self, bg, line, grid, text):
        self._bg_color = QColor(bg)
        self._line_color = QColor(line)
        self._grid_color = QColor(grid)
        self._text_color = QColor(text)
        self._fill_color = QColor(self._line_color)
        self._fill_color.setAlpha(40)
    
    def add_point(self, speed_bps):
        """Add a speed data point (bytes per second)."""
        self.data_points.append(float(speed_bps))
        if len(self.data_points) > self.max_points:
            self.data_points = self.data_points[-self.max_points:]
        self.update()
    
    def clear_data(self):
        self.data_points.clear()
        self.update()
    
    @staticmethod
    def _format_speed(bps):
        if bps >= 1024 * 1024:
            return f"{bps / (1024*1024):.1f} MB/s"
        elif bps >= 1024:
            return f"{bps / 1024:.0f} KB/s"
        return f"{bps:.0f} B/s"
    
    def paintEvent(self, event):
        if self._painting:
            return
        self._painting = True
        painter = QPainter()
        try:
            if not painter.begin(self):
                return

            painter.setRenderHint(QPainter.Antialiasing)
            w, h = self.width(), self.height()
            label_font = painter.font()
            label_font.setPointSize(max(7, min(9, h // 24)))
            metrics = QFontMetrics(label_font)
            guide_label = self._format_speed(max(self.data_points) if self.data_points else 1024 * 1024)
            margin_left = max(58, metrics.horizontalAdvance(guide_label) + 12)
            margin_right = 12
            margin_top = 12
            margin_bottom = metrics.height() + 12

            painter.fillRect(0, 0, w, h, self._bg_color)

            plot_x = margin_left
            plot_y = margin_top
            plot_w = w - margin_left - margin_right
            plot_h = h - margin_top - margin_bottom

            if plot_w < 10 or plot_h < 10:
                return

            painter.setPen(self._grid_color)
            for i in range(5):
                y = plot_y + int(plot_h * i / 4)
                painter.drawLine(plot_x, y, plot_x + plot_w, y)

            if not self.data_points:
                painter.setPen(self._text_color)
                painter.drawText(plot_x, plot_y, plot_w, plot_h, Qt.AlignCenter, "—")
                return

            max_val = max(self.data_points) if self.data_points else 1
            if max_val == 0:
                max_val = 1

            painter.setPen(self._text_color)
            font = label_font
            painter.setFont(font)
            for i in range(5):
                y = plot_y + int(plot_h * i / 4)
                val = max_val * (1.0 - i / 4.0)
                painter.drawText(
                    0,
                    y - 8,
                    margin_left - 4,
                    16,
                    Qt.AlignRight | Qt.AlignVCenter,
                    self._format_speed(val),
                )

            if len(self.data_points) < 2:
                return

            points = []
            for i, val in enumerate(self.data_points):
                x = plot_x + int(plot_w * i / (self.max_points - 1))
                y = plot_y + plot_h - int(plot_h * val / max_val)
                points.append(QPointF(x, y))

            fill_poly = QPolygonF(points)
            fill_poly.append(QPointF(points[-1].x(), plot_y + plot_h))
            fill_poly.append(QPointF(points[0].x(), plot_y + plot_h))
            painter.setBrush(self._fill_color)
            painter.setPen(Qt.NoPen)
            painter.drawPolygon(fill_poly)

            pen = QPen(self._line_color, 2)
            painter.setPen(pen)
            painter.setBrush(Qt.NoBrush)
            painter.drawPolyline(QPolygonF(points))

            current = self.data_points[-1]
            painter.setPen(self._line_color)
            font.setPointSize(max(9, min(11, h // 18)))
            font.setBold(True)
            painter.setFont(font)
            painter.drawText(plot_x, plot_y, plot_w, 18, Qt.AlignRight, self._format_speed(current))
        finally:
            if painter.isActive():
                painter.end()
            self._painting = False
