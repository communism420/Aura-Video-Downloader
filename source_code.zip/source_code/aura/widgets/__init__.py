from aura.widgets.speed_graph import SpeedGraphWidget
