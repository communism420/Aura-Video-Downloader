#!/usr/bin/env python3
from __future__ import annotations

"""Dependency checker - finds yt-dlp, ffmpeg, aria2c, node, Everything."""

import shutil

from PySide6.QtCore import Signal

from aura.constants import SUBPROCESS_FLAGS, SUBPROCESS_TIMEOUT
from aura.utils import find_binary
from aura.workers.base import StoppableProcessWorker


def _resolved_label(command: str) -> str:
    if not command:
        return ""
    return shutil.which(command) or command


class DepsWorker(StoppableProcessWorker):
    """Background dependency checker - finds binaries in system PATH."""

    results_ready = Signal(dict)

    def __init__(self, platform_config):
        super().__init__()
        self.pc = platform_config

    def _probe_binary(self, command: str, args: list[str], ok_returncodes: set[int] | None = None):
        if self._was_stopped():
            return None

        ok_returncodes = ok_returncodes or {0}
        try:
            result = self._run_process([command] + list(args), timeout=SUBPROCESS_TIMEOUT)
        except FileNotFoundError:
            return ("missing", "", "")
        except Exception as exc:
            return ("error", str(exc), _resolved_label(command))

        if result is None or self._was_stopped():
            return None

        label = _resolved_label(command)
        output = (result.stdout or result.stderr or "").strip()
        first_line = output.splitlines()[0].strip() if output else ""
        if result.returncode in ok_returncodes:
            return ("ok", first_line, label)

        error_text = first_line or f"exit code {result.returncode}"
        return ("error", error_text, label)

    def run(self) -> None:
        """Check all dependencies and emit results via signal."""
        results = {}

        # yt-dlp: allow either an external binary or the current venv/Scripts shim.
        results["ytdlp"] = self._probe_binary(find_binary("yt-dlp"), ["--version"])
        if results["ytdlp"] is None:
            return

        # ffmpeg must be runnable, not just present on disk.
        results["ffmpeg"] = self._probe_binary(find_binary("ffmpeg"), ["-version"])
        if results["ffmpeg"] is None:
            return

        if not self.pc.get("needs_nodejs", False):
            results["nodejs"] = ("notneeded", "", "")
        else:
            results["nodejs"] = self._probe_binary(find_binary("node"), ["--version"])
            if results["nodejs"] is None:
                return

        # aria2c is optional but should still be probed if present.
        results["aria2c"] = self._probe_binary(find_binary("aria2c"), ["--version"])
        if results["aria2c"] is None:
            return

        # Everything CLI can vary by filename; just verify that at least one variant starts.
        everything_result = ("missing", "", "")
        for candidate in ("es.exe", "es"):
            everything_result = self._probe_binary(find_binary(candidate), ["-help"], ok_returncodes={0, 1, 2})
            if everything_result is None:
                return
            if everything_result[0] != "missing":
                break
        results["everything"] = everything_result

        if not self._was_stopped():
            self.results_ready.emit(results)
