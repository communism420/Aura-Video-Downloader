#!/usr/bin/env python3
from __future__ import annotations

"""Background worker for blocking download-preparation probes."""

import json

from PySide6.QtCore import Signal

from aura.utils import find_binary
from aura.workers.base import StoppableProcessWorker


class DownloadPreparationWorker(StoppableProcessWorker):
    """Resolve metadata needed before launching the main download worker."""

    result_signal = Signal(dict)
    error_signal = Signal(str)

    def __init__(self, window, *, mode, url, cookies="", platform_id=None,
                 runtime_settings=None, selected_audio_lang="", needs_probe=False):
        super().__init__()
        self.window = window
        self.mode = mode
        self.url = str(url or "").strip()
        self.cookies = str(cookies or "").strip()
        self.platform_id = platform_id
        self.runtime_settings = window._clone_runtime_settings(runtime_settings)
        self.selected_audio_lang = str(selected_audio_lang or "").strip()
        self.needs_probe = bool(needs_probe)

    def _probe_media_info(self, *, cookies="", runtime_settings=None):
        platform_id, _ = self.window._resolve_platform_context(self.platform_id)
        effective_settings = self.window._clone_runtime_settings(runtime_settings)
        effective_cookies = str(cookies or effective_settings.get("cookies") or "").strip()
        key = self.window._media_info_cache_key(
            self.url,
            cookies=effective_cookies,
            platform_id=platform_id,
            runtime_settings=effective_settings,
        )
        cached = self.window._media_info_cache.get(key)
        if isinstance(cached, dict):
            return cached

        ytdlp_bin = getattr(self.window, "_ytdlp_bin", find_binary("yt-dlp"))
        cmd = [ytdlp_bin, "--dump-json", "--no-warnings", "--no-playlist"]
        cmd.extend(
            self.window._build_ytdlp_runtime_args(
                cookies=effective_cookies,
                platform_id=platform_id,
                runtime_settings=effective_settings,
            )
        )
        cmd.append(self.url)

        result = self._run_process(cmd, timeout=45)
        if result is None or self._was_stopped():
            return None
        if result.returncode != 0 or not result.stdout.strip():
            return {}
        try:
            data = json.loads(result.stdout)
        except Exception:
            return {}
        if isinstance(data, dict):
            self.window._media_info_cache[key] = data
            return data
        return {}

    def _resolve_media_info_for_requested_audio_language(self):
        platform_id, _ = self.window._resolve_platform_context(self.platform_id)
        effective_settings = self.window._clone_runtime_settings(self.runtime_settings)
        selected_audio_lang = self.window._runtime_audio_language(effective_settings)
        effective_cookies = str(self.cookies or effective_settings.get("cookies") or "").strip()

        media_info = self._probe_media_info(
            cookies=effective_cookies,
            runtime_settings=effective_settings,
        )
        if media_info is None or self._was_stopped():
            return None
        if self.window._media_info_matches_requested_audio_language(
            selected_audio_lang,
            media_info=media_info,
        ):
            return media_info, effective_settings, False

        if platform_id != "youtube":
            return media_info, effective_settings, False

        for candidate in self.window._youtube_audio_runtime_candidates(
            cookies=effective_cookies,
            platform_id=platform_id,
            runtime_settings=effective_settings,
        ):
            if self._was_stopped():
                return None
            if self.window._runtime_settings_match(candidate, effective_settings):
                continue
            candidate_cookies = str(candidate.get("cookies") or self.cookies or "").strip()
            candidate_info = self._probe_media_info(
                cookies=candidate_cookies,
                runtime_settings=candidate,
            )
            if candidate_info is None or self._was_stopped():
                return None
            if self.window._media_info_matches_requested_audio_language(
                selected_audio_lang,
                media_info=candidate_info,
            ):
                return candidate_info, candidate, True

        return media_info, effective_settings, False

    def run(self) -> None:
        try:
            media_info = {}
            current_settings = self.window._clone_runtime_settings(self.runtime_settings)
            used_audio_runtime_fallback = False

            if self.mode == self.window.MODE_VIDEO and self.selected_audio_lang not in {"", "any", "default", "original"}:
                resolved = self._resolve_media_info_for_requested_audio_language()
                if resolved is None or self._was_stopped():
                    return
                media_info, current_settings, used_audio_runtime_fallback = resolved

            if self.needs_probe and not media_info:
                probed = self._probe_media_info(
                    cookies=self.cookies,
                    runtime_settings=current_settings,
                )
                if probed is None or self._was_stopped():
                    return
                media_info = probed

            if not self._was_stopped():
                self.result_signal.emit(
                    {
                        "media_info": media_info or {},
                        "runtime_settings": current_settings,
                        "used_audio_runtime_fallback": used_audio_runtime_fallback,
                    }
                )
        except Exception as exc:
            if not self._was_stopped():
                self.error_signal.emit(str(exc))
