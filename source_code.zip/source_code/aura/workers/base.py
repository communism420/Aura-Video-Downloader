#!/usr/bin/env python3
from __future__ import annotations

"""Shared stoppable worker helpers for subprocess-based QThreads."""

import subprocess
import threading
from types import SimpleNamespace

from PySide6.QtCore import QThread

from aura.constants import PROCESS_TERMINATE_TIMEOUT, SUBPROCESS_FLAGS
from aura.utils import _get_subprocess_env, log_error, tracked_processes


class StoppableProcessWorker(QThread):
    """QThread wrapper that can stop a running subprocess safely."""

    def __init__(self) -> None:
        super().__init__()
        self._stop_requested = threading.Event()
        self._process = None
        self._process_lock = threading.Lock()

    def stop(self) -> None:
        self._stop_requested.set()
        self.requestInterruption()
        self._stop_process_if_needed()

    def _was_stopped(self) -> bool:
        return self._stop_requested.is_set() or self.isInterruptionRequested()

    def _set_process(self, process) -> None:
        with self._process_lock:
            self._process = process

    def _clear_process(self, process) -> None:
        with self._process_lock:
            if self._process is process:
                self._process = None

    def _get_process(self):
        with self._process_lock:
            return self._process

    def _stop_process_if_needed(self) -> None:
        process = self._get_process()
        if not process or process.poll() is not None:
            return
        try:
            process.terminate()
            process.wait(timeout=PROCESS_TERMINATE_TIMEOUT)
        except Exception:
            try:
                process.kill()
            except Exception as exc:
                log_error("worker_kill_process", exc, level="debug")

    def _run_process(self, cmd: list[str], timeout: int):
        if self._was_stopped():
            return None

        process = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            encoding="utf-8",
            errors="replace",
            env=_get_subprocess_env(),
            creationflags=SUBPROCESS_FLAGS,
        )
        self._set_process(process)
        tracked_processes.add(process)
        try:
            stdout, stderr = process.communicate(timeout=timeout)
        except subprocess.TimeoutExpired:
            self._stop_process_if_needed()
            stdout, stderr = process.communicate()
        finally:
            tracked_processes.discard(process)
            self._clear_process(process)

        return SimpleNamespace(
            returncode=process.returncode or 0,
            stdout=stdout or "",
            stderr=stderr or "",
        )
