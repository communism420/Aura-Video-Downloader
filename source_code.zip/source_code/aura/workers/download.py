#!/usr/bin/env python3
from __future__ import annotations

"""Download worker - runs yt-dlp subprocess in QThread."""

import subprocess

from PySide6.QtCore import QThread, Signal

from aura.constants import PROCESS_TERMINATE_TIMEOUT, SUBPROCESS_FLAGS
from aura.utils import _fix_encoding, _get_subprocess_env, tracked_processes


class DownloadWorker(QThread):
    log_signal = Signal(str)
    progress_signal = Signal(str)  # raw line for parsing
    finished_signal = Signal(int)  # return code

    def __init__(self, cmd, stop_event):
        """Initialize with command list and stop event."""
        super().__init__()
        self.cmd = cmd
        self.stop_event = stop_event
        self.process = None

    def run(self) -> None:
        """Execute yt-dlp subprocess with real-time output streaming."""
        try:
            # text=True + bufsize=1 gives REAL-TIME line-by-line output.
            # encoding='utf-8' + errors='surrogateescape' preserves raw bytes
            # when yt-dlp.EXE outputs in the system codepage instead of UTF-8.
            self.process = subprocess.Popen(
                self.cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                encoding="utf-8",
                errors="surrogateescape",
                creationflags=SUBPROCESS_FLAGS,
                env=_get_subprocess_env(),
                bufsize=1,
            )
            tracked_processes.add(self.process)

            stream = self.process.stdout
            if stream is None:
                raise RuntimeError("yt-dlp started without a readable stdout pipe")

            for line in stream:
                if self.stop_event.is_set():
                    self.process.terminate()
                    break
                line = _fix_encoding(line.rstrip("\n\r"))
                if line:
                    self.log_signal.emit(line)
                    self.progress_signal.emit(line)

            self.process.wait()
            rc = self.process.returncode or 0
            self.finished_signal.emit(rc)

        except FileNotFoundError:
            self.log_signal.emit("yt-dlp not found. Install it with: pip install yt-dlp")
            self.log_signal.emit(f"Command: {self.cmd[0]}")
            self.finished_signal.emit(1)
        except Exception as exc:
            self.log_signal.emit(f"Error: {exc}")
            self.finished_signal.emit(1)
            self._stop_process_if_needed()
        finally:
            if self.process:
                try:
                    if self.process.stdout:
                        self.process.stdout.close()
                except Exception:
                    pass
                tracked_processes.discard(self.process)

    def stop(self) -> None:
        """Signal the worker to stop and terminate subprocess."""
        self.stop_event.set()
        self._stop_process_if_needed()

    def _stop_process_if_needed(self) -> None:
        if not self.process or self.process.poll() is not None:
            return
        try:
            self.process.terminate()
            self.process.wait(timeout=PROCESS_TERMINATE_TIMEOUT)
        except Exception:
            try:
                self.process.kill()
            except Exception:
                pass
