#!/usr/bin/env python3
from __future__ import annotations
"""Format list worker — fetches available formats via yt-dlp --dump-json."""
import json

from PySide6.QtCore import Signal

from aura.workers.base import StoppableProcessWorker

# ══════════════════════════════════════════════════════════════════════════════
#  FORMAT LIST WORKER (background yt-dlp -F)
# ══════════════════════════════════════════════════════════════════════════════

class FormatListWorker(StoppableProcessWorker):
    """Fetch format list from yt-dlp -F in background."""
    result_signal = Signal(dict)
    error_signal = Signal(str)
    
    def __init__(self, url, ytdlp_bin="yt-dlp", extra_args=None):
        """Initialize with URL and optional yt-dlp arguments."""
        super().__init__()
        self.url = url
        self.ytdlp_bin = ytdlp_bin
        self.extra_args = extra_args or []
    
    def run(self) -> None:
        """Fetch format list via yt-dlp --dump-json and parse formats array."""
        try:
            cmd = [self.ytdlp_bin, "--dump-json", "--no-warnings",
                   "--no-playlist"] + self.extra_args + [self.url]
            result = self._run_process(cmd, timeout=60)
            if result is None or self._was_stopped():
                return
            if result.returncode != 0:
                self.error_signal.emit(result.stderr[:300] if result.stderr else "yt-dlp error")
                return
            data = json.loads(result.stdout)
            raw_formats = data.get('formats', [])
            formats = []
            audio_languages = set()
            for f in raw_formats:
                fid = str(f.get('format_id', ''))
                if not fid:
                    continue
                vcodec = f.get('vcodec', 'none') or 'none'
                acodec = f.get('acodec', 'none') or 'none'
                language = (f.get('language') or '').strip()
                if vcodec != 'none' and acodec != 'none':
                    kind = 'combined'
                elif vcodec != 'none':
                    kind = 'video-only'
                elif acodec != 'none':
                    kind = 'audio-only'
                else:
                    kind = 'other'
                if language and acodec != 'none':
                    audio_languages.add(language)
                # Resolution
                res = f.get('resolution', '') or ''
                if not res and f.get('height'):
                    res = f"{f.get('width', '?')}x{f['height']}"
                # Codec: prefer video, fallback audio
                codec = vcodec if vcodec != 'none' else acodec
                if codec == 'none':
                    codec = ''
                # Bitrate
                tbr = f.get('tbr')
                bitrate = f"{tbr:.0f}k" if tbr else ''
                # Size
                fsize = f.get('filesize') or f.get('filesize_approx') or 0
                if fsize >= 1024 * 1024 * 1024:
                    size_str = f"{fsize / (1024**3):.1f}GiB"
                elif fsize >= 1024 * 1024:
                    size_str = f"{fsize / (1024**2):.1f}MiB"
                elif fsize > 0:
                    size_str = f"{fsize / 1024:.0f}KiB"
                else:
                    size_str = ''
                # FPS
                fps = f.get('fps')
                fps_str = str(int(fps)) if fps and fps > 0 else ''
                
                formats.append({
                    'id': fid,
                    'ext': f.get('ext', ''),
                    'kind': kind,
                    'language': language,
                    'vcodec': vcodec,
                    'acodec': acodec,
                    'resolution': res,
                    'fps': fps_str,
                    'codec': codec,
                    'bitrate': bitrate,
                    'size': size_str,
                    'note': (f.get('format_note', '') or '')[:60],
                })
            subtitle_languages = sorted(k for k in (data.get('subtitles') or {}).keys() if k)
            auto_subtitle_languages = sorted(k for k in (data.get('automatic_captions') or {}).keys() if k)
            payload = {
                'formats': formats,
                'audio_languages': sorted(audio_languages),
                'subtitle_languages': subtitle_languages,
                'auto_subtitle_languages': auto_subtitle_languages,
            }
            if not self._was_stopped():
                self.result_signal.emit(payload)
        except Exception as e:
            if not self._was_stopped():
                self.error_signal.emit(str(e))
