#!/usr/bin/env python3
from __future__ import annotations
"""Preview workers — video metadata and thumbnail fetchers."""
import json
import threading

from PySide6.QtCore import QThread, Signal

from aura.constants import SUBPROCESS_TIMEOUT
from aura.workers.base import StoppableProcessWorker

# ══════════════════════════════════════════════════════════════════════════════
#  PREVIEW WORKER (background yt-dlp --dump-json)
# ══════════════════════════════════════════════════════════════════════════════

class PreviewWorker(StoppableProcessWorker):
    """Fetch video metadata via yt-dlp --dump-json."""
    result_signal = Signal(dict)
    error_signal = Signal(str)
    
    def __init__(self, url, ytdlp_bin="yt-dlp", extra_args=None):
        """Initialize with URL and optional yt-dlp arguments."""
        super().__init__()
        self.url = url
        self.ytdlp_bin = ytdlp_bin
        self.extra_args = extra_args or []
    
    def run(self) -> None:
        """Fetch video metadata via yt-dlp --dump-json."""
        try:
            cmd = [self.ytdlp_bin, "--dump-json", "--no-warnings", "--no-playlist"] + self.extra_args + [self.url]
            result = self._run_process(cmd, timeout=60)
            if result is None or self._was_stopped():
                return
            if result.returncode != 0:
                err = (result.stderr or result.stdout or "yt-dlp error").strip()
                self.error_signal.emit(err[:300])
                return
            try:
                data = json.loads(result.stdout)
            except json.JSONDecodeError as exc:
                snippet = (result.stdout or result.stderr or "").strip()
                self.error_signal.emit((snippet[:300] or str(exc)))
                return
            self.result_signal.emit(data)
        except Exception as e:
            self.error_signal.emit(str(e))



class ThumbnailWorker(QThread):
    """Download thumbnail image in background."""
    result_signal = Signal(bytes)
    
    def __init__(self, url):
        """Initialize with URL and optional yt-dlp arguments."""
        super().__init__()
        self.url = url
        self._stop_requested = threading.Event()
        self._response = None

    def stop(self) -> None:
        self._stop_requested.set()
        self.requestInterruption()
        response = self._response
        if response is not None:
            try:
                response.close()
            except Exception:
                pass
    
    def run(self):
        """Fetch video metadata via yt-dlp --dump-json."""
        try:
            import urllib.request
            req = urllib.request.Request(self.url, headers={'User-Agent': 'Mozilla/5.0'})
            with urllib.request.urlopen(req, timeout=SUBPROCESS_TIMEOUT) as resp:
                self._response = resp
                chunks = []
                while not self._stop_requested.is_set() and not self.isInterruptionRequested():
                    chunk = resp.read(64 * 1024)
                    if not chunk:
                        break
                    chunks.append(chunk)
                if not self._stop_requested.is_set() and not self.isInterruptionRequested():
                    self.result_signal.emit(b"".join(chunks))
        except Exception:
            if not self._stop_requested.is_set() and not self.isInterruptionRequested():
                self.result_signal.emit(b'')
        finally:
            self._response = None
