#!/usr/bin/env python3
from __future__ import annotations
"""Subscription check worker — finds new videos on channels."""
import json

from PySide6.QtCore import Signal

from aura.workers.base import StoppableProcessWorker

# ══════════════════════════════════════════════════════════════════════════════
#  SUBSCRIPTION CHECK WORKER
# ══════════════════════════════════════════════════════════════════════════════

class SubCheckWorker(StoppableProcessWorker):
    """Check a single subscription for new videos."""
    result_signal = Signal(int, list)  # sub_id, list of new URLs
    error_signal = Signal(int, str)    # sub_id, error msg
    
    def __init__(self, sub_id, channel_url, max_new, ytdlp_bin="yt-dlp",
                 archive_path=None, extra_args=None, target_kind="channel"):
        """Initialize with subscription details and yt-dlp configuration."""
        super().__init__()
        self.sub_id = sub_id
        self.channel_url = channel_url
        self.max_new = max_new
        self.ytdlp_bin = ytdlp_bin
        self.archive_path = archive_path
        self.extra_args = extra_args or []
        self.target_kind = (target_kind or "channel").strip().lower() or "channel"
    
    def run(self) -> None:
        """Check channel for new videos using --flat-playlist."""
        try:
            cmd = [self.ytdlp_bin, "--flat-playlist", "--dump-json",
                   "--playlist-end", str(self.max_new)]
            if self.archive_path:
                cmd.extend(["--download-archive", str(self.archive_path)])
            cmd.extend(self.extra_args)
            cmd.append(self.channel_url)
            
            result = self._run_process(cmd, timeout=120)
            if result is None or self._was_stopped():
                return
            if result.returncode != 0:
                err = (result.stderr or result.stdout or "yt-dlp error").strip()
                self.error_signal.emit(self.sub_id, err[:300])
                return
            urls = []
            for line in result.stdout.strip().split('\n'):
                if not line.strip():
                    continue
                try:
                    entry = json.loads(line)
                    url = entry.get('url') or entry.get('webpage_url') or entry.get('original_url', '')
                    if url:
                        urls.append(url)
                except json.JSONDecodeError:
                    continue
            if not self._was_stopped():
                self.result_signal.emit(self.sub_id, urls)
        except Exception as e:
            if not self._was_stopped():
                self.error_signal.emit(self.sub_id, str(e))


# Категории платформ
