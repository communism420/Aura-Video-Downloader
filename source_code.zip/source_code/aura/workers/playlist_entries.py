#!/usr/bin/env python3
from __future__ import annotations

"""Background worker that fetches playlist/channel/search entries."""

import json

from PySide6.QtCore import Signal

from aura.workers.base import StoppableProcessWorker


class PlaylistEntriesWorker(StoppableProcessWorker):
    """Fetch flat playlist entries so the user can select items manually."""

    result_signal = Signal(dict)
    error_signal = Signal(str)

    def __init__(self, url, ytdlp_bin="yt-dlp", extra_args=None):
        super().__init__()
        self.url = url
        self.ytdlp_bin = ytdlp_bin
        self.extra_args = extra_args or []

    def run(self) -> None:
        try:
            cmd = [
                self.ytdlp_bin,
                "--dump-single-json",
                "--flat-playlist",
                "--ignore-errors",
                "--no-warnings",
            ] + self.extra_args + [self.url]
            result = self._run_process(cmd, timeout=120)
            if result is None or self._was_stopped():
                return
            if result.returncode != 0 or not result.stdout.strip():
                err = (result.stderr or result.stdout or "yt-dlp error").strip()
                self.error_signal.emit(err[:300])
                return

            data = json.loads(result.stdout)
            if not isinstance(data, dict):
                self.error_signal.emit("Unexpected playlist metadata payload")
                return

            entries = []
            for index, raw_entry in enumerate(data.get("entries") or [], start=1):
                if not isinstance(raw_entry, dict):
                    continue
                entries.append(
                    {
                        "index": int(raw_entry.get("playlist_index") or index),
                        "title": (raw_entry.get("title") or "").strip() or f"Item {index}",
                        "uploader": (raw_entry.get("uploader") or raw_entry.get("channel") or "").strip(),
                        "duration": raw_entry.get("duration"),
                        "webpage_url": (
                            raw_entry.get("webpage_url")
                            or raw_entry.get("original_url")
                            or raw_entry.get("url")
                            or ""
                        ),
                        "id": raw_entry.get("id") or "",
                    }
                )

            payload = {
                "title": (data.get("title") or data.get("uploader") or self.url).strip(),
                "entries": entries,
                "total": len(entries),
            }
            if not self._was_stopped():
                self.result_signal.emit(payload)
        except Exception as exc:
            if not self._was_stopped():
                self.error_signal.emit(str(exc))
