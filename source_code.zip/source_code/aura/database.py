#!/usr/bin/env python3
from __future__ import annotations

"""SQLite database — downloads, subscriptions, sessions."""
import datetime
import json
import sqlite3
from contextlib import contextmanager
from pathlib import Path

from aura.utils import get_settings_dir

# ══════════════════════════════════════════════════════════════════════════════
#  SQLITE DATABASE (persistent storage for downloads, subscriptions, sessions)
# ══════════════════════════════════════════════════════════════════════════════

class AuraDatabase:
    """SQLite database for download history, subscriptions, and session recovery."""

    def __init__(self, db_path: Path | str | None = None) -> None:
        if db_path is None:
            db_path = get_settings_dir() / "aura_downloads.db"
        self.db_path = str(db_path)
        self._ensure_dir()
        self._init_db()

    def _ensure_dir(self) -> None:
        Path(self.db_path).parent.mkdir(parents=True, exist_ok=True)

    @contextmanager
    def _connect(self):
        """Open a SQLite connection that is always closed immediately after use."""
        conn = sqlite3.connect(self.db_path)
        try:
            yield conn
        finally:
            conn.close()

    def _init_db(self) -> None:
        with self._connect() as conn:
            conn.execute("""CREATE TABLE IF NOT EXISTS downloads (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                url TEXT DEFAULT '',
                name TEXT DEFAULT '',
                status TEXT DEFAULT 'done',
                date TEXT DEFAULT '',
                filepath TEXT DEFAULT '',
                filesize TEXT DEFAULT '',
                platform TEXT DEFAULT '',
                dtype TEXT DEFAULT 'video',
                format_id TEXT DEFAULT '',
                duration TEXT DEFAULT ''
            )""")
            conn.execute("""CREATE TABLE IF NOT EXISTS subscriptions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                platform TEXT NOT NULL,
                channel_url TEXT NOT NULL,
                channel_name TEXT DEFAULT '',
                target_kind TEXT DEFAULT 'channel',
                preset_json TEXT DEFAULT '{}',
                enabled INTEGER DEFAULT 1,
                last_check TEXT DEFAULT '',
                interval_minutes INTEGER DEFAULT 60,
                max_new INTEGER DEFAULT 5,
                added_date TEXT DEFAULT ''
            )""")
            conn.execute("""CREATE TABLE IF NOT EXISTS session_queue (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                url TEXT NOT NULL,
                mode TEXT DEFAULT 'video',
                platform TEXT DEFAULT '',
                quality TEXT DEFAULT 'max',
                status TEXT DEFAULT 'pending',
                created TEXT DEFAULT '',
                details_json TEXT DEFAULT '{}'
            )""")
            self._ensure_session_queue_columns(conn)
            self._ensure_subscriptions_columns(conn)
            conn.commit()

    @staticmethod
    def _ensure_session_queue_columns(conn) -> None:
        columns = {row[1] for row in conn.execute("PRAGMA table_info(session_queue)").fetchall()}
        if "details_json" not in columns:
            conn.execute("ALTER TABLE session_queue ADD COLUMN details_json TEXT DEFAULT '{}'")

    @staticmethod
    def _ensure_subscriptions_columns(conn) -> None:
        columns = {row[1] for row in conn.execute("PRAGMA table_info(subscriptions)").fetchall()}
        if "target_kind" not in columns:
            conn.execute("ALTER TABLE subscriptions ADD COLUMN target_kind TEXT DEFAULT 'channel'")

    # ── Downloads ──
    def add_download(self, name, status="done", size="", dtype="video",
                     platform="", url="", filepath="", format_id="", duration=""):
        date = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
        with self._connect() as conn:
            conn.execute(
                "INSERT INTO downloads (url, name, status, date, filepath, filesize, platform, dtype, format_id, duration) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (url, name, status, date, filepath, size, platform, dtype, format_id, duration))
            conn.commit()

    def get_downloads(self, platform=None, limit=1000):
        with self._connect() as conn:
            conn.row_factory = sqlite3.Row
            if platform:
                rows = conn.execute(
                    "SELECT * FROM downloads WHERE platform=? ORDER BY id DESC LIMIT ?",
                    (platform, limit)).fetchall()
            else:
                rows = conn.execute(
                    "SELECT * FROM downloads ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
        return [dict(r) for r in rows]

    def clear_completed(self, platform=None):
        with self._connect() as conn:
            if platform:
                conn.execute("DELETE FROM downloads WHERE status='done' AND platform=?", (platform,))
            else:
                conn.execute("DELETE FROM downloads WHERE status='done'")
            conn.commit()

    def get_download_count(self) -> int:
        with self._connect() as conn:
            return conn.execute("SELECT COUNT(*) FROM downloads").fetchone()[0]

    # ── Subscriptions ──
    def add_subscription(self, platform, channel_url, channel_name="",
                         interval_minutes=60, max_new=5, preset_json="{}",
                         target_kind="channel"):
        date = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
        with self._connect() as conn:
            conn.execute(
                "INSERT INTO subscriptions (platform, channel_url, channel_name, target_kind, interval_minutes, max_new, preset_json, added_date) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                (platform, channel_url, channel_name, target_kind, interval_minutes, max_new, preset_json, date))
            conn.commit()

    def get_subscriptions(self, platform=None):
        with self._connect() as conn:
            conn.row_factory = sqlite3.Row
            if platform:
                rows = conn.execute("SELECT * FROM subscriptions WHERE platform=? ORDER BY id", (platform,)).fetchall()
            else:
                rows = conn.execute("SELECT * FROM subscriptions ORDER BY id").fetchall()
        return [dict(r) for r in rows]

    def update_subscription(self, sub_id, **kwargs):
        sets = ", ".join(f"{k}=?" for k in kwargs)
        vals = list(kwargs.values()) + [sub_id]
        with self._connect() as conn:
            conn.execute(f"UPDATE subscriptions SET {sets} WHERE id=?", vals)
            conn.commit()

    def delete_subscription(self, sub_id: int) -> None:
        with self._connect() as conn:
            conn.execute("DELETE FROM subscriptions WHERE id=?", (sub_id,))
            conn.commit()

    def toggle_subscription(self, sub_id: int, enabled: bool) -> None:
        self.update_subscription(sub_id, enabled=1 if enabled else 0)

    # ── Session Recovery ──
    def save_session(self, entries):
        """Save download queue for session recovery."""
        with self._connect() as conn:
            conn.execute("DELETE FROM session_queue")
            date = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
            for e in entries:
                payload = e if isinstance(e, dict) else {}
                conn.execute(
                    "INSERT INTO session_queue (url, mode, platform, quality, status, created, details_json) VALUES (?, ?, ?, ?, ?, ?, ?)",
                    (
                        payload.get("url", ""),
                        payload.get("mode", "video"),
                        payload.get("platform", ""),
                        payload.get("quality", "max"),
                        payload.get("status", "pending"),
                        date,
                        json.dumps(payload, ensure_ascii=False),
                    ),
                )
            conn.commit()

    def load_session(self) -> list[dict]:
        with self._connect() as conn:
            conn.row_factory = sqlite3.Row
            rows = conn.execute("SELECT * FROM session_queue ORDER BY id").fetchall()
        loaded = []
        for row in rows:
            item = dict(row)
            details_raw = item.get("details_json") or "{}"
            try:
                details = json.loads(details_raw)
            except Exception:
                details = {}
            if isinstance(details, dict):
                merged = item.copy()
                merged.update(details)
                item = merged
            loaded.append(item)
        return loaded

    def clear_session(self) -> None:
        with self._connect() as conn:
            conn.execute("DELETE FROM session_queue")
            conn.commit()

    def export_state(self) -> dict:
        """Export database-backed state for full app backup/restore."""
        with self._connect() as conn:
            conn.row_factory = sqlite3.Row
            downloads = [dict(r) for r in conn.execute("SELECT * FROM downloads ORDER BY id").fetchall()]
            subscriptions = [dict(r) for r in conn.execute("SELECT * FROM subscriptions ORDER BY id").fetchall()]
            session_queue = [dict(r) for r in conn.execute("SELECT * FROM session_queue ORDER BY id").fetchall()]
        return {
            "downloads": downloads,
            "subscriptions": subscriptions,
            "session_queue": session_queue,
        }

    def import_state(self, state: dict | None) -> None:
        """Replace database-backed state from a previously exported snapshot."""
        if not isinstance(state, dict):
            return

        downloads = state.get("downloads", [])
        subscriptions = state.get("subscriptions", [])
        session_queue = state.get("session_queue", [])

        with self._connect() as conn:
            conn.execute("DELETE FROM downloads")
            conn.execute("DELETE FROM subscriptions")
            conn.execute("DELETE FROM session_queue")

            for row in downloads:
                if not isinstance(row, dict):
                    continue
                conn.execute(
                    "INSERT INTO downloads (url, name, status, date, filepath, filesize, platform, dtype, format_id, duration) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    (
                        row.get("url", ""),
                        row.get("name", ""),
                        row.get("status", "done"),
                        row.get("date", ""),
                        row.get("filepath", ""),
                        row.get("filesize", ""),
                        row.get("platform", ""),
                        row.get("dtype", "video"),
                        row.get("format_id", ""),
                        row.get("duration", ""),
                    ),
                )

            for row in subscriptions:
                if not isinstance(row, dict):
                    continue
                conn.execute(
                    "INSERT INTO subscriptions (platform, channel_url, channel_name, target_kind, preset_json, enabled, last_check, interval_minutes, max_new, added_date) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    (
                        row.get("platform", ""),
                        row.get("channel_url", ""),
                        row.get("channel_name", ""),
                        row.get("target_kind", "channel"),
                        row.get("preset_json", "{}"),
                        int(row.get("enabled", 1) or 0),
                        row.get("last_check", ""),
                        int(row.get("interval_minutes", 60) or 60),
                        int(row.get("max_new", 5) or 5),
                        row.get("added_date", ""),
                    ),
                )

            for row in session_queue:
                if not isinstance(row, dict):
                    continue
                conn.execute(
                    "INSERT INTO session_queue (url, mode, platform, quality, status, created, details_json) VALUES (?, ?, ?, ?, ?, ?, ?)",
                    (
                        row.get("url", ""),
                        row.get("mode", "video"),
                        row.get("platform", ""),
                        row.get("quality", "max"),
                        row.get("status", "pending"),
                        row.get("created", ""),
                        row.get("details_json", json.dumps(row, ensure_ascii=False)),
                    ),
                )

            conn.commit()

    def migrate_json_history(self, json_history: list[dict], platform: str) -> int:
        """Import legacy JSON history into SQLite (one-time migration)."""
        if not json_history:
            return 0
        count = 0
        with self._connect() as conn:
            for e in json_history:
                conn.execute(
                    "INSERT INTO downloads (name, status, date, filesize, platform, dtype) VALUES (?, ?, ?, ?, ?, ?)",
                    (e.get("name", ""), e.get("status", "done"), e.get("date", ""),
                     e.get("size", ""), e.get("platform", platform), e.get("type", "video")))
                count += 1
            conn.commit()
        return count
