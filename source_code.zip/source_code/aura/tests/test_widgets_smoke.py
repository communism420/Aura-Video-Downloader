import pytest
from PySide6.QtCore import qInstallMessageHandler

from aura.widgets import SpeedGraphWidget


def test_speed_graph_grab_does_not_emit_qpainter_warnings(qapp):
    widget = SpeedGraphWidget()
    widget.resize(480, 180)
    widget.set_colors("#121a2b", "#5cc8ff", "#22314a", "#c7d2e0")
    for speed in (128_000, 640_000, 2_400_000, 1_100_000, 2_900_000):
        widget.add_point(speed)

    messages = []

    def _handler(_mode, _context, message):
        messages.append(message)

    previous = qInstallMessageHandler(_handler)
    try:
        widget.show()
        qapp.processEvents()
        for _ in range(5):
            widget.grab()
            qapp.processEvents()
    finally:
        qInstallMessageHandler(previous)
        widget.close()
        qapp.processEvents()

    qpainter_messages = [msg for msg in messages if "QPainter::" in msg]
    assert qpainter_messages == []
