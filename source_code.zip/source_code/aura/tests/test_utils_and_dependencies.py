import json
import threading
from pathlib import Path
from types import SimpleNamespace

import pytest
from PySide6.QtWidgets import QWidget

import aura.workers.base as workers_base_module
from aura.constants import SETTINGS_FOLDER_NAME


def test_resource_path_resolves_project_assets_outside_repo(monkeypatch, tmp_path):
    import aura.utils as utils_module

    monkeypatch.chdir(tmp_path)

    resolved = Path(utils_module.resource_path("aura/assets/checkmark.svg"))

    assert resolved.exists()
    assert resolved.name == "checkmark.svg"


def test_get_app_icon_path_prefers_icon_inside_aura_package(monkeypatch, tmp_path):
    import aura.utils as utils_module

    package_icon = tmp_path / "aura" / "app.ico"
    legacy_icon = tmp_path / "app.ico"
    package_icon.parent.mkdir(parents=True)
    package_icon.write_bytes(b"package")
    legacy_icon.write_bytes(b"legacy")

    monkeypatch.setattr(utils_module, "resource_path", lambda relative: str(tmp_path / relative))

    assert utils_module.get_app_icon_path() == str(package_icon)


def test_get_app_icon_path_falls_back_to_legacy_icon(monkeypatch, tmp_path):
    import aura.utils as utils_module

    legacy_icon = tmp_path / "app.ico"
    legacy_icon.write_bytes(b"legacy")

    monkeypatch.setattr(utils_module, "resource_path", lambda relative: str(tmp_path / relative))

    assert utils_module.get_app_icon_path() == str(legacy_icon)


def test_get_settings_dir_preserves_custom_pointer_before_folder_exists(monkeypatch, tmp_path):
    import aura.utils as utils_module

    pointer_file = tmp_path / "pointer.txt"
    custom_root = tmp_path / "custom-root"
    pointer_file.write_text(str(custom_root), encoding="utf-8")

    monkeypatch.setattr(utils_module, "get_pointer_file", lambda: pointer_file)
    monkeypatch.setattr(utils_module, "_get_legacy_pointer", lambda: tmp_path / "legacy-pointer.txt")

    assert utils_module.get_settings_dir() == custom_root / SETTINGS_FOLDER_NAME


def test_activate_debug_mode_provides_runtime_settings_dir(monkeypatch, tmp_path):
    import aura.utils as utils_module

    monkeypatch.setattr(utils_module, "_DEBUG_MODE", False)
    monkeypatch.setattr(utils_module, "_DEBUG_SETTINGS_DIR", None)
    monkeypatch.setattr(utils_module, "_DEBUG_SETTINGS_HANDLE", None)

    runtime_dir = utils_module.activate_debug_mode(tmp_path / "debug-runtime")

    assert utils_module.is_debug_mode() is True
    assert runtime_dir == tmp_path / "debug-runtime"
    assert runtime_dir.exists()
    assert utils_module.get_settings_dir() == runtime_dir


def test_atomic_write_json_creates_missing_parent_directories(tmp_path):
    import aura.utils as utils_module

    target = tmp_path / "nested" / "state.json"

    assert utils_module.atomic_write_json(target, {"ok": True}) is True
    assert json.loads(target.read_text(encoding="utf-8")) == {"ok": True}


def test_configure_qt_fontdir_uses_system_fonts_on_windows(tmp_path):
    import aura

    fonts_dir = tmp_path / "Fonts"
    fonts_dir.mkdir()
    env = {"WINDIR": str(tmp_path)}

    configured = aura._configure_qt_fontdir(env=env, platform="win32")

    assert configured == str(fonts_dir)
    assert env["QT_QPA_FONTDIR"] == str(fonts_dir)


def test_translation_catalog_uses_metadata_and_code_fallbacks(monkeypatch):
    import aura.translations as translations_module

    monkeypatch.setattr(
        translations_module,
        "get_all_translations",
        lambda: {
            "ru": {
                "_meta_language_name": "Russian",
                "_meta_language_native_name": "Русский",
                "_meta_language_tagline": "Полный интерфейс на русском.",
                "window_title": "Aura",
            },
            "de": {
                "window_title": "Aura",
            },
        },
    )
    monkeypatch.setattr(translations_module, "_CATALOG_CACHE", None)

    catalog = translations_module.get_translation_catalog()
    ru = next(item for item in catalog if item["code"] == "ru")
    de = next(item for item in catalog if item["code"] == "de")

    assert ru["native_name"] == "Русский"
    assert ru["name"] == "Russian"
    assert ru["tagline"] == "Полный интерфейс на русском."
    assert de["native_name"] == "Deutsch"
    assert de["name"] == "German"
    assert de["tagline"] == "German interface translation."
    assert de["key_count"] == 1


def test_deps_worker_probes_runnable_binaries(monkeypatch):
    import aura.workers.deps as deps_module

    class FakePopen:
        def __init__(self, stdout="", stderr="", returncode=0):
            self._stdout = stdout
            self._stderr = stderr
            self.returncode = returncode

        def communicate(self, timeout=None):
            return self._stdout, self._stderr

        def poll(self):
            return self.returncode

        def wait(self, timeout=None):
            return self.returncode

        def terminate(self):
            return None

        def kill(self):
            return None

    def fake_find_binary(name):
        return name

    def fake_which(name):
        mapping = {
            "yt-dlp": r"C:\venv\Scripts\yt-dlp.exe",
            "ffmpeg": r"C:\tools\ffmpeg.exe",
            "aria2c": r"C:\tools\aria2c.exe",
            "es": r"C:\tools\es.exe",
        }
        return mapping.get(name)

    def fake_popen(cmd, **_kwargs):
        if cmd[0] == "yt-dlp":
            return FakePopen(stdout="2026.03.03\n", stderr="", returncode=0)
        if cmd[0] == "ffmpeg":
            return FakePopen(stdout="", stderr="broken ffmpeg", returncode=1)
        if cmd[0] == "node":
            raise FileNotFoundError()
        if cmd[0] == "aria2c":
            return FakePopen(stdout="", stderr="aria failed", returncode=9)
        if cmd[0] == "es.exe":
            raise FileNotFoundError()
        if cmd[0] == "es":
            return FakePopen(stdout="Everything help", stderr="", returncode=2)
        raise AssertionError(cmd[0])

    monkeypatch.setattr(deps_module, "find_binary", fake_find_binary)
    monkeypatch.setattr(deps_module.shutil, "which", fake_which)
    monkeypatch.setattr(workers_base_module.subprocess, "Popen", fake_popen)

    worker = deps_module.DepsWorker({"needs_nodejs": True})
    received = []
    worker.results_ready.connect(lambda data: received.append(data))

    worker.run()

    assert len(received) == 1
    results = received[0]
    assert results["ytdlp"] == ("ok", "2026.03.03", r"C:\venv\Scripts\yt-dlp.exe")
    assert results["ffmpeg"] == ("error", "broken ffmpeg", r"C:\tools\ffmpeg.exe")
    assert results["nodejs"] == ("missing", "", "")
    assert results["aria2c"] == ("error", "aria failed", r"C:\tools\aria2c.exe")
    assert results["everything"] == ("ok", "Everything help", r"C:\tools\es.exe")


def test_cookie_browser_requires_webengine(monkeypatch, tmp_path):
    import aura.dialogs.cookie_browser as cookie_browser_module

    monkeypatch.setattr(cookie_browser_module, "_HAS_WEBENGINE", False)

    with pytest.raises(RuntimeError, match="WebEngine"):
        cookie_browser_module.CookieBrowserDialog(
            None,
            platform_name="YouTube",
            login_url="https://example.com/login",
            output_path=tmp_path / "cookies.txt",
            lang="en",
        )


def test_cookie_browser_buttons_do_not_capture_enter(monkeypatch, tmp_path, qapp):
    import aura.dialogs.cookie_browser as cookie_browser_module

    class DummySignal:
        def connect(self, _callback):
            return None

    class FakeCookieStore:
        def __init__(self):
            self.cookieAdded = DummySignal()

    class FakeProfile:
        NoPersistentCookies = object()

        def __init__(self, *_args, **_kwargs):
            self._store = FakeCookieStore()
            self.policy = None

        def setPersistentCookiesPolicy(self, policy):
            self.policy = policy

        def cookieStore(self):
            return self._store

    class FakePage:
        def __init__(self, profile, parent):
            self.profile = profile
            self.parent = parent

    class FakeView(QWidget):
        def __init__(self, parent=None):
            super().__init__(parent)
            self.page = None
            self.loaded = None

        def setPage(self, page):
            self.page = page

        def load(self, url):
            self.loaded = url

    monkeypatch.setattr(cookie_browser_module, "_HAS_WEBENGINE", True)
    monkeypatch.setattr(cookie_browser_module, "QNetworkCookie", lambda cookie: cookie)
    monkeypatch.setattr(cookie_browser_module, "QWebEngineProfile", FakeProfile)
    monkeypatch.setattr(cookie_browser_module, "QWebEnginePage", FakePage)
    monkeypatch.setattr(cookie_browser_module, "QWebEngineView", FakeView)

    dialog = cookie_browser_module.CookieBrowserDialog(
        None,
        platform_name="YouTube",
        login_url="https://example.com/login",
        output_path=tmp_path / "cookies.txt",
        lang="en",
    )
    try:
        buttons = dialog.findChildren(cookie_browser_module.QPushButton)
        assert buttons
        assert all(button.autoDefault() is False for button in buttons)
        assert all(button.isDefault() is False for button in buttons)
    finally:
        dialog.close()


def test_download_worker_cleans_up_failed_processes(monkeypatch):
    import aura.workers.download as download_module

    class BrokenStream:
        def __iter__(self):
            return self

        def __next__(self):
            raise RuntimeError("stream exploded")

    class FakeProcess:
        def __init__(self):
            self.stdout = BrokenStream()
            self.returncode = None
            self.terminated = False
            self.killed = False

        def poll(self):
            return None if self.returncode is None else self.returncode

        def terminate(self):
            self.terminated = True
            self.returncode = 1

        def wait(self, timeout=None):
            self.returncode = 1
            return self.returncode

        def kill(self):
            self.killed = True
            self.returncode = 1

    process = FakeProcess()
    monkeypatch.setattr(download_module.subprocess, "Popen", lambda *args, **kwargs: process)

    worker = download_module.DownloadWorker(["yt-dlp", "https://example.com/watch?v=demo"], threading.Event())
    finished = []
    download_module.tracked_processes.clear()
    worker.finished_signal.connect(lambda code: finished.append(code))

    worker.run()

    assert finished == [1]
    assert process.terminated or process.killed
    assert process not in download_module.tracked_processes
