import json
import types
from pathlib import Path

import pytest


def test_build_ytdlp_runtime_args_supports_browser_auth_and_proxy(window):
    window._binary_available = lambda _path: True
    window._node_bin = "node"
    window.proxy_input.setText("socks5://127.0.0.1:1080")
    window._set_combo_by_data(window.auth_combo, "chrome")

    args = window._build_ytdlp_runtime_args(platform_id="youtube")

    assert "--cookies-from-browser" in args
    assert "chrome" in args
    assert "--proxy" in args
    assert "socks5://127.0.0.1:1080" in args
    assert "--js-runtimes" in args
    assert "youtube:player_client=android,web" not in args


def test_build_ytdlp_runtime_args_do_not_force_legacy_youtube_player_client_without_auth(window):
    window._binary_available = lambda _path: True
    window._node_bin = "node"
    window._set_combo_by_data(window.auth_combo, "none")

    args = window._build_ytdlp_runtime_args(platform_id="youtube")

    assert "--js-runtimes" in args
    assert "youtube:player_client=android,web" not in args


def test_build_ytdlp_runtime_args_prefers_selected_audio_language_for_youtube(window):
    window._binary_available = lambda _path: True
    window._node_bin = "node"
    window._set_combo_by_data(window.auth_combo, "none")
    window._set_combo_by_data(window.audio_lang_combo, "ru")
    window._set_combo_by_data(window.meta_lang_combo, "en")

    args = window._build_ytdlp_runtime_args(platform_id="youtube")

    extractor_arg_index = args.index("--extractor-args")
    extractor_value = args[extractor_arg_index + 1]
    header_index = args.index("--add-header")
    header_value = args[header_index + 1]

    assert "youtube:" in extractor_value
    assert "lang=ru" in extractor_value
    assert "lang=en" not in extractor_value
    assert "player_client=web_embedded,default" in extractor_value
    assert header_value == "Accept-Language:ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7"


def test_build_ytdlp_runtime_args_keeps_browser_auth_without_guest_audio_client_workaround(window):
    window._binary_available = lambda _path: True
    window._node_bin = "node"
    window._set_combo_by_data(window.auth_combo, "chrome")
    window._set_combo_by_data(window.audio_lang_combo, "ru")

    args = window._build_ytdlp_runtime_args(platform_id="youtube")

    extractor_arg_index = args.index("--extractor-args")
    extractor_value = args[extractor_arg_index + 1]

    assert "--cookies-from-browser" in args
    assert "lang=ru" in extractor_value
    assert "player_client=web_embedded,default" not in extractor_value


def test_resolve_media_info_for_requested_audio_language_uses_browser_auth_fallback_for_youtube(window, monkeypatch):
    window._set_combo_by_data(window.audio_lang_combo, "ru")
    window._set_combo_by_data(window.auth_combo, "none")
    attempts = []

    def fake_probe(url, cookies="", platform_id=None, log_errors=False, runtime_settings=None):
        auth_method = str((runtime_settings or {}).get("auth_method") or "none")
        attempts.append(auth_method)
        if auth_method == "none":
            return {
                "formats": [
                    {"format_id": "140", "acodec": "mp4a.40.2", "vcodec": "none", "language": "en"},
                ]
            }
        if auth_method == "edge":
            return {
                "formats": [
                    {"format_id": "251-ru", "acodec": "opus", "vcodec": "none", "language": "ru-RU"},
                ]
            }
        return {}

    monkeypatch.setattr(window, "_probe_media_info", fake_probe)
    monkeypatch.setattr(window, "_youtube_audio_browser_fallbacks", lambda: ["edge", "chrome"])

    info, runtime_settings, used_fallback = window._resolve_media_info_for_requested_audio_language(
        "https://www.youtube.com/watch?v=fallbackcandidate123",
        platform_id="youtube",
        runtime_settings=window._collect_runtime_settings_snapshot(),
    )

    assert used_fallback is True
    assert runtime_settings["auth_method"] == "edge"
    assert window._extract_audio_languages_from_info(info) == ["ru-RU"]
    assert attempts == ["none", "edge"]


def test_youtube_audio_runtime_candidates_include_firefox_profile_fallbacks(window, monkeypatch):
    window._set_combo_by_data(window.audio_lang_combo, "ru")
    window._set_combo_by_data(window.auth_combo, "none")
    monkeypatch.setattr(window, "_youtube_audio_browser_fallbacks", lambda: ["edge"])
    monkeypatch.setattr(window, "_youtube_audio_browser_profile_fallbacks", lambda: ["firefox:C:/Waterfox/Profile"])

    candidates = window._youtube_audio_runtime_candidates(
        platform_id="youtube",
        runtime_settings=window._collect_runtime_settings_snapshot(),
    )

    assert [candidate["auth_method"] for candidate in candidates] == [
        "none",
        "edge",
        "firefox:C:/Waterfox/Profile",
    ]


def test_get_selected_video_with_audio_format_id_prefers_best_requested_language(window):
    media_info = {
        "formats": [
            {"format_id": "95-en", "acodec": "mp4a.40.2", "vcodec": "avc1.4D401F", "language": "en", "height": 720, "fps": 30},
            {"format_id": "95-ru", "acodec": "mp4a.40.2", "vcodec": "avc1.4D401F", "language": "ru", "height": 720, "fps": 30},
            {"format_id": "96-ru", "acodec": "mp4a.40.2", "vcodec": "avc1.640028", "language": "ru", "height": 1080, "fps": 30, "format_note": "(default)"},
        ]
    }

    selected = window._get_selected_video_with_audio_format_id("ru", media_info=media_info)

    assert selected == "96-ru"


def test_build_command_uses_runtime_settings_auth_override(window, tmp_path):
    archive = tmp_path / "archive.txt"
    output_template = str(tmp_path / "%(title)s.%(ext)s")

    window._binary_available = lambda _path: True
    window._ytdlp_bin = "yt-dlp"
    window._ffmpeg_bin = "ffmpeg"
    window._node_bin = "node"
    window._set_combo_by_data(window.auth_combo, "none")
    window._set_combo_by_data(window.audio_lang_combo, "ru")

    runtime_settings = window._collect_runtime_settings_snapshot()
    runtime_settings["auth_method"] = "edge"

    cmd = window._build_command(
        window.MODE_VIDEO,
        "https://www.youtube.com/watch?v=runtimeoverride123",
        "",
        output_template,
        archive,
        platform_id="youtube",
        quality_override="max",
        allow_metadata_probe=False,
        runtime_settings=runtime_settings,
    )

    assert "--cookies-from-browser" in cmd
    assert "edge" in cmd


def test_build_command_can_use_load_info_json_with_forced_combined_format(window, tmp_path):
    archive = tmp_path / "archive.txt"
    output_template = str(tmp_path / "%(title)s.%(ext)s")
    info_json = tmp_path / "translated.info.json"
    info_json.write_text("{}", encoding="utf-8")

    window._ytdlp_bin = "yt-dlp"
    window._ffmpeg_bin = "ffmpeg"

    cmd = window._build_command(
        window.MODE_VIDEO,
        "https://www.youtube.com/watch?v=translatedcombo123",
        "",
        output_template,
        archive,
        platform_id="youtube",
        quality_override="max",
        allow_metadata_probe=False,
        preloaded_media_info={
            "formats": [
                {"format_id": "96-22", "acodec": "mp4a.40.2", "vcodec": "avc1.640028", "language": "ru", "height": 1080},
            ]
        },
        load_info_json_path=str(info_json),
        forced_format_id="96-22",
    )

    assert "--load-info-json" in cmd
    assert str(info_json) in cmd
    assert "96-22" in cmd
    assert "--no-keep-video" not in cmd
    assert cmd[-1] != "https://www.youtube.com/watch?v=translatedcombo123"


def test_build_command_includes_ffmpeg_subtitles_remux_and_cookies(window, tmp_path):
    cookies = tmp_path / "cookies.txt"
    cookies.write_text("# Netscape HTTP Cookie File\n", encoding="utf-8")
    archive = tmp_path / "archive.txt"
    output_template = str(tmp_path / "%(title)s.%(ext)s")

    window._binary_available = lambda _path: True
    window._ytdlp_bin = "yt-dlp"
    window._ffmpeg_bin = r"C:\tools\ffmpeg\bin\ffmpeg.exe"
    window._set_combo_by_data(window.auth_combo, "cookies_file")
    window.cookies_input.setText(str(cookies))
    window.proxy_input.setText("http://127.0.0.1:8080")
    window.chk_subs.setChecked(True)
    window.chk_embed_subs.setChecked(True)
    window._set_combo_by_data(window.sub_format_combo, "ass")
    window.container_combo.setCurrentIndex(1)  # MP4 remux

    cmd = window._build_command(
        window.MODE_VIDEO,
        "https://www.youtube.com/watch?v=command123",
        str(cookies),
        output_template,
        archive,
        platform_id="youtube",
        quality_override="max",
    )

    assert "--ffmpeg-location" in cmd
    assert r"C:\tools\ffmpeg\bin" in cmd
    assert "--cookies" in cmd
    assert str(cookies) in cmd
    assert "--proxy" in cmd
    assert "http://127.0.0.1:8080" in cmd
    assert "--write-sub" in cmd
    assert "--convert-subs" in cmd
    assert "ass" in cmd
    assert "--embed-subs" in cmd
    assert "--remux-video" in cmd
    assert "mp4" in cmd


def test_build_command_resolves_default_audio_and_subtitle_languages(window, tmp_path):
    archive = tmp_path / "archive.txt"
    output_template = str(tmp_path / "%(title)s.%(ext)s")

    window.lang = "ru"
    window._ytdlp_bin = "yt-dlp"
    window._ffmpeg_bin = "ffmpeg"
    window._set_combo_by_data(window.audio_lang_combo, "default")
    window.chk_subs.setChecked(True)
    window._set_combo_by_data(window.sub_lang_combo, "default")
    window._probe_media_info = lambda *args, **kwargs: {
        "formats": [
            {"format_id": "251-ru", "acodec": "opus", "vcodec": "none", "language": "ru-RU", "abr": 160, "language_preference": 10},
            {"format_id": "400", "acodec": "none", "vcodec": "av01.0.12M.08"},
        ],
        "subtitles": {"ru": [{"ext": "vtt"}]},
        "automatic_captions": {},
    }

    cmd = window._build_command(
        window.MODE_VIDEO,
        "https://www.youtube.com/watch?v=defaultlang123",
        "",
        output_template,
        archive,
        platform_id="youtube",
        quality_override="max",
    )

    fmt_index = cmd.index("-f")
    assert "251-ru" in cmd[fmt_index + 1]
    sub_lang_index = cmd.index("--sub-lang")
    assert cmd[sub_lang_index + 1] == "ru"


def test_build_command_always_uses_best_video_stream_and_merges_selected_audio(window, tmp_path):
    archive = tmp_path / "archive.txt"
    output_template = str(tmp_path / "%(title)s.%(ext)s")

    window._ytdlp_bin = "yt-dlp"
    window._ffmpeg_bin = "ffmpeg"
    window._set_combo_by_data(window.audio_lang_combo, "en")
    window._probe_media_info = lambda *args, **kwargs: {
        "formats": [
            {"format_id": "251-7", "acodec": "opus", "vcodec": "none", "language": "en-US", "abr": 160, "language_preference": 10, "format_note": "English original (default)"},
            {"format_id": "140-7", "acodec": "mp4a.40.2", "vcodec": "none", "language": "en-US", "abr": 128, "language_preference": 10},
            {"format_id": "401", "acodec": "none", "vcodec": "av01.0.12M.08"},
        ]
    }

    cmd = window._build_command(
        window.MODE_VIDEO,
        "https://www.youtube.com/watch?v=bestvideo123",
        "",
        output_template,
        archive,
        platform_id="youtube",
        quality_override="144p",
    )

    fmt_index = cmd.index("-f")
    assert cmd[fmt_index + 1] == "bv+251-7/bv+ba/b"
    assert "--no-keep-video" in cmd
    assert "height<=" not in cmd[fmt_index + 1]


def test_build_command_resolves_explicit_audio_language_to_exact_format_id(window, tmp_path):
    archive = tmp_path / "archive.txt"
    output_template = str(tmp_path / "%(title)s.%(ext)s")

    window._ytdlp_bin = "yt-dlp"
    window._ffmpeg_bin = "ffmpeg"
    window._set_combo_by_data(window.audio_lang_combo, "ru")
    window._probe_media_info = lambda *args, **kwargs: {
        "formats": [
            {"format_id": "251-ru", "acodec": "opus", "vcodec": "none", "language": "ru-RU", "abr": 192, "language_preference": 10, "format_note": "Russian (default)"},
            {"format_id": "140-en", "acodec": "mp4a.40.2", "vcodec": "none", "language": "en-US", "abr": 128, "language_preference": 1},
            {"format_id": "400", "acodec": "none", "vcodec": "av01.0.12M.08"},
        ]
    }

    cmd = window._build_command(
        window.MODE_VIDEO,
        "https://www.youtube.com/watch?v=fallbackaudio123",
        "",
        output_template,
        archive,
        platform_id="youtube",
        quality_override="max",
    )

    fmt_index = cmd.index("-f")
    assert cmd[fmt_index + 1] == "bv+251-ru/bv+ba/b"
    assert window._resolve_audio_language_selector("ru", media_info=window._probe_media_info()) == "ru-RU"


def test_build_command_can_keep_all_audio_tracks_in_single_mkv(window, tmp_path):
    archive = tmp_path / "archive.txt"
    output_template = str(tmp_path / "%(title)s.%(ext)s")

    window._ytdlp_bin = "yt-dlp"
    window._ffmpeg_bin = "ffmpeg"
    window._set_combo_by_data(window.audio_lang_combo, "ru")
    window.chk_all_audio_tracks.setChecked(True)

    cmd = window._build_command(
        window.MODE_VIDEO,
        "https://www.youtube.com/watch?v=multiaudio123",
        "",
        output_template,
        archive,
        platform_id="youtube",
        quality_override="max",
        preloaded_media_info={
            "formats": [
                {"format_id": "251-ru", "acodec": "opus", "vcodec": "none", "language": "ru-RU", "abr": 160, "language_preference": 10},
                {"format_id": "251-en", "acodec": "opus", "vcodec": "none", "language": "en-US", "abr": 160, "language_preference": 9},
                {"format_id": "140-en-low", "acodec": "mp4a.40.2", "vcodec": "none", "language": "en-US", "abr": 96, "language_preference": 1},
                {"format_id": "250-ja", "acodec": "opus", "vcodec": "none", "language": "ja", "abr": 96, "language_preference": 8},
                {"format_id": "401", "acodec": "none", "vcodec": "av01.0.12M.08"},
            ]
        },
    )

    fmt_index = cmd.index("-f")
    assert cmd[fmt_index + 1] == "bv+251-ru+251-en+250-ja/bv+251-ru/bv+ba/b"
    assert "--audio-multistreams" in cmd
    assert "--merge-output-format" in cmd
    assert cmd[cmd.index("--merge-output-format") + 1] == "mkv"


def test_build_command_prefers_h264_when_codec_policy_requests_compatibility(window, tmp_path):
    archive = tmp_path / "archive.txt"
    output_template = str(tmp_path / "%(title)s.%(ext)s")

    window._ytdlp_bin = "yt-dlp"
    window._ffmpeg_bin = "ffmpeg"
    window._set_combo_by_data(window.video_codec_combo, "h264")

    cmd = window._build_command(
        window.MODE_VIDEO,
        "https://www.youtube.com/watch?v=h264policy123",
        "",
        output_template,
        archive,
        platform_id="youtube",
        quality_override="max",
        allow_metadata_probe=False,
    )

    fmt_index = cmd.index("-f")
    assert cmd[fmt_index + 1] == "bv[vcodec~='^(avc|avc1|h264)']+ba/bv+ba/b"


def test_build_command_prefers_compatible_audio_and_video_for_selected_playback_target(window, tmp_path):
    archive = tmp_path / "archive.txt"
    output_template = str(tmp_path / "%(title)s.%(ext)s")

    window._ytdlp_bin = "yt-dlp"
    window._ffmpeg_bin = "ffmpeg"
    window._set_combo_by_data(window.playback_target_combo, "windows")

    cmd = window._build_command(
        window.MODE_VIDEO,
        "https://www.youtube.com/watch?v=compat123",
        "",
        output_template,
        archive,
        platform_id="youtube",
        quality_override="max",
        allow_metadata_probe=False,
    )

    fmt_index = cmd.index("-f")
    assert cmd[fmt_index + 1] == (
        "bv[vcodec~='^(avc|avc1|h264)']+ba[ext=m4a]/"
        "bv[vcodec~='^(avc|avc1|h264)']+ba/"
        "bv+ba[ext=m4a]/"
        "bv+ba/b"
    )


def test_playlist_download_can_prefer_original_audio_track(window, tmp_path):
    archive = tmp_path / "archive.txt"
    output_template = str(tmp_path / "%(title)s.%(ext)s")

    window._ytdlp_bin = "yt-dlp"
    window._ffmpeg_bin = "ffmpeg"
    window._set_combo_by_data(window.audio_lang_combo, "original")

    cmd = window._build_command(
        window.MODE_PLAYLIST,
        "https://www.youtube.com/playlist?list=PLoriginal123",
        "",
        output_template,
        archive,
        platform_id="youtube",
        quality_override="max",
    )

    fmt_index = cmd.index("-f")
    assert cmd[fmt_index + 1] == "bv+ba[format_note*=original]/bv+ba/b"


def test_playlist_download_uses_language_filter_instead_of_single_video_audio_format_id(window, tmp_path):
    archive = tmp_path / "archive.txt"
    output_template = str(tmp_path / "%(title)s.%(ext)s")

    window._ytdlp_bin = "yt-dlp"
    window._ffmpeg_bin = "ffmpeg"
    window._set_combo_by_data(window.audio_lang_combo, "ru")
    window._probe_media_info = lambda *args, **kwargs: {
        "formats": [
            {"format_id": "251-ru-first", "acodec": "opus", "vcodec": "none", "language": "ru-RU", "abr": 192, "language_preference": 10},
            {"format_id": "400", "acodec": "none", "vcodec": "av01.0.12M.08"},
        ]
    }

    cmd = window._build_command(
        window.MODE_PLAYLIST,
        "https://www.youtube.com/playlist?list=PLplaylist123",
        "",
        output_template,
        archive,
        platform_id="youtube",
        quality_override="max",
    )

    fmt_index = cmd.index("-f")
    assert cmd[fmt_index + 1] == "bv+ba[language=ru]/bv+ba/b"


def test_build_command_keeps_original_audio_unfiltered_and_uses_meta_for_original_subtitles(window, tmp_path):
    archive = tmp_path / "archive.txt"
    output_template = str(tmp_path / "%(title)s.%(ext)s")

    window._ytdlp_bin = "yt-dlp"
    window._ffmpeg_bin = "ffmpeg"
    window._set_combo_by_data(window.audio_lang_combo, "original")
    window._set_combo_by_data(window.meta_lang_combo, "en")
    window.chk_subs.setChecked(True)
    window._set_combo_by_data(window.sub_lang_combo, "original")
    window._probe_media_info = lambda *args, **kwargs: {
        "original_language": "en-US",
        "formats": [
            {"format_id": "251-en", "acodec": "opus", "vcodec": "none", "language": "en-US", "abr": 160, "language_preference": 10, "format_note": "English original (default)"},
            {"format_id": "140-es", "acodec": "mp4a.40.2", "vcodec": "none", "language": "es-ES", "abr": 128, "language_preference": 1},
        ],
        "subtitles": {"en": [{"ext": "vtt"}]},
        "automatic_captions": {},
    }

    cmd = window._build_command(
        window.MODE_AUDIO,
        "https://www.youtube.com/watch?v=originalaudio123",
        "",
        output_template,
        archive,
        platform_id="youtube",
        quality_override="max",
    )

    fmt_index = cmd.index("-f")
    assert cmd[fmt_index + 1] == "251-en"
    sub_lang_index = cmd.index("--sub-lang")
    assert cmd[sub_lang_index + 1] == "en"


def test_execution_readiness_requires_ffmpeg_for_video_merge(window, tmp_path):
    window._ytdlp_bin = "yt-dlp"
    window._ffmpeg_bin = "ffmpeg"
    window._binary_available = lambda candidate: candidate == "yt-dlp"

    readiness = window._evaluate_execution_readiness(
        params={
            "mode": window.MODE_VIDEO,
            "url": "https://www.youtube.com/watch?v=mergecheck123",
            "outdir": str(tmp_path),
            "cookies": "",
        },
        platform_id="youtube",
        quality_override="max",
    )

    assert any("FFmpeg" in issue and "audio track" in issue for issue in readiness["issues"])


def test_execution_readiness_preview_does_not_probe_media_info(window, tmp_path):
    window._ytdlp_bin = "yt-dlp"
    window._ffmpeg_bin = "ffmpeg"
    window._binary_available = lambda _candidate: True
    window._set_combo_by_data(window.audio_lang_combo, "ru")

    def _boom(*args, **kwargs):
        raise AssertionError("preview should not call _probe_media_info")

    window._probe_media_info = _boom

    readiness = window._evaluate_execution_readiness(
        params={
            "mode": window.MODE_VIDEO,
            "url": "https://www.youtube.com/watch?v=previewcheck123",
            "outdir": str(tmp_path),
            "cookies": "",
        },
        platform_id="youtube",
        quality_override="max",
        allow_blocking_probes=False,
    )

    assert readiness["issues"] == []


def test_build_command_playlist_does_not_probe_media_info_for_selected_audio_language(window, tmp_path):
    archive = tmp_path / "archive.txt"
    output_template = str(tmp_path / "%(title)s.%(ext)s")

    window._ytdlp_bin = "yt-dlp"
    window._ffmpeg_bin = "ffmpeg"
    window._binary_available = lambda _candidate: True
    window._set_combo_by_data(window.audio_lang_combo, "ru")

    def _boom(*args, **kwargs):
        raise AssertionError("playlist build should not call _probe_media_info")

    window._probe_media_info = _boom

    cmd = window._build_command(
        window.MODE_PLAYLIST,
        "https://www.youtube.com/playlist?list=PLdemo123",
        "",
        output_template,
        archive,
        platform_id="youtube",
        quality_override="max",
    )

    fmt_index = cmd.index("-f")
    assert cmd[fmt_index + 1] == "bv+ba[language=ru]/bv+ba/b"


def test_execution_readiness_blocks_unavailable_selected_audio_language(window, tmp_path):
    window._ytdlp_bin = "yt-dlp"
    window._ffmpeg_bin = "ffmpeg"
    window._binary_available = lambda _candidate: True
    window._set_combo_by_data(window.audio_lang_combo, "ru")
    window._probe_media_info = lambda *args, **kwargs: {
        "formats": [
            {"format_id": "140", "acodec": "mp4a.40.2", "vcodec": "none", "language": "en"},
            {"format_id": "299", "acodec": "none", "vcodec": "avc1.64002a"},
        ]
    }

    readiness = window._evaluate_execution_readiness(
        params={
            "mode": window.MODE_VIDEO,
            "url": "https://www.youtube.com/watch?v=audioavailability123",
            "outdir": str(tmp_path),
            "cookies": "",
        },
        platform_id="youtube",
        quality_override="max",
        allow_blocking_probes=True,
    )

    assert any("audio language" in issue.lower() for issue in readiness["issues"])


def test_media_probe_cache_key_changes_with_audio_language(window):
    window._binary_available = lambda _candidate: True
    window._node_bin = "node"
    window._set_combo_by_data(window.auth_combo, "none")
    window._set_combo_by_data(window.audio_lang_combo, "en")
    english_key = window._media_info_cache_key(
        "https://www.youtube.com/watch?v=cache123",
        cookies="",
        platform_id="youtube",
    )

    window._set_combo_by_data(window.audio_lang_combo, "ru")
    russian_key = window._media_info_cache_key(
        "https://www.youtube.com/watch?v=cache123",
        cookies="",
        platform_id="youtube",
    )

    assert english_key != russian_key


def test_build_command_ignores_stale_manual_format_from_other_url(window, tmp_path):
    archive = tmp_path / "archive.txt"
    output_template = str(tmp_path / "%(title)s.%(ext)s")

    window._ytdlp_bin = "yt-dlp"
    window._ffmpeg_bin = "ffmpeg"
    window._set_manual_format_selection(
        "18",
        fmt_kind="combined",
        url="https://www.youtube.com/watch?v=oldvideo123",
        mode=window.MODE_VIDEO,
        platform_id="youtube",
    )

    cmd = window._build_command(
        window.MODE_VIDEO,
        "https://www.youtube.com/watch?v=newvideo123",
        "",
        output_template,
        archive,
        platform_id="youtube",
        quality_override="max",
        allow_metadata_probe=False,
    )

    fmt_index = cmd.index("-f")
    assert cmd[fmt_index + 1] == "bv+ba/b"


def test_save_settings_does_not_persist_manual_format(window):
    window._set_manual_format_selection(
        "18",
        fmt_kind="combined",
        url="https://www.youtube.com/watch?v=stickyformat123",
        mode=window.MODE_VIDEO,
        platform_id="youtube",
    )

    window._save_settings()
    saved = json.loads(window.settings_manager.config_path.read_text(encoding="utf-8"))

    assert "manual_format_id" not in saved
    assert "manual_format_kind" not in saved
    assert "manual_format_context" not in saved


def test_app_main_bootstraps_with_mocked_dialogs(monkeypatch, tmp_path):
    import aura.app as app_module

    events = []

    class FakeApp:
        def __init__(self, argv):
            events.append(("app", tuple(argv)))

        def setApplicationName(self, name):
            events.append(("name", name))

        def setStyle(self, style):
            events.append(("style", style))

        def setWindowIcon(self, icon):
            events.append(("icon", bool(icon)))

        def exec(self):
            events.append(("exec", 0))
            return 0

    class FakeWindow:
        def __init__(self, lang, platform, theme_id):
            events.append(("window", lang, platform, theme_id))
            self._next_platform = None

        def show(self):
            events.append(("show", True))

    monkeypatch.setattr(app_module, "QApplication", FakeApp)
    monkeypatch.setattr(app_module, "LanguageSelector", lambda: types.SimpleNamespace(run=lambda: "en"))
    monkeypatch.setattr(app_module, "ThemeSelector", lambda lang: types.SimpleNamespace(run=lambda: "light"))
    monkeypatch.setattr(app_module, "PlatformSelector", lambda lang, theme_id: types.SimpleNamespace(run=lambda: "youtube"))
    monkeypatch.setattr(app_module, "AuraDownloader", FakeWindow)
    monkeypatch.setattr(app_module, "ask_config_location", lambda lang: tmp_path)
    monkeypatch.setattr(app_module, "get_theme_config", lambda: "light")
    monkeypatch.setattr(app_module, "get_settings_dir", lambda: Path(tmp_path))
    monkeypatch.setattr(app_module, "resource_path", lambda name: str(tmp_path / name))
    monkeypatch.setattr(app_module.os.path, "exists", lambda path: False)
    monkeypatch.setattr(app_module.sys, "argv", ["aura"])

    def fake_exit(code=0):
        raise SystemExit(code)

    monkeypatch.setattr(app_module.sys, "exit", fake_exit)

    with pytest.raises(SystemExit) as exc:
        app_module.main()

    assert exc.value.code == 0
    assert ("window", "en", "youtube", "light") in events
    assert ("show", True) in events
    assert ("exec", 0) in events


def test_theme_styles_avoid_transparent_surface_backgrounds():
    import aura.themes as themes_module
    from aura.dialogs.ui_chrome import build_dialog_chrome_qss

    for theme in themes_module.THEMES.values():
        colors = theme["colors"]
        app_qss = themes_module.build_qss(colors)
        dialog_qss = build_dialog_chrome_qss(colors)

        assert "background: transparent;" not in app_qss
        assert "rgba(" not in app_qss
        assert "background: transparent;" not in dialog_qss


def test_ask_config_location_allows_debug_mode_without_exiting(monkeypatch, tmp_path):
    import aura.app as app_module

    monkeypatch.setattr(app_module, "get_pointer_file", lambda: types.SimpleNamespace(exists=lambda: False))
    monkeypatch.setattr(app_module, "get_settings_dir", lambda: tmp_path / "debug-runtime")
    monkeypatch.setattr(app_module, "is_debug_mode", lambda: True)
    monkeypatch.setattr(
        app_module,
        "ConfigLocationDialog",
        lambda lang: types.SimpleNamespace(run=lambda: None),
    )

    result = app_module.ask_config_location("ru")

    assert result == tmp_path / "debug-runtime"
