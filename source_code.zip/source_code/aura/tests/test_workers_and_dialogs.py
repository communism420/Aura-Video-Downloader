import json
import subprocess
from types import SimpleNamespace

import pytest
from PySide6.QtGui import QCloseEvent

import aura.workers.base as workers_base_module
from aura.dialogs.preview_dialog import PreviewDialog
from aura.translations import get_translations
from aura.workers.formats import FormatListWorker
from aura.workers.playlist_entries import PlaylistEntriesWorker
from aura.workers.preview import PreviewWorker
from aura.workers.subscriptions import SubCheckWorker


class FakeCompletedPopen:
    def __init__(self, stdout="", stderr="", returncode=0):
        self._stdout = stdout
        self._stderr = stderr
        self.returncode = returncode

    def communicate(self, timeout=None):
        return self._stdout, self._stderr

    def poll(self):
        return self.returncode

    def wait(self, timeout=None):
        return self.returncode

    def terminate(self):
        self.returncode = self.returncode if self.returncode is not None else 1

    def kill(self):
        self.returncode = self.returncode if self.returncode is not None else 1


def test_format_list_worker_parses_languages_and_stream_kinds(monkeypatch):
    payload = {
        "formats": [
            {
                "format_id": "18",
                "ext": "mp4",
                "resolution": "640x360",
                "vcodec": "avc1.42001E",
                "acodec": "mp4a.40.2",
                "language": "en",
                "tbr": 512.0,
                "filesize": 10 * 1024 * 1024,
                "fps": 30,
                "format_note": "combined",
            },
            {
                "format_id": "137",
                "ext": "mp4",
                "height": 1080,
                "width": 1920,
                "vcodec": "avc1.640028",
                "acodec": "none",
                "tbr": 2048.0,
                "filesize_approx": 50 * 1024 * 1024,
                "fps": 30,
                "format_note": "video only",
            },
            {
                "format_id": "251",
                "ext": "webm",
                "vcodec": "none",
                "acodec": "opus",
                "language": "ja",
                "tbr": 160.0,
                "filesize": 4 * 1024 * 1024,
                "format_note": "audio only",
            },
        ],
        "subtitles": {"en": [{"ext": "vtt"}]},
        "automatic_captions": {"fr": [{"ext": "vtt"}]},
    }

    monkeypatch.setattr(
        workers_base_module.subprocess,
        "Popen",
        lambda *args, **kwargs: FakeCompletedPopen(stdout=json.dumps(payload), stderr="", returncode=0),
    )

    worker = FormatListWorker("https://example.com/watch?v=demo")
    received = []
    errors = []
    worker.result_signal.connect(lambda data: received.append(data))
    worker.error_signal.connect(lambda err: errors.append(err))

    worker.run()

    assert errors == []
    assert len(received) == 1
    data = received[0]
    assert data["audio_languages"] == ["en", "ja"]
    assert data["subtitle_languages"] == ["en"]
    assert data["auto_subtitle_languages"] == ["fr"]

    kinds = {item["id"]: item["kind"] for item in data["formats"]}
    assert kinds["18"] == "combined"
    assert kinds["137"] == "video-only"
    assert kinds["251"] == "audio-only"


def test_preview_dialog_displays_enriched_metadata(qapp):
    dialog = PreviewDialog(None, get_translations("en"))
    dialog.set_metadata(
        {
            "title": "Immersive demo",
            "duration": 125,
            "filesize": 15 * 1024 * 1024,
            "uploader": "Aura QA",
            "upload_date": "20260310",
            "view_count": 12345,
            "_aura_immersive": {"label": "360° / VR video", "projection": "equirectangular"},
            "_aura_audio_languages": ["en", "ja"],
            "_aura_subtitle_languages": ["en"],
            "_aura_auto_subtitle_languages": ["fr"],
        }
    )

    assert "360" in dialog._info_labels["media"].text()
    assert "English" in dialog._info_labels["audio_tracks"].text()
    assert "Japanese" in dialog._info_labels["audio_tracks"].text()
    subtitles = dialog._info_labels["subtitles"].text()
    assert "manual" in subtitles
    assert "auto" in subtitles


def test_preview_dialog_close_stops_thumbnail_worker(qapp):
    class FakeThumbWorker:
        def __init__(self):
            self.stop_calls = 0
            self.wait_calls = []
            self.terminate_calls = 0
            self.running = True

        def stop(self):
            self.stop_calls += 1

        def isRunning(self):
            return self.running

        def wait(self, timeout):
            self.wait_calls.append(timeout)

        def terminate(self):
            self.terminate_calls += 1
            self.running = False

    dialog = PreviewDialog(None, get_translations("en"))
    worker = FakeThumbWorker()
    dialog._thumb_worker = worker

    dialog.closeEvent(QCloseEvent())

    assert dialog._thumb_worker is None
    assert worker.stop_calls == 1
    assert worker.wait_calls
    assert worker.terminate_calls == 1


def test_preview_worker_emits_json_payload(monkeypatch):
    payload = {"title": "Demo preview", "id": "abc123"}

    monkeypatch.setattr(
        workers_base_module.subprocess,
        "Popen",
        lambda *args, **kwargs: FakeCompletedPopen(stdout=json.dumps(payload), stderr="", returncode=0),
    )

    worker = PreviewWorker("https://example.com/watch?v=demo")
    received = []
    errors = []
    worker.result_signal.connect(lambda data: received.append(data))
    worker.error_signal.connect(lambda err: errors.append(err))

    worker.run()

    assert errors == []
    assert received == [payload]


def test_playlist_entries_worker_emits_flat_item_list(monkeypatch):
    payload = {
        "title": "Demo playlist",
        "entries": [
            {"title": "Episode 1", "playlist_index": 1, "duration": 61, "uploader": "Aura QA", "webpage_url": "https://example.com/1"},
            {"title": "Episode 2", "playlist_index": 2, "duration": 125, "channel": "Aura QA", "url": "https://example.com/2"},
        ],
    }

    monkeypatch.setattr(
        workers_base_module.subprocess,
        "Popen",
        lambda *args, **kwargs: FakeCompletedPopen(stdout=json.dumps(payload), stderr="", returncode=0),
    )

    worker = PlaylistEntriesWorker("https://example.com/playlist")
    received = []
    errors = []
    worker.result_signal.connect(lambda data: received.append(data))
    worker.error_signal.connect(lambda err: errors.append(err))

    worker.run()

    assert errors == []
    assert received[0]["title"] == "Demo playlist"
    assert received[0]["total"] == 2
    assert received[0]["entries"][0]["index"] == 1
    assert received[0]["entries"][1]["uploader"] == "Aura QA"


@pytest.mark.parametrize(
    ("result", "expected_fragment"),
    [
        (SimpleNamespace(returncode=1, stdout="captcha required", stderr=""), "captcha required"),
        (SimpleNamespace(returncode=0, stdout="<html>blocked</html>", stderr=""), "blocked"),
    ],
)
def test_preview_worker_emits_useful_error_text(monkeypatch, result, expected_fragment):
    monkeypatch.setattr(
        workers_base_module.subprocess,
        "Popen",
        lambda *args, **kwargs: FakeCompletedPopen(
            stdout=result.stdout,
            stderr=result.stderr,
            returncode=result.returncode,
        ),
    )

    worker = PreviewWorker("https://example.com/watch?v=demo")
    received = []
    errors = []
    worker.result_signal.connect(lambda data: received.append(data))
    worker.error_signal.connect(lambda err: errors.append(err))

    worker.run()

    assert received == []
    assert len(errors) == 1
    assert expected_fragment in errors[0]


def test_subscription_worker_collects_new_urls(monkeypatch):
    payload = "\n".join(
        [
            json.dumps({"url": "https://example.com/watch?v=1"}),
            json.dumps({"webpage_url": "https://example.com/watch?v=2"}),
            "not-json",
            json.dumps({"original_url": "https://example.com/watch?v=3"}),
        ]
    )

    monkeypatch.setattr(
        workers_base_module.subprocess,
        "Popen",
        lambda *args, **kwargs: FakeCompletedPopen(stdout=payload, stderr="", returncode=0),
    )

    worker = SubCheckWorker(7, "https://example.com/channel/demo", max_new=5)
    received = []
    errors = []
    worker.result_signal.connect(lambda sub_id, urls: received.append((sub_id, urls)))
    worker.error_signal.connect(lambda sub_id, err: errors.append((sub_id, err)))

    worker.run()

    assert errors == []
    assert received == [
        (
            7,
            [
                "https://example.com/watch?v=1",
                "https://example.com/watch?v=2",
                "https://example.com/watch?v=3",
            ],
        )
    ]
