import json
from pathlib import Path

import pytest

import aura.main_window as main_window_module
from aura.dialogs.batch_links_dialog import BatchLinksDialog
from aura.platforms import PLATFORM_CONFIGS
from PySide6.QtCore import QCoreApplication, qInstallMessageHandler
from PySide6.QtGui import QFontMetrics
from PySide6.QtWidgets import QLabel


def test_main_window_startup_does_not_emit_tab_order_warnings(qapp, isolated_settings_dir):
    messages = []

    def handler(_msg_type, _context, message):
        messages.append(message)

    previous_handler = qInstallMessageHandler(handler)
    win = None
    try:
        win = main_window_module.AuraDownloader(lang="en", platform="youtube", theme_id="light")
        win.show()
        qapp.processEvents()
        QCoreApplication.sendPostedEvents(None, 0)
        qapp.processEvents()
    finally:
        qInstallMessageHandler(previous_handler)
        if win is not None:
            win.close()
            qapp.processEvents()
            QCoreApplication.sendPostedEvents(None, 0)
            win.deleteLater()
            qapp.processEvents()

    assert not any("QWidget::setTabOrder" in message for message in messages)


def test_main_window_builds_and_shows_dubbed_audio_followups(window, tmp_path, monkeypatch):
    window._binary_available = lambda _path: True
    window._ytdlp_bin = "yt-dlp"
    window._ffmpeg_bin = "ffmpeg"

    outdir = tmp_path / "downloads"
    outdir.mkdir()

    window.url_input.setText("https://www.youtube.com/watch?v=demo123")
    window.outdir_input.setText(str(outdir))
    window.chk_dubbed_audio.setChecked(True)
    window._set_combo_by_data(window.dubbed_audio_mode_combo, "custom")
    window.dubbed_audio_languages_input.setText("en, ja")

    window._refresh_execution_blueprint()
    preview = window.command_preview_box.toPlainText()

    assert "Draft command" in preview
    assert "All available dubbed audio tracks will be detected and exported after the main video download." in preview
    assert "--audio-format" not in preview


def test_main_window_exposes_codec_policy_and_seven_parallel_slots(window):
    assert window.video_codec_combo.count() == 3
    assert window.playback_target_combo.count() == 6
    assert [window.concurrent_combo.itemText(i) for i in range(window.concurrent_combo.count())] == [
        "1", "2", "3", "4", "5", "6", "7"
    ]


def test_visual_shortcuts_and_status_cards_are_built(window):
    assert set(window._sidebar_quick_buttons) == {"start", "preview", "formats", "folder"}
    assert window.sidebar_queue_value.text() == "0"
    assert window.sidebar_history_value.text() == "0"
    assert window.hero_subscriptions_value.text() == "0"
    assert window.hero_presets_value.text() == "0"
    assert window._sidebar_quick_buttons["preview"].isEnabled() is False
    assert window._sidebar_quick_buttons["formats"].isEnabled() is False

    window.url_input.setText("https://www.youtube.com/watch?v=demo123")

    assert window._sidebar_quick_buttons["preview"].isEnabled() is True
    assert window._sidebar_quick_buttons["formats"].isEnabled() is True


def test_sidebar_insight_labels_use_compact_copy_in_narrow_sidebar(window, qapp):
    window.show()
    window.resize(1280, 820)
    qapp.processEvents()
    QCoreApplication.sendPostedEvents(None, 0)
    qapp.processEvents()

    assert window._sidebar_insight_labels["queue"].text() == "Queue"
    assert window._sidebar_insight_labels["history"].text() == "History"


def test_hero_hides_theme_chip_and_idle_smart_meta_for_standard_width(window, qapp):
    window.show()
    window.resize(1280, 820)
    qapp.processEvents()
    QCoreApplication.sendPostedEvents(None, 0)
    qapp.processEvents()

    assert window.hero_theme_chip.isVisible() is False
    assert window.hero_smart_meta.isVisible() is False
    assert "Preset" in window.hero_smart_btn.text()


def test_quick_commands_use_single_column_with_full_labels(window, qapp):
    window.show()
    window.resize(1280, 820)
    qapp.processEvents()
    QCoreApplication.sendPostedEvents(None, 0)
    qapp.processEvents()

    xs = {button.geometry().x() for button in window._sidebar_quick_buttons.values()}
    assert len(xs) == 1

    for button in window._sidebar_quick_buttons.values():
        fm = QFontMetrics(button.font())
        assert button.width() >= fm.horizontalAdvance(button.text()) + 30


def test_quick_commands_return_to_two_columns_in_compact_mode(window, qapp):
    window.show()
    window.resize(940, 820)
    qapp.processEvents()
    QCoreApplication.sendPostedEvents(None, 0)
    qapp.processEvents()

    xs = {button.geometry().x() for button in window._sidebar_quick_buttons.values()}
    assert len(xs) == 2


def test_sidebar_page_buttons_keep_text_height_in_wide_mode(window, qapp):
    window.show()
    window.resize(1280, 820)
    qapp.processEvents()
    QCoreApplication.sendPostedEvents(None, 0)
    qapp.processEvents()

    for button in window._sidebar_page_buttons.values():
        fm = QFontMetrics(button.font())
        assert button.height() >= fm.height() + 12


def test_sidebar_page_buttons_use_compact_grid_when_sidebar_is_narrow(window, qapp):
    window.show()
    window.resize(1280, 820)
    qapp.processEvents()
    QCoreApplication.sendPostedEvents(None, 0)
    qapp.processEvents()

    xs = {button.geometry().x() for button in window._sidebar_page_buttons.values()}
    assert len(xs) == 2
    assert window._sidebar_page_buttons["automation"].text() in {"Auto", "Авто"}


def test_compact_window_responsive_layouts_activate_below_previous_minimum(window, qapp):
    window.show()
    window.url_input.setText("https://www.youtube.com/watch?v=demo123")
    window.resize(940, 820)
    qapp.processEvents()
    QCoreApplication.sendPostedEvents(None, 0)
    qapp.processEvents()

    assert window.width() == 940
    assert window.sidebar_panel.maximumWidth() <= 214
    assert window.toolbar_state_chip.isVisible() is False
    assert window._workspace_subnav_layout.direction() == main_window_module.QBoxLayout.TopToBottom
    assert "VIDEO" in window.start_btn.text()


def test_compact_labels_do_not_blank_sidebar_or_pause_button(qapp, isolated_settings_dir):
    win = main_window_module.AuraDownloader(lang="ru", platform="youtube", theme_id="light")
    win._deps_startup_dialog_shown = True
    try:
        win.show()
        win.url_input.setText("https://www.youtube.com/watch?v=demo123")
        win.resize(940, 820)
        qapp.processEvents()
        QCoreApplication.sendPostedEvents(None, 0)
        qapp.processEvents()

        assert win.pause_btn.text() == "Пауза"
        assert all(button.text().strip() for button in win._sidebar_page_buttons.values())
        assert all(button.text().strip() for button in win._sidebar_quick_buttons.values())
    finally:
        win.close()
        qapp.processEvents()
        QCoreApplication.sendPostedEvents(None, 0)
        win.deleteLater()
        qapp.processEvents()


def test_video_mode_uses_audio_track_label_for_setup_audio_page(window):
    window._activate_workspace_category("setup")

    assert window._workspace_subpage_buttons["setup_audio"][0].text() == "Audio Track"
    assert window._workspace_subpage_buttons["setup_dubbed"][0].text() == "Extra Audio"


def test_audio_mode_hides_video_container_controls_and_updates_audio_hint(window):
    window._set_radio_group(window.mode_buttons, "mode_value", window.MODE_AUDIO)
    window._on_mode_change()

    assert window.container_combo.isHidden()
    assert window.video_codec_combo.isHidden()
    assert window.playback_target_combo.isHidden()
    assert "extract" in window.audio_lang_hint_label.text().lower()


def test_all_audio_tracks_temporarily_forces_mkv_and_restores_previous_container(window):
    mp4_index = window.container_combo.findData("mp4")
    mkv_index = window.container_combo.findData("mkv")
    mp4_item = window.container_combo.model().item(mp4_index)

    window.container_combo.setCurrentIndex(mp4_index)
    window.chk_all_audio_tracks.setChecked(True)

    assert window.container_combo.currentData() == "mkv"
    assert mp4_item.isEnabled() is False

    window.chk_all_audio_tracks.setChecked(False)

    assert window.container_combo.currentData() == "mp4"
    assert mp4_item.isEnabled() is True
    assert mkv_index >= 0


def test_playback_target_disables_manual_codec_choice_and_updates_hint(window):
    window._set_combo_by_data(window.playback_target_combo, "android")
    window._refresh_download_ux_state()

    assert window.video_codec_combo.isEnabled() is False
    assert "playback target is active" in window.compatibility_hint_label.text().lower()


def test_audio_mode_hides_irrelevant_setup_pages_and_moves_to_audio_page(window):
    window._activate_workspace_category("setup")
    window._activate_workspace_page("setup_video")

    window._set_radio_group(window.mode_buttons, "mode_value", window.MODE_AUDIO)
    window._on_mode_change()

    assert set(window._workspace_subpage_buttons) == {"setup_source", "setup_audio"}
    assert window._workspace_page_key_by_index(window.workspace_tabs.currentIndex()) == "setup_audio"
    assert "EXTRACT AUDIO" in window.start_btn.text()


def test_search_mode_updates_primary_action_label(window):
    window._set_radio_group(window.mode_buttons, "mode_value", window.MODE_SEARCH)
    window._on_mode_change()

    assert "DOWNLOAD RESULTS" in window.start_btn.text()


def test_primary_actions_are_disabled_until_they_have_useful_context(window):
    window.url_input.clear()
    window._refresh_primary_action_state()

    assert window.preview_btn.isEnabled() is False
    assert window.format_panel_btn.isEnabled() is False
    assert window.similar_btn.isEnabled() is False

    window.url_input.setText("https://www.youtube.com/watch?v=demo123")

    assert window.preview_btn.isEnabled() is True
    assert window.format_panel_btn.isEnabled() is True
    assert window.similar_btn.isEnabled() is True

    window._set_radio_group(window.mode_buttons, "mode_value", window.MODE_AUDIO)
    window._on_mode_change()

    assert window.similar_btn.isEnabled() is False


def test_platform_without_audio_languages_hides_extra_setup_pages(qapp, isolated_settings_dir):
    win = main_window_module.AuraDownloader(lang="en", platform="vimeo", theme_id="light")
    win._deps_startup_dialog_shown = True
    try:
        win._activate_workspace_category("setup")

        assert set(win._workspace_subpage_buttons) == {"setup_source", "setup_video"}
        assert "DOWNLOAD VIDEO" in win.start_btn.text()
    finally:
        win.close()
        qapp.processEvents()
        QCoreApplication.sendPostedEvents(None, 0)
        win.deleteLater()
        qapp.processEvents()


def test_find_similar_media_opens_current_page_for_recommendations(window, monkeypatch):
    captured = {}

    class FakeDialog:
        def __init__(self, *_args, **kwargs):
            captured["start_url"] = kwargs.get("start_url")
            self.selected_url = ""
            self.download_requested = False

        def exec(self):
            return main_window_module.QDialog.Rejected

    monkeypatch.setattr(main_window_module, "_HAS_WEBENGINE", True)
    monkeypatch.setattr(main_window_module, "DiscoveryBrowserDialog", FakeDialog)
    monkeypatch.setattr(window, "_get_shared_browser_profile", lambda: object())
    monkeypatch.setattr(
        window,
        "_probe_media_info",
        lambda *args, **kwargs: {"title": "Demo title", "uploader": "Demo channel"},
    )
    window.url_input.setText("https://www.youtube.com/watch?v=demo123")

    window._find_similar_media()

    assert captured["start_url"] == "https://www.youtube.com/watch?v=demo123"


def test_find_similar_media_skips_metadata_probe_when_opening_direct_page(window, monkeypatch):
    captured = {}

    class FakeDialog:
        def __init__(self, *_args, **kwargs):
            captured["start_url"] = kwargs.get("start_url")
            self.selected_url = ""
            self.download_requested = False

        def exec(self):
            return main_window_module.QDialog.Rejected

    monkeypatch.setattr(main_window_module, "_HAS_WEBENGINE", True)
    monkeypatch.setattr(main_window_module, "DiscoveryBrowserDialog", FakeDialog)
    monkeypatch.setattr(window, "_get_shared_browser_profile", lambda: object())
    monkeypatch.setattr(
        window,
        "_probe_media_info",
        lambda *args, **kwargs: (_ for _ in ()).throw(AssertionError("probe should not run")),
    )
    window.url_input.setText("https://www.youtube.com/watch?v=demo123")

    window._find_similar_media()

    assert captured["start_url"] == "https://www.youtube.com/watch?v=demo123"


def test_write_m3u_manifest_sorts_entries_and_uses_playlist_folder_name(window, tmp_path):
    playlist_dir = tmp_path / "Weekend Playlist"
    playlist_dir.mkdir()
    second = playlist_dir / "02 - Episode.mp4"
    first = playlist_dir / "01 - Intro.mp4"
    second.write_text("b", encoding="utf-8")
    first.write_text("a", encoding="utf-8")

    manifest_path = window._write_m3u_manifest([str(second), str(first), str(first)])

    assert manifest_path == playlist_dir / "Weekend Playlist.m3u"
    assert manifest_path.read_text(encoding="utf-8").splitlines() == [
        "#EXTM3U",
        "#PLAYLIST:Weekend Playlist",
        "01 - Intro.mp4",
        "02 - Episode.mp4",
    ]


def test_should_generate_m3u_only_for_multi_item_downloads(window, tmp_path):
    window.chk_generate_m3u.setChecked(True)

    assert window._should_generate_m3u(window.MODE_PLAYLIST, {}, ["a", "b"]) is True
    assert window._should_generate_m3u(window.MODE_VIDEO, {}, ["a", "b"]) is False
    assert window._should_generate_m3u(window.MODE_AUDIO, {"audio_source": window.AUDIO_SOURCE_PLAYLIST}, ["a", "b"]) is True
    assert window._should_generate_m3u(window.MODE_AUDIO, {"audio_source": window.AUDIO_SOURCE_VIDEO}, ["a", "b"]) is False


def test_start_download_request_delegates_blocking_prep_to_background_worker(window, tmp_path, monkeypatch):
    captured = {}
    captured_commands = []
    outdir = tmp_path / "downloads"
    outdir.mkdir()

    window._binary_available = lambda _path: True
    window._ytdlp_bin = "yt-dlp"
    window._ffmpeg_bin = "ffmpeg"
    window.url_input.setText("https://www.youtube.com/watch?v=immersive123")
    window.outdir_input.setText(str(outdir))
    window.container_combo.setCurrentIndex(1)  # MP4, should switch to MKV
    window.chk_dubbed_audio.setChecked(True)
    window._set_combo_by_data(window.dubbed_audio_mode_combo, "all")

    monkeypatch.setattr(window, "_begin_download_preparation", lambda context: captured.setdefault("context", context) and True)
    monkeypatch.setattr(window, "_run_worker", lambda cmd: captured_commands.append(cmd))
    monkeypatch.setattr(window, "_save_settings", lambda: None)
    monkeypatch.setattr(window.db, "save_session", lambda entries: None)

    started = window._start_download_request(
        {
            "mode": window.MODE_VIDEO,
            "url": window.url_input.text(),
            "cookies": "",
            "outdir": window.outdir_input.text(),
        },
        platform_id="youtube",
        quality_override="max",
        save_settings=False,
        allow_queue=False,
    )

    assert started is True
    assert captured_commands == []
    assert captured["context"]["needs_probe"] is True
    assert captured["context"]["mode"] == window.MODE_VIDEO


def test_start_button_playlist_does_not_probe_media_info_before_parallel_launch(window, tmp_path, monkeypatch):
    captured = {}
    outdir = tmp_path / "downloads"
    outdir.mkdir()

    window._binary_available = lambda _path: True
    window._ytdlp_bin = "yt-dlp"
    window._ffmpeg_bin = "ffmpeg"
    window._set_radio_group(window.mode_buttons, "mode_value", window.MODE_PLAYLIST)
    window._on_mode_change()
    window.url_input.setText("https://www.youtube.com/playlist?list=PLdemo123")
    window.outdir_input.setText(str(outdir))
    window._set_combo_by_data(window.audio_lang_combo, "ru")

    def _boom(*args, **kwargs):
        raise AssertionError("playlist start should not call _probe_media_info")

    monkeypatch.setattr(window, "_probe_media_info", _boom)
    monkeypatch.setattr(window, "_download_parallel", lambda *args, **kwargs: captured.setdefault("parallel", True))
    monkeypatch.setattr(window, "_run_worker", lambda cmd: captured.setdefault("worker", list(cmd)))
    monkeypatch.setattr(window, "_set_live_command_preview", lambda *args, **kwargs: None)
    monkeypatch.setattr(window, "_save_settings", lambda: None)
    monkeypatch.setattr(window.db, "save_session", lambda entries: None)

    window.start_btn.click()

    assert captured.get("parallel") is True or bool(captured.get("worker"))


def test_continue_start_download_request_uses_audio_runtime_fallback_in_final_command(window, tmp_path, monkeypatch):
    captured = {}
    outdir = tmp_path / "downloads"
    outdir.mkdir()

    window._binary_available = lambda _path: True
    window._ytdlp_bin = "yt-dlp"
    window._ffmpeg_bin = "ffmpeg"
    window._node_bin = "node"
    window.url_input.setText("https://www.youtube.com/watch?v=ruaudio123")
    window.outdir_input.setText(str(outdir))
    window._set_combo_by_data(window.audio_lang_combo, "ru")
    window._set_combo_by_data(window.auth_combo, "none")

    monkeypatch.setattr(window, "_set_live_command_preview", lambda *args, **kwargs: None)
    monkeypatch.setattr(window, "_run_worker", lambda cmd: captured.setdefault("cmd", list(cmd)))
    monkeypatch.setattr(window, "_save_settings", lambda: None)
    monkeypatch.setattr(window.db, "save_session", lambda entries: None)

    started = window._continue_start_download_request(
        {
            "mode": window.MODE_VIDEO,
            "url": window.url_input.text(),
            "cookies": "",
            "outdir": window.outdir_input.text(),
        },
        platform_id="youtube",
        quality_override="max",
        save_settings=False,
        media_info={
            "formats": [
                {"format_id": "251-ru", "acodec": "opus", "vcodec": "none", "language": "ru-RU"},
                {"format_id": "401", "acodec": "none", "vcodec": "av01.0.12M.08"},
            ]
        },
        current_settings={
            **window._collect_runtime_settings_snapshot(),
            "auth_method": "edge",
        },
        used_audio_runtime_fallback=True,
    )

    assert started is True
    assert "--cookies-from-browser" in captured["cmd"]
    assert "edge" in captured["cmd"]


def test_continue_start_download_request_uses_load_info_json_for_youtube_translated_combo_stream(window, tmp_path, monkeypatch):
    captured = {}
    outdir = tmp_path / "downloads"
    outdir.mkdir()
    info_json = tmp_path / "translated.info.json"
    info_json.write_text("{}", encoding="utf-8")

    window._binary_available = lambda _path: True
    window._ytdlp_bin = "yt-dlp"
    window._ffmpeg_bin = "ffmpeg"
    window._node_bin = "node"
    window.url_input.setText("https://www.youtube.com/watch?v=translatedcombo123")
    window.outdir_input.setText(str(outdir))
    window._set_combo_by_data(window.audio_lang_combo, "ru")
    window._set_combo_by_data(window.auth_combo, "none")

    monkeypatch.setattr(window, "_create_temporary_info_json", lambda *args, **kwargs: info_json)
    monkeypatch.setattr(window, "_set_live_command_preview", lambda *args, **kwargs: None)
    monkeypatch.setattr(window, "_run_worker", lambda cmd: captured.setdefault("cmd", list(cmd)))
    monkeypatch.setattr(window, "_save_settings", lambda: None)
    monkeypatch.setattr(window.db, "save_session", lambda entries: None)

    started = window._continue_start_download_request(
        {
            "mode": window.MODE_VIDEO,
            "url": window.url_input.text(),
            "cookies": "",
            "outdir": window.outdir_input.text(),
        },
        platform_id="youtube",
        quality_override="max",
        save_settings=False,
        media_info={
            "formats": [
                {"format_id": "96-22", "acodec": "mp4a.40.2", "vcodec": "avc1.640028", "language": "ru", "height": 1080, "fps": 30},
                {"format_id": "95-12", "acodec": "mp4a.40.2", "vcodec": "avc1.4D401F", "language": "en", "height": 720, "fps": 30},
            ]
        },
        current_settings={
            **window._collect_runtime_settings_snapshot(),
            "auth_method": "firefox:C:/Waterfox/Profile",
        },
        used_audio_runtime_fallback=True,
    )

    assert started is True
    assert "--load-info-json" in captured["cmd"]
    assert str(info_json) in captured["cmd"]
    assert "96-22" in captured["cmd"]
    assert window._active_temp_download_files == [str(info_json)]


def test_continue_start_download_request_detects_immersive_video_and_prepares_followups(window, tmp_path, monkeypatch):
    captured_commands = []
    outdir = tmp_path / "downloads"
    outdir.mkdir()

    window._binary_available = lambda _path: True
    window._ytdlp_bin = "yt-dlp"
    window._ffmpeg_bin = "ffmpeg"
    window.url_input.setText("https://www.youtube.com/watch?v=immersive123")
    window.outdir_input.setText(str(outdir))
    window.container_combo.setCurrentIndex(1)
    window.chk_dubbed_audio.setChecked(True)
    window._set_combo_by_data(window.dubbed_audio_mode_combo, "all")

    monkeypatch.setattr(window, "_set_live_command_preview", lambda *args, **kwargs: None)
    monkeypatch.setattr(window, "_run_worker", lambda cmd: captured_commands.append(cmd))
    monkeypatch.setattr(window, "_save_settings", lambda: None)
    monkeypatch.setattr(window.db, "save_session", lambda entries: None)

    started = window._continue_start_download_request(
        {
            "mode": window.MODE_VIDEO,
            "url": window.url_input.text(),
            "cookies": "",
            "outdir": window.outdir_input.text(),
        },
        platform_id="youtube",
        quality_override="max",
        save_settings=False,
        media_info={
            "title": "VR sample",
            "projection": "equirectangular",
            "formats": [
                {"acodec": "mp4a.40.2", "language": "en"},
                {"acodec": "mp4a.40.2", "language": "ja"},
            ],
        },
        current_settings=window._collect_runtime_settings_snapshot(),
    )

    assert started is True
    assert captured_commands, "main yt-dlp command was not prepared"
    assert window.container_combo.currentIndex() == 2
    assert [task["language"] for task in window._pending_followup_tasks] == ["en", "ja"]


def test_cleanup_temp_download_files_removes_generated_info_json(window, tmp_path):
    info_json = tmp_path / "translated.info.json"
    info_json.write_text("{}", encoding="utf-8")
    window._active_temp_download_files = [str(info_json)]

    window._cleanup_temp_download_files()

    assert not info_json.exists()
    assert window._active_temp_download_files == []


def test_stop_download_cancels_active_preparation_worker(window, monkeypatch):
    class FakePrepWorker:
        def __init__(self):
            self.stopped = False

        def isRunning(self):
            return True

        def stop(self):
            self.stopped = True

    prep_worker = FakePrepWorker()
    window._download_prep_worker = prep_worker
    monkeypatch.setattr(main_window_module.QMessageBox, "question", lambda *args, **kwargs: main_window_module.QMessageBox.Yes)

    window.stop_download()

    assert prep_worker.stopped is True
    assert window._download_prep_worker is None


def test_detect_immersive_profile_covers_360_and_3d(window):
    immersive = window._detect_immersive_profile(
        {
            "title": "3D 360 sample",
            "projection": "equirectangular",
            "formats": [{"format_note": "stereoscopic side-by-side"}],
        }
    )

    assert immersive["is_360"] is True
    assert immersive["is_3d"] is True
    assert immersive["is_immersive"] is True


def test_pause_resume_requeues_active_download(window):
    class FakeWorker:
        def __init__(self):
            self.stopped = False

        def stop(self):
            self.stopped = True

        def isRunning(self):
            return True

    window.worker = FakeWorker()
    window._active_download_url = "https://www.youtube.com/watch?v=demo123"
    window._active_download_mode = window.MODE_PLAYLIST
    window._active_download_platform = "youtube"
    window._active_download_quality = "max"
    window._active_download_priority = main_window_module.Priority.HIGH
    window._active_runtime_settings = {"outdir": "C:/Downloads"}
    window._active_download_playlist_items = [1, 2, 3]

    window._pause_downloads()

    assert window._downloads_paused is True
    queued = window._download_queue.all_entries()
    assert len(queued) == 1
    assert queued[0].status == "paused"
    assert queued[0].options["playlist_items"] == [1, 2, 3]
    assert window.worker.stopped is True

    window._resume_downloads()

    assert window._downloads_paused is False
    assert window._download_queue.all_entries()[0].status == "pending"
    window.worker = None


def test_manual_selection_passes_selected_playlist_items(window, monkeypatch):
    captured = {}

    class FakePicker:
        def __init__(self, *_args, **_kwargs):
            pass

        def set_entries(self, entries, source_title=""):
            captured["entries"] = entries
            captured["source_title"] = source_title

        def exec(self):
            return main_window_module.QDialog.Accepted

        def selected_indices(self):
            return [2, 4]

    monkeypatch.setattr(main_window_module, "ItemPickerDialog", FakePicker)
    monkeypatch.setattr(
        window,
        "_start_download_request",
        lambda params, **kwargs: captured.update({"params": params, "kwargs": kwargs}),
    )
    window._manual_selection_context = {
        "params": {"mode": window.MODE_PLAYLIST, "url": "https://example.com/playlist", "cookies": "", "outdir": "C:/Downloads"},
        "platform_id": "youtube",
        "quality_override": "max",
        "save_settings": False,
        "allow_queue": True,
    }

    window._on_manual_selection_loaded(
        {
            "title": "Manual playlist",
            "entries": [
                {"index": 1, "title": "One"},
                {"index": 2, "title": "Two"},
                {"index": 3, "title": "Three"},
                {"index": 4, "title": "Four"},
            ],
        }
    )

    assert captured["source_title"] == "Manual playlist"
    assert captured["kwargs"]["playlist_items"] == [2, 4]
    assert captured["kwargs"]["manual_selection_resolved"] is True


def test_batch_links_dialog_parser_supports_plaintext_and_csv():
    parsed = BatchLinksDialog.parse_links(
        """
        # comment
        https://example.com/watch?v=1
        https://example.com/watch?v=2,Title
        https://example.com/watch?v=1
        """
    )

    assert parsed == [
        "https://example.com/watch?v=1",
        "https://example.com/watch?v=2",
    ]


def test_queue_urls_for_download_stores_runtime_settings(window, tmp_path):
    outdir = tmp_path / "downloads"
    outdir.mkdir()
    window.outdir_input.setText(str(outdir))
    window.proxy_input.setText("socks5://127.0.0.1:1080")
    window.chk_manual_selection.setChecked(True)
    window._downloads_paused = True

    added = window._queue_urls_for_download(
        ["https://www.youtube.com/watch?v=1", "https://www.youtube.com/watch?v=2"]
    )

    assert added == 2
    entries = window._download_queue.all_entries()
    assert len(entries) == 2
    assert entries[0].options["settings"]["outdir"] == str(outdir)
    assert entries[0].options["settings"]["proxy"] == "socks5://127.0.0.1:1080"
    assert entries[0].options["settings"]["manual_item_selection"] is True


def test_subscription_runtime_settings_uses_saved_preset(window, tmp_path):
    outdir = tmp_path / "preset-downloads"
    outdir.mkdir()
    window._save_presets_for_platform(
        "youtube",
        {
            "Playlist preset": {
                "mode": window.MODE_PLAYLIST,
                "video_quality": "720p",
                "outdir": str(outdir),
            }
        },
    )

    payload = window._build_subscription_preset_payload("youtube", "Playlist preset")
    label, _ = window._subscription_preset_info({"preset_json": payload})
    settings = window._subscription_runtime_settings({"platform": "youtube", "preset_json": payload})

    assert label == "Playlist preset"
    assert settings["mode"] == window.MODE_PLAYLIST
    assert settings["video_quality"] == "720p"
    assert settings["outdir"] == str(outdir)


def test_detect_subscription_target_kind_distinguishes_playlist_urls(window):
    assert window._detect_subscription_target_kind("https://www.youtube.com/playlist?list=demo") == "playlist"
    assert window._detect_subscription_target_kind("https://soundcloud.com/artist/sets/demo") == "playlist"
    assert window._detect_subscription_target_kind("https://www.youtube.com/@demo/videos") == "channel"


def test_platform_configs_cover_bilibili_tv_and_naver_blog_domains():
    bilibili = PLATFORM_CONFIGS["bilibili"]
    naver = PLATFORM_CONFIGS["naver"]

    assert "bilibili.tv" in bilibili["domains"]
    assert bilibili["search_url"].startswith("https://search.bilibili.com/")
    assert "blog.naver.com" in naver["domains"]
    assert naver["search_url"].startswith("https://search.naver.com/")


def test_subscription_result_normalizes_collection_presets_and_keeps_playlist_metadata(window, tmp_path, monkeypatch):
    outdir = tmp_path / "subscription-downloads"
    outdir.mkdir()
    monkeypatch.setattr(window, "_persist_session_snapshot", lambda: None)
    monkeypatch.setattr(window, "_sub_process_download_queue", lambda: None)

    window.db.add_subscription(
        "youtube",
        "https://www.youtube.com/playlist?list=demo",
        target_kind="playlist",
        preset_json=json.dumps(
            {
                "label": "Playlist preset",
                "data": {
                    "mode": window.MODE_PLAYLIST,
                    "audio_source": window.AUDIO_SOURCE_PLAYLIST,
                    "outdir": str(outdir),
                },
            }
        ),
    )
    sub = window.db.get_subscriptions()[0]

    window._on_sub_check_result(sub["id"], ["https://www.youtube.com/watch?v=demo123"])

    entry = window._download_queue.all_entries()[0]
    assert entry.mode == window.MODE_VIDEO
    assert entry.options["settings"]["mode"] == window.MODE_VIDEO
    assert entry.options["subscription"]["id"] == sub["id"]
    assert entry.options["subscription"]["target_kind"] == "playlist"
    assert entry.options["subscription"]["url"] == "https://www.youtube.com/playlist?list=demo"


def test_write_m3u_manifest_uses_relative_paths_and_natural_order(window, tmp_path):
    root = tmp_path / "Playlist Folder"
    root.mkdir()
    second = root / "02 Track.mp4"
    first = root / "01 Track.mp4"
    first.write_text("a", encoding="utf-8")
    second.write_text("b", encoding="utf-8")

    manifest = window._write_m3u_manifest([str(second), str(first)])

    assert manifest == root / "Playlist Folder.m3u"
    lines = manifest.read_text(encoding="utf-8").splitlines()
    assert lines[0] == "#EXTM3U"
    assert lines[1] == "#PLAYLIST:Playlist Folder"
    assert lines[2:] == ["01 Track.mp4", "02 Track.mp4"]


def test_download_finished_creates_m3u_for_playlist_mode(window, tmp_path, monkeypatch):
    playlist_dir = tmp_path / "My Playlist"
    playlist_dir.mkdir()
    file_one = playlist_dir / "01 First.mp4"
    file_two = playlist_dir / "02 Second.mp4"
    file_one.write_text("1", encoding="utf-8")
    file_two.write_text("2", encoding="utf-8")

    window.chk_generate_m3u.setChecked(True)
    window._active_download_mode = window.MODE_PLAYLIST
    window._active_runtime_settings = {"mode": window.MODE_PLAYLIST}
    window._completed_output_paths = [str(file_two), str(file_one)]
    window._last_destination_path = str(file_two)
    window.stop_event.clear()
    window._pending_followup_tasks = []
    window._parallel_state = {}
    monkeypatch.setattr(window, "_show_finish_notification", lambda *_args, **_kwargs: None)

    window._download_finished_impl(0)

    manifest = playlist_dir / "My Playlist.m3u"
    assert manifest.exists()
    assert "01 First.mp4" in manifest.read_text(encoding="utf-8")


def test_download_finished_updates_playlist_subscription_manifest(window, tmp_path, monkeypatch):
    outdir = tmp_path / "subscription-output"
    outdir.mkdir()
    first = outdir / "01 First.mp4"
    second = outdir / "02 Second.mp4"
    first.write_text("1", encoding="utf-8")
    second.write_text("2", encoding="utf-8")

    window.chk_generate_m3u.setChecked(True)
    monkeypatch.setattr(window, "_show_finish_notification", lambda *_args, **_kwargs: None)
    monkeypatch.setattr(window, "_persist_session_snapshot", lambda: None)

    for path in (first, second):
        window._active_download_mode = window.MODE_VIDEO
        window._active_runtime_settings = {"mode": window.MODE_VIDEO}
        window._active_download_outdir = str(outdir)
        window._active_download_subscription = {
            "id": 41,
            "name": "Saved Playlist",
            "target_kind": "playlist",
        }
        window._completed_output_paths = [str(path)]
        window._last_destination_path = str(path)
        window.stop_event.clear()
        window._pending_followup_tasks = []
        window._parallel_state = {}
        window._download_finished_impl(0)

    manifest = outdir / "Saved Playlist.m3u"
    assert manifest.exists()
    assert manifest.read_text(encoding="utf-8").splitlines() == [
        "#EXTM3U",
        "#PLAYLIST:Saved Playlist",
        "01 First.mp4",
        "02 Second.mp4",
    ]


def test_find_similar_media_falls_back_to_search_mode_without_webengine(window, monkeypatch):
    monkeypatch.setattr(main_window_module, "_HAS_WEBENGINE", False)
    window.url_input.setText("https://www.youtube.com/watch?v=demo123")
    monkeypatch.setattr(
        window,
        "_probe_media_info",
        lambda *args, **kwargs: {"title": "Demo Similar Clip", "uploader": "Aura QA"},
    )

    window._find_similar_media()

    assert window._get_mode() == window.MODE_SEARCH
    assert window.url_input.text() == "Demo Similar Clip Aura QA"


def test_session_save_restore_preserves_queue_options(window, tmp_path):
    outdir = tmp_path / "downloads"
    outdir.mkdir()
    entry = window._download_queue.add(
        "https://www.youtube.com/playlist?list=demo",
        mode=window.MODE_PLAYLIST,
        platform="youtube",
        quality="1080p",
        options={
            "playlist_items": [1, 3],
            "settings": {"outdir": str(outdir), "mode": window.MODE_PLAYLIST},
        },
    )
    entry.status = "paused"

    window._session_save()
    window._download_queue.clear()
    window._session_restore()

    restored = window._download_queue.all_entries()
    assert len(restored) == 1
    assert restored[0].status == "paused"
    assert restored[0].options["playlist_items"] == [1, 3]
    assert restored[0].options["settings"]["outdir"] == str(outdir)


def test_shared_browser_profile_is_reused(window, isolated_settings_dir):
    if not main_window_module._HAS_WEBENGINE:
        pytest.skip("PySide6-WebEngine is not available in this environment")

    profile_a = window._get_shared_browser_profile()
    profile_b = window._get_shared_browser_profile()

    assert profile_a is profile_b
    assert Path(profile_a.persistentStoragePath()).is_relative_to(isolated_settings_dir)


def test_activity_category_contains_dedicated_log_page(window):
    assert "activity" in window._workspace_categories
    assert "activity_log" in window._workspace_pages
    assert "activity" in window._sidebar_page_buttons

    window._activate_workspace_category("activity")

    assert window._workspace_page_key_by_index(window.workspace_tabs.currentIndex()) == "activity_log"
    assert window.log_text.parentWidget() is window._page_scroll_areas["activity_log"].widget()
    assert window.command_preview_box.parentWidget() is not None


def test_workspace_navigation_refreshes_hero_title_and_subnav(window, qapp):
    window._activate_workspace_category("automation")
    qapp.processEvents()
    qapp.processEvents()

    expected = [label for _page_key, label in window._workspace_categories["automation"]["pages"]]
    actual = [
        button.text()
        for button in window.workspace_subnav.findChildren(main_window_module.QPushButton)
        if button.parentWidget() is window.workspace_subnav
    ]
    assert actual == expected

    window._activate_workspace_page("automation_subscriptions")
    qapp.processEvents()
    qapp.processEvents()
    assert window._workspace_categories["automation"]["label"] in window.hero_title.text()
    assert window._workspace_tab_texts["automation_subscriptions"]["full"] in window.hero_title.text()

    window._activate_workspace_page("library_history")
    qapp.processEvents()
    qapp.processEvents()
    assert window._workspace_categories["library"]["label"] in window.hero_title.text()
    assert window._workspace_tab_texts["library_history"]["full"] in window.hero_title.text()


def test_crash_recovery_skips_hidden_or_closing_window(window, monkeypatch):
    prompts = []
    monkeypatch.setattr(
        main_window_module.QMessageBox,
        "question",
        lambda *args, **kwargs: prompts.append(True) or main_window_module.QMessageBox.No,
    )
    monkeypatch.setattr(
        window.db,
        "load_session",
        lambda: [{"status": "downloading", "url": "https://example.com/watch?v=1"}],
    )

    window._closing = True
    window._check_crash_recovery()
    window._closing = False
    window.hide()
    window._check_crash_recovery()

    assert prompts == []


def test_russian_automation_labels_stay_localized(qapp, isolated_settings_dir, monkeypatch):
    monkeypatch.setattr(main_window_module.AuraDownloader, "_check_dependencies_bg", lambda self: None)
    monkeypatch.setattr(main_window_module.AuraDownloader, "_check_crash_recovery", lambda self: None)
    monkeypatch.setattr(main_window_module.AuraDownloader, "_setup_tray_icon", lambda self: None)

    win = main_window_module.AuraDownloader(lang="ru", platform="youtube", theme_id="dark")
    try:
        win._activate_workspace_page("automation_presets")
        qapp.processEvents()
        qapp.processEvents()

        assert win.chk_manual_selection.text() == "Выбор элементов вручную"
        all_label_text = " ".join(label.text() for label in win.findChildren(QLabel))
        assert "Умный режим" in all_label_text
        assert "Paste list" not in all_label_text
        assert "Manual item picker" not in all_label_text
    finally:
        win.close()
        qapp.processEvents()


def test_missing_dependencies_dialog_shows_only_when_tools_are_missing(window, monkeypatch):
    shown = []

    class FakeDialog:
        def __init__(self, parent=None, items=None, t=None, theme_id=None):
            shown.append(list(items or []))
            self.open_system = False

        def exec(self):
            shown.append("exec")
            return main_window_module.QDialog.Accepted

    monkeypatch.setattr(main_window_module, "MissingDependenciesDialog", FakeDialog)
    monkeypatch.setattr(main_window_module.QTimer, "singleShot", lambda _delay, callback: callback())
    monkeypatch.setattr(window, "isVisible", lambda: True)
    window._deps_startup_dialog_shown = False

    window._apply_dep_results(
        {
            "ytdlp": ("ok", "2026.03.01", "yt-dlp"),
            "ffmpeg": ("ok", "ffmpeg", "ffmpeg"),
            "nodejs": ("notneeded", "", ""),
            "aria2c": ("ok", "1.37.0", "aria2c"),
            "everything": ("ok", "es", "es.exe"),
        }
    )
    assert shown == []

    window._deps_startup_dialog_shown = False
    window._apply_dep_results(
        {
            "ytdlp": ("missing", "", ""),
            "ffmpeg": ("missing", "", ""),
            "nodejs": ("missing", "", ""),
            "aria2c": ("missing", "", ""),
            "everything": ("missing", "", ""),
        }
    )

    assert shown
    items = shown[0]
    assert {item["key"] for item in items} == {"ytdlp", "ffmpeg", "nodejs", "aria2c", "everything"}
    assert any(item["key"] == "ytdlp" and item["severity"] == "critical" for item in items)
    assert any(item["key"] == "ffmpeg" and item["severity"] == "high" for item in items)
    assert any(item["key"] == "nodejs" and item["severity"] == "medium" for item in items)
    assert any(item["key"] == "aria2c" and item["severity"] == "low" for item in items)
    assert any(item["key"] == "everything" and item["severity"] == "low" for item in items)

    already_shown = len(shown)
    window._apply_dep_results({"ytdlp": ("missing", "", "")})
    assert len(shown) == already_shown


def test_close_event_allows_forced_exit_when_background_mode_enabled(window, monkeypatch):
    class FakeTrayIcon:
        def __init__(self):
            self.hidden = False

        def isVisible(self):
            return True

        def hide(self):
            self.hidden = True

    class FakeCloseEvent:
        def __init__(self):
            self.accepted = False
            self.ignored = False

        def accept(self):
            self.accepted = True

        def ignore(self):
            self.ignored = True

    hidden = []
    tray_icon = FakeTrayIcon()
    monkeypatch.setattr(window, "_tray_icon", tray_icon, raising=False)
    monkeypatch.setattr(window, "_save_settings", lambda: None)
    monkeypatch.setattr(window, "_save_download_history", lambda: None)
    monkeypatch.setattr(window, "_persist_session_snapshot", lambda: None)
    monkeypatch.setattr(window, "hide", lambda: hidden.append(True))
    window.chk_background.setChecked(True)

    first_event = FakeCloseEvent()
    window.closeEvent(first_event)

    assert first_event.ignored is True
    assert hidden == [True]

    window._force_close = True
    second_event = FakeCloseEvent()
    window.closeEvent(second_event)

    assert second_event.accepted is True
    assert tray_icon.hidden is True


def test_change_platform_uses_forced_close_path(window, monkeypatch):
    closed = []

    class FakeSelector:
        def __init__(self, *_args, **_kwargs):
            pass

        def run(self):
            return "vk"

    monkeypatch.setattr(main_window_module, "PlatformSelector", FakeSelector)
    monkeypatch.setattr(window, "_save_settings", lambda: None)
    monkeypatch.setattr(window, "_save_download_history", lambda: None)
    monkeypatch.setattr(window, "_request_app_close", lambda: closed.append(True))

    window._change_platform()

    assert window._next_platform == "vk"
    assert closed == [True]


def test_add_to_history_skips_completed_entries_when_auto_remove_is_enabled(window):
    window.chk_history_auto_remove.setChecked(True)

    window._add_to_history("Done item", "done", "", "video")

    assert window.download_history == []
    assert window.db.get_download_count() == 1

    window._add_to_history("Failed item", "error", "", "video")

    assert window.download_history[-1]["status"] == "error"


def test_close_event_stops_background_workers(window, monkeypatch):
    class FakeThreadWorker:
        def __init__(self):
            self.stop_calls = 0
            self.request_calls = 0
            self.wait_calls = []
            self.terminate_calls = 0
            self.running = True

        def stop(self):
            self.stop_calls += 1

        def requestInterruption(self):
            self.request_calls += 1

        def isRunning(self):
            return self.running

        def wait(self, timeout):
            self.wait_calls.append(timeout)

        def terminate(self):
            self.terminate_calls += 1
            self.running = False

    class FakeCloseEvent:
        def __init__(self):
            self.accepted = False

        def accept(self):
            self.accepted = True

        def ignore(self):
            raise AssertionError("closeEvent should not be ignored")

    monkeypatch.setattr(window, "_save_settings", lambda: None)
    monkeypatch.setattr(window, "_save_download_history", lambda: None)
    monkeypatch.setattr(window, "_persist_session_snapshot", lambda: None)

    workers = [FakeThreadWorker() for _ in range(6)]
    window.deps_worker = workers[0]
    window._format_worker = workers[1]
    window._preview_worker = workers[2]
    window._playlist_entries_worker = workers[3]
    window._sub_workers = [workers[4], workers[5]]
    window._sub_pending_queue = [{"id": 1}]

    event = FakeCloseEvent()
    window.closeEvent(event)

    assert event.accepted is True
    assert window.deps_worker is None
    assert window._format_worker is None
    assert window._preview_worker is None
    assert window._playlist_entries_worker is None
    assert window._sub_workers == []
    assert window._sub_pending_queue == []
    for worker in workers:
        assert worker.wait_calls
        assert worker.terminate_calls == 0


def test_check_dependencies_bg_skips_worker_start_while_closing(window, monkeypatch):
    started = []

    class FakeWorker:
        def __init__(self, *_args, **_kwargs):
            started.append("init")
            self.results_ready = type("DummySignal", (), {"connect": lambda self, cb: None})()

        def setParent(self, *_args, **_kwargs):
            return None

        def start(self):
            started.append("start")

    monkeypatch.setattr(main_window_module, "DepsWorker", FakeWorker)
    window._closing = True

    window._check_dependencies_bg()

    assert started == []


def test_scheduler_restarts_when_runtime_config_changes(window, monkeypatch):
    restarts = []
    monkeypatch.setattr(window, "_start_scheduler", lambda: restarts.append("start"))

    window.chk_scheduler.setChecked(True)
    restarts.clear()

    window.scheduler_mode_combo.setCurrentIndex(2)
    assert restarts == ["start"]

    restarts.clear()
    window.scheduler_interval_input.setText("15")
    window.scheduler_interval_input.editingFinished.emit()
    assert restarts == ["start"]


def test_speed_graph_widget_is_created_lazily(window):
    assert window.speed_graph is None

    window.chk_speed_graph.setChecked(True)

    assert window.speed_graph is not None
    assert window.speed_graph.isHidden() is False

    window.chk_speed_graph.setChecked(False)

    assert window.speed_graph.isHidden() is True


def test_workspace_page_animation_is_disabled_offscreen(window):
    scroll = window._page_scroll_areas["download_options"]
    scroll.setGraphicsEffect(None)

    window._animate_workspace_page("download_options")

    assert scroll.graphicsEffect() is None


def test_system_tools_action_buttons_stay_within_card(window, qapp):
    window.resize(1280, 920)
    window.show()
    window._activate_workspace_category("system")
    qapp.processEvents()
    qapp.processEvents()

    labels = (
        window.t.get("change_platform_btn", "🔄 Platform"),
        window.t.get("change_theme_btn", "🎨 Theme"),
        window.t.get("reset_settings_btn", "🗑️ Reset"),
    )
    for text in labels:
        matches = [button for button in window.findChildren(main_window_module.QPushButton) if button.text() == text]
        assert matches, f"system action button not found: {text}"
        button = matches[0]
        assert button.parentWidget().rect().contains(button.geometry()), f"system action overflow: {text}"


def test_subscription_checks_use_saved_runtime_settings(window, tmp_path, monkeypatch):
    cookies = tmp_path / "cookies.txt"
    cookies.write_text("# Netscape HTTP Cookie File\n", encoding="utf-8")
    captured = {}

    class DummySignal:
        def connect(self, _callback):
            return None

    class FakeWorker:
        def __init__(self, sub_id, channel_url, max_new, ytdlp_bin="yt-dlp", archive_path=None, extra_args=None, target_kind="channel"):
            captured["sub_id"] = sub_id
            captured["channel_url"] = channel_url
            captured["max_new"] = max_new
            captured["ytdlp_bin"] = ytdlp_bin
            captured["archive_path"] = archive_path
            captured["extra_args"] = list(extra_args or [])
            captured["target_kind"] = target_kind
            self.result_signal = DummySignal()
            self.error_signal = DummySignal()

        def start(self):
            captured["started"] = True

    window.proxy_input.setText("")
    window.cookies_input.setText("")
    window._set_combo_by_data(window.auth_combo, "none")
    monkeypatch.setattr(main_window_module, "SubCheckWorker", FakeWorker)
    window._ytdlp_bin = "yt-dlp"
    window._sub_pending_queue = [
        {
            "id": 7,
            "platform": "youtube",
            "channel_url": "https://www.youtube.com/@demo/videos",
            "max_new": 5,
            "preset_json": json.dumps(
                {
                    "label": "Saved auth",
                    "data": {
                        "auth_method": "cookies_file",
                        "cookies": str(cookies),
                        "proxy": "http://127.0.0.1:8080",
                        "meta_language": "en",
                    },
                }
            ),
        }
    ]

    window._sub_start_next()

    args = captured["extra_args"]
    assert captured["started"] is True
    assert "--cookies" in args
    assert str(cookies) in args
    assert "--proxy" in args
    assert "http://127.0.0.1:8080" in args
    assert captured["target_kind"] == "channel"


def test_subscription_checks_do_not_leak_current_ui_auth_or_proxy(window, monkeypatch):
    captured = {}

    class DummySignal:
        def connect(self, _callback):
            return None

    class FakeWorker:
        def __init__(self, sub_id, channel_url, max_new, ytdlp_bin="yt-dlp", archive_path=None, extra_args=None, target_kind="channel"):
            captured["extra_args"] = list(extra_args or [])
            captured["target_kind"] = target_kind
            self.result_signal = DummySignal()
            self.error_signal = DummySignal()

        def start(self):
            captured["started"] = True

    window.proxy_input.setText("socks5://127.0.0.1:1080")
    window.cookies_input.setText("C:/wrong/cookies.txt")
    window._set_combo_by_data(window.auth_combo, "chrome")
    monkeypatch.setattr(main_window_module, "SubCheckWorker", FakeWorker)
    window._ytdlp_bin = "yt-dlp"
    window._sub_pending_queue = [
        {
            "id": 8,
            "platform": "youtube",
            "channel_url": "https://www.youtube.com/@clean/videos",
            "max_new": 2,
            "preset_json": json.dumps(
                {
                    "label": "No auth",
                    "data": {
                        "auth_method": "none",
                        "cookies": "",
                        "proxy": "",
                        "meta_language": "any",
                    },
                }
            ),
        }
    ]

    window._sub_start_next()

    args = captured["extra_args"]
    assert captured["started"] is True
    assert "--proxy" not in args
    assert "--cookies-from-browser" not in args
    assert "--cookies" not in args
    assert captured["target_kind"] == "channel"


def test_save_all_presets_uses_atomic_write(window, monkeypatch):
    captured = {}

    def fake_atomic_write(path, data, indent=2):
        captured["path"] = path
        captured["data"] = data
        captured["indent"] = indent
        return True

    monkeypatch.setattr(main_window_module, "atomic_write_json", fake_atomic_write)

    window._save_all_presets({"Daily": {"mode": window.MODE_VIDEO}})

    assert captured["path"] == window._get_presets_file()
    assert captured["data"] == {"Daily": {"mode": window.MODE_VIDEO}}


@pytest.mark.parametrize("lang", ["en", "ru"])
@pytest.mark.parametrize("width", [1280, 860, 780])
def test_workspace_menu_categories_stay_within_containers(qapp, isolated_settings_dir, monkeypatch, lang, width):
    monkeypatch.setattr(main_window_module.AuraDownloader, "_check_dependencies_bg", lambda self: None)
    monkeypatch.setattr(main_window_module.AuraDownloader, "_check_crash_recovery", lambda self: None)
    monkeypatch.setattr(main_window_module.AuraDownloader, "_setup_tray_icon", lambda self: None)

    win = main_window_module.AuraDownloader(lang=lang, platform="youtube", theme_id="light")
    try:
        win.resize(width, 920)
        win.show()
        qapp.processEvents()
        qapp.processEvents()

        for key, button in win._sidebar_page_buttons.items():
            parent_rect = button.parentWidget().rect()
            rect = button.geometry()
            assert parent_rect.contains(rect), f"sidebar button overflow: {key} {button.text()} {rect}"

        for category_key in win._workspace_categories:
            win._activate_workspace_category(category_key)
            qapp.processEvents()
            qapp.processEvents()
            container_rect = win.workspace_subnav.rect()
            for page_key, buttons in win._workspace_subpage_buttons.items():
                for button in buttons:
                    rect = button.geometry()
                    assert container_rect.contains(rect), (
                        f"subnav overflow: {category_key}/{page_key} {button.text()} {rect}"
                    )
    finally:
        win.close()
        qapp.processEvents()
