from pathlib import Path

import pytest
from PySide6.QtGui import QColor
from PySide6.QtWidgets import QFrame, QLabel

from aura.constants import SETTINGS_FOLDER_NAME


def test_config_location_dialog_supports_home_and_custom_paths(monkeypatch, qapp, tmp_path):
    import aura.dialogs.config_location as config_module

    pointer_file = tmp_path / "pointer.txt"
    fake_home = tmp_path / "home-root"
    fake_custom = tmp_path / "custom-root"

    monkeypatch.setattr(config_module, "get_pointer_file", lambda: pointer_file)
    monkeypatch.setattr(config_module.Path, "home", classmethod(lambda cls: fake_home))
    monkeypatch.setattr(
        config_module.QFileDialog,
        "getExistingDirectory",
        lambda *args, **kwargs: str(fake_custom),
    )

    home_dialog = config_module.ConfigLocationDialog(lang="en", theme_id="light")
    home_dialog._use_home()

    assert home_dialog.result_path == fake_home / SETTINGS_FOLDER_NAME
    assert pointer_file.read_text(encoding="utf-8") == "default"

    custom_dialog = config_module.ConfigLocationDialog(lang="en", theme_id="light")
    custom_dialog._use_custom()

    assert custom_dialog.result_path == fake_custom / SETTINGS_FOLDER_NAME
    assert pointer_file.read_text(encoding="utf-8") == str(fake_custom)


def test_config_location_debug_mode_returns_runtime_path_without_pointer_write(monkeypatch, qapp, tmp_path):
    import aura.dialogs.config_location as config_module

    pointer_file = tmp_path / "pointer.txt"
    debug_dir = tmp_path / "debug-runtime"
    activated = []

    monkeypatch.setattr(config_module, "get_pointer_file", lambda: pointer_file)
    monkeypatch.setattr(
        config_module.aura_utils,
        "activate_debug_mode",
        lambda: activated.append(True) or debug_dir,
    )

    dialog = config_module.ConfigLocationDialog(lang="en", theme_id="light")
    dialog._activate_debug()

    assert dialog.result_path == debug_dir
    assert activated == [True]
    assert pointer_file.exists() is False


def test_selectors_capture_user_choices(monkeypatch, qapp):
    import aura.dialogs.selectors as selectors_module

    saved_themes = []
    monkeypatch.setattr(selectors_module, "save_theme_config", lambda theme_id: saved_themes.append(theme_id))

    lang_dialog = selectors_module.LanguageSelector(theme_id="dark")
    lang_dialog._select("en")
    assert lang_dialog._selection == "en"
    assert selectors_module.THEMES["dark"]["colors"]["bg_main"] in lang_dialog.styleSheet()

    theme_dialog = selectors_module.ThemeSelector(lang="en")
    theme_dialog._select("gray")
    assert theme_dialog._selection == "gray"
    assert saved_themes == ["gray"]

    platform_dialog = selectors_module.PlatformSelector(lang="en", theme_id="light")
    platform_dialog._select("youtube")
    assert platform_dialog._selection == "youtube"


def test_video_player_dialog_shows_multimedia_fallback(monkeypatch, qapp):
    import aura.dialogs.player_dialog as player_module

    monkeypatch.setattr(player_module, "_HAS_MULTIMEDIA", False)

    dialog = player_module.VideoPlayerDialog(None, {"player_no_multimedia": "Multimedia missing"})
    labels = [label.text() for label in dialog.findChildren(QLabel)]

    assert "Multimedia missing" in labels


def test_video_player_dialog_uses_polished_empty_state_when_idle(qapp):
    import aura.dialogs.player_dialog as player_module

    if not player_module._HAS_MULTIMEDIA:
        pytest.skip("PySide6 multimedia is unavailable in this environment")

    dialog = player_module.VideoPlayerDialog(None, {"player_status_idle": "No media loaded"}, theme_id="dark")
    try:
        dialog.show()
        qapp.processEvents()

        empty_title = dialog.findChild(QLabel, "playerEmptyTitle")
        assert empty_title is not None
        assert dialog.file_status_label.text() == "No media loaded"
        assert dialog.btn_play.isEnabled() is False
        assert dialog.btn_stop.isEnabled() is False
    finally:
        dialog.close()
        qapp.processEvents()


def test_save_theme_config_ignores_unknown_theme(monkeypatch, tmp_path):
    import aura.themes as themes_module

    monkeypatch.setattr(themes_module, "get_settings_dir", lambda: Path(tmp_path))

    themes_module.save_theme_config("unknown-theme")

    assert not (tmp_path / "general.json").exists()


@pytest.mark.parametrize("lang", ["en", "ru"])
def test_platform_selector_category_blocks_fit_layout(qapp, lang):
    import aura.dialogs.selectors as selectors_module
    from PySide6.QtWidgets import QScrollArea

    dialog = selectors_module.PlatformSelector(lang=lang, theme_id="light")
    try:
        dialog.resize(920, 720)
        dialog.show()
        qapp.processEvents()
        qapp.processEvents()

        scroll = dialog.findChild(QScrollArea)
        assert scroll is not None
        host = scroll.widget()
        assert host is not None
        host_rect = host.rect()

        for label in host.findChildren(QLabel):
            if label.objectName() == "platformCategory":
                assert host_rect.contains(label.geometry()), f"category label overflow: {label.text()}"

        for button in host.findChildren(selectors_module.QPushButton):
            if button.objectName() == "platformCard":
                assert host_rect.contains(button.geometry()), f"platform card overflow: {button.text()}"
    finally:
        dialog.close()
        qapp.processEvents()


def test_platform_selector_gap_background_matches_theme(qapp):
    import aura.dialogs.selectors as selectors_module
    from PySide6.QtWidgets import QScrollArea

    dialog = selectors_module.PlatformSelector(lang="en", theme_id="dark")
    try:
        dialog.resize(920, 720)
        dialog.show()
        qapp.processEvents()
        qapp.processEvents()

        scroll = dialog.findChild(QScrollArea)
        assert scroll is not None
        host = scroll.widget()
        assert host is not None

        buttons = sorted(
            [button for button in host.findChildren(selectors_module.QPushButton) if button.objectName() == "platformCard"],
            key=lambda button: (button.geometry().y(), button.geometry().x()),
        )
        pair = None
        for left, right in zip(buttons, buttons[1:]):
            if abs(left.geometry().y() - right.geometry().y()) <= 2 and right.geometry().left() > left.geometry().right():
                pair = (left, right)
                break

        assert pair is not None, "no adjacent platform card pair found"
        left, right = pair
        gap_x = left.geometry().right() + (right.geometry().left() - left.geometry().right()) // 2
        gap_y = left.geometry().center().y()
        image = host.grab().toImage()
        sampled = image.pixelColor(gap_x, gap_y)
        expected = QColor(selectors_module.THEMES["dark"]["colors"]["bg_main"])

        assert sampled == expected, f"unexpected gap color: {sampled.name()} != {expected.name()}"
    finally:
        dialog.close()
        qapp.processEvents()


def test_config_location_dialog_scroll_background_matches_theme(qapp):
    import aura.dialogs.config_location as config_module
    from PySide6.QtWidgets import QScrollArea

    dialog = config_module.ConfigLocationDialog(lang="en", theme_id="dark")
    try:
        dialog.resize(820, 620)
        dialog.show()
        qapp.processEvents()
        qapp.processEvents()

        scroll = dialog.findChild(QScrollArea, "configLocationScroll")
        assert scroll is not None
        image = scroll.viewport().grab().toImage()
        sampled = image.pixelColor(2, 2)
        expected = QColor(config_module.THEMES["dark"]["colors"]["bg_main"])

        assert sampled == expected, f"unexpected config dialog gutter color: {sampled.name()} != {expected.name()}"
        assert dialog.findChild(QLabel, "choicePathBlock") is not None
        assert dialog.findChild(QLabel, "choiceBadge") is not None
    finally:
        dialog.close()
        qapp.processEvents()


def test_platform_selector_cards_keep_hover_on_whole_surface(qapp):
    import aura.dialogs.selectors as selectors_module

    dialog = selectors_module.PlatformSelector(lang="en", theme_id="dark")
    try:
        dialog.show()
        qapp.processEvents()

        cards = [button for button in dialog.findChildren(selectors_module.QPushButton) if button.objectName() == "platformCard"]
        assert cards

        first_card = cards[0]
        assert first_card.testAttribute(selectors_module.Qt.WA_StyledBackground) is True

        labels = first_card.findChildren(selectors_module.QLabel)
        assert labels
        for label in labels:
            assert label.testAttribute(selectors_module.Qt.WA_TransparentForMouseEvents) is True
    finally:
        dialog.close()
        qapp.processEvents()


def test_preview_dialog_thumbnail_fits_inside_panel_at_minimum_size(qapp):
    import aura.dialogs.preview_dialog as preview_module

    dialog = preview_module.PreviewDialog(
        None,
        {"preview_title": "Preview", "preview_dialog_hint": "Hint", "close": "Close"},
        theme_id="light",
    )
    try:
        dialog.set_metadata(
            {
                "title": "Demo",
                "uploader": "Uploader",
                "duration": 125,
                "view_count": 12345,
                "thumbnail": "",
                "upload_date": "20260301",
                "_aura_audio_languages": ["en"],
                "_aura_subtitle_languages": ["en"],
            }
        )
        dialog.resize(dialog.minimumSize())
        dialog.show()
        qapp.processEvents()
        qapp.processEvents()

        panel_rect = dialog.thumb_label.parentWidget().rect()
        assert panel_rect.contains(dialog.thumb_label.geometry())
    finally:
        dialog.close()
        qapp.processEvents()


def test_format_dialog_tree_fits_inside_panel_at_minimum_size(qapp):
    import aura.dialogs.format_dialog as format_module

    dialog = format_module.FormatDialog(
        None,
        {
            "formats": [
                {
                    "id": "137",
                    "ext": "mp4",
                    "kind": "video-only",
                    "language": "en",
                    "resolution": "1920x1080",
                    "fps": "30",
                    "codec": "avc1",
                }
            ]
        },
        {"format_panel_title": "Formats", "format_panel_hint": "Select a format"},
    )
    try:
        dialog.resize(dialog.minimumSize())
        dialog.show()
        qapp.processEvents()
        qapp.processEvents()

        panel_rect = dialog.tree.parentWidget().rect()
        assert panel_rect.contains(dialog.tree.geometry())
    finally:
        dialog.close()
        qapp.processEvents()


def test_secondary_dialogs_use_polished_chrome(qapp):
    import aura.dialogs.batch_links_dialog as batch_module
    import aura.dialogs.format_dialog as format_module
    import aura.dialogs.item_picker as picker_module
    import aura.dialogs.missing_dependencies_dialog as deps_dialog_module
    from aura.translations import get_translations

    t = get_translations("en")
    format_dialog = format_module.FormatDialog(
        None,
        {
            "formats": [
                {
                    "id": "137",
                    "ext": "mp4",
                    "kind": "video-only",
                    "language": "en",
                    "resolution": "1920x1080",
                    "fps": "30",
                    "codec": "avc1",
                    "bitrate": "2048k",
                    "size": "50MiB",
                    "note": "video only",
                }
            ],
            "audio_languages": ["en", "ja"],
            "subtitle_languages": ["en"],
        },
        t,
        theme_id="dark",
    )
    picker_dialog = picker_module.ItemPickerDialog(None, title="Manual Selection", t=t, theme_id="dark")
    batch_dialog = batch_module.BatchLinksDialog(None, t=t, theme_id="dark")
    deps_dialog = deps_dialog_module.MissingDependenciesDialog(
        None,
        items=[
            {"key": "ytdlp", "name": "yt-dlp", "severity": "critical", "impact": "Core downloads cannot start."},
            {"key": "aria2c", "name": "aria2c", "severity": "low", "impact": "Acceleration is disabled."},
        ],
        t=t,
        theme_id="dark",
    )

    try:
        for dialog in (format_dialog, picker_dialog, batch_dialog, deps_dialog):
            dialog.show()
            qapp.processEvents()
            assert dialog.styleSheet()
            assert dialog.findChildren(QLabel)

        assert format_dialog.findChild(format_module.QFrame, "dialogHeroCard") is not None
        assert format_dialog.tree.objectName() == "dialogTree"
        picker_dialog.set_entries([{"index": 1, "title": "One", "duration": 61, "uploader": "Aura QA"}], "Demo")
        assert picker_dialog.findChild(picker_module.QFrame, "dialogHeroCard") is not None
        assert picker_dialog.tree.objectName() == "dialogTree"
        assert batch_dialog.findChild(batch_module.QFrame, "dialogHeroCard") is not None
        assert batch_dialog.editor.objectName() == "dialogEditor"
        assert deps_dialog.findChild(deps_dialog_module.QFrame, "dialogHeroCard") is not None
        assert deps_dialog.findChildren(QLabel, "dependencyBadge")
    finally:
        for dialog in (format_dialog, picker_dialog, batch_dialog, deps_dialog):
            dialog.close()
            qapp.processEvents()


def test_item_picker_summary_uses_source_title_and_translation(qapp):
    import aura.dialogs.item_picker as picker_module
    from aura.translations import get_translations

    dialog = picker_module.ItemPickerDialog(None, title="Ручной выбор", t=get_translations("ru"), theme_id="dark")
    try:
        dialog.set_entries(
            [
                {"index": 1, "title": "One", "duration": 61, "uploader": "Aura QA"},
                {"index": 2, "title": "Two", "duration": 125, "uploader": "Aura QA"},
            ],
            "Тестовый плейлист",
        )

        text = dialog.summary_label.text()
        assert "Тестовый плейлист" in text
        assert "Выбрано: 2 / 2" in text
    finally:
        dialog.close()
        qapp.processEvents()


def test_item_picker_defaults_to_localized_title_and_preview_formats_date(qapp):
    import aura.dialogs.item_picker as picker_module
    from aura.dialogs.preview_dialog import PreviewDialog
    from aura.translations import get_translations

    picker = picker_module.ItemPickerDialog(None, t=get_translations("ru"), theme_id="dark")
    preview = PreviewDialog(None, get_translations("en"), theme_id="dark")
    try:
        picker.show()
        preview.show()
        qapp.processEvents()

        assert picker.windowTitle() == "Ручной выбор"
        title_label = picker.findChild(QLabel, "dialogTitle")
        assert title_label is not None
        assert title_label.text() == "Ручной выбор"

        preview.set_metadata({"title": "Demo", "upload_date": "20260311"})
        assert preview.findChild(QFrame, "dialogHeroCard") is not None
        assert preview.findChild(QFrame, "dialogFooterCard") is not None
        assert preview._info_labels["date"].text() == "2026-03-11"
    finally:
        picker.close()
        preview.close()
        qapp.processEvents()


def test_item_picker_exposes_accessible_names(qapp):
    import aura.dialogs.item_picker as picker_module
    from aura.translations import get_translations

    picker = picker_module.ItemPickerDialog(None, t=get_translations("en"), theme_id="dark")
    try:
        picker.set_entries([{"index": 1, "title": "One", "duration": 61, "uploader": "Aura QA"}], "Demo")
        assert picker.filter_input.accessibleName()
        assert picker.tree.accessibleName()
        assert picker.btn_accept.accessibleName()
    finally:
        picker.close()
        qapp.processEvents()
