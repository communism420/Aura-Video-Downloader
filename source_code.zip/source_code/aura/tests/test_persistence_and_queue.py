import json

from aura.core.download_queue import DownloadQueue, Priority
from aura.database import AuraDatabase
from aura.settings import SettingsManager


def test_download_queue_reorders_pending_entries():
    queue = DownloadQueue()
    queue.add("https://example.com/1", priority=Priority.NORMAL)
    second = queue.add("https://example.com/2", priority=Priority.NORMAL)
    queue.add("https://example.com/3", priority=Priority.LOW)

    assert [entry.url for entry in queue.all_entries()] == [
        "https://example.com/1",
        "https://example.com/2",
        "https://example.com/3",
    ]

    assert queue.move(second, -1) is True
    assert [entry.url for entry in queue.all_entries()] == [
        "https://example.com/2",
        "https://example.com/1",
        "https://example.com/3",
    ]
    assert queue.next() is second

    queue.remove(second)
    queue.clear()
    assert [entry.url for entry in queue.all_entries()] == []
    assert queue.pending_count() == 0


def test_download_queue_preserves_paused_entries_and_options():
    queue = DownloadQueue()
    entry = queue.add(
        "https://example.com/playlist",
        mode="playlist",
        quality="1080p",
        priority=Priority.HIGH,
        options={"playlist_items": [1, 3, 5], "settings": {"outdir": "C:/Downloads"}},
    )
    entry.status = "paused"

    serialized = queue.to_list()
    restored = DownloadQueue()
    restored.load_from_list(serialized)

    loaded = restored.all_entries()[0]
    assert loaded.status == "paused"
    assert loaded.options["playlist_items"] == [1, 3, 5]
    assert loaded.options["settings"]["outdir"] == "C:/Downloads"


def test_database_export_import_roundtrip(tmp_path):
    source = AuraDatabase(db_path=tmp_path / "source.db")
    source.add_download(
        name="Demo video",
        status="done",
        size="42 MB",
        dtype="video",
        platform="youtube",
        url="https://youtube.com/watch?v=demo",
        filepath=str(tmp_path / "demo.mp4"),
        format_id="137+140",
        duration="10:00",
    )
    source.add_subscription(
        "youtube",
        "https://youtube.com/@demo/videos",
        channel_name="Demo channel",
        interval_minutes=30,
        max_new=7,
        target_kind="playlist",
    )
    sub_id = source.get_subscriptions()[0]["id"]
    source.update_subscription(sub_id, last_check="2026-03-10 12:30")
    source.save_session(
        [
            {
                "url": "https://youtube.com/watch?v=queued",
                "mode": "video",
                "platform": "youtube",
                "quality": "1080p",
                "status": "paused",
                "priority": int(Priority.NORMAL),
                "options": {
                    "playlist_items": [2, 4],
                    "settings": {"outdir": str(tmp_path / "downloads")},
                },
            }
        ]
    )

    snapshot = source.export_state()

    restored = AuraDatabase(db_path=tmp_path / "restored.db")
    restored.import_state(snapshot)

    downloads = restored.get_downloads()
    subs = restored.get_subscriptions()
    session = restored.load_session()

    assert len(downloads) == 1
    assert downloads[0]["format_id"] == "137+140"
    assert len(subs) == 1
    assert subs[0]["channel_name"] == "Demo channel"
    assert subs[0]["target_kind"] == "playlist"
    assert subs[0]["last_check"] == "2026-03-10 12:30"
    assert len(session) == 1
    assert session[0]["quality"] == "1080p"
    assert session[0]["status"] == "paused"
    assert session[0]["options"]["playlist_items"] == [2, 4]
    assert session[0]["options"]["settings"]["outdir"] == str(tmp_path / "downloads")


def test_settings_manager_migrates_schema(isolated_settings_dir):
    manager = SettingsManager(platform="youtube")
    manager.config_path.write_text(
        json.dumps(
            {
                "mode": "audio",
                "audio_format": "mp3",
                "stale_key": "remove-me",
            }
        ),
        encoding="utf-8",
    )

    loaded = manager.load()
    on_disk = json.loads(manager.config_path.read_text(encoding="utf-8"))

    assert loaded["mode"] == "audio"
    assert loaded["audio_format"] == "mp3"
    assert loaded["dubbed_audio_export"] is False
    assert loaded["generate_m3u"] is False
    assert loaded["immersive_safe_container"] is True
    assert "stale_key" not in on_disk
    assert "dubbed_audio_export" in on_disk
    assert "generate_m3u" in on_disk
    assert manager.last_migration is not None
