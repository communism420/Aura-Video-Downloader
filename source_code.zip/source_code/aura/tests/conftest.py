import os
import sys
from pathlib import Path

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

PROJECT_ROOT = Path(__file__).resolve().parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

for module_name in list(sys.modules):
    if module_name == "aura" or module_name.startswith("aura."):
        del sys.modules[module_name]

import pytest
from PySide6.QtCore import QCoreApplication
from PySide6.QtWidgets import QApplication


@pytest.fixture(scope="session")
def qapp():
    app = QApplication.instance() or QApplication([])
    yield app


@pytest.fixture
def isolated_settings_dir(tmp_path, monkeypatch):
    settings_dir = tmp_path / "settings"
    settings_dir.mkdir()

    import aura.database as database_module
    import aura.main_window as main_window_module
    import aura.settings as settings_module
    import aura.utils as utils_module

    monkeypatch.setattr(database_module, "get_settings_dir", lambda: settings_dir)
    monkeypatch.setattr(main_window_module, "get_settings_dir", lambda: settings_dir)
    monkeypatch.setattr(settings_module, "get_settings_dir", lambda: settings_dir)
    monkeypatch.setattr(utils_module, "get_settings_dir", lambda: settings_dir)
    return settings_dir


@pytest.fixture
def window(qapp, isolated_settings_dir):
    import aura.main_window as main_window_module

    win = main_window_module.AuraDownloader(lang="en", platform="youtube", theme_id="light")
    win._deps_startup_dialog_shown = True
    yield win
    win.close()
    qapp.processEvents()
    QCoreApplication.sendPostedEvents(None, 0)
    win.deleteLater()
    qapp.processEvents()
