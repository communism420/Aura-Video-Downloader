#!/usr/bin/env python3
"""Constants, regex patterns, configuration values."""
import re
import subprocess
import sys

POINTER_FILE_NAME = ".aura_video_downloader_pointer"  # single file in home, NOT inside settings folder
SETTINGS_FOLDER_NAME = "aura_video_downloader_settings"
APP_VERSION = "2.2"
CONFIG_FILENAME = "config.json"
YTDLP_CONFIG_FILENAME = "yt-dlp.conf"

SUBPROCESS_FLAGS = subprocess.CREATE_NO_WINDOW if sys.platform == 'win32' else 0
SUBPROCESS_TIMEOUT = 15
PROCESS_TERMINATE_TIMEOUT = 3
MAX_CONSECUTIVE_EMPTY_RUNS = 3
LOG_MAX_LINES = 5000


PROGRESS_REGEX = re.compile(r'[Dd]ownloading\s+(?:item|video)\s+(\d+)\s+of\s+(\d+)')
SPEED_REGEX = re.compile(r'\[download\]\s+[\d.]+%.*?at\s+~?\s*([\d.]+\S+/s)\s+ETA\s+(\S+)')
SPEED_ONLY_REGEX = re.compile(r'\[download\]\s+[\d.]+%.*?at\s+~?\s*([\d.]+\S+/s)')
PERCENT_REGEX = re.compile(r'\[download\]\s+([\d.]+)%')

# aria2c external downloader progress:
#   [#72ee7e 47MiB/3.9GiB(1%) CN:16 DL:7.8MiB ETA:8m27s]
#   [#5f5b78 512KiB/544KiB(94%) CN:1 DL:66KiB]
ARIA2C_PROGRESS_REGEX = re.compile(r'\[#\w+\s+\S+/\S+\((\d+)%\)')
ARIA2C_SPEED_REGEX = re.compile(r'DL:([\d.]+\s*[A-Za-z/]+)')
ARIA2C_ETA_REGEX = re.compile(r'ETA:(\S+?)\]')

DOWNLOAD_COMPLETE_PATTERNS = ['has already been downloaded']
DOWNLOAD_COMPLETE_100_REGEX = re.compile(r'\[download\]\s+100(?:\.0)?%')
ARCHIVE_SKIP_PATTERNS = ['has already been recorded in the archive']
# aria2c prints "Download complete:" when a file finishes
ARIA2C_COMPLETE_PATTERN = 'Download complete:'

DOWNLOAD_COMPLETE_PATTERNS = ['has already been downloaded']
DOWNLOAD_COMPLETE_100_REGEX = re.compile(r'\[download\]\s+100(?:\.0)?%')
ARCHIVE_SKIP_PATTERNS = ['has already been recorded in the archive']


AUTH_METHODS = [
    ("none", "auth_none"),
    ("cookies_file", "auth_cookies_file"),
    ("chrome", "auth_chrome"),
    ("firefox", "auth_firefox"),
    ("edge", "auth_edge"),
    ("brave", "auth_brave"),
    ("opera", "auth_opera"),
    ("chromium", "auth_chromium"),
    ("safari", "auth_safari"),
]

SUBTITLE_LANGUAGES = [
    ("all", "sub_lang_all"),
    ("ru", "sub_lang_ru"),
    ("en", "sub_lang_en"),
    ("uk", "sub_lang_uk"),
    ("de", "sub_lang_de"),
    ("fr", "sub_lang_fr"),
    ("es", "sub_lang_es"),
    ("it", "sub_lang_it"),
    ("pt", "sub_lang_pt"),
    ("ja", "sub_lang_ja"),
    ("ko", "sub_lang_ko"),
    ("zh", "sub_lang_zh"),
    ("ar", "sub_lang_ar"),
    ("hi", "sub_lang_hi"),
    ("tr", "sub_lang_tr"),
    ("pl", "sub_lang_pl"),
    ("nl", "sub_lang_nl"),
    ("sv", "sub_lang_sv"),
    ("cs", "sub_lang_cs"),
    ("ro", "sub_lang_ro"),
    ("hu", "sub_lang_hu"),
    ("el", "sub_lang_el"),
    ("he", "sub_lang_he"),
    ("th", "sub_lang_th"),
    ("vi", "sub_lang_vi"),
    ("id", "sub_lang_id"),
    ("fi", "sub_lang_fi"),
    ("da", "sub_lang_da"),
    ("no", "sub_lang_no"),
    ("bg", "sub_lang_bg"),
    ("hr", "sub_lang_hr"),
    ("sk", "sub_lang_sk"),
    ("sr", "sub_lang_sr"),
    ("lt", "sub_lang_lt"),
    ("lv", "sub_lang_lv"),
    ("et", "sub_lang_et"),
    ("ka", "sub_lang_ka"),
    ("az", "sub_lang_az"),
    ("kk", "sub_lang_kk"),
    ("be", "sub_lang_be"),
    ("fa", "sub_lang_fa"),
]

SUBTITLE_LANGUAGE_CHOICES = [
    ("default", "sub_lang_default"),
    ("original", "sub_lang_original"),
] + SUBTITLE_LANGUAGES

AUDIO_LANGUAGES = [
    ("any", "lang_any"),
    ("ru", "lang_ru"),
    ("en", "lang_en"),
    ("uk", "lang_uk"),
    ("de", "lang_de"),
    ("fr", "lang_fr"),
    ("es", "lang_es"),
    ("it", "lang_it"),
    ("pt", "lang_pt"),
    ("ja", "lang_ja"),
    ("ko", "lang_ko"),
    ("zh", "lang_zh"),
    ("ar", "lang_ar"),
    ("hi", "lang_hi"),
    ("bn", "lang_bn"),
    ("tr", "lang_tr"),
    ("pl", "lang_pl"),
    ("nl", "lang_nl"),
    ("sv", "lang_sv"),
    ("da", "lang_da"),
    ("no", "lang_no"),
    ("fi", "lang_fi"),
    ("cs", "lang_cs"),
    ("ro", "lang_ro"),
    ("hu", "lang_hu"),
    ("el", "lang_el"),
    ("he", "lang_he"),
    ("th", "lang_th"),
    ("vi", "lang_vi"),
    ("id", "lang_id"),
    ("ms", "lang_ms"),
    ("tl", "lang_tl"),
    ("bg", "lang_bg"),
    ("hr", "lang_hr"),
    ("sk", "lang_sk"),
    ("sr", "lang_sr"),
    ("lt", "lang_lt"),
    ("lv", "lang_lv"),
    ("et", "lang_et"),
    ("ka", "lang_ka"),
    ("hy", "lang_hy"),
    ("az", "lang_az"),
    ("kk", "lang_kk"),
    ("uz", "lang_uz"),
    ("be", "lang_be"),
    ("fa", "lang_fa"),
    ("ta", "lang_ta"),
    ("te", "lang_te"),
    ("mr", "lang_mr"),
    ("ur", "lang_ur"),
    ("sw", "lang_sw"),
    ("af", "lang_af"),
    ("ca", "lang_ca"),
    ("gl", "lang_gl"),
    ("eu", "lang_eu"),
]

AUDIO_TRACK_LANGUAGES = [
    ("default", "lang_default"),
    ("original", "lang_original"),
    ("any", "lang_any"),
] + [item for item in AUDIO_LANGUAGES if item[0] != "any"]

YOUTUBE_PRIVATE_PLAYLISTS = [
    ("watch_later", ":ytwatchlater", "🕐 Watch Later"),
    ("liked", "https://www.youtube.com/playlist?list=LL", "❤️ Liked Videos"),
    ("history", "https://www.youtube.com/feed/history", "📜 History"),
]

SPONSORBLOCK_CATEGORIES = [
    ("sponsor",        "sb_cat_sponsor",        True),
    ("intro",          "sb_cat_intro",          True),
    ("outro",          "sb_cat_outro",          True),
    ("selfpromo",      "sb_cat_selfpromo",      True),
    ("interaction",    "sb_cat_interaction",    False),
    ("preview",        "sb_cat_preview",        False),
    ("filler",         "sb_cat_filler",         False),
    ("music_offtopic", "sb_cat_music_offtopic", False),
]

# ══════════════════════════════════════════════════════════════════════════════
#  QUALITY & FORMAT CONSTANTS
# ══════════════════════════════════════════════════════════════════════════════

VIDEO_QUALITIES = [
    ("max", "quality_max", None),
    ("8k", "quality_8k", 4320),
    ("4k", "quality_4k", 2160),
    ("1440p", "quality_1440p", 1440),
    ("1080p", "quality_1080p", 1080),
    ("720p", "quality_720p", 720),
    ("480p", "quality_480p", 480),
    ("360p", "quality_360p", 360),
    ("240p", "quality_240p", 240),
    ("144p", "quality_144p", 144),
]

AUDIO_FORMATS = ["wav", "mp3", "m4a", "ogg"]

AUDIO_BITRATES = [
    ("max", "bitrate_max", 0),
    ("320", "bitrate_320", 320),
    ("256", "bitrate_256", 256),
    ("192", "bitrate_192", 192),
    ("128", "bitrate_128", 128),
    ("96", "bitrate_96", 96),
    ("64", "bitrate_64", 64),
]
