#!/usr/bin/env python3
"""Aura Video Downloader — main application window (AuraDownloader)."""
import os, sys, re, json, random, subprocess, threading, datetime, time, shutil, webbrowser, atexit, fnmatch, ctypes, locale
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QDialog, QVBoxLayout, QHBoxLayout,
    QGridLayout, QLabel, QPushButton, QLineEdit, QComboBox,
    QRadioButton, QCheckBox, QGroupBox, QButtonGroup, QPlainTextEdit,
    QTreeWidget, QTreeWidgetItem, QHeaderView, QProgressBar, QStatusBar,
    QToolBar, QFileDialog, QMessageBox, QInputDialog, QFrame, QScrollArea,
    QSystemTrayIcon, QMenu, QGraphicsOpacityEffect, QSizePolicy,
    QTabWidget, QBoxLayout
)
from PySide6.QtCore import Qt, QThread, Signal, QTimer, QSize, QEasingCurve, QPropertyAnimation, QPoint
from PySide6.QtGui import QIcon, QPixmap, QColor, QPainter, QKeySequence, QShortcut

from aura.constants import *
from aura.utils import (
    resource_path, find_binary, get_settings_dir, is_debug_mode,
    get_ytdlp_config_path, ensure_ytdlp_config,
    _get_subprocess_env, _fix_encoding, log_error, tracked_processes,
    atomic_write_json,
    get_pointer_file, _get_legacy_pointer,
)
from aura.translations import get_all_translations, get_translations
from aura.platforms import PLATFORM_CONFIGS, get_platform_name, get_all_domains
from aura.database import AuraDatabase
from aura.settings import SettingsManager
from aura.core.download_queue import DownloadQueue, Priority
from aura.themes import THEMES, build_qss, get_theme_config
from aura.workers import (
    DownloadPreparationWorker, DownloadWorker, DepsWorker, FormatListWorker,
    PlaylistEntriesWorker, PreviewWorker, ThumbnailWorker, SubCheckWorker,
)
from aura.dialogs import (
    FormatDialog, PreviewDialog, VideoPlayerDialog, _HAS_MULTIMEDIA,
    BatchLinksDialog, CookieBrowserDialog, DiscoveryBrowserDialog,
    ItemPickerDialog, _HAS_WEBENGINE,
    ThemeSelector, PlatformSelector, MissingDependenciesDialog,
)
from aura.widgets import SpeedGraphWidget

# Backward compat: TRANSLATIONS as dict
TRANSLATIONS = get_all_translations()


class AuraDownloader(QMainWindow):
    MODE_CHANNEL = "channel"
    MODE_PLAYLIST = "playlist"
    MODE_VIDEO = "video"
    MODE_AUDIO = "audio"
    MODE_SEARCH = "search"
    AUDIO_SOURCE_VIDEO = "audio_video"
    AUDIO_SOURCE_PLAYLIST = "audio_playlist"
    AUDIO_SOURCE_CHANNEL = "audio_channel"
    
    # Cross-thread signals
    _sig_log = Signal(str)
    _sig_progress = Signal(str)
    _sig_finished = Signal(int)
    
    def __init__(self, lang="en", platform="youtube", theme_id="light"):
        super().__init__()
        self.lang = lang
        self.platform = platform
        self.theme_id = theme_id
        self.COLORS = THEMES.get(theme_id, THEMES["light"])["colors"]
        self.t = TRANSLATIONS.get(lang, TRANSLATIONS["en"])
        self.pc = PLATFORM_CONFIGS.get(platform, PLATFORM_CONFIGS["youtube"])
        self.settings_manager = SettingsManager(platform=platform)
        
        # State
        self.stop_event = threading.Event()
        self.worker = None
        self._download_generation = 0      # Incremented each start — prevents stale callbacks
        self._restart_process = None        # Active subprocess in restart mode (for cleanup)
        self._restart_thread = None         # Active restart thread reference
        self.total_videos = 0
        self.downloaded_videos = 0
        self._last_destination = ""
        self._last_destination_path = ""  # Full file path for zero-byte check
        self._pending_history = False
        self.current_speed = ""
        self.current_eta = ""
        self._buffered_progress_pct = 0
        self.download_history = []
        self.db = AuraDatabase()
        self._speed_data_points = []
        self._speed_graph_timer = None
        self._scheduler_timer = None
        self.deps_worker = None
        self._sub_workers = []
        self._sub_pending_queue = []
        self._sub_download_queue = []  # Legacy — use _download_queue
        self._download_queue = DownloadQueue()  # Centralized download queue
        self._format_worker = None
        self._preview_worker = None
        self._download_prep_worker = None
        self._download_prep_token = 0
        self._pending_download_context = None
        self._section_widgets = {}
        self._intro_animations = []
        self._runtime_state = "idle"
        self._scroll_anim = None
        self._nav_buttons = {}
        self._page_buttons = {}
        self._workspace_pages = {}
        self._workspace_tab_indices = {}
        self._workspace_tab_texts = {}
        self._workspace_categories = {}
        self._workspace_page_category = {}
        self._workspace_page_descriptions = {}
        self._workspace_category_defaults = {}
        self._workspace_subpage_buttons = {}
        self._sidebar_quick_buttons = {}
        self._sidebar_quick_texts = {}
        self._sidebar_page_buttons = {}
        self._sidebar_page_texts = {}
        self._sidebar_nav_buttons = {}
        self._sidebar_nav_texts = {}
        self._sidebar_insight_labels = {}
        self._sidebar_insight_texts = {}
        self._active_workspace_category = ""
        self._page_scroll_areas = {}
        self._section_page_map = {}
        self._responsive_columns = []
        self._page_transition = None
        self._active_download_platform = None
        self._active_download_mode = None
        self._active_download_quality = None
        self._active_download_url = ""
        self._active_download_outdir = ""
        self._active_download_cookies = ""
        self._live_command_preview = ""
        self._live_command_title = ""
        self._current_preview_text = ""
        self._node_bin = "node"
        self._media_info_cache = {}
        self._pending_followup_tasks = []
        self._active_followup_task = None
        self._active_download_playlist_items = []
        self._active_download_priority = Priority.HIGH
        self._active_runtime_settings = {}
        self._active_download_subscription = {}
        self._active_temp_download_files = []
        self._completed_output_paths = []
        self._subscription_playlist_manifests = {}
        self._playlist_entries_worker = None
        self._manual_selection_context = None
        self._downloads_paused = False
        self._pause_requested = False
        self._browser_profile = None
        self._closing = False
        self._force_close = False
        self._deps_startup_dialog_shown = False
        
        # Settings vars (plain Python, not tkinter StringVar)
        self._mode = self.MODE_VIDEO
        self._quality = "max"
        self._search_results_limit = "25"
        self._audio_format = "wav"
        self._audio_bitrate = "max"
        self._audio_source = self.AUDIO_SOURCE_VIDEO
        self._audio_language = "any"
        self._download_all_audio_tracks = False
        self._dubbed_audio_export = False
        self._dubbed_audio_mode = "selected"
        self._dubbed_audio_languages = ""
        self._dubbed_audio_format = "best"
        self._meta_language = "any"
        self._reverse_playlist = True
        self._use_archive = True
        self._no_numbering = False
        self._restart_each = False
        self._notify_on_finish = True
        self._download_subs = False
        self._sub_language = "all"
        self._embed_subtitles = False
        self._subtitle_format = "srt"
        self._auth_method = "none"
        self._use_aria2c = False
        self._aria2c_threads = "16"
        self._concurrent_videos = "1"
        self._smart_auto = False
        self._manual_item_selection = False
        self._sb_enabled = False
        self._speed_limit = 0
        self._speed_limit_unit = "mbs"
        self._output_container = "auto"
        self._container_before_multi_audio = "auto"
        self._container_forced_by_multi_audio = False
        self._video_codec_policy = "auto"
        self._playback_target = "auto"
        self._immersive_safe_container = True
        self._manual_format_id = ""
        self._manual_format_kind = ""
        self._manual_format_context = {}
        self._generate_m3u = False
        self._history_auto_remove_completed = False
        self._speed_graph_enabled = False
        self._background_mode = False
        self._scheduler_enabled = False
        self._scheduler_mode = "daily"
        self._scheduler_interval = 60
        self._sb_action = "mark"
        self._sb_categories = ["sponsor", "intro", "outro", "selfpromo"]
        self._sb_force_keyframes = False
        self._log_file_enabled = False
        self._log_file_path = ""
        self._auto_remove_completed = False
        self._writing_log_file = False
        
        platform_name = get_platform_name(platform, lang)
        self.setWindowTitle(f"✦ AURA VIDEO DOWNLOADER ✦ — {platform_name}")
        self.setMinimumSize(940, 760)
        self.resize(1280, 920)
        
        self.setStyleSheet(build_qss(self.COLORS))
        
        # Connect cross-thread signals
        self._sig_log.connect(self.log)
        self._sig_progress.connect(self._handle_progress_line)
        self._sig_finished.connect(self._download_finished)
        
        self._create_ui()
        self._load_settings()
        self._refresh_hero_banner()
        self._show_welcome()
        QTimer.singleShot(120, self._animate_intro)
        
        # System tray icon — persistent while app is running
        self._setup_tray_icon()
        
        # Check dependencies in background
        QTimer.singleShot(300, self._check_dependencies_bg)
        
        # Check for crash-recovery session (auto-saved before last download)
        self._crash_recovery_timer = QTimer(self)
        self._crash_recovery_timer.setSingleShot(True)
        self._crash_recovery_timer.timeout.connect(self._check_crash_recovery)
        self._crash_recovery_timer.start(1000)
        
        # Progress UI throttle: buffer updates, flush at 10Hz (not 100+ Hz)
        self._progress_ui_dirty = False
        self._progress_ui_timer = QTimer(self)
        self._progress_ui_timer.setInterval(100)  # 100ms = 10 FPS for progress bar
        self._progress_ui_timer.timeout.connect(self._flush_progress_ui)
        self._progress_ui_timer.start()

        self._execution_preview_timer = QTimer(self)
        self._execution_preview_timer.setSingleShot(True)
        self._execution_preview_timer.setInterval(140)
        self._execution_preview_timer.timeout.connect(self._refresh_execution_blueprint)
        self._wire_execution_blueprint_inputs()
        QTimer.singleShot(0, self._refresh_execution_blueprint)
        QTimer.singleShot(0, self._refresh_primary_action_state)
    
    # ══════════════════════════════════════════════════════════════════════════
    #  UI CREATION
    # ══════════════════════════════════════════════════════════════════════════
    
    def _create_ui(self):
        C = self.COLORS
        t = self.t
        
        # ─── TOP BAR ─────────────────────────────────────────────────────
        shell = QWidget()
        shell.setObjectName("appChrome")
        shell_layout = QVBoxLayout(shell)
        shell_layout.setContentsMargins(0, 0, 0, 0)
        shell_layout.setSpacing(0)
        self.setCentralWidget(shell)

        platform_name = get_platform_name(self.platform, self.lang)
        top_bar = QFrame()
        top_bar.setObjectName("topBar")
        top_bar_layout = QGridLayout(top_bar)
        top_bar_layout.setContentsMargins(14, 10, 14, 10)
        top_bar_layout.setHorizontalSpacing(10)
        top_bar_layout.setVerticalSpacing(8)
        self._top_bar_layout = top_bar_layout

        title_col = QVBoxLayout()
        title_col.setSpacing(1)
        brand = QLabel("Aura Video Downloader")
        brand.setObjectName("toolbarBrand")
        brand.setWordWrap(True)
        self._configure_wrap_label(brand)
        self.toolbar_brand_label = brand
        title_col.addWidget(brand)

        meta = QLabel(platform_name)
        meta.setObjectName("toolbarMeta")
        meta.setWordWrap(True)
        self._configure_wrap_label(meta)
        self.toolbar_meta_label = meta
        title_col.addWidget(meta)
        top_bar_layout.addLayout(title_col, 0, 0)

        self.url_input = QLineEdit()
        self.url_input.setObjectName("toolbarUrlField")
        self.url_input.setPlaceholderText(self._pc_url_hint(self.MODE_CHANNEL))
        self.url_input.setMinimumWidth(220)
        self.url_input.setClearButtonEnabled(True)
        self.url_input.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self.url_input.returnPressed.connect(self.start_download)
        self.url_input.textChanged.connect(self._refresh_primary_action_state)
        top_bar_layout.addWidget(self.url_input, 0, 1)

        browse_btn = QPushButton(self.t.get("browser_open_btn", "Browser"))
        browse_btn.setObjectName("ghostBtn")
        browse_btn.setCursor(Qt.PointingHandCursor)
        browse_btn.setMinimumWidth(92)
        browse_btn.setToolTip(self.t.get("browser_open_tip", "Open built-in browser and search inside the app"))
        browse_btn.clicked.connect(self._open_media_browser)
        self.browse_btn = browse_btn
        
        self.start_btn = QPushButton(t['start_btn'])
        self.start_btn.setObjectName("startBtn")
        self.start_btn.setCursor(Qt.PointingHandCursor)
        self.start_btn.setMinimumWidth(148)
        self.start_btn.setToolTip("Ctrl+Enter")
        self.start_btn.setShortcut("Ctrl+Return")
        self.start_btn.clicked.connect(self.start_download)

        self.stop_btn = QPushButton(t['stop_btn'])
        self.stop_btn.setObjectName("stopBtn")
        self.stop_btn.setEnabled(False)
        self.stop_btn.setCursor(Qt.PointingHandCursor)
        self.stop_btn.setMinimumWidth(96)
        self.stop_btn.setToolTip("Ctrl+Q")
        self.stop_btn.setShortcut("Ctrl+Q")
        self.stop_btn.clicked.connect(self.stop_download)

        self.pause_btn = QPushButton(self.t.get("pause_btn", "Pause"))
        self.pause_btn.setObjectName("ghostBtn")
        self.pause_btn.setEnabled(False)
        self.pause_btn.setCursor(Qt.PointingHandCursor)
        self.pause_btn.setMinimumWidth(90)
        self.pause_btn.clicked.connect(self._toggle_pause_downloads)
        
        clear_btn = QPushButton(t.get("log_clear_action", "Clear"))
        clear_btn.setObjectName("ghostBtn")
        clear_btn.setCursor(Qt.PointingHandCursor)
        clear_btn.setMinimumWidth(80)
        clear_btn.setToolTip(t.get("clear_log_btn", "Clear log") + "  (Ctrl+L)")
        clear_btn.setShortcut("Ctrl+L")
        clear_btn.clicked.connect(self.clear_log)
        self.clear_log_btn = clear_btn

        actions_row = QHBoxLayout()
        actions_row.setSpacing(8)
        for btn in (browse_btn, self.start_btn, self.stop_btn, self.pause_btn, clear_btn):
            actions_row.addWidget(btn)
        actions_row.addStretch()
        self._top_actions_layout = actions_row
        top_bar_layout.addLayout(actions_row, 1, 0, 1, 2)

        self.toolbar_state_chip = QLabel()
        self.toolbar_state_chip.setObjectName("toolbarChip")
        self.toolbar_state_chip.setMinimumWidth(126)
        top_bar_layout.addWidget(self.toolbar_state_chip, 0, 2, Qt.AlignRight | Qt.AlignVCenter)
        top_bar_layout.setColumnStretch(0, 0)
        top_bar_layout.setColumnStretch(1, 1)
        top_bar_layout.setColumnStretch(2, 0)
        shell_layout.addWidget(top_bar)
        
        # ─── MAIN AREA: sidebar + workspace ──────────────────────────────
        top_container = QWidget()
        top_container.setObjectName("workspaceSurface")
        top_layout = QHBoxLayout(top_container)
        top_layout.setContentsMargins(0, 0, 0, 0)
        top_layout.setSpacing(12)
        self._workspace_surface_layout = top_layout

        self.sidebar_panel = self._build_sidebar(t)
        top_layout.addWidget(self.sidebar_panel)

        content = QWidget()
        content.setObjectName("workspaceContent")
        layout = QVBoxLayout(content)
        layout.setSpacing(12)
        layout.setContentsMargins(18, 18, 18, 18)

        self._content_layout = layout

        self._build_hero_section(layout, t, C)
        self._build_workspace_tabs(t)
        layout.addWidget(self.workspace_subnav)
        layout.addWidget(self.workspace_tabs, 1)
        self._build_all_sections(t)
        self._refresh_primary_action_state()

        top_layout.addWidget(content, 1)
        top_container.setMinimumHeight(220)
        shell_layout.addWidget(top_container, 1)
        
        # ─── STATUS BAR ──────────────────────────────────────────────────
        self.progress_bar = QProgressBar()
        self.progress_bar.setMaximum(100)
        self.progress_bar.setValue(0)
        self.progress_bar.setTextVisible(False)
        self.progress_bar.setFixedHeight(8)
        
        status_widget = QWidget()
        status_widget.setObjectName("statusChrome")
        status_layout = QVBoxLayout(status_widget)
        status_layout.setContentsMargins(12, 4, 12, 4)
        status_layout.setSpacing(2)
        status_layout.addWidget(self.progress_bar)
        
        info_layout = QHBoxLayout()
        self.progress_label = QLabel(t["progress_idle"])
        self.progress_label.setObjectName("statusLabel")
        self.speed_label = QLabel(t["speed_idle"])
        self.speed_label.setObjectName("statusLabel")
        
        info_layout.addWidget(QLabel(t["progress_label"]))
        info_layout.addWidget(self.progress_label)
        info_layout.addStretch()
        
        version_lbl = QLabel(f"v{APP_VERSION}")
        version_lbl.setStyleSheet(f"color: {C['text_hint']}; font-size: 8pt;")
        info_layout.addWidget(version_lbl)
        info_layout.addStretch()
        
        info_layout.addWidget(QLabel(t["speed_label"]))
        info_layout.addWidget(self.speed_label)
        status_layout.addLayout(info_layout)
        
        self.statusBar().addPermanentWidget(status_widget, 1)
        self._set_runtime_state("idle")
        self._refresh_workspace_insights()

    def _build_sidebar(self, t):
        """Build a compact category sidebar; page details live in the sub-navigation above the workspace."""
        sidebar = QFrame()
        sidebar.setObjectName("sidebarCard")
        sidebar.setMinimumWidth(208)
        sidebar.setMaximumWidth(252)
        sidebar.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Expanding)

        layout = QVBoxLayout(sidebar)
        layout.setContentsMargins(14, 14, 14, 14)
        layout.setSpacing(10)

        eyebrow = QLabel(t.get("sidebar_eyebrow", "Workspace"))
        eyebrow.setObjectName("sidebarEyebrow")
        layout.addWidget(eyebrow)

        title = QLabel(t.get("sidebar_title", "Workspace"))
        title.setObjectName("sidebarTitle")
        title.setWordWrap(True)
        self._configure_wrap_label(title)
        self.sidebar_title_label = title
        layout.addWidget(title)

        self.sidebar_meta = QLabel(t.get("sidebar_subtitle", "Open a page, change the essentials, and launch the download."))
        self.sidebar_meta.setObjectName("sidebarMeta")
        self.sidebar_meta.setWordWrap(True)
        self._configure_wrap_label(self.sidebar_meta)
        layout.addWidget(self.sidebar_meta)

        self.sidebar_status_chip = QLabel()
        self.sidebar_status_chip.setObjectName("sidebarChip")
        layout.addWidget(self.sidebar_status_chip, 0, Qt.AlignLeft)

        pages_box = QFrame()
        pages_box.setObjectName("sidebarSection")
        pages_layout = QVBoxLayout(pages_box)
        pages_layout.setContentsMargins(12, 12, 12, 12)
        pages_layout.setSpacing(6)
        pages_title = QLabel(t.get("sidebar_pages_title", "Pages"))
        pages_title.setObjectName("sidebarSectionTitle")
        pages_layout.addWidget(pages_title)
        pages_grid = QGridLayout()
        pages_grid.setHorizontalSpacing(8)
        pages_grid.setVerticalSpacing(6)
        self._sidebar_pages_grid = pages_grid

        categories = [
            ("setup", t.get("workspace_tab_setup", "Setup"), t.get("workspace_tab_setup_compact", "Setup")),
            ("download", t.get("workspace_tab_download", "Download"), t.get("workspace_tab_download_compact", "Files")),
            ("automation", t.get("workspace_tab_automation", "Automation"), t.get("workspace_tab_automation_compact", "Auto")),
            ("library", t.get("workspace_tab_library", "Library"), t.get("workspace_tab_library_compact", "Queue")),
            ("activity", t.get("workspace_tab_activity", t.get("log_panel_title", "Activity")), t.get("workspace_tab_activity_compact", "Log")),
            ("system", t.get("workspace_tab_system", "System"), t.get("workspace_tab_system_compact", "System")),
        ]
        for key, label, compact_label in categories:
            btn = self._make_sidebar_page_button(key, label)
            self._sidebar_page_buttons[key] = btn
            self._sidebar_page_texts[key] = {"full": label, "compact": compact_label}
            pages_grid.addWidget(btn, len(self._sidebar_page_buttons) - 1, 0)
        self._reflow_sidebar_page_buttons(compact=True)
        pages_layout.addLayout(pages_grid)
        layout.addWidget(pages_box)

        quick_box = QFrame()
        quick_box.setObjectName("sidebarSection")
        quick_layout = QVBoxLayout(quick_box)
        quick_layout.setContentsMargins(12, 12, 12, 12)
        quick_layout.setSpacing(8)
        quick_title = QLabel(t.get("sidebar_quick_title", "Shortcuts"))
        quick_title.setObjectName("sidebarSectionTitle")
        quick_layout.addWidget(quick_title)

        quick_grid = QGridLayout()
        quick_grid.setHorizontalSpacing(8)
        quick_grid.setVerticalSpacing(8)
        self._sidebar_quick_grid = quick_grid
        quick_specs = [
            ("start", t.get("sidebar_quick_start", "Start download"), t.get("sidebar_quick_start_compact", "Start"), self.start_download),
            ("preview", t.get("sidebar_quick_preview", "Open preview"), t.get("sidebar_quick_preview_compact", "Preview"), self._show_preview),
            ("formats", t.get("sidebar_quick_formats", "Inspect formats"), t.get("sidebar_quick_formats_compact", "Formats"), self._show_format_panel),
            ("folder", t.get("sidebar_quick_folder", "Open folder"), t.get("sidebar_quick_folder_compact", "Folder"), self._open_download_folder),
        ]
        for index, (key, full_label, compact_label, slot) in enumerate(quick_specs):
            btn = QPushButton(full_label)
            btn.setObjectName("sidebarQuickBtn")
            btn.setCursor(Qt.PointingHandCursor)
            btn.setMinimumHeight(34)
            btn.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
            if key in {"preview", "formats"}:
                btn.setEnabled(False)
            btn.clicked.connect(slot)
            self._sidebar_quick_buttons[key] = btn
            self._sidebar_quick_texts[key] = {"full": full_label, "compact": compact_label}
            quick_grid.addWidget(btn, index, 0)
        self._reflow_sidebar_quick_buttons(compact=self.width() < 1040)
        quick_layout.addLayout(quick_grid)
        layout.addWidget(quick_box)

        insights_box = QFrame()
        insights_box.setObjectName("sidebarSection")
        insights_layout = QVBoxLayout(insights_box)
        insights_layout.setContentsMargins(12, 12, 12, 12)
        insights_layout.setSpacing(8)
        insights_title = QLabel(t.get("sidebar_insights_title", "Current status"))
        insights_title.setObjectName("sidebarSectionTitle")
        insights_layout.addWidget(insights_title)

        insights_grid = QGridLayout()
        insights_grid.setHorizontalSpacing(8)
        insights_grid.setVerticalSpacing(8)

        def _add_insight_card(row, col, key, label_text, compact_text, value_attr_name):
            card = QFrame()
            card.setObjectName("sidebarInsightCard")
            card_layout = QVBoxLayout(card)
            card_layout.setContentsMargins(10, 8, 10, 8)
            card_layout.setSpacing(2)
            value_label = QLabel("0")
            value_label.setObjectName("sidebarInsightValue")
            card_layout.addWidget(value_label)
            meta_label = QLabel(label_text)
            meta_label.setObjectName("sidebarInsightMeta")
            meta_label.setWordWrap(True)
            self._configure_wrap_label(meta_label)
            card_layout.addWidget(meta_label)
            setattr(self, value_attr_name, value_label)
            self._sidebar_insight_labels[key] = meta_label
            self._sidebar_insight_texts[key] = {"full": label_text, "compact": compact_text}
            insights_grid.addWidget(card, row, col)

        _add_insight_card(0, 0, "queue", t.get("sidebar_insight_queue", "Items in queue"), t.get("sidebar_insight_queue_compact", "Queue"), "sidebar_queue_value")
        _add_insight_card(0, 1, "history", t.get("sidebar_insight_history", "History entries"), t.get("sidebar_insight_history_compact", "History"), "sidebar_history_value")
        _add_insight_card(1, 0, "subs", t.get("sidebar_insight_subs", "Active subscriptions"), t.get("sidebar_insight_subs_compact", "Subs"), "sidebar_subs_value")
        _add_insight_card(1, 1, "presets", t.get("sidebar_insight_presets", "Saved presets"), t.get("sidebar_insight_presets_compact", "Presets"), "sidebar_presets_value")
        insights_layout.addLayout(insights_grid)
        layout.addWidget(insights_box)

        layout.addStretch(1)
        return sidebar

    def _build_hero_section(self, layout, t, C):
        """Build a lean summary banner so the active settings page gets most of the height."""
        hero = QFrame()
        hero.setObjectName("heroCard")
        hero_layout = QVBoxLayout(hero)
        hero_layout.setContentsMargins(14, 10, 14, 10)
        hero_layout.setSpacing(8)

        top_row = QBoxLayout(QBoxLayout.LeftToRight)
        top_row.setSpacing(10)
        self._hero_top_layout = top_row

        text_col = QVBoxLayout()
        text_col.setSpacing(3)
        self.hero_title = QLabel()
        self.hero_title.setObjectName("heroTitle")
        self.hero_title.setWordWrap(True)
        self._configure_wrap_label(self.hero_title)
        text_col.addWidget(self.hero_title)

        self.hero_subtitle = QLabel()
        self.hero_subtitle.setObjectName("heroSubtitle")
        self.hero_subtitle.setWordWrap(True)
        self._configure_wrap_label(self.hero_subtitle)
        text_col.addWidget(self.hero_subtitle)

        chips_row = QHBoxLayout()
        chips_row.setSpacing(8)
        self._hero_chips_layout = chips_row
        self.hero_mode_chip = QLabel()
        self.hero_mode_chip.setObjectName("heroChip")
        chips_row.addWidget(self.hero_mode_chip)

        self.hero_platform_chip = QLabel(get_platform_name(self.platform, self.lang))
        self.hero_platform_chip.setObjectName("heroChipAlt")
        chips_row.addWidget(self.hero_platform_chip)

        self.hero_queue_chip = QLabel()
        self.hero_queue_chip.setObjectName("heroChipAlt")
        chips_row.addWidget(self.hero_queue_chip)

        current_theme = THEMES.get(self.theme_id, THEMES["light"])
        self.hero_theme_chip = QLabel(current_theme.get(f"name_{self.lang}", current_theme.get("name_en", self.theme_id)))
        self.hero_theme_chip.setObjectName("heroChipAlt")
        chips_row.addWidget(self.hero_theme_chip)
        chips_row.addStretch()
        text_col.addLayout(chips_row)
        top_row.addLayout(text_col, 3)

        smart_card = QFrame()
        smart_card.setObjectName("heroSmartCard")
        smart_layout = QVBoxLayout(smart_card)
        smart_layout.setContentsMargins(10, 8, 10, 8)
        smart_layout.setSpacing(2)
        smart_title = QLabel(t.get("hero_smart_title", "Smart Mode"))
        smart_title.setObjectName("heroSmartTitle")
        smart_layout.addWidget(smart_title)
        self.hero_smart_value = QLabel()
        self.hero_smart_value.setObjectName("heroSmartValue")
        self.hero_smart_value.setWordWrap(True)
        self._configure_wrap_label(self.hero_smart_value)
        smart_layout.addWidget(self.hero_smart_value)
        self.hero_smart_meta = QLabel()
        self.hero_smart_meta.setObjectName("heroSmartMeta")
        self.hero_smart_meta.setWordWrap(True)
        self._configure_wrap_label(self.hero_smart_meta)
        smart_layout.addWidget(self.hero_smart_meta)
        smart_btn = QPushButton(t.get("hero_smart_open", "Open automation"))
        smart_btn.setObjectName("heroAction")
        smart_btn.setCursor(Qt.PointingHandCursor)
        smart_btn.clicked.connect(lambda: self._activate_workspace_category("automation"))
        self.hero_smart_btn = smart_btn
        smart_layout.addWidget(smart_btn, 0, Qt.AlignLeft)
        top_row.addWidget(smart_card, 2)

        hero_layout.addLayout(top_row)

        bottom_row = QBoxLayout(QBoxLayout.LeftToRight)
        bottom_row.setSpacing(10)
        self._hero_bottom_layout = bottom_row

        self.hero_guide_label = QLabel(t.get("hero_guide", "Start with the link and mode, then adjust quality, files, and presets only if you need them. The rest stays out of the way."))
        self.hero_guide_label.setObjectName("heroGuide")
        self.hero_guide_label.setWordWrap(True)
        self._configure_wrap_label(self.hero_guide_label)
        bottom_row.addWidget(self.hero_guide_label, 3)

        stats_card = QFrame()
        stats_card.setObjectName("heroStats")
        stats_layout = QGridLayout(stats_card)
        stats_layout.setContentsMargins(12, 10, 12, 10)
        stats_layout.setHorizontalSpacing(18)
        stats_layout.setVerticalSpacing(4)

        self.hero_subscriptions_value = QLabel("0")
        self.hero_subscriptions_value.setObjectName("heroStatValue")
        stats_layout.addWidget(self.hero_subscriptions_value, 0, 0)
        hero_subs_label = QLabel(t.get("hero_stat_subs", "Subscriptions"))
        hero_subs_label.setObjectName("heroStatLabel")
        hero_subs_label.setWordWrap(True)
        self._configure_wrap_label(hero_subs_label)
        stats_layout.addWidget(hero_subs_label, 1, 0)

        self.hero_presets_value = QLabel("0")
        self.hero_presets_value.setObjectName("heroStatValue")
        stats_layout.addWidget(self.hero_presets_value, 0, 1)
        hero_presets_label = QLabel(t.get("hero_stat_presets", "Saved presets"))
        hero_presets_label.setObjectName("heroStatLabel")
        hero_presets_label.setWordWrap(True)
        self._configure_wrap_label(hero_presets_label)
        stats_layout.addWidget(hero_presets_label, 1, 1)
        bottom_row.addWidget(stats_card, 2)

        hero_layout.addLayout(bottom_row)
        layout.addWidget(hero)
        self._register_section("hero", hero)

    def _build_workspace_tabs(self, t):
        """Create hidden stacked pages; a compact sub-navigation above the stack exposes only the active category."""
        self.workspace_tabs = QTabWidget()
        self.workspace_tabs.setObjectName("workspaceTabs")
        self.workspace_tabs.setDocumentMode(True)
        self.workspace_tabs.setTabPosition(QTabWidget.North)
        self.workspace_tabs.setElideMode(Qt.ElideRight)
        self.workspace_tabs.tabBar().hide()
        self.workspace_tabs.currentChanged.connect(self._on_workspace_tab_changed)

        self.workspace_subnav = QFrame()
        self.workspace_subnav.setObjectName("workspaceSubnav")
        subnav_layout = QHBoxLayout(self.workspace_subnav)
        subnav_layout.setContentsMargins(0, 0, 0, 0)
        subnav_layout.setSpacing(8)
        self._workspace_subnav_layout = subnav_layout

        self._workspace_categories = {
            "setup": {
                "label": t.get("workspace_tab_setup", "Setup"),
                "pages": [
                    ("setup_source", t.get("workspace_page_setup_source", "Источник" if self.lang == "ru" else "Source")),
                    ("setup_video", t.get("workspace_page_setup_video", "Видео" if self.lang == "ru" else "Video")),
                    ("setup_audio", t.get("workspace_page_setup_audio", "Аудио" if self.lang == "ru" else "Audio")),
                    ("setup_dubbed", t.get("workspace_page_setup_dubbed", "Дубляж" if self.lang == "ru" else "Dubbed")),
                ],
            },
            "download": {
                "label": t.get("workspace_tab_download", "Download"),
                "pages": [
                    ("download_options", t.get("workspace_page_download_options", "Опции" if self.lang == "ru" else "Options")),
                    ("download_files", t.get("workspace_page_download_files", "Файлы" if self.lang == "ru" else "Files")),
                    ("download_tools", t.get("workspace_page_download_tools", "Инструменты" if self.lang == "ru" else "Tools")),
                ],
            },
            "automation": {
                "label": t.get("workspace_tab_automation", "Automation"),
                "pages": [
                    ("automation_presets", t.get("workspace_page_automation_presets", "Пресеты" if self.lang == "ru" else "Presets")),
                    ("automation_subscriptions", t.get("workspace_page_automation_subscriptions", "Подписки" if self.lang == "ru" else "Subscriptions")),
                    ("automation_session", t.get("workspace_page_automation_session", "Сессия" if self.lang == "ru" else "Session")),
                ],
            },
            "library": {
                "label": t.get("workspace_tab_library", "Library"),
                "pages": [
                    ("library_queue", t.get("workspace_page_library_queue", "Очередь" if self.lang == "ru" else "Queue")),
                    ("library_history", t.get("workspace_page_library_history", "История" if self.lang == "ru" else "History")),
                ],
            },
            "activity": {
                "label": t.get("workspace_tab_activity", t.get("log_panel_title", "Activity")),
                "pages": [
                    ("activity_log", t.get("workspace_page_activity_log", "Журнал" if self.lang == "ru" else "Log")),
                ],
            },
            "system": {
                "label": t.get("workspace_tab_system", "System"),
                "pages": [
                    ("system_tools", t.get("workspace_page_system_tools", "Система" if self.lang == "ru" else "System")),
                ],
            },
        }

        for category_key, category in self._workspace_categories.items():
            pages = category.get("pages", [])
            if pages:
                self._workspace_category_defaults[category_key] = pages[0][0]
            for page_key, label in pages:
                page = QWidget()
                page_layout = QVBoxLayout(page)
                page_layout.setContentsMargins(0, 0, 0, 0)
                page_layout.setSpacing(0)

                scroll = QScrollArea()
                scroll.setObjectName("workspaceScroll")
                scroll.setWidgetResizable(True)
                scroll.setFrameShape(QFrame.NoFrame)
                scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)

                content = QWidget()
                content.setObjectName("workspacePage")
                content_layout = QVBoxLayout(content)
                content_layout.setContentsMargins(2, 2, 2, 2)
                content_layout.setSpacing(12)
                scroll.setWidget(content)
                page_layout.addWidget(scroll)

                self.workspace_tabs.addTab(page, label)
                self._workspace_pages[page_key] = content_layout
                self._page_scroll_areas[page_key] = scroll
                self._workspace_tab_indices[page_key] = self.workspace_tabs.count() - 1
                self._workspace_tab_texts[page_key] = {"full": label, "compact": label}
                self._workspace_page_category[page_key] = category_key

        self._content_scroll = self._page_scroll_areas.get("setup_source")

    def _refresh_workspace_tab_labels(self):
        """Refresh the visible sub-navigation for the current category."""
        self._refresh_workspace_subnav(self._active_workspace_category or None)

    def _refresh_workspace_subnav(self, category_key=None):
        """Rebuild the page switcher for the active workspace category."""
        if not hasattr(self, "_workspace_subnav_layout"):
            return
        if category_key is None and hasattr(self, "workspace_tabs"):
            category_key = self._workspace_page_category.get(
                self._workspace_page_key_by_index(self.workspace_tabs.currentIndex()),
                "",
            )
        category_key = category_key or self._active_workspace_category or next(iter(self._workspace_categories), "")
        self._active_workspace_category = category_key

        while self._workspace_subnav_layout.count():
            item = self._workspace_subnav_layout.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.hide()
                widget.setParent(None)
                widget.deleteLater()
        self._workspace_subpage_buttons = {}

        for page_key in self._workspace_visible_pages(category_key):
            btn = QPushButton(self._workspace_page_nav_label(page_key))
            btn.setObjectName("navPill")
            btn.setCursor(Qt.PointingHandCursor)
            btn.setCheckable(True)
            btn.setMinimumHeight(34)
            btn.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
            btn.clicked.connect(lambda checked=False, key=page_key: self._activate_workspace_page(key, scroll_top=True))
            self._workspace_subpage_buttons.setdefault(page_key, []).append(btn)
            self._workspace_subnav_layout.addWidget(btn)
        self._workspace_subnav_layout.addStretch(1)
        self.workspace_subnav.setVisible(bool(self._workspace_visible_pages(category_key)))
        if hasattr(self, "workspace_tabs"):
            current_page = self._workspace_page_key_by_index(self.workspace_tabs.currentIndex())
            if current_page and self._workspace_page_is_visible(current_page):
                self._set_active_workspace_page(current_page)

    def _apply_compact_labels(self, is_tight=False):
        """Shorten high-risk button labels on narrow widths."""
        sidebar_page_compact = True
        sidebar_insight_compact = True
        if hasattr(self, "sidebar_panel"):
            sidebar_page_compact = self.sidebar_panel.width() < 260
            sidebar_insight_compact = self.sidebar_panel.width() < 260
        if hasattr(self, "browse_btn"):
            self.browse_btn.setText(
                self.t.get("browser_open_btn_compact", self.t.get("browser_open_btn", "Browser"))
                if is_tight else self.t.get("browser_open_btn", "Browser")
            )
        if hasattr(self, "clear_log_btn"):
            self.clear_log_btn.setText(
                self.t.get("log_clear_action_compact", self.t.get("log_clear_action", "Clear"))
                if is_tight else self.t.get("log_clear_action", "Clear")
            )
        if hasattr(self, "panel_clear_btn"):
            self.panel_clear_btn.setText(
                self.t.get("log_clear_action_compact", self.t.get("log_clear_action", "Clear"))
                if is_tight else self.t.get("log_clear_action", "Clear")
            )
        if hasattr(self, "panel_open_folder_btn"):
            self.panel_open_folder_btn.setText(
                self.t.get("log_open_folder_action_compact", self.t.get("log_open_folder_action", "Open folder"))
                if is_tight else self.t.get("log_open_folder_action", "Open folder")
            )
        if hasattr(self, "stop_btn"):
            self.stop_btn.setText(
                self.t.get("stop_btn_compact", self.t.get("stop_btn", "Stop"))
                if is_tight else self.t.get("stop_btn", "Stop")
            )
        if hasattr(self, "pause_btn"):
            self.pause_btn.setText(
                self.t.get("pause_btn_compact", self.t.get("pause_btn", "Pause"))
                if is_tight else self.t.get("pause_btn", "Pause")
            )
        if hasattr(self, "preview_copy_btn"):
            self.preview_copy_btn.setText(
                self.t.get("execution_copy_command_compact", self.t.get("execution_copy_command", "Copy command"))
                if is_tight else self.t.get("execution_copy_command", "Copy command")
            )
        for key, button in self._sidebar_quick_buttons.items():
            labels = self._sidebar_quick_texts.get(key, {})
            selected = labels.get("compact" if is_tight else "full")
            button.setText(selected or labels.get("full") or button.text())
        for key, button in self._sidebar_page_buttons.items():
            labels = self._sidebar_page_texts.get(key, {})
            selected = labels.get("compact" if sidebar_page_compact else "full")
            button.setText(selected or labels.get("full") or button.text())
        for key, button in self._sidebar_nav_buttons.items():
            labels = self._sidebar_nav_texts.get(key, {})
            selected = labels.get("compact" if is_tight else "full")
            button.setText(selected or labels.get("full") or button.text())
        for key, label in self._sidebar_insight_labels.items():
            labels = self._sidebar_insight_texts.get(key, {})
            selected = labels.get("compact" if sidebar_insight_compact else "full")
            label.setText(selected or labels.get("full") or label.text())

    def _reflow_sidebar_quick_buttons(self, compact=False):
        """Use one column for full labels and two columns for compact labels."""
        grid = getattr(self, "_sidebar_quick_grid", None)
        if grid is None:
            return
        while grid.count():
            item = grid.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.hide()
        columns = 2 if compact else 1
        for index, key in enumerate(self._sidebar_quick_buttons):
            button = self._sidebar_quick_buttons[key]
            row = index // columns if compact else index
            col = index % columns if compact else 0
            grid.addWidget(button, row, col)
            button.show()
        grid.setColumnStretch(0, 1)
        grid.setColumnStretch(1, 1 if compact else 0)

    def _reflow_sidebar_page_buttons(self, compact=False):
        """Use a compact two-column grid for the page switcher when sidebar space is tight."""
        grid = getattr(self, "_sidebar_pages_grid", None)
        if grid is None:
            return
        while grid.count():
            item = grid.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.hide()
        columns = 2 if compact else 1
        for index, key in enumerate(self._sidebar_page_buttons):
            button = self._sidebar_page_buttons[key]
            row = index // columns if compact else index
            col = index % columns if compact else 0
            grid.addWidget(button, row, col)
            button.show()
        grid.setColumnStretch(0, 1)
        grid.setColumnStretch(1, 1 if compact else 0)

    def _start_button_text_for_mode(self, mode, compact=False):
        labels = {
            self.MODE_VIDEO: self.t.get(
                "start_btn_video_compact" if compact else "start_btn_video",
                self.t.get("start_btn", "Start"),
            ),
            self.MODE_AUDIO: self.t.get(
                "start_btn_audio_compact" if compact else "start_btn_audio",
                self.t.get("start_btn", "Start"),
            ),
            self.MODE_PLAYLIST: self.t.get(
                "start_btn_playlist_compact" if compact else "start_btn_playlist",
                self.t.get("start_btn", "Start"),
            ),
            self.MODE_CHANNEL: self.t.get(
                "start_btn_channel_compact" if compact else "start_btn_channel",
                self.t.get("start_btn", "Start"),
            ),
            self.MODE_SEARCH: self.t.get(
                "start_btn_search_compact" if compact else "start_btn_search",
                self.t.get("start_btn", "Start"),
            ),
        }
        return labels.get(mode, self.t.get("start_btn", "Start"))

    def _refresh_primary_action_state(self, *_args):
        mode = self._get_mode() if hasattr(self, "mode_buttons") else self.MODE_VIDEO
        raw_url = self.url_input.text().strip() if hasattr(self, "url_input") else ""
        has_url = bool(raw_url)
        has_direct_target = has_url and (mode != self.MODE_SEARCH or raw_url.startswith(("http://", "https://")))
        can_open_recommendations = has_url and mode != self.MODE_AUDIO
        disabled_media_tip = self.t.get(
            "toolbar_action_needs_url",
            "Enter a URL first.",
        ) if not has_url else self.t.get(
            "toolbar_action_media_url_only",
            "This action works with direct media or playlist URLs, not plain search text.",
        )

        if hasattr(self, "start_btn") and self.start_btn:
            label = self._start_button_text_for_mode(mode, compact=self.width() < 1040)
            self.start_btn.setText(label)
            self.start_btn.setToolTip(f"{label}  (Ctrl+Enter)")

        if hasattr(self, "format_panel_btn") and self.format_panel_btn:
            self.format_panel_btn.setEnabled(has_direct_target)
            self.format_panel_btn.setToolTip(
                self.t.get(
                    "toolbar_formats_tip",
                    "Load all available formats for the current link and optionally choose one manually.",
                ) if has_direct_target else disabled_media_tip
            )

        if hasattr(self, "preview_btn") and self.preview_btn:
            self.preview_btn.setEnabled(has_direct_target)
            self.preview_btn.setToolTip(
                self.t.get(
                    "toolbar_preview_tip",
                    "Preview metadata, languages, and subtitles for the current link before downloading.",
                ) if has_direct_target else disabled_media_tip
            )

        if hasattr(self, "_sidebar_quick_buttons"):
            start_shortcut = self._sidebar_quick_buttons.get("start")
            if start_shortcut is not None:
                start_shortcut.setToolTip(self.start_btn.toolTip() if hasattr(self, "start_btn") else "")

            preview_shortcut = self._sidebar_quick_buttons.get("preview")
            if preview_shortcut is not None:
                preview_shortcut.setEnabled(has_direct_target)
                preview_shortcut.setToolTip(
                    self.t.get(
                        "toolbar_preview_tip",
                        "Preview metadata, languages, and subtitles for the current link before downloading.",
                    ) if has_direct_target else disabled_media_tip
                )

            formats_shortcut = self._sidebar_quick_buttons.get("formats")
            if formats_shortcut is not None:
                formats_shortcut.setEnabled(has_direct_target)
                formats_shortcut.setToolTip(
                    self.t.get(
                        "toolbar_formats_tip",
                        "Load all available formats for the current link and optionally choose one manually.",
                    ) if has_direct_target else disabled_media_tip
                )

            folder_shortcut = self._sidebar_quick_buttons.get("folder")
            if folder_shortcut is not None:
                folder_shortcut.setToolTip(self.t.get("open_folder_btn", "Open folder"))

        if hasattr(self, "similar_btn") and self.similar_btn:
            self.similar_btn.setEnabled(can_open_recommendations)
            disabled_tip = self.t.get(
                "toolbar_recommended_audio_mode_hint",
                "Recommendations are based on the current video page and are unavailable in Audio mode.",
            ) if mode == self.MODE_AUDIO else self.t.get(
                "toolbar_action_needs_url",
                "Enter a URL first.",
            )
            self.similar_btn.setToolTip(
                self.t.get(
                    "toolbar_recommended_tip",
                    "Open the current page in Aura browser and continue through recommended videos.",
                ) if can_open_recommendations else disabled_tip
            )

    def _make_page_columns(self, layout, left_stretch=1, right_stretch=1):
        """Create a compact two-column page layout."""
        wrapper = QWidget()
        wrapper.setObjectName("workspaceColumns")
        box = QBoxLayout(QBoxLayout.LeftToRight, wrapper)
        box.setContentsMargins(0, 0, 0, 0)
        box.setSpacing(12)

        left_widget = QWidget()
        left_widget.setObjectName("workspaceColumn")
        left_layout = QVBoxLayout(left_widget)
        left_layout.setContentsMargins(0, 0, 0, 0)
        left_layout.setSpacing(12)

        right_widget = QWidget()
        right_widget.setObjectName("workspaceColumn")
        right_layout = QVBoxLayout(right_widget)
        right_layout.setContentsMargins(0, 0, 0, 0)
        right_layout.setSpacing(12)

        box.addWidget(left_widget, left_stretch)
        box.addWidget(right_widget, right_stretch)
        self._responsive_columns.append((box, left_stretch, right_stretch))
        layout.addWidget(wrapper)
        return left_layout, right_layout

    def _apply_responsive_layouts(self):
        """Collapse page columns on narrow widths to avoid control overlap."""
        is_narrow = self.width() < 1180
        is_tight = self.width() < 1040
        is_stack = self.width() < 960
        for layout, left_stretch, right_stretch in self._responsive_columns:
            layout.setDirection(QBoxLayout.TopToBottom if is_narrow else QBoxLayout.LeftToRight)
            if is_narrow:
                layout.setStretch(0, 0)
                layout.setStretch(1, 0)
            else:
                layout.setStretch(0, left_stretch)
                layout.setStretch(1, right_stretch)
        if hasattr(self, "_hero_top_layout"):
            self._hero_top_layout.setDirection(QBoxLayout.TopToBottom if is_narrow else QBoxLayout.LeftToRight)
        if hasattr(self, "_hero_chips_layout"):
            self._hero_chips_layout.setDirection(QBoxLayout.TopToBottom if is_stack else QBoxLayout.LeftToRight)
        if hasattr(self, "_hero_bottom_layout"):
            self._hero_bottom_layout.setDirection(QBoxLayout.TopToBottom if is_tight else QBoxLayout.LeftToRight)
        if hasattr(self, "_workspace_subnav_layout"):
            self._workspace_subnav_layout.setDirection(QBoxLayout.TopToBottom if is_stack else QBoxLayout.LeftToRight)
            self._workspace_subnav_layout.setSpacing(6 if is_stack else 8)
        self._refresh_workspace_tab_labels()
        self._apply_compact_labels(is_tight=is_tight)
        self._reflow_sidebar_page_buttons(compact=hasattr(self, "sidebar_panel") and self.sidebar_panel.width() < 260)
        self._reflow_sidebar_quick_buttons(compact=is_tight)
        if hasattr(self, "_workspace_surface_layout"):
            self._workspace_surface_layout.setSpacing(10 if is_tight else 12)
        if hasattr(self, "_content_layout"):
            content_margin = 14 if is_tight else 18
            self._content_layout.setContentsMargins(content_margin, content_margin, content_margin, content_margin)
        if hasattr(self, "_top_bar_layout"):
            top_margin = 12 if is_tight else 14
            self._top_bar_layout.setContentsMargins(top_margin, 8 if is_tight else 10, top_margin, 8 if is_tight else 10)
            self._top_bar_layout.setHorizontalSpacing(8 if is_tight else 10)
            self._top_bar_layout.setVerticalSpacing(6 if is_tight else 8)
        if hasattr(self, "sidebar_panel"):
            self.sidebar_panel.setMinimumWidth(186 if is_stack else 198 if is_tight else 208)
            self.sidebar_panel.setMaximumWidth(214 if is_stack else 228 if is_tight else 252)
        if hasattr(self, "url_input"):
            self.url_input.setMinimumWidth(160 if is_stack else 190 if is_tight else 220)
        if hasattr(self, "browse_btn"):
            self.browse_btn.setMinimumWidth(76 if is_tight else 92)
        if hasattr(self, "start_btn"):
            self.start_btn.setMinimumWidth(108 if is_stack else 124 if is_tight else 148)
        if hasattr(self, "stop_btn"):
            self.stop_btn.setMinimumWidth(74 if is_stack else 82 if is_tight else 96)
        if hasattr(self, "pause_btn"):
            self.pause_btn.setMinimumWidth(72 if is_tight else 90)
        if hasattr(self, "clear_log_btn"):
            self.clear_log_btn.setMinimumWidth(64 if is_tight else 80)
        if hasattr(self, "toolbar_state_chip"):
            self.toolbar_state_chip.setMinimumWidth(96 if is_tight else 126)
            self.toolbar_state_chip.setVisible(not is_stack)
        if hasattr(self, "_top_actions_layout"):
            self._top_actions_layout.setSpacing(6 if is_tight else 8)
        if hasattr(self, "_command_header_layout"):
            self._command_header_layout.setDirection(QBoxLayout.TopToBottom if is_tight else QBoxLayout.LeftToRight)
        if hasattr(self, "_command_actions_layout"):
            self._command_actions_layout.setDirection(QBoxLayout.TopToBottom if is_stack else QBoxLayout.LeftToRight)
        if hasattr(self, "_preview_header_layout"):
            self._preview_header_layout.setDirection(QBoxLayout.TopToBottom if is_tight else QBoxLayout.LeftToRight)
        if hasattr(self, "_log_file_row_layout"):
            self._log_file_row_layout.setDirection(QBoxLayout.TopToBottom if is_tight else QBoxLayout.LeftToRight)
        if hasattr(self, "execution_summary_label"):
            self.execution_summary_label.setVisible(not is_tight)
        if hasattr(self, "execution_note_label"):
            self.execution_note_label.setVisible(not is_tight)
        if hasattr(self, "log_file_hint"):
            self.log_file_hint.setVisible(not is_tight)
        if hasattr(self, "log_summary_label"):
            self.log_summary_label.setVisible(not is_tight)
        if hasattr(self, "sidebar_meta"):
            self.sidebar_meta.setVisible(not is_tight)
        if hasattr(self, "toolbar_meta_label"):
            self.toolbar_meta_label.setVisible(not is_narrow)
        if hasattr(self, "sidebar_title_label"):
            self.sidebar_title_label.setText(
                self.t.get("sidebar_title_compact", self.t.get("sidebar_title", "Panel"))
                if is_narrow
                else self.t.get("sidebar_title", "Workspace")
            )
        if hasattr(self, "command_preview_box"):
            self.command_preview_box.setMaximumHeight(152 if is_tight else 180)
        if hasattr(self, "hero_guide_label"):
            self.hero_guide_label.setVisible(not is_stack)
        self._refresh_hero_banner()

    def _build_all_sections(self, t):
        """Build all UI sections split into smaller pages so each screen fits without vertical scrolling."""
        C = self.COLORS

        setup_source_layout = self._workspace_pages["setup_source"]
        self._build_section_mode(setup_source_layout, t, C)
        self._build_section_url_examples(setup_source_layout, t, C)
        setup_source_layout.addStretch()
        self._map_sections_to_page("setup_source", "mode")

        setup_video_layout = self._workspace_pages["setup_video"]
        self._build_section_quality(setup_video_layout, t, C)
        self._build_section_meta_language(setup_video_layout, t, C)
        setup_video_layout.addStretch()
        self._map_sections_to_page("setup_video", "quality")

        setup_audio_layout = self._workspace_pages["setup_audio"]
        self._build_section_audio_settings(setup_audio_layout, t, C)
        self._build_section_audio_language(setup_audio_layout, t, C)
        setup_audio_layout.addStretch()

        setup_dubbed_layout = self._workspace_pages["setup_dubbed"]
        self._build_section_dubbed_audio(setup_dubbed_layout, t, C)
        setup_dubbed_layout.addStretch()

        download_options_layout = self._workspace_pages["download_options"]
        self._build_section_options(download_options_layout, t, C)
        download_options_layout.addStretch()
        self._map_sections_to_page("download_options", "options")

        download_files_layout = self._workspace_pages["download_files"]
        self._build_section_paths(download_files_layout, t, C)
        download_files_layout.addStretch()
        self._map_sections_to_page("download_files", "paths")

        download_tools_layout = self._workspace_pages["download_tools"]
        tools_left, tools_right = self._make_page_columns(download_tools_layout, 1, 1)
        self._build_section_bandwidth(tools_left, t, C)
        self._build_section_speed_graph(tools_right, t, C)
        tools_left.addStretch()
        tools_right.addStretch()
        download_tools_layout.addStretch()
        self._map_sections_to_page("download_tools", "bandwidth", "speed_graph")

        automation_presets_layout = self._workspace_pages["automation_presets"]
        self._build_section_smart_mode(automation_presets_layout, t, C)
        automation_presets_layout.addStretch()
        self._map_sections_to_page("automation_presets", "smart")

        automation_subs_layout = self._workspace_pages["automation_subscriptions"]
        self._build_section_subscriptions(automation_subs_layout, t, C)
        automation_subs_layout.addStretch()
        self._map_sections_to_page("automation_subscriptions", "subscriptions")

        automation_session_layout = self._workspace_pages["automation_session"]
        self._build_section_session(automation_session_layout, t, C)
        automation_session_layout.addStretch()
        self._map_sections_to_page("automation_session", "session")

        library_queue_layout = self._workspace_pages["library_queue"]
        self._build_section_queue(library_queue_layout, t, C)
        library_queue_layout.addStretch()
        self._map_sections_to_page("library_queue", "queue")

        library_history_layout = self._workspace_pages["library_history"]
        self._build_section_history(library_history_layout, t, C)
        library_history_layout.addStretch()
        self._map_sections_to_page("library_history", "history")

        activity_log_layout = self._workspace_pages["activity_log"]
        self._build_activity_page(activity_log_layout, t)
        self._map_sections_to_page("activity_log", "activity_log")

        system_layout = self._workspace_pages["system_tools"]
        system_left, system_right = self._make_page_columns(system_layout)
        self._build_section_dependencies(system_left, t, C)
        self._build_section_app_settings(system_right, t, C)
        system_left.addStretch()
        system_right.addStretch()
        system_layout.addStretch()
        self._map_sections_to_page("system_tools", "dependencies")

        self._load_download_history()
        self._refresh_subscriptions()
        self._start_scheduler_if_enabled()
        self._update_mode_visibility()
        self._apply_responsive_layouts()
        self._install_accessibility_features()
        self._activate_workspace_category("setup")

    def _install_accessibility_features(self):
        self._global_shortcuts = []
        widgets = [
            (getattr(self, "url_input", None), "Media URL input"),
            (getattr(self, "outdir_input", None), "Output folder input"),
            (getattr(self, "cookies_input", None), "Cookies file input"),
            (getattr(self, "proxy_input", None), "Proxy input"),
            (getattr(self, "audio_lang_combo", None), "Audio language selector"),
            (getattr(self, "sub_lang_combo", None), "Subtitle language selector"),
            (getattr(self, "smart_combo", None), "Preset selector"),
            (getattr(self, "queue_tree", None), "Download queue"),
            (getattr(self, "dm_tree", None), "Download history"),
            (getattr(self, "sub_tree", None), "Subscriptions list"),
            (getattr(self, "log_text", None), "Execution log"),
            (getattr(self, "start_btn", None), "Start download"),
            (getattr(self, "stop_btn", None), "Stop download"),
        ]
        for widget, name in widgets:
            if widget is not None and hasattr(widget, "setAccessibleName"):
                widget.setAccessibleName(name)

        if hasattr(self, "log_text") and hasattr(self.log_text, "setAccessibleDescription"):
            self.log_text.setAccessibleDescription("Live downloader output and diagnostics")
        if hasattr(self, "queue_tree") and hasattr(self.queue_tree, "setAccessibleDescription"):
            self.queue_tree.setAccessibleDescription("Pending and paused download tasks")
        if hasattr(self, "sub_tree") and hasattr(self.sub_tree, "setAccessibleDescription"):
            self.sub_tree.setAccessibleDescription("Saved channel and playlist subscriptions")

        self._accessibility_tab_chain = [
            getattr(self, "url_input", None),
            getattr(self, "outdir_input", None),
            getattr(self, "start_btn", None),
            getattr(self, "stop_btn", None),
            getattr(self, "log_text", None),
        ]
        # Delay tab-order wiring until the event loop starts so widgets hosted in
        # workspace pages share a settled Qt window hierarchy.
        QTimer.singleShot(0, self._apply_accessibility_tab_order)

        shortcut_specs = [
            ("Ctrl+L", getattr(self, "url_input", None)),
            ("Ctrl+Shift+L", getattr(self, "log_text", None)),
            ("Ctrl+Shift+Q", getattr(self, "queue_tree", None)),
            ("Ctrl+Shift+S", getattr(self, "sub_tree", None)),
        ]
        for sequence, widget in shortcut_specs:
            if widget is None:
                continue
            shortcut = QShortcut(QKeySequence(sequence), self)
            shortcut.activated.connect(widget.setFocus)
            self._global_shortcuts.append(shortcut)

    def _apply_accessibility_tab_order(self):
        previous = None
        for widget in getattr(self, "_accessibility_tab_chain", []):
            if widget is None:
                continue
            if previous is not None:
                previous_window = previous.window() if hasattr(previous, "window") else None
                current_window = widget.window() if hasattr(widget, "window") else None
                if previous_window is current_window and previous_window is not None:
                    QWidget.setTabOrder(previous, widget)
            previous = widget

    def _build_activity_page(self, layout, t):
        """Build the execution log page as a dedicated workspace category."""
        command_center = QFrame()
        command_center.setObjectName("commandCenter")
        command_layout = QVBoxLayout(command_center)
        command_layout.setContentsMargins(14, 10, 14, 10)
        command_layout.setSpacing(6)

        header_block = QWidget()
        header_block.setObjectName("panelHeaderBlock")
        header_block_layout = QVBoxLayout(header_block)
        header_block_layout.setContentsMargins(0, 0, 0, 0)
        header_block_layout.setSpacing(6)

        header_row = QBoxLayout(QBoxLayout.LeftToRight)
        header_row.setSpacing(12)
        self._command_header_layout = header_row

        command_text = QVBoxLayout()
        command_text.setSpacing(2)
        panel_title = QLabel(t.get("log_panel_title", "Activity"))
        panel_title.setObjectName("panelTitle")
        panel_title.setWordWrap(True)
        self._configure_wrap_label(panel_title)
        command_text.addWidget(panel_title)

        self.log_summary_label = QLabel(t.get("log_panel_hint", "Live activity, queue state, and execution output appear here."))
        self.log_summary_label.setObjectName("panelMeta")
        self.log_summary_label.setWordWrap(True)
        self._configure_wrap_label(self.log_summary_label)
        command_text.addWidget(self.log_summary_label)
        header_row.addLayout(command_text, 1)

        self.log_status_chip = QLabel()
        self.log_status_chip.setObjectName("panelStatus")
        self.log_status_chip.setMinimumHeight(28)
        header_row.addWidget(self.log_status_chip, 0, Qt.AlignTop)
        header_block_layout.addLayout(header_row)

        action_row = QBoxLayout(QBoxLayout.LeftToRight)
        action_row.setSpacing(8)
        self._command_actions_layout = action_row
        self.log_progress_metric = QLabel()
        self.log_progress_metric.setObjectName("panelMetric")
        self.log_progress_metric.setWordWrap(True)
        self._configure_wrap_label(self.log_progress_metric)
        self.log_speed_metric = QLabel()
        self.log_speed_metric.setObjectName("panelMetric")
        self.log_speed_metric.setWordWrap(True)
        self._configure_wrap_label(self.log_speed_metric)
        self.log_queue_metric = QLabel()
        self.log_queue_metric.setObjectName("panelMetric")
        self.log_queue_metric.setWordWrap(True)
        self._configure_wrap_label(self.log_queue_metric)
        self.log_history_metric = QLabel()
        self.log_history_metric.setObjectName("panelMetric")
        self.log_history_metric.setWordWrap(True)
        self._configure_wrap_label(self.log_history_metric)

        quick_clear = QPushButton(t.get("log_clear_action", "Clear"))
        quick_clear.setObjectName("panelAction")
        quick_clear.setMinimumHeight(32)
        quick_clear.clicked.connect(self.clear_log)
        self.panel_clear_btn = quick_clear
        action_row.addWidget(quick_clear)

        quick_open = QPushButton(t.get("log_open_folder_action", "Open folder"))
        quick_open.setObjectName("panelAction")
        quick_open.setMinimumHeight(32)
        quick_open.clicked.connect(self._open_download_folder)
        self.panel_open_folder_btn = quick_open
        action_row.addWidget(quick_open)
        action_row.addStretch()
        header_block_layout.addLayout(action_row)

        metrics_grid = QGridLayout()
        metrics_grid.setHorizontalSpacing(8)
        metrics_grid.setVerticalSpacing(8)
        metrics_grid.addWidget(self.log_progress_metric, 0, 0)
        metrics_grid.addWidget(self.log_speed_metric, 0, 1)
        metrics_grid.addWidget(self.log_queue_metric, 1, 0)
        metrics_grid.addWidget(self.log_history_metric, 1, 1)
        metrics_grid.setColumnStretch(0, 1)
        metrics_grid.setColumnStretch(1, 1)

        command_layout.addWidget(header_block)
        command_layout.addLayout(metrics_grid)

        preview_card = QFrame()
        preview_card.setObjectName("executionPreviewCard")
        preview_layout = QVBoxLayout(preview_card)
        preview_layout.setContentsMargins(10, 8, 10, 8)
        preview_layout.setSpacing(5)

        preview_header = QBoxLayout(QBoxLayout.LeftToRight)
        preview_header.setSpacing(8)
        self._preview_header_layout = preview_header
        preview_title = QLabel(t.get("execution_blueprint_title", "Execution Blueprint"))
        preview_title.setObjectName("executionTitle")
        preview_header.addWidget(preview_title)
        preview_header.addStretch()
        self.execution_preflight_chip = QLabel()
        self.execution_preflight_chip.setObjectName("executionChip")
        preview_header.addWidget(self.execution_preflight_chip)
        preview_copy_btn = QPushButton(t.get("execution_copy_command", "Copy command"))
        preview_copy_btn.setObjectName("panelAction")
        preview_copy_btn.clicked.connect(self._copy_command_preview)
        self.preview_copy_btn = preview_copy_btn
        preview_header.addWidget(preview_copy_btn)
        preview_layout.addLayout(preview_header)

        self.execution_summary_label = QLabel(t.get(
            "execution_blueprint_hint",
            "The workspace now shows the exact yt-dlp launch plan, output path, and blockers before the run starts."
        ))
        self.execution_summary_label.setObjectName("executionBody")
        self.execution_summary_label.setWordWrap(True)
        self._configure_wrap_label(self.execution_summary_label)
        self.execution_summary_label.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Minimum)
        preview_layout.addWidget(self.execution_summary_label)

        chips_row = QGridLayout()
        chips_row.setHorizontalSpacing(8)
        chips_row.setVerticalSpacing(8)
        self.execution_plan_chip = QLabel()
        self.execution_plan_chip.setObjectName("executionChip")
        self.execution_plan_chip.setWordWrap(True)
        self.execution_plan_chip.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        self.execution_plan_chip.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Minimum)
        chips_row.addWidget(self.execution_plan_chip, 0, 0)
        self.execution_destination_chip = QLabel()
        self.execution_destination_chip.setObjectName("executionChip")
        self.execution_destination_chip.setWordWrap(True)
        self.execution_destination_chip.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        self.execution_destination_chip.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Minimum)
        chips_row.addWidget(self.execution_destination_chip, 0, 1)
        self.execution_pipeline_chip = QLabel()
        self.execution_pipeline_chip.setObjectName("executionChip")
        self.execution_pipeline_chip.setWordWrap(True)
        self.execution_pipeline_chip.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        self.execution_pipeline_chip.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Minimum)
        chips_row.addWidget(self.execution_pipeline_chip, 1, 0)
        self.execution_auth_chip = QLabel()
        self.execution_auth_chip.setObjectName("executionChip")
        self.execution_auth_chip.setWordWrap(True)
        self.execution_auth_chip.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        self.execution_auth_chip.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Minimum)
        chips_row.addWidget(self.execution_auth_chip, 1, 1)
        preview_layout.addLayout(chips_row)

        self.command_preview_box = QPlainTextEdit()
        self.command_preview_box.setObjectName("commandPreviewBox")
        self.command_preview_box.setReadOnly(True)
        self.command_preview_box.setMaximumBlockCount(200)
        self.command_preview_box.setMinimumHeight(56)
        self.command_preview_box.setMaximumHeight(96)
        self.command_preview_box.setLineWrapMode(QPlainTextEdit.WidgetWidth)
        self.command_preview_box.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.MinimumExpanding)
        preview_layout.addWidget(self.command_preview_box)

        self.execution_note_label = QLabel()
        self.execution_note_label.setObjectName("executionHint")
        self.execution_note_label.setWordWrap(True)
        self._configure_wrap_label(self.execution_note_label)
        self.execution_note_label.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Minimum)
        preview_layout.addWidget(self.execution_note_label)

        preview_card.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Minimum)
        command_layout.addWidget(preview_card)
        command_center.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Minimum)
        layout.addWidget(command_center)

        log_file_block = QWidget()
        log_file_block.setObjectName("logFileBlock")
        log_file_block_layout = QVBoxLayout(log_file_block)
        log_file_block_layout.setContentsMargins(14, 10, 14, 10)
        log_file_block_layout.setSpacing(6)

        log_file_row = QBoxLayout(QBoxLayout.LeftToRight)
        log_file_row.setContentsMargins(0, 0, 0, 0)
        log_file_row.setSpacing(8)
        self._log_file_row_layout = log_file_row

        self.chk_log_file = QCheckBox(t.get("log_file_enable", "Save log to file"))
        self.chk_log_file.setMinimumHeight(28)
        self.chk_log_file.toggled.connect(self._on_log_file_toggled)
        log_file_row.addWidget(self.chk_log_file)

        self.log_file_input = QLineEdit()
        self.log_file_input.setObjectName("pathField")
        self.log_file_input.setMinimumHeight(32)
        self.log_file_input.setPlaceholderText(t.get("log_file_path_placeholder", "Path to .txt log file"))
        self.log_file_input.setClearButtonEnabled(True)
        self.log_file_input.editingFinished.connect(self._on_log_file_path_changed)
        log_file_row.addWidget(self.log_file_input, 1)

        log_browse_btn = self._icon_btn("📁", self._browse_log_file, t.get("log_file_browse", "Select log file"))
        log_file_row.addWidget(log_browse_btn)

        log_file_block_layout.addLayout(log_file_row)

        self.log_file_hint = QLabel(t.get("log_file_hint", "When enabled, new log lines are appended to a UTF-8 text file."))
        self.log_file_hint.setObjectName("hintLabel")
        self.log_file_hint.setWordWrap(True)
        self._configure_wrap_label(self.log_file_hint)
        log_file_block_layout.addWidget(self.log_file_hint)

        layout.addWidget(log_file_block)
        self._update_log_file_ui()

        self.log_text = QPlainTextEdit()
        self.log_text.setReadOnly(True)
        self.log_text.setLineWrapMode(QPlainTextEdit.WidgetWidth)
        self.log_text.setMaximumBlockCount(10000)
        self.log_text.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.log_text.setMinimumHeight(280)
        layout.addWidget(self.log_text, 1)

    @staticmethod
    def _configure_wrap_label(label):
        """Make a word-wrapped QLabel negotiate height correctly in tight layouts."""
        policy = label.sizePolicy()
        policy.setHorizontalPolicy(QSizePolicy.Ignored)
        policy.setVerticalPolicy(QSizePolicy.Minimum)
        policy.setHeightForWidth(True)
        label.setSizePolicy(policy)

    @staticmethod
    def _ui_btn(text, slot, accent=False, tip=None, role="default"):
        """Create a themed button with cursor."""
        b = QPushButton(text)
        b.setCursor(Qt.PointingHandCursor)
        b.clicked.connect(slot)
        if accent:
            b.setObjectName("accentBtn")
        elif role == "danger":
            b.setObjectName("dangerBtn")
        elif role == "ghost":
            b.setObjectName("ghostBtn")
        if tip:
            b.setToolTip(tip)
        return b

    @staticmethod
    def _icon_btn(text, slot, tip=None):
        """Create a compact icon-style button."""
        b = QPushButton(text)
        b.setObjectName("iconBtn")
        b.setCursor(Qt.PointingHandCursor)
        b.setFixedSize(44, 34)
        b.clicked.connect(slot)
        if tip:
            b.setToolTip(tip)
        return b

    def _make_nav_button(self, section_key, text):
        """Create a compact button that scrolls to a UI section."""
        btn = QPushButton(text)
        btn.setObjectName("navPill")
        btn.setCursor(Qt.PointingHandCursor)
        btn.setCheckable(True)
        btn.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        btn.setMinimumHeight(36)
        btn.clicked.connect(lambda checked=False, key=section_key: self._scroll_to_section(key))
        self._nav_buttons.setdefault(section_key, []).append(btn)
        return btn

    def _make_sidebar_page_button(self, page_key, text):
        btn = QPushButton(text)
        btn.setObjectName("sidebarNavBtn")
        btn.setCursor(Qt.PointingHandCursor)
        btn.setCheckable(True)
        btn.setMinimumHeight(34)
        btn.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        btn.clicked.connect(lambda checked=False, key=page_key: self._activate_workspace_category(key))
        self._page_buttons.setdefault(page_key, []).append(btn)
        return btn

    def _make_sidebar_nav_button(self, section_key, text):
        btn = QPushButton(text)
        btn.setObjectName("sidebarNavBtn")
        btn.setCursor(Qt.PointingHandCursor)
        btn.setCheckable(True)
        btn.setMinimumHeight(34)
        btn.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        btn.clicked.connect(lambda checked=False, section_key=section_key: self._scroll_to_section(section_key))
        self._nav_buttons.setdefault(section_key, []).append(btn)
        return btn

    def _map_sections_to_page(self, page_key, *section_keys):
        for section_key in section_keys:
            self._section_page_map[section_key] = page_key

    def _workspace_visible_pages(self, category_key):
        pages = [
            page_key
            for page_key, _label in self._workspace_categories.get(category_key, {}).get("pages", [])
        ]
        if category_key != "setup":
            return pages
        mode = self._get_mode() if hasattr(self, "mode_buttons") else self.MODE_VIDEO
        has_audio_lang = bool(self.pc.get("has_audio_lang", False))
        visible = ["setup_source"]
        if mode != self.MODE_AUDIO:
            visible.append("setup_video")
        if mode == self.MODE_AUDIO or has_audio_lang:
            visible.append("setup_audio")
        if mode != self.MODE_AUDIO and has_audio_lang:
            visible.append("setup_dubbed")
        return [page_key for page_key in pages if page_key in visible]

    def _workspace_page_is_visible(self, page_key):
        category_key = self._workspace_page_category.get(page_key, "")
        if not category_key:
            return False
        return page_key in self._workspace_visible_pages(category_key)

    def _workspace_page_nav_label(self, page_key):
        if page_key == "setup_audio":
            if (self._get_mode() if hasattr(self, "mode_buttons") else self.MODE_VIDEO) == self.MODE_AUDIO:
                return self.t.get("workspace_page_setup_audio", "Audio")
            return self.t.get("workspace_page_setup_audio_track", "Audio Track")
        if page_key == "setup_dubbed":
            return self.t.get("workspace_page_setup_dubbed_audio", self.t.get("workspace_page_setup_dubbed", "Dubbed"))
        return self._workspace_tab_texts.get(page_key or "", {}).get("full", page_key)

    def _workspace_category_default_page(self, category_key):
        visible_pages = self._workspace_visible_pages(category_key)
        if not visible_pages:
            return self._workspace_category_defaults.get(category_key)
        if category_key == "setup":
            preferred = "setup_audio" if (self._get_mode() if hasattr(self, "mode_buttons") else self.MODE_VIDEO) == self.MODE_AUDIO else "setup_source"
            if preferred in visible_pages:
                return preferred
        stored_default = self._workspace_category_defaults.get(category_key)
        if stored_default in visible_pages:
            return stored_default
        return visible_pages[0]

    def _ensure_workspace_page_visible(self, category_key=None):
        if not hasattr(self, "workspace_tabs"):
            return
        current_page = self._workspace_page_key_by_index(self.workspace_tabs.currentIndex())
        if current_page and self._workspace_page_is_visible(current_page):
            return
        effective_category = category_key or self._workspace_page_category.get(current_page or "", "") or self._active_workspace_category
        fallback_page = self._workspace_category_default_page(effective_category)
        if fallback_page and fallback_page != current_page:
            self._activate_workspace_page(fallback_page, scroll_top=True)

    def _set_active_workspace_page(self, active_key):
        active_category = self._workspace_page_category.get(active_key, active_key)
        self._active_workspace_category = active_category
        for key, buttons in self._page_buttons.items():
            for button in buttons:
                button.setChecked(key == active_category)
        for key, buttons in self._workspace_subpage_buttons.items():
            for button in buttons:
                button.setChecked(key == active_key)
        if hasattr(self, "hero_title"):
            self._refresh_hero_banner()

    def _workspace_page_key_by_index(self, index):
        for key, tab_index in self._workspace_tab_indices.items():
            if tab_index == index:
                return key
        return None

    def _workspace_page_description(self, page_key):
        mode = self._get_mode() if hasattr(self, "mode_buttons") else self.MODE_VIDEO
        descriptions = {
            "setup_source": self.t.get("workspace_desc_setup_source", self.t.get("section_mode_hint", "Choose what exactly should be downloaded from the current link.")),
            "setup_video": self.t.get("workspace_desc_setup_video", self.t.get("section_quality_hint", "Select the preferred visual quality or keep maximum quality for the best source available.")),
            "setup_audio": self.t.get(
                "workspace_desc_setup_audio" if mode == self.MODE_AUDIO else "workspace_desc_setup_audio_track",
                self.t.get(
                    "section_audio_hint" if mode == self.MODE_AUDIO else "audio_language_hint_video_mode",
                    "Configure extraction format, bitrate, and source when downloading audio-only media."
                    if mode == self.MODE_AUDIO
                    else "Choose one preferred track for the final video, or enable all audio tracks when you want a multi-language MKV.",
                ),
            ),
            "setup_dubbed": self.t.get("workspace_desc_setup_dubbed", self.t.get("section_dubbed_audio_hint", "Save translated or dubbed audio tracks as separate audio files after the main video download finishes.")),
            "download_options": self.t.get("workspace_desc_download_options", self.t.get("section_options_hint", "Control ordering, archive behavior, subtitles, acceleration, authorization, and advanced YouTube cleanup.")),
            "download_files": self.t.get("workspace_desc_download_files", self.t.get("section_paths_hint", "Choose where files are stored, how cookies are supplied, and whether browser login should be used.")),
            "download_tools": self.t.get("workspace_desc_download_tools", self.t.get("section_bandwidth_hint", "Tune bandwidth, remux container, inspect formats, preview metadata, or open the built-in player.")),
            "automation_presets": self.t.get("workspace_desc_automation_presets", self.t.get("section_smart_hint", "Save complete download presets once and reapply them instantly for recurring tasks.")),
            "automation_subscriptions": self.t.get("workspace_desc_automation_subscriptions", self.t.get("section_subscriptions_hint", "Monitor channels automatically, schedule checks, and push new items into the queue without manual searching.")),
            "automation_session": self.t.get("workspace_desc_automation_session", self.t.get("section_session_hint", "Keep recovery and background behavior under control for long-running or unattended download sessions.")),
            "library_queue": self.t.get("workspace_desc_library_queue", self.t.get("section_queue_hint", "Inspect pending items, change order, and remove entries before they start.")),
            "library_history": self.t.get("workspace_desc_library_history", self.t.get("section_history_hint", "Filter previous downloads, sort them quickly, and clean completed entries without touching saved files.")),
            "activity_log": self.t.get("workspace_desc_activity_log", self.t.get("log_panel_hint", "Queue updates, current job progress, and yt-dlp output appear here.")),
            "system_tools": self.t.get("workspace_desc_system_tools", self.t.get("workspace_desc_system", "Dependencies, theme, platform, and global controls.")),
        }
        return descriptions.get(page_key, self.t.get("sidebar_subtitle", "Open a page, change the essentials, and launch the download."))

    def _on_workspace_tab_changed(self, index):
        page_key = self._workspace_page_key_by_index(index)
        if not page_key:
            return
        self._content_scroll = self._page_scroll_areas.get(page_key)
        self._refresh_workspace_subnav(self._workspace_page_category.get(page_key))
        self._set_active_workspace_page(page_key)
        self._animate_workspace_page(page_key)
        if self._runtime_state in {"idle", "finished", "stopped"} and hasattr(self, "sidebar_meta"):
            self.sidebar_meta.setText(self._workspace_page_description(page_key))
        QTimer.singleShot(0, lambda key=page_key: self._fit_workspace_page(key))

    def _activate_workspace_page(self, page_key, scroll_top=False):
        if not self._workspace_page_is_visible(page_key):
            fallback_page = self._workspace_category_default_page(self._workspace_page_category.get(page_key, ""))
            if fallback_page and fallback_page != page_key:
                page_key = fallback_page
        index = self._workspace_tab_indices.get(page_key)
        if index is None or not hasattr(self, "workspace_tabs"):
            return
        self.workspace_tabs.setCurrentIndex(index)
        scroll = self._page_scroll_areas.get(page_key)
        if scroll:
            self._content_scroll = scroll
            if scroll_top:
                scroll.verticalScrollBar().setValue(0)
        self._set_active_workspace_page(page_key)
        if self._runtime_state in {"idle", "finished", "stopped"} and hasattr(self, "sidebar_meta"):
            self.sidebar_meta.setText(self._workspace_page_description(page_key))

    def _activate_workspace_category(self, category_key):
        target_page = self._workspace_category_default_page(category_key)
        if target_page:
            self._refresh_workspace_subnav(category_key)
            self._activate_workspace_page(target_page, scroll_top=True)

    def _fit_workspace_page(self, page_key=None):
        """Favor the active settings page and grow the window when the screen allows it."""
        if page_key is None and hasattr(self, "workspace_tabs"):
            page_key = self._workspace_page_key_by_index(self.workspace_tabs.currentIndex())
        scroll = self._page_scroll_areas.get(page_key or "")
        hero = self._section_widgets.get("hero")
        if not scroll or not hero:
            return

        QApplication.processEvents()
        viewport_height = scroll.viewport().height()
        content_height = scroll.widget().sizeHint().height() if scroll.widget() else 0
        overflow = max(
            scroll.verticalScrollBar().maximum(),
            content_height - viewport_height,
        )

        if overflow > 0:
            screen = self.screen() or QApplication.primaryScreen()
            max_height = screen.availableGeometry().height() - 24 if screen is not None else self.height()
            desired_height = min(max_height, self.height() + overflow + 28)
            if desired_height > self.height():
                self.resize(self.width(), desired_height)
                QApplication.processEvents()

    def _animate_workspace_page(self, page_key):
        scroll = self._page_scroll_areas.get(page_key)
        if scroll and scroll.graphicsEffect() is not None:
            scroll.setGraphicsEffect(None)

    def _register_section(self, key, widget):
        """Register a section widget for quick navigation and intro animation."""
        self._section_widgets[key] = widget
        widget.setProperty("sectionKey", key)

    def _scroll_to_section(self, key):
        """Scroll smoothly to the requested section."""
        target = self._section_widgets.get(key)
        if key == "hero":
            self._set_active_section(key)
            return
        if not target:
            return
        page_key = self._section_page_map.get(key)
        if page_key:
            self._activate_workspace_page(page_key)
        if not hasattr(self, "_content_scroll") or not self._content_scroll:
            return
        self._set_active_section(key)
        scrollbar = self._content_scroll.verticalScrollBar()
        scroll_content = self._content_scroll.widget()
        target_value = max(0, target.mapTo(scroll_content, QPoint(0, 0)).y() - 16) if scroll_content else 0
        self._scroll_anim = QPropertyAnimation(scrollbar, b"value", self)
        self._scroll_anim.setDuration(320)
        self._scroll_anim.setStartValue(scrollbar.value())
        self._scroll_anim.setEndValue(target_value)
        self._scroll_anim.setEasingCurve(QEasingCurve.OutCubic)
        self._scroll_anim.start()

    def _set_active_section(self, active_key):
        for key, buttons in self._nav_buttons.items():
            for button in buttons:
                button.setChecked(key == active_key)

    def _animate_intro(self):
        """Apply light fade-in animations to key sections."""
        app = QApplication.instance()
        if app is not None and app.platformName() == "offscreen":
            return
        self._intro_animations = []
        ordered_keys = [
            "hero", "mode", "quality", "options", "paths",
            "smart", "dependencies", "history", "queue", "bandwidth",
            "speed_graph", "subscriptions", "session",
        ]
        if hasattr(self, "sidebar_panel"):
            sidebar_effect = QGraphicsOpacityEffect(self.sidebar_panel)
            sidebar_effect.setOpacity(0.0)
            self.sidebar_panel.setGraphicsEffect(sidebar_effect)
            sidebar_anim = QPropertyAnimation(sidebar_effect, b"opacity", self)
            sidebar_anim.setDuration(240)
            sidebar_anim.setStartValue(0.0)
            sidebar_anim.setEndValue(1.0)
            sidebar_anim.setEasingCurve(QEasingCurve.OutCubic)
            sidebar_anim.start()
            self._intro_animations.append((sidebar_effect, sidebar_anim))
        for index, key in enumerate(ordered_keys):
            widget = self._section_widgets.get(key)
            if not widget:
                continue
            effect = QGraphicsOpacityEffect(widget)
            effect.setOpacity(0.0)
            widget.setGraphicsEffect(effect)
            anim = QPropertyAnimation(effect, b"opacity", self)
            anim.setDuration(260)
            anim.setStartValue(0.0)
            anim.setEndValue(1.0)
            anim.setEasingCurve(QEasingCurve.OutCubic)
            delay = 80 * index
            QTimer.singleShot(delay, anim.start)
            self._intro_animations.append((effect, anim))

    def _refresh_hero_banner(self):
        """Refresh top banner labels to match current UI state."""
        if not hasattr(self, "hero_title"):
            return
        platform_name = get_platform_name(self.platform, self.lang)
        compact = self.width() < 1040
        page_key = self._workspace_page_key_by_index(self.workspace_tabs.currentIndex()) if hasattr(self, "workspace_tabs") else ""
        category_key = self._workspace_page_category.get(page_key or "", "")
        category_label = self._workspace_categories.get(category_key, {}).get("label", "Aura")
        page_label = self._workspace_page_nav_label(page_key) if page_key else category_label
        mode = self._get_mode() if hasattr(self, "mode_buttons") else self.MODE_VIDEO
        mode_map = {
            self.MODE_CHANNEL: self.t.get("mode_channel", "Channel"),
            self.MODE_PLAYLIST: self.t.get("mode_playlist", "Playlist"),
            self.MODE_VIDEO: self.t.get("mode_video", "Video"),
            self.MODE_AUDIO: self.t.get("mode_audio", "Audio"),
            self.MODE_SEARCH: self.t.get("mode_search", "Search"),
        }
        self.hero_title.setText(
            f"{page_label} · {platform_name}" if compact else f"{category_label} · {page_label} · {platform_name}"
        )
        self.hero_subtitle.setText(self._workspace_page_description(page_key))
        self.hero_mode_chip.setText(mode_map.get(mode, "Video"))
        self.hero_platform_chip.setText(platform_name)
        current_theme = THEMES.get(self.theme_id, THEMES["light"])
        self.hero_theme_chip.setText(current_theme.get(f"name_{self.lang}", current_theme.get("name_en", self.theme_id)))
        self.hero_theme_chip.setVisible(self.width() >= 1500)
        self._refresh_smart_summary()
        self._refresh_runtime_badges()

    def _refresh_smart_summary(self):
        """Mirror Smart Mode state into the compact hero card."""
        if not hasattr(self, "hero_smart_value"):
            return
        compact = self.width() < 1040
        auto_enabled = False
        preset_name = ""
        manual_picker = False
        try:
            auto_enabled = bool(getattr(self, "chk_smart_auto", None) and self.chk_smart_auto.isChecked())
            preset_name = self.smart_combo.currentText().strip() if hasattr(self, "smart_combo") else ""
            manual_picker = bool(getattr(self, "chk_manual_selection", None) and self.chk_manual_selection.isChecked())
        except Exception:
            auto_enabled = False
            preset_name = ""
            manual_picker = False
        if auto_enabled and preset_name:
            self.hero_smart_value.setText(
                self.t.get(
                    "hero_smart_active_compact" if compact else "hero_smart_active",
                    ("Авто: {name}" if self.lang == "ru" else "Auto: {name}") if compact else ("Auto preset: {name}")
                ).format(name=preset_name)
            )
        elif preset_name:
            self.hero_smart_value.setText(
                self.t.get(
                    "hero_smart_selected_compact" if compact else "hero_smart_selected",
                    ("Пресет: {name}" if self.lang == "ru" else "Preset: {name}")
                ).format(name=preset_name)
            )
        else:
            self.hero_smart_value.setText(self.t.get("hero_smart_disabled", "Пресет не выбран" if self.lang == "ru" else "No preset selected"))
        meta_text = ""
        if manual_picker:
            meta_text = self.t.get(
                "hero_smart_meta_compact" if compact else "hero_smart_meta",
                ("Выбор вручную: {state}" if self.lang == "ru" else "Manual picker: {state}")
            ).format(state=self.t.get("hero_smart_meta_on", "on"))
        elif auto_enabled and preset_name:
            meta_text = self.t.get(
                "hero_smart_auto_hint_compact" if compact else "hero_smart_auto_hint",
                "Будет применяться автоматически." if self.lang == "ru" else "Will be applied automatically.",
            )
        self.hero_smart_meta.setText(meta_text)
        self.hero_smart_meta.setVisible(bool(meta_text))

    def resizeEvent(self, event):
        super().resizeEvent(event)
        if hasattr(self, "_responsive_columns"):
            self._apply_responsive_layouts()

    @staticmethod
    def _ui_sep():
        """Create a thin separator line."""
        s = QFrame()
        s.setFrameShape(QFrame.HLine)
        s.setObjectName("separator")
        return s

    def _add_section_note(self, layout, text):
        """Add a short explanatory label inside a card."""
        if not text:
            return
        note = QLabel(text)
        note.setObjectName("sectionNote")
        note.setWordWrap(True)
        self._configure_wrap_label(note)
        if isinstance(layout, QGridLayout):
            layout.addWidget(note, layout.rowCount(), 0, 1, 5)
        else:
            layout.addWidget(note)

    def _set_runtime_state(self, state, summary=None):
        """Update live status chips in the toolbar and command center."""
        self._runtime_state = state
        labels = {
            "idle": self.t.get("status_idle", "Ready"),
            "queued": self.t.get("status_queued", "Queued"),
            "running": self.t.get("status_running", "Downloading"),
            "finished": self.t.get("status_finished", "Completed"),
            "error": self.t.get("status_error", "Needs attention"),
            "stopped": self.t.get("status_stopped", "Stopped"),
        }
        text = labels.get(state, state)
        if hasattr(self, "toolbar_state_chip"):
            self.toolbar_state_chip.setText(text)
        if hasattr(self, "log_status_chip"):
            self.log_status_chip.setText(text)
        if hasattr(self, "sidebar_status_chip"):
            self.sidebar_status_chip.setText(text)
        if summary and hasattr(self, "log_summary_label"):
            self.log_summary_label.setText(summary)
        if hasattr(self, "sidebar_meta"):
            self.sidebar_meta.setText(summary or self.t.get("sidebar_subtitle", "Open a page, change the essentials, and launch the download."))
        self._refresh_runtime_badges()

    def _refresh_primary_action_label(self):
        if not hasattr(self, "start_btn"):
            return
        mode = self._get_mode() if hasattr(self, "mode_buttons") else self.MODE_VIDEO
        text = self._start_button_text_for_mode(mode)
        if mode == self.MODE_AUDIO:
            accessible = self.t.get("start_btn_audio_accessible", "Extract audio")
        elif mode == self.MODE_SEARCH:
            accessible = self.t.get("start_btn_search_accessible", "Download search results")
        elif mode in {self.MODE_CHANNEL, self.MODE_PLAYLIST}:
            accessible = self.t.get("start_btn_batch_accessible", "Start batch download")
        else:
            accessible = self.t.get("start_btn_accessible", "Start download")
        self.start_btn.setText(text)
        if hasattr(self.start_btn, "setAccessibleName"):
            self.start_btn.setAccessibleName(accessible)
        self.start_btn.setToolTip(f"{accessible}  (Ctrl+Enter)")

    def _refresh_runtime_badges(self):
        """Refresh queue counters shown in the hero area."""
        pending = self._download_queue.pending_count() if hasattr(self, "_download_queue") else 0
        if hasattr(self, "hero_queue_chip"):
            self.hero_queue_chip.setText(self.t.get("hero_queue_chip", "Queue: {n}").format(n=pending))
        if hasattr(self, "log_queue_metric"):
            self.log_queue_metric.setText(self.t.get("sidebar_insight_queue", "Items in queue") + f": {pending}")
        if hasattr(self, "sidebar_queue_value"):
            self.sidebar_queue_value.setText(str(pending))
        self._refresh_queue_manager()
        self._update_pause_button_state()
        self._refresh_workspace_insights()

    def _refresh_workspace_insights(self):
        """Refresh live KPI values across sidebar and command center."""
        history_total = len(getattr(self, "download_history", []))
        enabled_count = 0
        preset_total = 0
        if hasattr(self, "sidebar_history_value"):
            self.sidebar_history_value.setText(str(history_total))
        if hasattr(self, "log_history_metric"):
            self.log_history_metric.setText(self.t.get("sidebar_insight_history", "History entries") + f": {history_total}")
        if hasattr(self, "sidebar_subs_value"):
            try:
                enabled_count = sum(1 for item in self.db.get_subscriptions() if item.get("enabled", 1))
            except Exception:
                enabled_count = 0
            self.sidebar_subs_value.setText(str(enabled_count))
        if hasattr(self, "sidebar_presets_value"):
            try:
                preset_total = len(self._load_all_presets())
            except Exception:
                preset_total = 0
            self.sidebar_presets_value.setText(str(preset_total))
        if hasattr(self, "hero_subscriptions_value"):
            self.hero_subscriptions_value.setText(str(enabled_count))
        if hasattr(self, "hero_presets_value"):
            self.hero_presets_value.setText(str(preset_total))
        self._sync_execution_metrics()

    def _sync_execution_metrics(self):
        """Mirror current execution values into the richer command center chips."""
        if hasattr(self, "log_progress_metric") and hasattr(self, "progress_label"):
            self.log_progress_metric.setText(
                self.t.get("execution_progress_metric", "Progress") + f": {self.progress_label.text()}"
            )
        if hasattr(self, "log_speed_metric") and hasattr(self, "speed_label"):
            self.log_speed_metric.setText(
                self.t.get("execution_speed_metric", "Speed") + f": {self.speed_label.text()}"
            )

    def _binary_available(self, candidate):
        if not candidate:
            return False
        try:
            if os.path.isabs(candidate):
                return Path(candidate).exists()
        except Exception:
            pass
        return shutil.which(candidate) is not None

    def _display_path(self, raw_path):
        value = str(raw_path or "").strip()
        if not value:
            return ""
        try:
            return os.path.normpath(os.path.expanduser(value))
        except Exception:
            return value

    def _set_line_edit_path(self, widget, raw_path):
        display_path = self._display_path(raw_path)
        widget.setText(display_path)
        widget.setCursorPosition(0)
        widget.setToolTip(display_path)

    def _normalize_outdir_input_display(self):
        if hasattr(self, "outdir_input"):
            self._set_line_edit_path(self.outdir_input, self.outdir_input.text())

    def _shorten_display_text(self, value, limit=72):
        value = str(value or "").strip()
        if len(value) <= limit:
            return value
        head = max(18, (limit // 2) - 2)
        tail = max(12, limit - head - 3)
        return f"{value[:head]}...{value[-tail:]}"

    def _set_status_badge(self, label, text, state):
        label.setText(text)
        if label.property("status") != state:
            label.setProperty("status", state)
            label.style().unpolish(label)
            label.style().polish(label)
        label.update()

    def _get_existing_parent_dir(self, path_obj):
        current = Path(path_obj)
        while True:
            if current.exists():
                return current
            if current.parent == current:
                return None
            current = current.parent

    def _check_output_directory(self, outdir, create=False):
        if not outdir:
            return None
        try:
            path_obj = Path(outdir).expanduser()
        except Exception:
            return self.t.get(
                "execution_issue_outdir_invalid",
                "The selected output path is invalid.",
            )

        if path_obj.exists() and not path_obj.is_dir():
            return self.t.get(
                "execution_issue_outdir_file",
                "The selected output path points to a file, not a folder.",
            )

        if create:
            try:
                path_obj.mkdir(parents=True, exist_ok=True)
            except Exception:
                return self.t.get(
                    "execution_issue_outdir_create",
                    "Aura could not create the output folder. Check the path and permissions.",
                )

        existing_parent = path_obj if path_obj.exists() else self._get_existing_parent_dir(path_obj)
        if existing_parent is not None:
            probe = existing_parent if existing_parent.is_dir() else existing_parent.parent
            if probe and not os.access(str(probe), os.W_OK):
                return self.t.get(
                    "execution_issue_outdir_write",
                    "Aura does not have permission to write to the selected output folder.",
                )
        return None

    def _format_mode_label(self, mode):
        labels = {
            self.MODE_CHANNEL: self.t.get("mode_channel", "Channel"),
            self.MODE_PLAYLIST: self.t.get("mode_playlist", "Playlist"),
            self.MODE_VIDEO: self.t.get("mode_video", "Single video"),
            self.MODE_AUDIO: self.t.get("mode_audio", "Audio only"),
            self.MODE_SEARCH: self.t.get("mode_search", "Search results"),
        }
        return labels.get(mode, mode)

    def _format_quality_label(self, mode, quality):
        if mode == self.MODE_AUDIO:
            fmt = self._get_audio_format().upper()
            bitrate = self._get_audio_bitrate()
            bitrate_text = "max" if bitrate == "max" else f"{bitrate} kbps"
            return f"{fmt} · {bitrate_text}"
        return self.t.get(
            "quality_best_video_selected_audio",
            "Best video + selected audio",
        )

    def _get_pipeline_summary(self, mode, platform_id, concurrent):
        parts = []
        if mode != self.MODE_AUDIO:
            parts.append(
                self.t.get(
                    "execution_pipeline_merge_selected_audio",
                    "Best video + selected audio merge",
                )
            )
        if self.chk_aria2c.isChecked():
            parts.append(f"aria2c ×{self.aria2c_threads_combo.currentText()}")
        else:
            parts.append(self.t.get("execution_pipeline_native", "Native downloader"))
        if concurrent > 1:
            parts.append(self.t.get("execution_plan_parallel", "Parallel ×{n}").format(n=concurrent))
        elif self.chk_restart.isChecked() and mode in (self.MODE_PLAYLIST, self.MODE_CHANNEL, self.MODE_SEARCH):
            parts.append(self.t.get("execution_plan_restart", "Restart-per-item"))
        else:
            parts.append(self.t.get("execution_plan_single", "Single process"))
        if self.chk_archive.isChecked():
            parts.append("archive")
        if self.chk_subs.isChecked():
            sub_part = self.t.get("execution_pipeline_subs", "subtitles")
            if self._get_embed_subtitles():
                sub_part += " + embed"
            parts.append(sub_part)
        if self._get_dubbed_audio_export_enabled() and mode != self.MODE_AUDIO:
            parts.append(self.t.get("execution_pipeline_dubbed_audio", "dubbed audio files"))
        if platform_id == "youtube" and self.chk_sb and self.chk_sb.isChecked():
            parts.append("SponsorBlock")
        return " · ".join(parts)

    def _get_auth_summary(self):
        method = self._get_auth_method()
        if method == "none":
            return self.t.get("execution_auth_none", "No auth")
        if method == "cookies_file":
            return self.t.get("execution_auth_file", "cookies.txt")
        return self.t.get("execution_auth_browser", "Browser auth") + f": {method}"

    def _get_parallel_worker_archive_path(self, archive_path, worker_id):
        if not archive_path or not self.chk_archive.isChecked():
            return None
        ap = Path(archive_path)
        return str(ap.parent / f"{ap.stem}_w{worker_id}{ap.suffix}")

    def _build_parallel_worker_command(self, mode, url, cookies, output_template, archive_path,
                                       worker_id, concurrent, platform_id, quality, playlist_items=None,
                                       allow_metadata_probe=True):
        worker_archive = self._get_parallel_worker_archive_path(archive_path, worker_id)
        worker_playlist_items = self._split_playlist_indices(playlist_items, worker_id, concurrent) if playlist_items else []
        if playlist_items and not worker_playlist_items:
            return None, None
        cmd = self._build_command(
            mode, url, cookies, output_template, worker_archive or archive_path,
            platform_id=platform_id, quality_override=quality,
            playlist_items=worker_playlist_items or None,
            allow_metadata_probe=allow_metadata_probe,
        )
        if not playlist_items:
            cmd.insert(-1, "--playlist-items")
            cmd.insert(-1, f"{worker_id}::{concurrent}")
        return cmd, worker_archive

    def _build_restart_command(self, mode, url, cookies, output_template, archive_path,
                               platform_id, quality, playlist_items=None, allow_metadata_probe=True):
        return self._build_command(
            mode, url, cookies, output_template, archive_path,
            max_downloads=1,
            platform_id=platform_id,
            quality_override=quality,
            playlist_items=playlist_items,
            allow_metadata_probe=allow_metadata_probe,
        )

    def _build_parallel_command_preview(self, mode, url, cookies, output_template, archive_path,
                                        concurrent, platform_id, quality, playlist_items=None):
        lines = [self.t.get("execution_parallel_preview", "Parallel launch plan")]
        worker_count = concurrent
        selected = self._coerce_playlist_indices(playlist_items)
        if selected:
            worker_count = min(concurrent, len(selected))
        for worker_id in range(1, worker_count + 1):
            cmd, _ = self._build_parallel_worker_command(
                mode, url, cookies, output_template, archive_path,
                worker_id, worker_count, platform_id, quality, playlist_items=playlist_items,
                allow_metadata_probe=False,
            )
            if not cmd:
                continue
            lines.append(f"W{worker_id}: {subprocess.list2cmdline(cmd)}")
        return "\n".join(lines)

    def _build_restart_command_preview(self, mode, url, cookies, output_template, archive_path,
                                       platform_id, quality, playlist_items=None):
        restart_cmd = self._build_restart_command(
            mode, url, cookies, output_template, archive_path,
            platform_id, quality, playlist_items=playlist_items,
            allow_metadata_probe=False,
        )
        return "\n".join([
            self.t.get("execution_restart_preview", "Restart-per-item launch plan"),
            self.t.get("execution_restart_note", "The process is relaunched after each finished item until the archive is exhausted."),
            "",
            subprocess.list2cmdline(restart_cmd),
        ])

    def _schedule_execution_blueprint_refresh(self, *_args):
        if hasattr(self, "_execution_preview_timer"):
            self._execution_preview_timer.start()

    def _wire_execution_blueprint_inputs(self):
        signal_groups = [
            (getattr(self, "url_input", None), "textChanged"),
            (getattr(self, "outdir_input", None), "textChanged"),
            (getattr(self, "cookies_input", None), "textChanged"),
            (getattr(self, "proxy_input", None), "textChanged"),
            (getattr(self, "auth_combo", None), "currentIndexChanged"),
            (getattr(self, "container_combo", None), "currentIndexChanged"),
            (getattr(self, "video_codec_combo", None), "currentIndexChanged"),
            (getattr(self, "playback_target_combo", None), "currentIndexChanged"),
            (getattr(self, "speed_limit_unit", None), "currentIndexChanged"),
            (getattr(self, "speed_limit_input", None), "textChanged"),
            (getattr(self, "concurrent_combo", None), "currentIndexChanged"),
            (getattr(self, "search_limit_combo", None), "currentIndexChanged"),
            (getattr(self, "sub_lang_combo", None), "currentIndexChanged"),
            (getattr(self, "sub_format_combo", None), "currentIndexChanged"),
            (getattr(self, "audio_lang_combo", None), "currentIndexChanged"),
            (getattr(self, "dubbed_audio_mode_combo", None), "currentIndexChanged"),
            (getattr(self, "dubbed_audio_format_combo", None), "currentIndexChanged"),
            (getattr(self, "dubbed_audio_languages_input", None), "textChanged"),
            (getattr(self, "meta_lang_combo", None), "currentIndexChanged"),
            (getattr(self, "sb_action_combo", None), "currentIndexChanged"),
            (getattr(self, "aria2c_threads_combo", None), "currentIndexChanged"),
            (getattr(self, "chk_archive", None), "toggled"),
            (getattr(self, "chk_subs", None), "toggled"),
            (getattr(self, "chk_embed_subs", None), "toggled"),
            (getattr(self, "chk_all_audio_tracks", None), "toggled"),
            (getattr(self, "chk_dubbed_audio", None), "toggled"),
            (getattr(self, "chk_immersive_safe", None), "toggled"),
            (getattr(self, "chk_aria2c", None), "toggled"),
            (getattr(self, "chk_restart", None), "toggled"),
            (getattr(self, "chk_reverse", None), "toggled"),
            (getattr(self, "chk_nonumber", None), "toggled"),
            (getattr(self, "chk_sb", None), "toggled"),
            (getattr(self, "chk_sb_keyframes", None), "toggled"),
        ]
        for obj, signal_name in signal_groups:
            signal = getattr(obj, signal_name, None) if obj is not None else None
            if signal is not None:
                signal.connect(self._schedule_execution_blueprint_refresh)

        for group_name in ("mode_buttons", "quality_buttons", "format_buttons", "bitrate_buttons"):
            group = getattr(self, group_name, None)
            if group is not None:
                group.buttonToggled.connect(self._schedule_execution_blueprint_refresh)

        for checks in (getattr(self, "sb_cat_checks", {}),):
            for checkbox in checks.values():
                checkbox.toggled.connect(self._schedule_execution_blueprint_refresh)

    def _evaluate_execution_readiness(self, params=None, platform_id=None, quality_override=None,
                                      allow_blocking_probes=False):
        params = params or {
            "mode": self._get_mode(),
            "url": self.url_input.text().strip(),
            "outdir": self.outdir_input.text().strip(),
            "cookies": self.cookies_input.text().strip(),
        }
        mode = params["mode"]
        url = params["url"].strip()
        outdir = params["outdir"].strip()
        cookies = params.get("cookies", "").strip()
        platform_id, pc = self._resolve_platform_context(platform_id)
        quality = quality_override or self._get_quality()
        issues = []
        warnings = []

        if not url:
            issues.append(self.t.get("execution_issue_url", "Add a URL before starting the run."))
        if not outdir:
            issues.append(self.t.get("execution_issue_outdir", "Choose an output folder before starting the run."))
        else:
            outdir_issue = self._check_output_directory(outdir)
            if outdir_issue:
                issues.append(outdir_issue)

        ytdlp_bin = getattr(self, "_ytdlp_bin", find_binary("yt-dlp"))
        if not self._binary_available(ytdlp_bin):
            issues.append(self.t.get("execution_issue_ytdlp", "yt-dlp is not available in PATH."))

        auth_method = self._get_auth_method()
        if auth_method == "cookies_file":
            if not cookies:
                issues.append(self.t.get("execution_issue_cookies_missing", "Authorization is set to cookies.txt, but no file is selected."))
            elif not os.path.isfile(cookies):
                issues.append(self.t.get("execution_issue_cookies_not_found", "The selected cookies.txt file does not exist."))

        ffmpeg_needed = []
        if mode == self.MODE_AUDIO:
            ffmpeg_needed.append(self.t.get("execution_issue_ffmpeg_audio", "FFmpeg is required for audio extraction."))
        if mode != self.MODE_AUDIO:
            ffmpeg_needed.append(
                self.t.get(
                    "execution_issue_ffmpeg_merge",
                    "FFmpeg is required to merge the best video stream with the selected audio track.",
                )
            )
        if self._get_dubbed_audio_export_enabled() and mode != self.MODE_AUDIO:
            ffmpeg_needed.append(self.t.get("execution_issue_ffmpeg_dubbed_audio", "FFmpeg is required to export separate dubbed audio files."))
        if hasattr(self, "container_combo") and self.container_combo.currentIndex() in (1, 2):
            ffmpeg_needed.append(self.t.get("execution_issue_ffmpeg_remux", "FFmpeg is required for forced MP4/MKV remux."))
        if self.chk_subs.isChecked() and self._get_embed_subtitles() and mode != self.MODE_AUDIO:
            ffmpeg_needed.append(
                self.t.get("execution_issue_ffmpeg_embed_subs", "FFmpeg is required to embed subtitles into the final video.")
            )
        if platform_id == "youtube" and self.chk_sb and self.chk_sb.isChecked() and self._get_sb_action() == "remove":
            ffmpeg_needed.append(self.t.get("execution_issue_ffmpeg_sponsorblock", "FFmpeg is required to remove SponsorBlock segments."))

        ffmpeg_bin = getattr(self, "_ffmpeg_bin", find_binary("ffmpeg"))
        if ffmpeg_needed and not self._binary_available(ffmpeg_bin):
            issues.extend(ffmpeg_needed)

        if self.chk_aria2c.isChecked():
            aria2c_bin = getattr(self, "_aria2c_bin", find_binary("aria2c"))
            if not self._binary_available(aria2c_bin):
                issues.append(self.t.get("execution_issue_aria2c_missing", "aria2c acceleration is enabled, but aria2c is not installed."))

        if pc.get("needs_nodejs", False):
            node_bin = find_binary("node")
            if not self._binary_available(node_bin if node_bin != "node" else "node"):
                warnings.append(self.t.get("execution_warn_node_missing", "Node.js is recommended for the most reliable YouTube extraction path."))

        if self._get_dubbed_audio_export_enabled() and mode == self.MODE_AUDIO:
            warnings.append(self.t.get("dubbed_audio_disabled_in_audio_mode", "Separate dubbed audio export is disabled in Audio mode."))
        if self._get_dubbed_audio_export_enabled():
            selection_mode = self._get_dubbed_audio_mode()
            if selection_mode == "custom" and not self._split_language_codes(self._get_dubbed_audio_languages_text()):
                issues.append(self.t.get("dubbed_audio_custom_missing", "Enter one or more language codes for custom dubbed audio export."))
            elif selection_mode == "all" and mode != self.MODE_VIDEO:
                issues.append(self.t.get("dubbed_audio_all_single_only", "All available tracks can be detected automatically only for single video mode."))

        selected_audio_lang = self._get_audio_language()
        if (
            allow_blocking_probes
            and mode == self.MODE_VIDEO
            and selected_audio_lang not in {"", "any", "default", "original"}
            and url
        ):
            runtime_settings = self._collect_runtime_settings_snapshot()
            media_info, _effective_runtime_settings, _used_audio_fallback = self._resolve_media_info_for_requested_audio_language(
                url,
                cookies=cookies,
                platform_id=platform_id,
                runtime_settings=runtime_settings,
                log_errors=False,
            )
            if self._selected_audio_language_missing(selected_audio_lang, media_info=media_info):
                issues.append(
                    self.t.get(
                        "execution_issue_audio_language_unavailable",
                        "The selected audio language is not available for this video.",
                    )
                )

        source = self._get_audio_source()
        is_multi = mode in (self.MODE_PLAYLIST, self.MODE_CHANNEL, self.MODE_SEARCH)
        if not is_multi and mode == self.MODE_AUDIO:
            is_multi = source in (self.AUDIO_SOURCE_CHANNEL, self.AUDIO_SOURCE_PLAYLIST)
        try:
            concurrent = int(self.concurrent_combo.currentText()) if is_multi else 1
        except (ValueError, AttributeError):
            concurrent = 1

        normalized_url = self.normalize_url(url, mode, platform_id=platform_id) if url else ""
        output_template = self._get_output_template(outdir, mode, platform_id=platform_id) if outdir else ""
        archive_path = get_settings_dir() / f"archive_{platform_id}.txt"

        preview_text = self.t.get("execution_preview_empty", "Set a URL and output folder to preview the exact yt-dlp launch plan.")
        if url and outdir and not issues:
            if self.chk_restart.isChecked() and mode in (self.MODE_PLAYLIST, self.MODE_CHANNEL, self.MODE_SEARCH):
                preview_text = self._build_restart_command_preview(
                    mode, normalized_url, cookies, output_template, archive_path,
                    platform_id, quality,
                )
            elif concurrent > 1 and is_multi:
                preview_text = self._build_parallel_command_preview(
                    mode, normalized_url, cookies, output_template, archive_path,
                    concurrent, platform_id, quality,
                )
            else:
                cmd = self._build_command(
                    mode, normalized_url, cookies, output_template, archive_path,
                    platform_id=platform_id,
                    quality_override=quality,
                    allow_metadata_probe=False,
                )
                preview_text = subprocess.list2cmdline(cmd)
            if self._get_download_all_audio_tracks() and mode == self.MODE_VIDEO:
                preview_text += "\n\n" + self.t.get(
                    "all_audio_tracks_preview_probe",
                    "Aura will detect one best separate audio stream per language and keep them together in an MKV when possible.",
                )
            if self._get_dubbed_audio_export_enabled() and mode != self.MODE_AUDIO:
                preview_text += "\n\n" + self.t.get("dubbed_audio_preview_probe", "All available dubbed audio tracks will be detected and exported after the main video download.")

        if issues:
            readiness_label = self.t.get("execution_preflight_blocked", "Blocked")
            summary = self.t.get("execution_blocked_summary", "Resolve the execution blockers before starting the run.")
        elif warnings:
            readiness_label = self.t.get("execution_preflight_review", "Review")
            summary = warnings[0]
        else:
            readiness_label = self.t.get("execution_preflight_ready", "Ready")
            summary = self.t.get(
                "execution_ready_summary_detailed",
                "Ready to launch {mode} from {platform} into {outdir}.",
            ).format(
                mode=self._format_mode_label(mode),
                platform=get_platform_name(platform_id, self.lang),
                outdir=self._shorten_display_text(outdir, 88),
            )

        return {
            "mode": mode,
            "platform_id": platform_id,
            "quality": quality,
            "url": normalized_url,
            "outdir": outdir,
            "preview_text": preview_text,
            "issues": issues,
            "warnings": warnings,
            "summary": summary,
            "readiness_label": readiness_label,
            "concurrent": concurrent,
            "output_template": output_template,
        }

    def _refresh_execution_blueprint(self):
        if not hasattr(self, "command_preview_box"):
            return

        live_mode = self._runtime_state == "running" and bool(self._live_command_preview)
        platform_id = self._active_download_platform if live_mode else self.platform
        quality = self._active_download_quality if live_mode else self._get_quality()
        params = {
            "mode": self._active_download_mode if live_mode and self._active_download_mode else self._get_mode(),
            "url": self._active_download_url if live_mode else self.url_input.text().strip(),
            "outdir": self._active_download_outdir if live_mode else self.outdir_input.text().strip(),
            "cookies": self._active_download_cookies if live_mode else self.cookies_input.text().strip(),
        }
        blueprint = self._evaluate_execution_readiness(
            params=params,
            platform_id=platform_id,
            quality_override=quality,
            allow_blocking_probes=False,
        )

        preview_title = self._live_command_title if live_mode and self._live_command_title else (
            self.t.get("execution_live_command", "Live command")
            if live_mode else self.t.get("execution_draft_command", "Draft command")
        )
        preview_text = self._live_command_preview if live_mode and self._live_command_preview else blueprint["preview_text"]
        preview_text = f"{preview_title}\n\n{preview_text}" if preview_text else preview_title

        if preview_text != self._current_preview_text:
            self.command_preview_box.setPlainText(preview_text)
            self._current_preview_text = preview_text

        self.execution_summary_label.setText(blueprint["summary"])
        self.execution_summary_label.setToolTip(blueprint["summary"])
        self.execution_preflight_chip.setText(blueprint["readiness_label"])
        if blueprint["issues"]:
            chip_fg = "#ffffff"
            chip_bg = self.COLORS["red"]
            chip_border = self.COLORS["red_hover"]
        elif blueprint["warnings"]:
            chip_fg = "#ffffff" if self.theme_id != "light" else self.COLORS["text"]
            chip_bg = self.COLORS["accent2"]
            chip_border = self.COLORS["accent2"]
        else:
            chip_fg = "#ffffff"
            chip_bg = self.COLORS["green"]
            chip_border = self.COLORS["green_hover"]
        self.execution_preflight_chip.setStyleSheet(
            f"background: {chip_bg}; color: {chip_fg}; border: 1px solid {chip_border}; "
            "border-radius: 11px; padding: 6px 10px; font-size: 8.6pt; font-weight: 800;"
        )
        plan_text = (
            self.t.get("execution_plan_label", "Plan") + ": " +
            f"{get_platform_name(blueprint['platform_id'], self.lang)} · {self._format_mode_label(blueprint['mode'])} · {self._format_quality_label(blueprint['mode'], blueprint['quality'])}"
        )
        self.execution_plan_chip.setText(self._shorten_display_text(plan_text, 82))
        self.execution_plan_chip.setToolTip(plan_text)
        destination_text = blueprint["outdir"] or self.t.get("execution_destination_placeholder", "Choose output folder")
        destination_label = self.t.get("execution_destination_label", "Output") + f": {destination_text}"
        self.execution_destination_chip.setText(self._shorten_display_text(destination_label, 82))
        self.execution_destination_chip.setToolTip(destination_label)
        pipeline_text = (
            self.t.get("execution_pipeline_label", "Pipeline") + ": " +
            self._get_pipeline_summary(blueprint["mode"], blueprint["platform_id"], blueprint["concurrent"])
        )
        self.execution_pipeline_chip.setText(self._shorten_display_text(pipeline_text, 82))
        self.execution_pipeline_chip.setToolTip(pipeline_text)
        auth_text = self.t.get("execution_auth_label", "Auth") + ": " + self._get_auth_summary()
        self.execution_auth_chip.setText(self._shorten_display_text(auth_text, 82))
        self.execution_auth_chip.setToolTip(auth_text)

        notes = blueprint["issues"] or blueprint["warnings"]
        self.execution_note_label.setText("\n".join(f"• {note}" for note in notes) if notes else "")
        self.execution_preflight_chip.setToolTip("\n".join(notes) if notes else blueprint["summary"])
        self.execution_note_label.setStyleSheet(
            f"color: {self.COLORS['red'] if blueprint['issues'] else self.COLORS['text_hint']}; font-size: 8.8pt;"
        )

    def _copy_command_preview(self):
        if not hasattr(self, "command_preview_box"):
            return
        text = self.command_preview_box.toPlainText().strip()
        if not text:
            return
        QApplication.clipboard().setText(text)
        self.log(self.t.get("execution_command_copied", "Execution blueprint copied to clipboard"))

    def _set_live_command_preview(self, title, preview_text):
        self._live_command_title = title
        self._live_command_preview = preview_text
        self._current_preview_text = ""
        self._refresh_execution_blueprint()

    def _clear_live_command_preview(self):
        self._live_command_title = ""
        self._live_command_preview = ""
        self._current_preview_text = ""
        self._refresh_execution_blueprint()

    def _resolve_settings_candidate(self, raw_value):
        """Resolve pointer text to a concrete settings directory."""
        if not raw_value:
            return None
        raw_value = str(raw_value).strip()
        if not raw_value or raw_value.lower() == "default":
            return Path.home() / SETTINGS_FOLDER_NAME
        base = Path(raw_value)
        return base if base.name == SETTINGS_FOLDER_NAME else (base / SETTINGS_FOLDER_NAME)

    def _collect_reset_targets(self):
        """Collect settings directories and files that must be removed on full reset."""
        dirs_to_nuke = set()
        files_to_nuke = set()

        def register_settings_path(path_obj):
            if not path_obj:
                return
            try:
                if path_obj.exists() and not path_obj.is_dir():
                    files_to_nuke.add(path_obj)
                else:
                    dirs_to_nuke.add(path_obj)
            except Exception:
                dirs_to_nuke.add(path_obj)

        pointer_candidates = [get_pointer_file(), _get_legacy_pointer()]
        for pointer in pointer_candidates:
            files_to_nuke.add(pointer)
            try:
                if pointer.exists():
                    resolved = self._resolve_settings_candidate(pointer.read_text(encoding="utf-8", errors="ignore"))
                    if resolved:
                        register_settings_path(resolved)
            except Exception:
                pass

        try:
            register_settings_path(get_settings_dir())
        except Exception:
            pass
        register_settings_path(Path.home() / SETTINGS_FOLDER_NAME)

        target_patterns = [
            "config.json", "config.json.bak",
            "general.json", "general.json.bak",
            "yt-dlp.conf", "yt-dlp.conf.bak",
            "aura_downloads.db", "aura_downloads.db-shm", "aura_downloads.db-wal",
            "history_*.json", "history_*.bak",
            "presets_*.json", "presets_*.bak",
            "archive_*.txt", "archive_*.bak",
            "log_*.txt", "log_*.bak",
            "cookies_*.txt", "cookies_*.bak",
            "*.tmp",
        ]

        for directory in list(dirs_to_nuke):
            try:
                if not directory.exists():
                    continue
                for pattern in target_patterns:
                    for path in directory.glob(pattern):
                        if path.is_dir():
                            dirs_to_nuke.add(path)
                        else:
                            files_to_nuke.add(path)
            except Exception:
                pass

        return dirs_to_nuke, files_to_nuke

    def _program_save_patterns(self):
        """Known save-file patterns that may be safely removed on full reset."""
        return [
            "config.json", "config.json.bak",
            "config_*.json", "config_*.bak",
            "general.json", "general.json.bak",
            "yt-dlp.conf", "yt-dlp.conf.bak",
            "aura_downloads.db", "aura_downloads.db-shm", "aura_downloads.db-wal",
            "history_*.json", "history_*.bak",
            "presets_*.json", "presets_*.bak",
            "archive_*.txt", "archive_*.bak",
            "log_*.txt", "log_*.bak",
            "cookies_*.txt", "cookies_*.bak",
            "*.tmp",
        ]

    def _find_everything_cli(self):
        """Return Everything CLI path if installed and accessible via PATH."""
        for candidate in ("es.exe", "es"):
            path = find_binary(candidate)
            if path and path != candidate:
                return path
        return None

    def _is_safe_program_save_path(self, path_obj):
        """Allow deletion only for known save files inside program settings folders."""
        try:
            parts_lower = [part.lower() for part in path_obj.parts]
            if SETTINGS_FOLDER_NAME.lower() not in parts_lower:
                return False
            filename = path_obj.name.lower()
            for pattern in self._program_save_patterns():
                if fnmatch.fnmatch(filename, pattern.lower()):
                    return True
        except Exception:
            return False
        return False

    def _is_safe_program_save_dir(self, dir_path):
        """Allow directory deletion only when it contains program save data only."""
        try:
            if not dir_path.is_dir() or dir_path.name.lower() != SETTINGS_FOLDER_NAME.lower():
                return False
            for child in dir_path.rglob("*"):
                if child.is_dir():
                    continue
                if not self._is_safe_program_save_path(child):
                    return False
        except Exception:
            return False
        return True

    def _collect_everything_reset_targets(self):
        """Use Everything CLI plus a real drive walk to find save files across the machine."""
        dir_targets = set()
        file_targets = set()
        es_path = self._find_everything_cli()
        used_any_scan = False

        if es_path:
            self.log(self.t.get("reset_everything_index_stage", "  🔎 Everything index scan..."))
            used_any_scan = True
            queries = [f"\\{SETTINGS_FOLDER_NAME}\\ {pattern}" for pattern in self._program_save_patterns()]
            queries.append(f"folder: wfn:{SETTINGS_FOLDER_NAME}")

            for query in queries:
                try:
                    result = subprocess.run(
                        [es_path, "-n", "4000", query],
                        capture_output=True,
                        text=True,
                        encoding="utf-8",
                        errors="surrogateescape",
                        env=_get_subprocess_env(),
                        creationflags=SUBPROCESS_FLAGS,
                        timeout=10,
                    )
                except Exception as exc:
                    self.log(f"    {exc}")
                    continue

                if result.returncode not in (0, 1):
                    output = _fix_encoding((result.stdout or "") + (result.stderr or "")).strip()
                    if output:
                        self.log(f"    {output}")
                    continue

                for raw_line in (result.stdout or "").splitlines():
                    line = _fix_encoding(raw_line).strip().strip('"')
                    if not line:
                        continue
                    found = Path(line)
                    try:
                        if found.is_dir():
                            if self._is_safe_program_save_dir(found):
                                dir_targets.add(found)
                            continue
                        if not self._is_safe_program_save_path(found):
                            continue
                        file_targets.add(found)
                        for parent in found.parents:
                            if parent.name.lower() == SETTINGS_FOLDER_NAME.lower():
                                if self._is_safe_program_save_dir(parent):
                                    dir_targets.add(parent)
                                break
                    except Exception:
                        continue

        deep_dirs, deep_files = self._collect_deep_reset_targets()
        dir_targets.update(deep_dirs)
        file_targets.update(deep_files)
        used_any_scan = used_any_scan or bool(deep_dirs or deep_files)
        return dir_targets, file_targets, used_any_scan

    def _iter_scan_roots(self):
        """Yield local roots that should be deeply scanned for settings folders."""
        if os.name != "nt":
            yield Path("/")
            return
        mask = ctypes.windll.kernel32.GetLogicalDrives()
        get_drive_type = ctypes.windll.kernel32.GetDriveTypeW
        for idx in range(26):
            if not (mask & (1 << idx)):
                continue
            drive = f"{chr(65 + idx)}:\\"
            try:
                drive_type = get_drive_type(drive)
            except Exception:
                drive_type = 0
            if drive_type in (2, 3, 4):
                yield Path(drive)

    def _collect_deep_reset_targets(self, roots=None):
        """Walk every available local root and find safe program save folders."""
        dir_targets = set()
        file_targets = set()
        roots = list(roots) if roots is not None else list(self._iter_scan_roots())
        self.log(self.t.get("reset_everything_walk_stage", "  🧭 Deep drive scan: checking every accessible folder on every local disk..."))

        for root in roots:
            self.log(self.t.get("reset_everything_walk_root", "    • Scanning {root}").format(root=root))
            try:
                for current_root, dirs, _files in os.walk(root, topdown=True, onerror=lambda _e: None, followlinks=False):
                    if SETTINGS_FOLDER_NAME in dirs:
                        candidate = Path(current_root) / SETTINGS_FOLDER_NAME
                        if self._is_safe_program_save_dir(candidate):
                            dir_targets.add(candidate)
                            for pattern in self._program_save_patterns():
                                for path in candidate.glob(pattern):
                                    if path.is_file():
                                        file_targets.add(path)
            except Exception as exc:
                self.log(f"    {exc}")

        return dir_targets, file_targets

    def _build_section_mode(self, layout, t, C):
        """Build UI: MODE."""
        mode_group = QGroupBox(t["mode_label"])
        mode_group.setObjectName("featureCard")
        mode_layout = QHBoxLayout(mode_group)
        self._add_section_note(mode_layout, t.get("section_mode_hint", "Choose what exactly should be downloaded from the current link."))
        self.mode_buttons = QButtonGroup(self)
        
        modes = [
            (self.MODE_CHANNEL, "mode_channel"),
            (self.MODE_PLAYLIST, "mode_playlist"),
            (self.MODE_VIDEO, "mode_video"),
            (self.MODE_AUDIO, "mode_audio"),
            (self.MODE_SEARCH, "mode_search"),
        ]
        
        # Filter modes by platform capabilities
        available_modes = []
        for mval, mkey in modes:
            if mval == self.MODE_CHANNEL and not self.pc.get("has_channels", True):
                continue
            if mval == self.MODE_PLAYLIST and not self.pc.get("has_playlists", True):
                continue
            if mval == self.MODE_SEARCH and not self.pc.get("search_prefix"):
                continue
            available_modes.append((mval, mkey))
        
        # Validate saved mode against available options
        available_vals = [m[0] for m in available_modes]
        effective_mode = self._mode if self._mode in available_vals else self.MODE_VIDEO
        
        for mval, mkey in available_modes:
            rb = QRadioButton(t[mkey])
            rb.setProperty("mode_value", mval)
            self.mode_buttons.addButton(rb)
            mode_layout.addWidget(rb)
            if mval == effective_mode:
                rb.setChecked(True)

        self.search_limit_lbl = QLabel(t.get("search_limit_label", "Results:"))
        self.search_limit_lbl.setVisible(effective_mode == self.MODE_SEARCH)
        mode_layout.addWidget(self.search_limit_lbl)

        self.search_limit_combo = QComboBox()
        self.search_limit_combo.setObjectName("compactCombo")
        for value in ("10", "25", "50", "100"):
            self.search_limit_combo.addItem(value, value)
        self.search_limit_combo.setCurrentText(
            self._search_results_limit if self._search_results_limit in ("10", "25", "50", "100") else "25"
        )
        self.search_limit_combo.setMinimumWidth(76)
        self.search_limit_combo.setToolTip(
            t.get("search_limit_hint", "How many search results should Aura queue for this run.")
        )
        self.search_limit_combo.setVisible(effective_mode == self.MODE_SEARCH)
        mode_layout.addWidget(self.search_limit_combo)

        self.mode_buttons.buttonClicked.connect(self._on_mode_change)
        mode_layout.addStretch()
        layout.addWidget(mode_group)
        self._register_section("mode", mode_group)
        
    def _build_section_url_examples(self, layout, t, C):
        """Build UI: URL EXAMPLES (visible hint)."""
        example_card = QFrame()
        example_card.setObjectName("exampleCard")
        example_layout = QVBoxLayout(example_card)
        example_layout.setContentsMargins(14, 12, 14, 12)
        example_layout.setSpacing(4)

        title = QLabel(t.get("url_examples_title", "URL examples:"))
        title.setObjectName("exampleTitle")
        example_layout.addWidget(title)

        self.url_examples_label = QLabel()
        self.url_examples_label.setObjectName("exampleText")
        self.url_examples_label.setWordWrap(True)
        self._configure_wrap_label(self.url_examples_label)
        example_layout.addWidget(self.url_examples_label)
        self._update_url_examples()
        layout.addWidget(example_card)
        
    def _build_section_quality(self, layout, t, C):
        """Build UI: QUALITY (grid layout — shown in video modes)."""
        self.quality_group = QGroupBox(t["video_quality_label"])
        self.quality_group.setObjectName("featureCard")
        q_layout = QVBoxLayout(self.quality_group)
        q_layout.setSpacing(8)
        self._add_section_note(q_layout, t.get("section_quality_hint", "Select the preferred visual quality or keep maximum quality for the best source available."))
        q_grid = QGridLayout()
        q_grid.setSpacing(6)
        self.quality_buttons = QButtonGroup(self)
        
        num_cols = 5
        for idx, (q_val, q_key, _) in enumerate(VIDEO_QUALITIES):
            rb = QRadioButton(t[q_key])
            rb.setProperty("q_value", q_val)
            self.quality_buttons.addButton(rb)
            q_grid.addWidget(rb, idx // num_cols, idx % num_cols)
            if q_val == self._quality:
                rb.setChecked(True)
        q_layout.addLayout(q_grid)
        
        layout.addWidget(self.quality_group)
        self._register_section("quality", self.quality_group)
        
    def _build_section_audio_settings(self, layout, t, C):
        """Build UI: AUDIO SETTINGS (shown only in audio mode)."""
        self.audio_group = QGroupBox(t.get("audio_format_label", "🎵 Audio"))
        self.audio_group.setObjectName("featureCard")
        a_layout = QVBoxLayout(self.audio_group)
        a_layout.setSpacing(8)
        self._add_section_note(a_layout, t.get("section_audio_hint", "Configure extraction format, bitrate, and source when downloading audio-only media."))
        
        # Format row (horizontal)
        fmt_row = QHBoxLayout()
        self.format_buttons = QButtonGroup(self)
        for fmt in AUDIO_FORMATS:
            rb = QRadioButton(fmt.upper())
            rb.setProperty("fmt_value", fmt)
            self.format_buttons.addButton(rb)
            fmt_row.addWidget(rb)
            if fmt == self._audio_format:
                rb.setChecked(True)
        self.format_buttons.buttonClicked.connect(self._on_format_change)
        fmt_row.addStretch()
        a_layout.addLayout(fmt_row)
        
        # Bitrate row (label + buttons in one container)
        self.bitrate_label = QLabel(t["audio_bitrate_label"])
        a_layout.addWidget(self.bitrate_label)
        self.bitrate_buttons = QButtonGroup(self)
        self.bitrate_widget = QWidget()
        br_layout = QHBoxLayout(self.bitrate_widget)
        br_layout.setContentsMargins(0, 0, 0, 0)
        br_layout.setSpacing(8)
        for b_val, b_key, _ in AUDIO_BITRATES:
            rb = QRadioButton(t[b_key])
            rb.setProperty("br_value", b_val)
            self.bitrate_buttons.addButton(rb)
            br_layout.addWidget(rb)
            if b_val == self._audio_bitrate:
                rb.setChecked(True)
        br_layout.addStretch()
        a_layout.addWidget(self.bitrate_widget)
        
        # Audio language
        if self.pc.get("has_audio_lang", False):
            self.audio_lang_combo = QComboBox()
            self.audio_lang_combo.setMinimumWidth(150)
            self.audio_lang_combo.setSizeAdjustPolicy(QComboBox.AdjustToContentsOnFirstShow)
            for code, lkey in self._audio_language_choices():
                self.audio_lang_combo.addItem(t.get(lkey, lkey), code)
            self.audio_lang_combo.currentIndexChanged.connect(self._on_audio_lang_change)
        else:
            self.audio_lang_combo = None
        
        # Audio source (horizontal row)
        a_layout.addWidget(self._ui_sep())
        src_row = QHBoxLayout()
        src_row.addWidget(QLabel(t.get("audio_source_label", "📥 Source:")))
        self.source_buttons = QButtonGroup(self)
        
        # Only show audio sources that the platform actually supports
        audio_sources = [(self.AUDIO_SOURCE_VIDEO, "audio_source_video")]
        if self.pc.get("has_playlists", False):
            audio_sources.append((self.AUDIO_SOURCE_PLAYLIST, "audio_source_playlist"))
        if self.pc.get("has_channels", False):
            audio_sources.append((self.AUDIO_SOURCE_CHANNEL, "audio_source_channel"))
        
        # Validate saved source against available options
        available_vals = [s[0] for s in audio_sources]
        effective_source = self._audio_source if self._audio_source in available_vals else self.AUDIO_SOURCE_VIDEO
        
        for src_val, src_key in audio_sources:
            rb = QRadioButton(t.get(src_key, src_key))
            rb.setProperty("src_value", src_val)
            self.source_buttons.addButton(rb)
            src_row.addWidget(rb)
            if src_val == effective_source:
                rb.setChecked(True)
        self.source_buttons.buttonClicked.connect(self._on_source_change)
        src_row.addStretch()
        a_layout.addLayout(src_row)
        
        layout.addWidget(self.audio_group)
        
    def _build_section_audio_language(self, layout, t, C):
        """Build UI: AUDIO LANGUAGE (visible in ALL modes when platform supports it)."""
        if self.audio_lang_combo:
            self.audio_lang_row = QWidget()
            alr_layout = QVBoxLayout(self.audio_lang_row)
            alr_layout.setContentsMargins(4, 2, 4, 2)
            alr_layout.setSpacing(6)

            top_row = QHBoxLayout()
            top_row.setContentsMargins(0, 0, 0, 0)
            top_row.setSpacing(8)
            self.audio_language_label_widget = QLabel(t["audio_language_label"])
            top_row.addWidget(self.audio_language_label_widget)
            top_row.addWidget(self.audio_lang_combo)
            self.chk_all_audio_tracks = QCheckBox(
                t.get("all_audio_tracks_label", "All audio tracks (video)")
            )
            self.chk_all_audio_tracks.setChecked(self._download_all_audio_tracks)
            self.chk_all_audio_tracks.setToolTip(
                t.get(
                    "all_audio_tracks_fixed_pipeline_hint",
                    "Keep one best audio track per language inside the final MKV when the source exposes separate audio streams.",
                )
            )
            self.chk_all_audio_tracks.toggled.connect(self._refresh_download_ux_state)
            top_row.addWidget(self.chk_all_audio_tracks)
            top_row.addStretch()
            alr_layout.addLayout(top_row)

            self.audio_lang_hint_label = QLabel(t.get("audio_language_hint", ""))
            self.audio_lang_hint_label.setObjectName("hintLabel")
            self.audio_lang_hint_label.setWordWrap(True)
            self._configure_wrap_label(self.audio_lang_hint_label)
            alr_layout.addWidget(self.audio_lang_hint_label)
            self.audio_lang_combo.currentIndexChanged.connect(self._refresh_download_ux_state)
            layout.addWidget(self.audio_lang_row)
        else:
            self.chk_all_audio_tracks = None

    def _build_section_dubbed_audio(self, layout, t, C):
        """Build UI: separate dubbed audio exports for video downloads."""
        if not self.pc.get("has_audio_lang", False):
            self.dubbed_audio_group = None
            return

        group = QGroupBox(t.get("dubbed_audio_label", "🎧 Dubbed audio files"))
        group.setObjectName("featureCard")
        group_layout = QVBoxLayout(group)
        group_layout.setSpacing(8)
        self._add_section_note(
            group_layout,
            t.get(
                "section_dubbed_audio_hint",
                "Save translated or dubbed audio tracks as separate audio files after the main video download finishes.",
            ),
        )

        top_row = QHBoxLayout()
        top_row.setSpacing(8)

        self.chk_dubbed_audio = QCheckBox(t.get("dubbed_audio_toggle", "Export separate dubbed audio files"))
        self.chk_dubbed_audio.setChecked(self._dubbed_audio_export)
        self.chk_dubbed_audio.toggled.connect(self._on_dubbed_audio_toggle)
        top_row.addWidget(self.chk_dubbed_audio)

        top_row.addWidget(QLabel(t.get("dubbed_audio_mode_label", "Tracks:")))
        self.dubbed_audio_mode_combo = QComboBox()
        self.dubbed_audio_mode_combo.setObjectName("compactCombo")
        self.dubbed_audio_mode_combo.addItem(t.get("dubbed_audio_mode_selected", "Current / default"), "selected")
        self.dubbed_audio_mode_combo.addItem(t.get("dubbed_audio_mode_custom", "Custom list"), "custom")
        self.dubbed_audio_mode_combo.addItem(t.get("dubbed_audio_mode_all", "All available"), "all")
        self._set_combo_by_data(self.dubbed_audio_mode_combo, self._dubbed_audio_mode)
        self.dubbed_audio_mode_combo.currentIndexChanged.connect(self._on_dubbed_audio_toggle)
        top_row.addWidget(self.dubbed_audio_mode_combo)

        top_row.addWidget(QLabel(t.get("dubbed_audio_format_label", "Format:")))
        self.dubbed_audio_format_combo = QComboBox()
        self.dubbed_audio_format_combo.setObjectName("compactCombo")
        for fmt in ("best", "m4a", "mp3", "opus", "flac", "wav"):
            self.dubbed_audio_format_combo.addItem(fmt.upper() if fmt != "best" else t.get("dubbed_audio_format_best", "Best"), fmt)
        self._set_combo_by_data(self.dubbed_audio_format_combo, self._dubbed_audio_format)
        top_row.addWidget(self.dubbed_audio_format_combo)
        top_row.addStretch()
        group_layout.addLayout(top_row)

        bottom_row = QHBoxLayout()
        bottom_row.setSpacing(8)
        bottom_row.addWidget(QLabel(t.get("dubbed_audio_custom_label", "Languages:")))
        self.dubbed_audio_languages_input = QLineEdit()
        self.dubbed_audio_languages_input.setObjectName("compactField")
        self.dubbed_audio_languages_input.setPlaceholderText(t.get("dubbed_audio_custom_placeholder", "en, es-419, ja"))
        self.dubbed_audio_languages_input.setText(self._dubbed_audio_languages)
        bottom_row.addWidget(self.dubbed_audio_languages_input, 1)

        self.dubbed_audio_hint_label = QLabel(
            t.get(
                "dubbed_audio_hint",
                "Use the audio language selector for one track, enter comma-separated codes for several tracks, or let Aura detect all available languages for single videos.",
            )
        )
        self.dubbed_audio_hint_label.setObjectName("hintLabel")
        self.dubbed_audio_hint_label.setWordWrap(True)
        self._configure_wrap_label(self.dubbed_audio_hint_label)
        bottom_row.addWidget(self.dubbed_audio_hint_label, 2)
        group_layout.addLayout(bottom_row)

        safe_row = QHBoxLayout()
        safe_row.setSpacing(8)
        self.chk_immersive_safe = QCheckBox(
            t.get("immersive_safe_container", "Prefer MKV for detected 360° / 3D videos")
        )
        self.chk_immersive_safe.setChecked(self._immersive_safe_container)
        safe_row.addWidget(self.chk_immersive_safe)
        safe_row.addWidget(QLabel(t.get("immersive_safe_hint", "Helps avoid fragile MP4 remux choices for VR / stereoscopic media.")))
        safe_row.addStretch()
        group_layout.addLayout(safe_row)

        layout.addWidget(group)
        self.dubbed_audio_group = group
        self._on_dubbed_audio_toggle()
        
    def _build_section_meta_language(self, layout, t, C):
        """Build UI: METADATA LANGUAGE (YouTube only, visible in ALL modes)."""
        if self.platform == "youtube":
            self.meta_lang_combo = QComboBox()
            self.meta_lang_combo.setMinimumWidth(150)
            self.meta_lang_combo.setSizeAdjustPolicy(QComboBox.AdjustToContentsOnFirstShow)
            for code, lkey in AUDIO_LANGUAGES:
                self.meta_lang_combo.addItem(t.get(lkey, lkey), code)
            self.meta_lang_row = QWidget()
            mlr_layout = QHBoxLayout(self.meta_lang_row)
            mlr_layout.setContentsMargins(4, 2, 4, 2)
            mlr_layout.addWidget(QLabel(t.get("meta_language_label", "🏷️ Title language (YouTube):")))
            mlr_layout.addWidget(self.meta_lang_combo)
            meta_lang_hint = QLabel(t.get("meta_language_hint", ""))
            meta_lang_hint.setObjectName("hintLabel")
            meta_lang_hint.setWordWrap(True)
            self._configure_wrap_label(meta_lang_hint)
            mlr_layout.addWidget(meta_lang_hint)
            mlr_layout.addStretch()
            layout.addWidget(self.meta_lang_row)
        else:
            self.meta_lang_combo = None
        
    def _build_section_options(self, layout, t, C):
        """Build UI: OPTIONS."""
        opts = QGroupBox(t.get("options_label", "⚙️ Options"))
        opts.setObjectName("featureCard")
        opts_layout = QVBoxLayout(opts)
        opts_layout.setSpacing(8)
        self._add_section_note(opts_layout, t.get("section_options_hint", "Control ordering, archive behavior, subtitles, acceleration, authorization, and advanced YouTube cleanup."))
        
        # Row 1: main checkboxes
        row1 = QHBoxLayout()
        self.chk_reverse = QCheckBox(t["reverse_playlist"])
        self.chk_reverse.setChecked(self._reverse_playlist)
        self.chk_reverse.setToolTip(t.get("reverse_playlist_hint", ""))
        row1.addWidget(self.chk_reverse)
        
        self.chk_archive = QCheckBox(t["use_archive"])
        self.chk_archive.setChecked(self._use_archive)
        self.chk_archive.setToolTip(t.get("use_archive_hint", ""))
        row1.addWidget(self.chk_archive)
        
        self.chk_nonumber = QCheckBox(t["no_numbering"])
        self.chk_nonumber.setChecked(self._no_numbering)
        self.chk_nonumber.setToolTip(t.get("no_numbering_hint", ""))
        row1.addWidget(self.chk_nonumber)
        
        self.chk_restart = QCheckBox(t["restart_each_video"])
        self.chk_restart.setChecked(self._restart_each)
        self.chk_restart.setToolTip(t.get("restart_each_video_hint", ""))
        row1.addWidget(self.chk_restart)

        self.chk_generate_m3u = QCheckBox(
            t.get("generate_m3u_label", "Create M3U for playlist-style downloads")
        )
        self.chk_generate_m3u.setChecked(self._generate_m3u)
        self.chk_generate_m3u.setToolTip(
            t.get(
                "generate_m3u_hint",
                "Write an .m3u file next to completed playlist, channel, or search downloads.",
            )
        )
        row1.addWidget(self.chk_generate_m3u)

        self.chk_notify = QCheckBox(t["notify_on_finish"])
        self.chk_notify.setChecked(self._notify_on_finish)
        self.chk_notify.setToolTip(t.get("notify_on_finish_hint", ""))
        row1.addWidget(self.chk_notify)
        row1.addStretch()
        opts_layout.addLayout(row1)
        
        # Row 2: Subtitles + aria2c
        row2 = QHBoxLayout()
        self.chk_subs = QCheckBox(t["subtitles"])
        self.chk_subs.setChecked(self._download_subs)
        self.chk_subs.stateChanged.connect(self._on_subs_toggle)
        row2.addWidget(self.chk_subs)
        
        self.sub_lang_combo = QComboBox()
        for code, lkey in self._subtitle_language_choices():
            self.sub_lang_combo.addItem(t.get(lkey, lkey), code)
        self.sub_lang_combo.setVisible(self._download_subs)
        self.sub_lang_combo.setMinimumWidth(150)
        self.sub_lang_combo.setSizeAdjustPolicy(QComboBox.AdjustToContentsOnFirstShow)
        row2.addWidget(self.sub_lang_combo)

        self.chk_embed_subs = QCheckBox(t.get("sub_embed", "📎 Embed subtitles"))
        self.chk_embed_subs.setChecked(self._embed_subtitles)
        self.chk_embed_subs.setVisible(self._download_subs)
        self.chk_embed_subs.setToolTip(
            t.get("sub_embed_hint", "Mux downloaded subtitles into the final video file when possible.")
        )
        row2.addWidget(self.chk_embed_subs)

        self.sub_format_combo = QComboBox()
        self.sub_format_combo.addItem(t.get("sub_format_srt", "SRT"), "srt")
        self.sub_format_combo.addItem(t.get("sub_format_vtt", "VTT"), "vtt")
        self.sub_format_combo.addItem(t.get("sub_format_ass", "ASS"), "ass")
        self.sub_format_combo.setCurrentIndex({"srt": 0, "vtt": 1, "ass": 2}.get(self._subtitle_format, 0))
        self.sub_format_combo.setVisible(self._download_subs)
        self.sub_format_combo.setMinimumWidth(92)
        self.sub_format_combo.setToolTip(
            t.get("sub_format_hint", "Convert downloaded subtitles to the selected format.")
        )
        row2.addWidget(self.sub_format_combo)
        
        row2.addSpacing(20)
        self.chk_aria2c = QCheckBox(t.get("aria2c_label", "🚀 aria2c"))
        self.chk_aria2c.setChecked(self._use_aria2c)
        self.chk_aria2c.setToolTip(t.get("aria2c_hint", ""))
        self.chk_aria2c.stateChanged.connect(self._on_aria2c_toggle)
        row2.addWidget(self.chk_aria2c)
        
        self.aria2c_threads_lbl = QLabel(t.get("aria2c_threads_label", "Threads:"))
        self.aria2c_threads_lbl.setVisible(self._use_aria2c)
        row2.addWidget(self.aria2c_threads_lbl)
        
        self.aria2c_threads_combo = QComboBox()
        self.aria2c_threads_combo.addItems(["4", "8", "16"])
        self.aria2c_threads_combo.setCurrentText(min(self._aria2c_threads, "16") if self._aria2c_threads in ["4","8","16"] else "16")
        self.aria2c_threads_combo.setMinimumWidth(72)
        self.aria2c_threads_combo.setVisible(self._use_aria2c)
        row2.addWidget(self.aria2c_threads_combo)
        
        row2.addSpacing(20)
        self.concurrent_lbl = QLabel(t.get("concurrent_videos_label", "📥 Parallel:"))
        row2.addWidget(self.concurrent_lbl)
        
        self.concurrent_combo = QComboBox()
        self.concurrent_combo.addItems(["1", "2", "3", "4", "5", "6", "7"])
        self.concurrent_combo.setCurrentText(self._concurrent_videos)
        self.concurrent_combo.setMinimumWidth(72)
        self.concurrent_combo.setToolTip(t.get("concurrent_videos_hint", ""))
        row2.addWidget(self.concurrent_combo)
        
        row2.addStretch()
        opts_layout.addLayout(row2)
        
        # Row 3: Auth
        row3 = QHBoxLayout()
        row3.addWidget(QLabel(t["auth_label"]))
        self.auth_combo = QComboBox()
        for am_id, am_key in AUTH_METHODS:
            self.auth_combo.addItem(t.get(am_key, am_key), am_id)
        self.auth_combo.setMinimumWidth(170)
        self.auth_combo.setSizeAdjustPolicy(QComboBox.AdjustToContentsOnFirstShow)
        row3.addWidget(self.auth_combo)
        
        if self.platform == "youtube":
            for pid, purl, pname in YOUTUBE_PRIVATE_PLAYLISTS:
                btn = QPushButton(pname)
                btn.setFixedHeight(28)
                btn.setCursor(Qt.PointingHandCursor)
                btn.clicked.connect(lambda checked, u=purl: self._set_private_url(u))
                row3.addWidget(btn)
        
        row3.addStretch()
        opts_layout.addLayout(row3)
        
        # Row 4: SponsorBlock (YouTube only)
        if self.platform == "youtube":
            row4 = QHBoxLayout()
            self.chk_sb = QCheckBox(t["sb_label"])
            self.chk_sb.setChecked(self._sb_enabled)
            self.chk_sb.setToolTip(t.get("sb_hint", ""))
            self.chk_sb.stateChanged.connect(self._on_sb_toggle)
            row4.addWidget(self.chk_sb)
            
            self.sb_action_lbl = QLabel(t.get("sb_action_label", "Action:"))
            self.sb_action_lbl.setVisible(self._sb_enabled)
            row4.addWidget(self.sb_action_lbl)
            
            self.sb_action_combo = QComboBox()
            self.sb_action_combo.addItem(t["sb_action_mark"], "mark")
            self.sb_action_combo.addItem(t["sb_action_remove"], "remove")
            self.sb_action_combo.setMinimumWidth(170)
            self.sb_action_combo.setSizeAdjustPolicy(QComboBox.AdjustToContentsOnFirstShow)
            self.sb_action_combo.setVisible(self._sb_enabled)
            self.sb_action_combo.currentIndexChanged.connect(self._on_sb_action_change)
            if self._sb_action == "remove":
                self.sb_action_combo.setCurrentIndex(1)
            row4.addWidget(self.sb_action_combo)
            
            row4.addSpacing(10)
            self.chk_sb_keyframes = QCheckBox(t.get("sb_force_keyframes", "🔑 Precise cuts"))
            self.chk_sb_keyframes.setChecked(self._sb_force_keyframes)
            self.chk_sb_keyframes.setToolTip(t.get("sb_force_keyframes_hint", ""))
            self.chk_sb_keyframes.setVisible(self._sb_enabled and self._sb_action == "remove")
            row4.addWidget(self.chk_sb_keyframes)
            
            row4.addStretch()
            opts_layout.addLayout(row4)
            
            # Row 4b: SponsorBlock category checkboxes
            self.sb_cats_row = QWidget()
            sb_cats_layout = QHBoxLayout(self.sb_cats_row)
            sb_cats_layout.setContentsMargins(24, 0, 4, 2)
            self.sb_cat_checks = {}
            for cat_id, cat_key, _ in SPONSORBLOCK_CATEGORIES:
                chk = QCheckBox(t.get(cat_key, cat_id))
                chk.setChecked(cat_id in self._sb_categories)
                self.sb_cat_checks[cat_id] = chk
                sb_cats_layout.addWidget(chk)
            sb_cats_layout.addStretch()
            self.sb_cats_row.setVisible(self._sb_enabled)
            opts_layout.addWidget(self.sb_cats_row)
        else:
            self.chk_sb = None
        
        layout.addWidget(opts)
        self._register_section("options", opts)
        
    def _build_section_paths(self, layout, t, C):
        """Build UI: PATHS."""
        paths = QGroupBox(t.get("paths_label", "📂 Paths & Files"))
        paths.setObjectName("featureCard")
        pl = QVBoxLayout(paths)
        pl.setSpacing(8)
        self._add_section_note(pl, t.get("section_paths_hint", "Choose where files are stored, how cookies are supplied, and whether browser login should be used."))
        
        # Output dir (no duplicate label — GroupBox title is enough)
        folder_row = QHBoxLayout()
        self.outdir_input = QLineEdit(str(self._get_default_outdir()))
        self.outdir_input.setObjectName("pathField")
        self.outdir_input.setPlaceholderText(t["outdir_label"])
        self.outdir_input.setCursorPosition(0)
        self.outdir_input.setToolTip(self.outdir_input.text())
        self.outdir_input.setClearButtonEnabled(True)
        self.outdir_input.editingFinished.connect(self._normalize_outdir_input_display)
        folder_row.addWidget(self.outdir_input)
        btn_browse = self._icon_btn("📁", self._browse_folder, t.get("browse_folder_tip", "Select folder"))
        folder_row.addWidget(btn_browse)
        btn_open = self._icon_btn("📂", self._open_download_folder, t.get("open_folder_btn", "Open folder"))
        folder_row.addWidget(btn_open)
        pl.addLayout(folder_row)
        
        # Cookies
        cookies_row = QHBoxLayout()
        cookies_row.addWidget(QLabel(t["cookies_label"]))
        self.cookies_input = QLineEdit()
        self.cookies_input.setObjectName("pathField")
        self.cookies_input.setPlaceholderText("cookies.txt")
        self.cookies_input.setClearButtonEnabled(True)
        cookies_row.addWidget(self.cookies_input)
        btn_cookies = self._icon_btn("📁", self._browse_cookies, t.get("browse_file_tip", "Select file"))
        cookies_row.addWidget(btn_cookies)
        
        btn_login = self._ui_btn(t.get("auth_browser_login", "🔐 Sign in"), self._browser_login, accent=True)
        btn_login.setFixedHeight(32)
        btn_login.setToolTip(t.get("auth_browser_login_tip", ""))
        cookies_row.addWidget(btn_login)
        
        pl.addLayout(cookies_row)
        
        # Cookies hint (compact)
        hint = QLabel(t["cookies_hint"])
        hint.setObjectName("hintLabel")
        hint.setWordWrap(True)
        self._configure_wrap_label(hint)
        pl.addWidget(hint)
        
        # Proxy
        proxy_row = QHBoxLayout()
        proxy_row.addWidget(QLabel(t["proxy_label"]))
        self.proxy_input = QLineEdit()
        self.proxy_input.setObjectName("proxyField")
        self.proxy_input.setPlaceholderText(t.get("proxy_hint", "socks5://127.0.0.1:1080"))
        self.proxy_input.setClearButtonEnabled(True)
        proxy_row.addWidget(self.proxy_input)
        pl.addLayout(proxy_row)
        layout.addWidget(paths)
        self._register_section("paths", paths)
        
    def _build_section_smart_mode(self, layout, t, C):
        """Build UI: SMART MODE + IMPORT/EXPORT."""
        smart = QGroupBox(t["smart_mode_label"])
        smart.setObjectName("featureCard")
        smart.setToolTip(t.get("smart_mode_hint", ""))
        sl = QVBoxLayout(smart)
        sl.setSpacing(8)
        self._add_section_note(sl, t.get("section_smart_hint", "Save complete download presets once and reapply them instantly for recurring tasks."))
        
        # Presets row
        preset_row = QHBoxLayout()
        self.smart_combo = QComboBox()
        self.smart_combo.setMinimumWidth(180)
        self._refresh_smart_presets()
        if self.smart_combo.count() == 0:
            self.smart_combo.setPlaceholderText(t.get("smart_select_preset", "—"))
        preset_row.addWidget(self.smart_combo)
        
        for text, slot in [(t["smart_save_btn"], self._smart_save),
                           (t["smart_load_btn"], self._smart_load),
                           (t["smart_delete_btn"], self._smart_delete)]:
            preset_row.addWidget(self._ui_btn(text, slot, role="danger" if slot == self._smart_delete else "default"))
        
        self.chk_smart_auto = QCheckBox(t["smart_apply_on_start"])
        self.chk_smart_auto.setChecked(self._smart_auto)
        self.chk_smart_auto.toggled.connect(self._refresh_smart_summary)
        preset_row.addWidget(self.chk_smart_auto)
        self.smart_stats_label = QLabel()
        self.smart_stats_label.setObjectName("sectionBadge")
        preset_row.addWidget(self.smart_stats_label)
        preset_row.addStretch()
        sl.addLayout(preset_row)
        self.smart_combo.currentTextChanged.connect(self._refresh_smart_summary)
        
        # Import/Export row (logically belongs with Smart Mode)
        ie_row = QHBoxLayout()
        ie_row.addWidget(self._ui_btn(t["import_btn"], self._import_links))
        ie_row.addWidget(self._ui_btn(t.get("batch_paste_btn", "Paste list"), self._batch_paste_links, role="ghost"))
        ie_row.addWidget(self._ui_btn(t["export_btn"], self._export_history))
        ie_row.addStretch()
        sl.addLayout(ie_row)

        state_row = QHBoxLayout()
        state_row.addWidget(self._ui_btn(t.get("import_state_btn", "Import full state"), self._import_app_state))
        state_row.addWidget(self._ui_btn(t.get("export_state_btn", "Export full state"), self._export_app_state))
        state_row.addStretch()
        sl.addLayout(state_row)

        options_row = QHBoxLayout()
        self.chk_manual_selection = QCheckBox(t.get("manual_selection_toggle", "Manual item picker"))
        self.chk_manual_selection.setChecked(self._manual_item_selection)
        self.chk_manual_selection.setToolTip(
            t.get(
                "manual_selection_hint",
                "Before playlist/channel/search downloads start, choose the exact items to keep.",
            )
        )
        self.chk_manual_selection.toggled.connect(self._refresh_smart_summary)
        options_row.addWidget(self.chk_manual_selection)
        options_row.addStretch()
        sl.addLayout(options_row)
        self._refresh_smart_summary()
        layout.addWidget(smart)
        self._register_section("smart", smart)
        
    def _build_section_dependencies(self, layout, t, C):
        """Build UI: DEPENDENCIES."""
        deps = QGroupBox(t["deps_frame"])
        deps.setObjectName("featureCard")
        deps_layout = QHBoxLayout(deps)
        self._add_section_note(deps_layout, t.get("section_dependencies_hint", "Track external tools required for media processing, acceleration, cookies, and playback."))
        
        # Status grid
        status_grid = QGridLayout()
        for i, (name, attr) in enumerate([
            ("yt-dlp", "ytdlp_status_label"),
            ("ffmpeg", "ffmpeg_status_label"),
            ("aria2c", "aria2c_status_label"),
            ("Node.js", "nodejs_status_label"),
            ("Everything", "everything_status_label"),
        ]):
            status_grid.addWidget(QLabel(f"<b>{name}:</b>"), i, 0)
            lbl = QLabel(t["checking"])
            lbl.setObjectName("depStatus")
            lbl.setProperty("status", "pending")
            setattr(self, attr, lbl)
            status_grid.addWidget(lbl, i, 1)
        deps_layout.addLayout(status_grid)
        deps_layout.addStretch()
        
        # Dep action buttons only
        deps_layout.addWidget(self._ui_btn(t["update_ytdlp_btn"], self._update_ytdlp, accent=True))
        deps_layout.addWidget(self._ui_btn(t.get("update_nodejs_btn", "Node.js"), self._download_nodejs, role="ghost"))
        layout.addWidget(deps)
        self._register_section("dependencies", deps)
        
    def _build_section_app_settings(self, layout, t, C):
        """Build UI: APP SETTINGS (separate from dependencies)."""
        app_settings = QGroupBox(t.get("settings_label", "🔧 App Settings"))
        app_settings.setObjectName("featureCard")
        as_layout = QVBoxLayout(app_settings)
        self._add_section_note(as_layout, t.get("section_app_hint", "Switch platform or theme and manage global program state from one place."))
        action_grid = QGridLayout()
        action_grid.setHorizontalSpacing(10)
        action_grid.setVerticalSpacing(10)

        change_platform_btn = self._ui_btn(t.get("change_platform_btn", "🔄 Platform"), self._change_platform, accent=True)
        change_theme_btn = self._ui_btn(t.get("change_theme_btn", "🎨 Theme"), self._change_theme, role="ghost")
        reset_btn = self._ui_btn(t.get("reset_settings_btn", "🗑️ Reset"), self._reset_settings, role="danger")
        for button in (change_platform_btn, change_theme_btn, reset_btn):
            button.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)

        action_grid.addWidget(change_platform_btn, 0, 0)
        action_grid.addWidget(change_theme_btn, 0, 1)
        action_grid.addWidget(reset_btn, 1, 0, 1, 2)
        action_grid.setColumnStretch(0, 1)
        action_grid.setColumnStretch(1, 1)
        as_layout.addLayout(action_grid)
        layout.addWidget(app_settings)
        
    def _build_section_history(self, layout, t, C):
        """Build UI: HISTORY."""
        hist = QGroupBox(t.get("history_label", "📜 Download History"))
        hist.setObjectName("featureCard")
        hist_layout = QVBoxLayout(hist)
        hist_layout.setSpacing(8)
        # Filter toolbar
        filter_row = QHBoxLayout()
        self.dm_filter_group = QButtonGroup(self)
        for fval, ftext in [("all", t["dm_tab_all"]), ("video", t["dm_tab_video"]),
                            ("audio", t["dm_tab_audio"]), ("playlist", t["dm_tab_playlist"])]:
            rb = QRadioButton(ftext)
            rb.setProperty("filter", fval)
            self.dm_filter_group.addButton(rb)
            filter_row.addWidget(rb)
            if fval == "all":
                rb.setChecked(True)
        self.dm_filter_group.buttonClicked.connect(self._dm_apply_filter)
        
        filter_row.addSpacing(12)
        self.dm_search = QLineEdit()
        self.dm_search.setObjectName("searchField")
        self.dm_search.setPlaceholderText(t.get("dm_search_placeholder", "🔍 Filter by name..."))
        self.dm_search.setMinimumWidth(180)
        self.dm_search.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self.dm_search.setClearButtonEnabled(True)
        self.dm_search.textChanged.connect(self._dm_apply_filter)
        filter_row.addWidget(self.dm_search)
        self.history_stats_label = QLabel()
        self.history_stats_label.setObjectName("sectionBadge")
        filter_row.addWidget(self.history_stats_label)
        
        for text, slot in [(t["dm_sort_date"], lambda: self._dm_sort("date")),
                           (t["dm_sort_name"], lambda: self._dm_sort("name"))]:
            filter_row.addWidget(self._ui_btn(text, slot, role="ghost"))
        
        self.chk_auto_remove_completed = QCheckBox(
            t.get("auto_remove_completed_label", "Auto-remove completed")
        )
        self.chk_auto_remove_completed.setChecked(self._auto_remove_completed)
        self.chk_auto_remove_completed.setToolTip(
            t.get(
                "auto_remove_completed_hint",
                "Keep successful downloads out of the on-screen history list while leaving files on disk untouched.",
            )
        )
        # Backward-compatible alias for older tests/runtime code.
        self.chk_history_auto_remove = self.chk_auto_remove_completed
        filter_row.addWidget(self.chk_auto_remove_completed)

        filter_row.addStretch()
        filter_row.addWidget(self._ui_btn(t["dm_clear_completed"], self._dm_clear_completed, role="danger"))
        hist_layout.addLayout(filter_row)
        
        # Tree (with constrained height)
        self.dm_tree = QTreeWidget()
        self.dm_tree.setObjectName("dataTree")
        self.dm_tree.setAlternatingRowColors(True)
        self.dm_tree.setRootIsDecorated(False)
        self.dm_tree.setMinimumHeight(112)
        self.dm_tree.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.dm_tree.setHeaderLabels([t["dm_col_status"], t["dm_col_name"],
                                      t["dm_col_size"], t["dm_col_date"]])
        header = self.dm_tree.header()
        header.setStretchLastSection(False)
        header.setSectionResizeMode(0, QHeaderView.ResizeToContents)
        header.setSectionResizeMode(1, QHeaderView.Stretch)
        header.setSectionResizeMode(2, QHeaderView.ResizeToContents)
        header.setSectionResizeMode(3, QHeaderView.ResizeToContents)
        hist_layout.addWidget(self.dm_tree)
        layout.addWidget(hist)
        self._register_section("history", hist)
        
        self._load_download_history()

    def _build_section_queue(self, layout, t, C):
        """Build UI: DOWNLOAD QUEUE MANAGER."""
        queue_group = QGroupBox(t.get("queue_label", "рџ“‹ Download Queue"))
        queue_group.setObjectName("featureCard")
        queue_layout = QVBoxLayout(queue_group)
        queue_layout.setSpacing(8)
        toolbar = QHBoxLayout()
        toolbar.setSpacing(8)
        toolbar.addWidget(self._ui_btn(t.get("queue_move_up_btn", "в†‘ Up"), lambda: self._queue_move_selected(-1), role="ghost"))
        toolbar.addWidget(self._ui_btn(t.get("queue_move_down_btn", "в†“ Down"), lambda: self._queue_move_selected(1), role="ghost"))
        toolbar.addWidget(self._ui_btn(t.get("queue_remove_btn", "Remove"), self._queue_remove_selected, role="danger"))
        toolbar.addWidget(self._ui_btn(t.get("queue_clear_btn", "Clear pending"), self._queue_clear_pending, role="ghost"))
        toolbar.addStretch()
        self.queue_stats_label = QLabel()
        self.queue_stats_label.setObjectName("sectionBadge")
        toolbar.addWidget(self.queue_stats_label)
        queue_layout.addLayout(toolbar)

        self.queue_tree = QTreeWidget()
        self.queue_tree.setObjectName("dataTree")
        self.queue_tree.setAlternatingRowColors(True)
        self.queue_tree.setRootIsDecorated(False)
        self.queue_tree.setMinimumHeight(104)
        self.queue_tree.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.queue_tree.setHeaderLabels([
            t.get("queue_col_mode", "Mode"),
            t.get("queue_col_url", "URL / Query"),
            t.get("queue_col_platform", "Platform"),
            t.get("queue_col_priority", "Priority"),
            t.get("queue_col_added", "Added"),
        ])
        queue_header = self.queue_tree.header()
        queue_header.setSectionResizeMode(0, QHeaderView.ResizeToContents)
        queue_header.setSectionResizeMode(1, QHeaderView.Stretch)
        queue_header.setSectionResizeMode(2, QHeaderView.ResizeToContents)
        queue_header.setSectionResizeMode(3, QHeaderView.ResizeToContents)
        queue_header.setSectionResizeMode(4, QHeaderView.ResizeToContents)
        queue_layout.addWidget(self.queue_tree)

        layout.addWidget(queue_group)
        self._register_section("queue", queue_group)
        self._refresh_queue_manager()

    def _build_section_bandwidth(self, layout, t, C):
        """Build UI: BANDWIDTH + CONTAINER."""
        bw_group = QGroupBox(t.get("speed_limit_label", "🏎️ Speed limit"))
        bw_group.setObjectName("featureCard")
        bw_layout = QVBoxLayout(bw_group)
        bw_layout.setSpacing(10)
        self._add_section_note(bw_layout, t.get("section_bandwidth_hint", "Tune bandwidth, remux container, inspect formats, preview metadata, or open the built-in player."))
        controls_row = QHBoxLayout()
        controls_row.setSpacing(10)
        
        # Speed limit
        self.speed_limit_input = QLineEdit()
        self.speed_limit_input.setObjectName("compactField")
        self.speed_limit_input.setMinimumWidth(64)
        self.speed_limit_input.setPlaceholderText("0")
        self.speed_limit_input.setText(str(self._speed_limit) if self._speed_limit else "")
        self.speed_limit_input.setToolTip(t.get("speed_limit_hint", ""))
        self.speed_limit_input.setAlignment(Qt.AlignCenter)
        controls_row.addWidget(self.speed_limit_input)
        
        self.speed_limit_unit = QComboBox()
        self.speed_limit_unit.setObjectName("compactCombo")
        self.speed_limit_unit.addItems([t.get("speed_limit_unit_kbs", "KB/s"),
                                        t.get("speed_limit_unit_mbs", "MB/s")])
        self.speed_limit_unit.setCurrentIndex(0 if self._speed_limit_unit == "kbs" else 1)
        self.speed_limit_unit.setMinimumWidth(86)
        controls_row.addWidget(self.speed_limit_unit)
        
        off_label = QLabel(t.get("speed_limit_off", "Off"))
        off_label.setObjectName("hintLabel")
        controls_row.addWidget(off_label)
        
        controls_row.addSpacing(20)
        
        # Output container
        self.output_container_label = QLabel(t.get("output_container_label", "📦 Container:"))
        controls_row.addWidget(self.output_container_label)
        self.container_combo = QComboBox()
        self.container_combo.setObjectName("compactCombo")
        self.container_combo.addItem(t.get("output_container_auto", "Auto"), "auto")
        self.container_combo.addItem("MP4", "mp4")
        self.container_combo.addItem("MKV", "mkv")
        container_map = {"auto": 0, "mp4": 1, "mkv": 2}
        self.container_combo.setCurrentIndex(container_map.get(self._output_container, 0))
        self.container_combo.setMinimumWidth(92)
        self.container_combo.setToolTip(t.get("output_container_hint", ""))
        self.container_combo.currentIndexChanged.connect(self._refresh_download_ux_state)
        controls_row.addWidget(self.container_combo)

        self.video_codec_label = QLabel(t.get("video_codec_policy_label", "🎛️ Codec:"))
        controls_row.addWidget(self.video_codec_label)
        self.video_codec_combo = QComboBox()
        self.video_codec_combo.setObjectName("compactCombo")
        self.video_codec_combo.addItem(t.get("video_codec_policy_auto", "Auto"), "auto")
        self.video_codec_combo.addItem(t.get("video_codec_policy_h264", "Prefer H.264"), "h264")
        self.video_codec_combo.addItem(t.get("video_codec_policy_modern", "Prefer VP9 / AV1"), "modern")
        self._set_combo_by_data(self.video_codec_combo, self._video_codec_policy)
        self.video_codec_combo.setMinimumWidth(152)
        self.video_codec_combo.setToolTip(
            t.get(
                "video_codec_policy_hint",
                "Bias automatic format selection toward broad H.264 compatibility or newer VP9/AV1 codecs.",
            )
        )
        self.video_codec_combo.currentIndexChanged.connect(self._refresh_download_ux_state)
        controls_row.addWidget(self.video_codec_combo)

        self.playback_target_label = QLabel(t.get("playback_target_label", "🖥️ Target:"))
        controls_row.addWidget(self.playback_target_label)
        self.playback_target_combo = QComboBox()
        self.playback_target_combo.setObjectName("compactCombo")
        self.playback_target_combo.addItem(t.get("playback_target_auto", "Auto"), "auto")
        self.playback_target_combo.addItem(t.get("playback_target_windows", "Windows"), "windows")
        self.playback_target_combo.addItem(t.get("playback_target_macos", "macOS"), "macos")
        self.playback_target_combo.addItem(t.get("playback_target_linux", "Linux"), "linux")
        self.playback_target_combo.addItem(t.get("playback_target_android", "Android"), "android")
        self.playback_target_combo.addItem(t.get("playback_target_iphone", "iPhone / iPad"), "iphone")
        self._set_combo_by_data(self.playback_target_combo, self._playback_target)
        self.playback_target_combo.setMinimumWidth(154)
        self.playback_target_combo.setToolTip(
            t.get(
                "playback_target_hint",
                "Prefer the most widely playable video and audio formats for the selected system or device.",
            )
        )
        self.playback_target_combo.currentIndexChanged.connect(self._refresh_download_ux_state)
        controls_row.addWidget(self.playback_target_combo)
        
        controls_row.addStretch()
        bw_layout.addLayout(controls_row)

        self.compatibility_hint_label = QLabel()
        self.compatibility_hint_label.setObjectName("hintLabel")
        self.compatibility_hint_label.setWordWrap(True)
        self._configure_wrap_label(self.compatibility_hint_label)
        bw_layout.addWidget(self.compatibility_hint_label)
        
        # Format + Preview + Player buttons
        actions_row = QHBoxLayout()
        actions_row.setSpacing(8)
        self.format_panel_btn = self._ui_btn(t.get("format_panel_btn", "📋 All Formats"), self._show_format_panel, role="ghost")
        actions_row.addWidget(self.format_panel_btn)
        
        self.preview_btn = self._ui_btn(t.get("preview_btn", "👁️ Preview"), self._show_preview, accent=True)
        actions_row.addWidget(self.preview_btn)

        self.similar_btn = self._ui_btn(
            t.get("similar_btn", "🔎 Similar"),
            self._find_similar_media,
            role="ghost",
        )
        actions_row.addWidget(self.similar_btn)
        
        self.player_btn = self._ui_btn(t.get("player_btn", "▶️ Player"), self._open_player, role="ghost")
        actions_row.addWidget(self.player_btn)
        actions_row.addStretch()
        bw_layout.addLayout(actions_row)
        
        layout.addWidget(bw_group)
        self._register_section("bandwidth", bw_group)
        
    def _build_section_speed_graph(self, layout, t, C):
        """Build UI: SPEED GRAPH."""
        self.speed_graph_group = QGroupBox(t.get("speed_graph_label", "📈 Speed Graph"))
        self.speed_graph_group.setObjectName("featureCard")
        sg_layout = QVBoxLayout(self.speed_graph_group)
        self._add_section_note(sg_layout, t.get("section_graph_hint", "Enable a live throughput graph when you need to inspect real download stability over time."))
        
        self.chk_speed_graph = QCheckBox(t.get("speed_graph_toggle", "📈 Show graph"))
        self.chk_speed_graph.setChecked(self._speed_graph_enabled)
        self.chk_speed_graph.stateChanged.connect(self._on_speed_graph_toggle)
        sg_layout.addWidget(self.chk_speed_graph)

        self._speed_graph_colors = (C['log_bg'], C['accent2'], C['border'], C['text_dim'])
        self.speed_graph = None
        self.speed_graph_host = QWidget()
        self.speed_graph_host_layout = QVBoxLayout(self.speed_graph_host)
        self.speed_graph_host_layout.setContentsMargins(0, 0, 0, 0)
        self.speed_graph_host_layout.setSpacing(0)
        sg_layout.addWidget(self.speed_graph_host)
        self._sync_speed_graph_visibility()
        
        layout.addWidget(self.speed_graph_group)
        self._register_section("speed_graph", self.speed_graph_group)

    def _ensure_speed_graph_widget(self):
        if self.speed_graph is None:
            self.speed_graph = SpeedGraphWidget()
            if hasattr(self, "_speed_graph_colors"):
                self.speed_graph.set_colors(*self._speed_graph_colors)
            self.speed_graph_host_layout.addWidget(self.speed_graph)
        return self.speed_graph

    def _sync_speed_graph_visibility(self):
        visible = bool(self.chk_speed_graph.isChecked()) if hasattr(self, "chk_speed_graph") else self._speed_graph_enabled
        if visible:
            self._ensure_speed_graph_widget().setVisible(True)
            return
        if self.speed_graph is not None:
            self.speed_graph.clear_data()
            self.speed_graph.setVisible(False)
        
    def _build_section_subscriptions(self, layout, t, C):
        """Build UI: SUBSCRIPTIONS + SCHEDULER."""
        sub_group = QGroupBox(t.get("subscriptions_label", "📡 Subscriptions"))
        sub_group.setObjectName("featureCard")
        sub_layout = QVBoxLayout(sub_group)
        sub_layout.setSpacing(8)
        # Sub toolbar
        sub_toolbar = QHBoxLayout()
        sub_toolbar.setSpacing(8)
        sub_toolbar.addWidget(self._ui_btn(t.get("sub_add_btn", "➕ Subscribe"), self._sub_add, accent=True))
        sub_toolbar.addWidget(self._ui_btn(t.get("sub_edit_btn", "✏ Edit"), self._sub_edit, role="ghost"))
        sub_toolbar.addWidget(self._ui_btn(t.get("sub_remove_btn", "🗑️ Remove"), self._sub_remove, role="danger"))
        sub_toolbar.addWidget(self._ui_btn(t.get("sub_check_now_btn", "🔄 Check Now"), lambda: self._sub_check_all(force=True), role="ghost"))
        sub_toolbar.addStretch()
        self.sub_stats_label = QLabel()
        self.sub_stats_label.setObjectName("sectionBadge")
        sub_toolbar.addWidget(self.sub_stats_label)
        sub_layout.addLayout(sub_toolbar)
        
        # Scheduler controls
        scheduler_row = QHBoxLayout()
        scheduler_row.setSpacing(8)
        self.chk_scheduler = QCheckBox(t.get("scheduler_enabled_label", "Scheduler enabled"))
        self.chk_scheduler.setChecked(self._scheduler_enabled)
        self.chk_scheduler.stateChanged.connect(self._on_scheduler_toggle)
        scheduler_row.addWidget(self.chk_scheduler)
        
        self.scheduler_mode_combo = QComboBox()
        self.scheduler_mode_combo.setObjectName("compactCombo")
        self.scheduler_mode_combo.addItems([
            t.get("scheduler_daily", "Daily"),
            t.get("scheduler_weekly", "Weekly"),
            t.get("scheduler_custom", "Custom"),
        ])
        sched_map = {"daily": 0, "weekly": 1, "custom": 2}
        self.scheduler_mode_combo.setCurrentIndex(sched_map.get(self._scheduler_mode, 0))
        self.scheduler_mode_combo.setMinimumWidth(110)
        self.scheduler_mode_combo.currentIndexChanged.connect(self._on_scheduler_config_changed)
        scheduler_row.addWidget(self.scheduler_mode_combo)
        
        self.scheduler_interval_input = QLineEdit()
        self.scheduler_interval_input.setObjectName("compactField")
        self.scheduler_interval_input.setMinimumWidth(64)
        self.scheduler_interval_input.setPlaceholderText("60")
        self.scheduler_interval_input.setText(str(self._scheduler_interval))
        self.scheduler_interval_input.setAlignment(Qt.AlignCenter)
        self.scheduler_interval_input.editingFinished.connect(self._on_scheduler_config_changed)
        scheduler_row.addWidget(QLabel(t.get("scheduler_interval_label", "min:")))
        scheduler_row.addWidget(self.scheduler_interval_input)
        scheduler_row.addStretch()
        
        sub_layout.addLayout(scheduler_row)
        
        # Sub tree
        self.sub_tree = QTreeWidget()
        self.sub_tree.setObjectName("dataTree")
        self.sub_tree.setAlternatingRowColors(True)
        self.sub_tree.setRootIsDecorated(False)
        self.sub_tree.setMinimumHeight(104)
        self.sub_tree.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.sub_tree.setHeaderLabels([
            t.get("sub_col_enabled", "On"),
            t.get("sub_col_kind", "Type"),
            t.get("sub_col_channel", "Channel"),
            t.get("sub_col_platform", "Platform"),
            t.get("sub_col_preset", "Preset"),
            t.get("sub_col_interval", "Interval"),
            t.get("sub_col_last_check", "Last Check"),
        ])
        sub_header = self.sub_tree.header()
        sub_header.setSectionResizeMode(0, QHeaderView.ResizeToContents)
        sub_header.setSectionResizeMode(1, QHeaderView.ResizeToContents)
        sub_header.setSectionResizeMode(2, QHeaderView.Stretch)
        sub_header.setSectionResizeMode(3, QHeaderView.ResizeToContents)
        sub_header.setSectionResizeMode(4, QHeaderView.ResizeToContents)
        sub_header.setSectionResizeMode(5, QHeaderView.ResizeToContents)
        sub_header.setSectionResizeMode(6, QHeaderView.ResizeToContents)
        self.sub_tree.itemDoubleClicked.connect(self._sub_toggle_enabled)
        sub_layout.addWidget(self.sub_tree)
        
        layout.addWidget(sub_group)
        self._register_section("subscriptions", sub_group)
        
    def _build_section_session(self, layout, t, C):
        """Build UI: SESSION RECOVERY + BACKGROUND MODE."""
        session_group = QGroupBox(t.get("session_label", "💾 Session"))
        session_group.setObjectName("featureCard")
        sess_layout = QHBoxLayout(session_group)
        self._add_section_note(sess_layout, t.get("section_session_hint", "Keep recovery and background behavior under control for long-running or unattended download sessions."))
        sess_layout.addWidget(self._ui_btn(t.get("session_save", "💾 Save"), self._session_save, accent=True))
        sess_layout.addWidget(self._ui_btn(t.get("session_restore", "📂 Restore"), self._session_restore, role="ghost"))
        sess_layout.addSpacing(30)
        
        self.chk_background = QCheckBox(t.get("background_mode_label", "Background mode"))
        self.chk_background.setChecked(self._background_mode)
        self.chk_background.setToolTip(t.get("background_mode_hint", ""))
        sess_layout.addWidget(self.chk_background)
        
        sess_layout.addStretch()
        layout.addWidget(session_group)
        self._register_section("session", session_group)

        self._refresh_subscriptions()
        self._start_scheduler_if_enabled()
        
        # Initial visibility

    # ══════════════════════════════════════════════════════════════════════════
    #  PLATFORM HELPERS
    # ══════════════════════════════════════════════════════════════════════════
    
    def _pc_get(self, key, default=None):
        return self.pc.get(key, default)
    
    def _pc_label(self, key, default=""):
        val = self.pc.get(key, {})
        if isinstance(val, dict):
            return val.get(self.lang, val.get("en", default))
        return val if val else default
    
    def _pc_channel_label(self):
        return self._pc_label("channel_label", "📺 Channel" if self.lang == "en" else "📺 Канал")
    
    def _pc_channel_desc(self):
        return self._pc_label("channel_desc", "All videos" if self.lang == "en" else "Все видео")
    
    def _pc_url_label(self, mode):
        if mode == self.MODE_CHANNEL:
            custom = self._pc_label("url_label_channel")
            if custom:
                return custom
            ch_name = self._pc_channel_label()
            name_only = ch_name.split(" ", 1)[-1] if " " in ch_name else ch_name
            return f"🔗 URL ({name_only}):" if self.lang == "ru" else f"🔗 {name_only} URL:"
        elif mode == self.MODE_PLAYLIST:
            return self.t.get("url_label_playlist", "🔗 Playlist URL:")
        elif mode == self.MODE_SEARCH:
            return self.t.get("url_label_search", "🔎 Search query:")
        return self.t.get("url_label_video", "🔗 Video URL:")
    
    def _pc_url_hint(self, mode):
        examples = self.pc.get("url_examples", {})
        key_map = {
            self.MODE_CHANNEL: "channel",
            self.MODE_PLAYLIST: "playlist",
            self.MODE_VIDEO: "video",
            self.MODE_SEARCH: "search",
        }
        example = examples.get(key_map.get(mode, "video"), "")
        return example if example else ""
    
    def _pc_audio_url_label(self, source):
        mapping = {self.AUDIO_SOURCE_VIDEO: self.MODE_VIDEO,
                   self.AUDIO_SOURCE_PLAYLIST: self.MODE_PLAYLIST,
                   self.AUDIO_SOURCE_CHANNEL: self.MODE_CHANNEL}
        return self._pc_url_label(mapping.get(source, self.MODE_VIDEO))
    
    def _pc_audio_url_hint(self, source):
        mapping = {self.AUDIO_SOURCE_VIDEO: self.MODE_VIDEO,
                   self.AUDIO_SOURCE_PLAYLIST: self.MODE_PLAYLIST,
                   self.AUDIO_SOURCE_CHANNEL: self.MODE_CHANNEL}
        return self._pc_url_hint(mapping.get(source, self.MODE_VIDEO))
    
    # ══════════════════════════════════════════════════════════════════════════
    #  GETTERS (read from widgets)
    # ══════════════════════════════════════════════════════════════════════════
    
    def _get_mode(self):
        btn = self.mode_buttons.checkedButton()
        return btn.property("mode_value") if btn else self.MODE_VIDEO
    
    def _get_quality(self):
        btn = self.quality_buttons.checkedButton()
        return btn.property("q_value") if btn else "max"
    
    def _get_audio_format(self):
        btn = self.format_buttons.checkedButton()
        return btn.property("fmt_value") if btn else "wav"
    
    def _get_audio_bitrate(self):
        btn = self.bitrate_buttons.checkedButton()
        return btn.property("br_value") if btn else "max"
    
    def _get_audio_source(self):
        btn = self.source_buttons.checkedButton()
        return btn.property("src_value") if btn else self.AUDIO_SOURCE_VIDEO

    def _get_search_results_limit(self):
        if hasattr(self, "search_limit_combo"):
            value = self.search_limit_combo.currentData() or self.search_limit_combo.currentText()
            if value in ("10", "25", "50", "100"):
                return str(value)
        return "25"
    
    @staticmethod
    def _choice_values(choices):
        return [code for code, _label_key in choices]

    @staticmethod
    def _plain_language_codes(choices):
        return [
            code
            for code, _label_key in choices
            if code not in {"any", "all", "default", "original"}
        ]

    def _audio_language_choices(self):
        return AUDIO_TRACK_LANGUAGES

    def _subtitle_language_choices(self):
        return SUBTITLE_LANGUAGE_CHOICES

    @staticmethod
    def _normalize_language_code(value):
        return str(value or "").strip().lower().replace("_", "-")

    def _match_language_code(self, preferred_codes, allowed_codes):
        aliases = {}
        for code in allowed_codes or []:
            normalized = self._normalize_language_code(code)
            if not normalized or normalized in {"any", "all", "default", "original"}:
                continue
            aliases.setdefault(normalized, code)
            aliases.setdefault(normalized.split("-", 1)[0], code)
        for preferred in preferred_codes or []:
            normalized = self._normalize_language_code(preferred)
            if not normalized:
                continue
            for candidate in (normalized, normalized.split("-", 1)[0]):
                match = aliases.get(candidate)
                if match:
                    return match
        return ""

    def _original_language_candidates(self, info):
        candidates = []
        for key in ("original_language", "language", "release_language", "audio_language"):
            value = (info or {}).get(key)
            if isinstance(value, str) and value.strip():
                candidates.append(value.strip())
        return candidates

    def _preferred_default_language_code(self, allowed_codes):
        candidates = [self._get_meta_language(), self.lang]
        try:
            system_locale = locale.getlocale()[0] or ""
        except Exception:
            system_locale = ""
        if system_locale:
            candidates.append(system_locale)
        return self._match_language_code(candidates, allowed_codes)

    def _resolve_audio_language_selector(self, audio_lang=None, media_info=None):
        value = audio_lang if audio_lang is not None else self._get_audio_language()
        if value in ("", "any"):
            return ""
        available = self._extract_audio_languages_from_info(media_info or {})
        allowed = available or self._plain_language_codes(self._audio_language_choices())
        if value == "default":
            return self._preferred_default_language_code(allowed)
        if value == "original":
            match = self._match_language_code(self._original_language_candidates(media_info or {}), available)
            if match:
                return match
            ranked = {}
            for fmt in (media_info or {}).get("formats", []):
                acodec = (fmt.get("acodec") or "none").strip()
                language = self._normalize_language_code(fmt.get("language"))
                if acodec == "none" or not language:
                    continue
                actual = self._match_language_code([language], available) or language
                ranked[actual] = max(ranked.get(actual, -999), int(fmt.get("language_preference") or 0))
            if ranked:
                return max(ranked.items(), key=lambda item: item[1])[0]
            return ""
        matched_value = self._match_language_code([value], available)
        if matched_value:
            return matched_value
        if value in allowed:
            return value
        return ""

    def _selected_audio_language_missing(self, selected_audio_lang, media_info=None):
        selected = self._normalize_language_code(selected_audio_lang)
        if selected in {"", "any", "default", "original"}:
            return False
        available = self._extract_audio_languages_from_info(media_info or {})
        if not available:
            return False
        return not bool(self._match_language_code([selected], available))

    def _resolve_subtitle_language_selector(self, sub_lang=None, media_info=None):
        value = sub_lang if sub_lang is not None else self._get_sub_language()
        if value == "all":
            return "all"
        manual = sorted(k for k in ((media_info or {}).get("subtitles") or {}).keys() if k)
        auto = sorted(k for k in ((media_info or {}).get("automatic_captions") or {}).keys() if k)
        available = manual + [code for code in auto if code not in manual]
        allowed = available or self._plain_language_codes(self._subtitle_language_choices())
        if value == "default":
            preferred = self._preferred_default_language_code(allowed)
            return preferred or (available[0] if available else "all")
        if value == "original":
            candidates = self._original_language_candidates(media_info or {})
            meta_language = self._get_meta_language()
            if meta_language and meta_language != "any":
                candidates.append(meta_language)
            resolved_audio = self._resolve_audio_language_selector(media_info=media_info)
            if resolved_audio:
                candidates.append(resolved_audio)
            match = self._match_language_code(candidates, allowed)
            if match:
                return match
            preferred = self._preferred_default_language_code(allowed)
            return preferred or (available[0] if available else "all")
        if value in allowed:
            return value
        return "all"

    def _get_audio_language(self):
        if self.audio_lang_combo:
            return self.audio_lang_combo.currentData() or "any"
        return "any"

    def _current_manual_format_context(self, url="", mode=None, platform_id=None, audio_lang=None):
        resolved_platform_id, _ = self._resolve_platform_context(platform_id)
        return {
            "url": str(url or self.url_input.text() or "").strip(),
            "mode": mode or self._get_mode(),
            "platform_id": resolved_platform_id,
            "audio_language": audio_lang if audio_lang is not None else self._get_audio_language(),
        }

    def _set_manual_format_selection(self, fmt_id="", fmt_kind="", url="", mode=None, platform_id=None, audio_lang=None):
        self._manual_format_id = str(fmt_id or "").strip()
        self._manual_format_kind = str(fmt_kind or "").strip()
        if self._manual_format_id:
            self._manual_format_context = self._current_manual_format_context(
                url=url,
                mode=mode,
                platform_id=platform_id,
                audio_lang=audio_lang,
            )
        else:
            self._manual_format_context = {}
            self._manual_format_kind = ""

    def _manual_format_matches_context(self, url="", mode=None, platform_id=None, audio_lang=None):
        if not getattr(self, "_manual_format_id", ""):
            return False
        context = getattr(self, "_manual_format_context", {}) or {}
        if not context:
            return False
        current = self._current_manual_format_context(
            url=url,
            mode=mode,
            platform_id=platform_id,
            audio_lang=audio_lang,
        )
        return all(context.get(key, "") == current.get(key, "") for key in ("url", "mode", "platform_id", "audio_language"))

    def _get_generate_m3u_enabled(self):
        if hasattr(self, "chk_generate_m3u"):
            return self.chk_generate_m3u.isChecked()
        return bool(self._generate_m3u)

    def _get_download_all_audio_tracks(self):
        if hasattr(self, "chk_all_audio_tracks") and self.chk_all_audio_tracks:
            return self.chk_all_audio_tracks.isChecked() and self._get_mode() == self.MODE_VIDEO
        return bool(self._download_all_audio_tracks) and self._get_mode() == self.MODE_VIDEO

    def _get_dubbed_audio_export_enabled(self):
        if hasattr(self, "chk_dubbed_audio") and self.chk_dubbed_audio:
            return self.chk_dubbed_audio.isChecked() and self._get_mode() != self.MODE_AUDIO
        return bool(self._dubbed_audio_export) and self._get_mode() != self.MODE_AUDIO

    def _get_dubbed_audio_mode(self):
        if hasattr(self, "dubbed_audio_mode_combo") and self.dubbed_audio_mode_combo:
            return self.dubbed_audio_mode_combo.currentData() or "selected"
        return self._dubbed_audio_mode

    def _get_dubbed_audio_languages_text(self):
        if hasattr(self, "dubbed_audio_languages_input") and self.dubbed_audio_languages_input:
            return self.dubbed_audio_languages_input.text().strip()
        return (self._dubbed_audio_languages or "").strip()

    def _get_dubbed_audio_format(self):
        if hasattr(self, "dubbed_audio_format_combo") and self.dubbed_audio_format_combo:
            return self.dubbed_audio_format_combo.currentData() or "best"
        return self._dubbed_audio_format

    def _get_video_codec_policy(self):
        if hasattr(self, "video_codec_combo") and self.video_codec_combo:
            return self.video_codec_combo.currentData() or "auto"
        return self._video_codec_policy

    def _get_playback_target(self):
        if hasattr(self, "playback_target_combo") and self.playback_target_combo:
            return self.playback_target_combo.currentData() or "auto"
        return self._playback_target

    def _prefers_compatibility_target(self):
        return self._get_playback_target() != "auto"

    def _should_use_exact_audio_format_ids(self, mode):
        return mode == self.MODE_VIDEO or (mode == self.MODE_AUDIO and self._get_audio_source() == self.AUDIO_SOURCE_VIDEO)

    def _should_probe_media_info_for_command(self, mode, audio_lang="", subtitle_lang="all", prefer_exact_audio=True):
        if self._mode_uses_multi_items(mode=mode):
            return False
        if mode == self.MODE_VIDEO and self._get_download_all_audio_tracks():
            return True
        if audio_lang not in {"", "any"} and prefer_exact_audio:
            return True
        return bool(self.chk_subs.isChecked() and subtitle_lang in {"default", "original"})

    def _get_immersive_safe_container_enabled(self):
        if hasattr(self, "chk_immersive_safe") and self.chk_immersive_safe:
            return self.chk_immersive_safe.isChecked()
        return bool(self._immersive_safe_container)
    
    def _get_meta_language(self):
        if self.meta_lang_combo:
            return self.meta_lang_combo.currentData() or "any"
        return "any"
    
    def _get_sub_language(self):
        return self.sub_lang_combo.currentData() or "all"

    def _get_subtitle_format(self):
        if hasattr(self, "sub_format_combo"):
            return self.sub_format_combo.currentData() or "srt"
        return "srt"

    def _get_embed_subtitles(self):
        if hasattr(self, "chk_embed_subs"):
            return self.chk_embed_subs.isChecked()
        return False
    
    def _get_auth_method(self):
        return self.auth_combo.currentData() or "none"
    
    def _get_sb_categories(self):
        """Get list of selected SponsorBlock category IDs."""
        if not self.chk_sb or not hasattr(self, 'sb_cat_checks'):
            return []
        return [cat_id for cat_id, chk in self.sb_cat_checks.items() if chk.isChecked()]
    
    def _get_sb_action(self):
        """Get current SponsorBlock action: 'mark' or 'remove'."""
        if not self.chk_sb:
            return "mark"
        return self.sb_action_combo.currentData() or "mark"
    
    # ══════════════════════════════════════════════════════════════════════════
    #  SETTERS (write to widgets)
    # ══════════════════════════════════════════════════════════════════════════
    
    def _set_radio_group(self, group, prop_name, value):
        for btn in group.buttons():
            if btn.property(prop_name) == value:
                btn.setChecked(True)
                return
    
    def _set_combo_by_data(self, combo, value):
        for i in range(combo.count()):
            if combo.itemData(i) == value:
                combo.setCurrentIndex(i)
                return
    
    # ══════════════════════════════════════════════════════════════════════════
    #  SETTINGS LOAD / SAVE
    # ══════════════════════════════════════════════════════════════════════════
    
    def _load_settings(self):
        try:
            self._load_settings_impl()
        except Exception as e:
            import traceback
            self.log(f"\n⚠️ ERROR in _load_settings:\n{traceback.format_exc()}")
    
    def _load_settings_impl(self):
        settings = self.settings_manager.load()
        
        # Log migration report (new/removed settings detected)
        migration = self.settings_manager.last_migration
        if migration:
            self.log(self.t.get("settings_migrated", "  🔄 Settings migrated:"))
            for key, value in migration["added"].items():
                display_val = json.dumps(value, ensure_ascii=False) if not isinstance(value, str) else value
                self.log(self.t.get("settings_key_added", "     + {key} = {value}").format(
                    key=key, value=display_val))
            for key in migration["removed"]:
                self.log(self.t.get("settings_key_removed", "     − {key}").format(key=key))
            self.log(self.t.get("settings_file_saved", "     💾 {path}").format(
                path=self.settings_manager.config_path))
            self.log("")
        
        valid_modes = [self.MODE_CHANNEL, self.MODE_PLAYLIST, self.MODE_VIDEO, self.MODE_AUDIO, self.MODE_SEARCH]
        if settings.get("mode") in valid_modes:
            self._set_radio_group(self.mode_buttons, "mode_value", settings["mode"])
        
        if settings.get("url"):
            self.url_input.setText(settings["url"])
        if settings.get("outdir"):
            self._set_line_edit_path(self.outdir_input, settings["outdir"])
        if settings.get("cookies"):
            self.cookies_input.setText(settings["cookies"])
        if hasattr(self, 'speed_limit_input'):
            self.speed_limit_input.setText(str(settings.get("speed_limit", 0)) if settings.get("speed_limit", 0) else "")
        if hasattr(self, 'speed_limit_unit'):
            self.speed_limit_unit.setCurrentIndex(0 if settings.get("speed_limit_unit", "mbs") == "kbs" else 1)
        if hasattr(self, 'container_combo'):
            cm = {"auto": 0, "mp4": 1, "mkv": 2}
            self.container_combo.setCurrentIndex(cm.get(settings.get("output_container", "auto"), 0))
        self._video_codec_policy = settings.get("video_codec_policy", "auto")
        if hasattr(self, "video_codec_combo"):
            self._set_combo_by_data(self.video_codec_combo, self._video_codec_policy)
        self._playback_target = settings.get("playback_target", "auto")
        if hasattr(self, "playback_target_combo"):
            self._set_combo_by_data(self.playback_target_combo, self._playback_target)
        self._immersive_safe_container = bool(settings.get("immersive_safe_container", True))
        if hasattr(self, "chk_immersive_safe"):
            self.chk_immersive_safe.setChecked(self._immersive_safe_container)
        self._manual_format_id = ""
        self._manual_format_kind = ""
        self._manual_format_context = {}
        self._generate_m3u = bool(settings.get("generate_m3u", False))
        if hasattr(self, "chk_generate_m3u"):
            self.chk_generate_m3u.setChecked(self._generate_m3u)
        if hasattr(self, 'chk_speed_graph'):
            self.chk_speed_graph.setChecked(settings.get("speed_graph_enabled", False))
            self._sync_speed_graph_visibility()
        if hasattr(self, 'chk_background'):
            self.chk_background.setChecked(settings.get("background_mode", False))
        if hasattr(self, 'chk_scheduler'):
            self.chk_scheduler.setChecked(settings.get("scheduler_enabled", False))
        if hasattr(self, 'scheduler_mode_combo'):
            sm = {"daily": 0, "weekly": 1, "custom": 2}
            self.scheduler_mode_combo.setCurrentIndex(sm.get(settings.get("scheduler_mode", "daily"), 0))
        if hasattr(self, 'scheduler_interval_input'):
            self.scheduler_interval_input.setText(str(settings.get("scheduler_interval", 60)))
        if settings.get("proxy"):
            self.proxy_input.setText(settings["proxy"])
        self._search_results_limit = str(settings.get("search_results_limit", "25"))
        if hasattr(self, "search_limit_combo"):
            self.search_limit_combo.setCurrentText(
                self._search_results_limit if self._search_results_limit in ("10", "25", "50", "100") else "25"
            )
        self._log_file_enabled = bool(settings.get("log_file_enabled", False))
        self._log_file_path = (settings.get("log_file_path") or "").strip()
        history_auto_remove = settings.get(
            "history_auto_remove_completed",
            settings.get("auto_remove_completed", False),
        )
        self._history_auto_remove_completed = bool(history_auto_remove)
        self._auto_remove_completed = bool(history_auto_remove)
        if hasattr(self, "chk_log_file"):
            self.chk_log_file.setChecked(self._log_file_enabled)
        if hasattr(self, "log_file_input"):
            self.log_file_input.setText(self._log_file_path or self._default_log_file_path())
        if hasattr(self, "chk_auto_remove_completed"):
            self.chk_auto_remove_completed.setChecked(self._auto_remove_completed)
        self._update_log_file_ui()
        
        valid_qualities = [q[0] for q in VIDEO_QUALITIES]
        if settings.get("video_quality") in valid_qualities:
            self._set_radio_group(self.quality_buttons, "q_value", settings["video_quality"])
        
        if settings.get("audio_format") in AUDIO_FORMATS:
            self._set_radio_group(self.format_buttons, "fmt_value", settings["audio_format"])
        
        valid_bitrates = [b[0] for b in AUDIO_BITRATES]
        if settings.get("audio_bitrate") in valid_bitrates:
            self._set_radio_group(self.bitrate_buttons, "br_value", settings["audio_bitrate"])
        
        valid_sources = [self.AUDIO_SOURCE_VIDEO, self.AUDIO_SOURCE_PLAYLIST, self.AUDIO_SOURCE_CHANNEL]
        if settings.get("audio_source") in valid_sources:
            self._set_radio_group(self.source_buttons, "src_value", settings["audio_source"])
        
        valid_langs = self._choice_values(self._audio_language_choices())
        if settings.get("audio_language") in valid_langs and self.audio_lang_combo:
            self._set_combo_by_data(self.audio_lang_combo, settings["audio_language"])
        self._download_all_audio_tracks = bool(settings.get("download_all_audio_tracks", False))
        if self.chk_all_audio_tracks:
            self.chk_all_audio_tracks.setChecked(self._download_all_audio_tracks)
        self._dubbed_audio_export = bool(settings.get("dubbed_audio_export", False))
        self._dubbed_audio_mode = settings.get("dubbed_audio_mode", "selected")
        self._dubbed_audio_languages = (settings.get("dubbed_audio_languages") or "").strip()
        self._dubbed_audio_format = settings.get("dubbed_audio_format", "best")
        if hasattr(self, "chk_dubbed_audio"):
            self.chk_dubbed_audio.setChecked(self._dubbed_audio_export)
        if hasattr(self, "dubbed_audio_mode_combo"):
            self._set_combo_by_data(self.dubbed_audio_mode_combo, self._dubbed_audio_mode)
        if hasattr(self, "dubbed_audio_languages_input"):
            self.dubbed_audio_languages_input.setText(self._dubbed_audio_languages)
        if hasattr(self, "dubbed_audio_format_combo"):
            self._set_combo_by_data(self.dubbed_audio_format_combo, self._dubbed_audio_format)
        meta_langs = [code for code, _label_key in AUDIO_LANGUAGES]
        if settings.get("meta_language") in meta_langs and self.meta_lang_combo:
            self._set_combo_by_data(self.meta_lang_combo, settings["meta_language"])
        
        self.chk_restart.setChecked(settings.get("restart_each_video", False))
        self.chk_notify.setChecked(settings.get("notify_on_finish", True))
        self.chk_nonumber.setChecked(settings.get("no_numbering", False))
        self.chk_reverse.setChecked(settings.get("reverse_playlist", True))
        self.chk_archive.setChecked(settings.get("use_archive", True))
        self.chk_subs.setChecked(settings.get("download_subtitles", False))
        
        valid_sub = self._choice_values(self._subtitle_language_choices())
        if settings.get("subtitle_language") in valid_sub:
            self._set_combo_by_data(self.sub_lang_combo, settings["subtitle_language"])
        self.sub_lang_combo.setVisible(settings.get("download_subtitles", False))
        if hasattr(self, "chk_embed_subs"):
            self.chk_embed_subs.setChecked(settings.get("embed_subtitles", False))
            self.chk_embed_subs.setVisible(settings.get("download_subtitles", False))
        if hasattr(self, "sub_format_combo"):
            self._set_combo_by_data(self.sub_format_combo, settings.get("subtitle_format", "srt"))
            self.sub_format_combo.setVisible(settings.get("download_subtitles", False))
        if hasattr(self, "chk_dubbed_audio"):
            self._on_dubbed_audio_toggle()
        
        auth = settings.get("auth_method", "none")
        valid_auths = [am[0] for am in AUTH_METHODS]
        if auth in valid_auths:
            self._set_combo_by_data(self.auth_combo, auth)
        
        self.chk_aria2c.setChecked(settings.get("use_aria2c", False))
        threads = settings.get("aria2c_threads", "16")
        if threads in ["4", "8", "16"]:
            self.aria2c_threads_combo.setCurrentText(threads)
        conc = settings.get("concurrent_videos", "1")
        if conc in ["1", "2", "3", "4", "5", "6", "7"]:
            self.concurrent_combo.setCurrentText(conc)
        
        self.chk_smart_auto.setChecked(settings.get("smart_auto_apply", False))
        self._manual_item_selection = bool(settings.get("manual_item_selection", False))
        if hasattr(self, "chk_manual_selection"):
            self.chk_manual_selection.setChecked(self._manual_item_selection)
        if settings.get("smart_auto_apply", False):
            auto_preset = settings.get("smart_auto_preset", "")
            if auto_preset:
                presets = self._load_all_presets()
                if auto_preset in presets:
                    self._apply_preset_data(presets[auto_preset])
                    self.smart_combo.setCurrentText(auto_preset)
        
        # SponsorBlock (YouTube only)
        if self.chk_sb:
            self.chk_sb.setChecked(settings.get("sb_enabled", False))
            action = settings.get("sb_action", "mark")
            if action in ("mark", "remove"):
                self._set_combo_by_data(self.sb_action_combo, action)
            cats = settings.get("sb_categories", ["sponsor", "intro", "outro", "selfpromo"])
            valid_cats = [c for c, _, _ in SPONSORBLOCK_CATEGORIES]
            for cat_id, chk in self.sb_cat_checks.items():
                chk.setChecked(cat_id in cats and cat_id in valid_cats)
            self.chk_sb_keyframes.setChecked(settings.get("sb_force_keyframes", False))
            self._on_sb_toggle()
        
        self._update_mode_visibility()
        self._on_format_change()
        self._update_url_examples()
        self._on_mode_change()
    
    def _save_settings(self):
        if is_debug_mode():
            return
        try:
            self._save_settings_impl()
        except Exception as e:
            import traceback
            self.log(f"\n⚠️ ERROR in _save_settings:\n{traceback.format_exc()}")
    
    def _save_settings_impl(self):
        settings = self._collect_runtime_settings_snapshot()
        settings.update({
            "url": self.url_input.text().strip(),
            "notify_on_finish": self.chk_notify.isChecked(),
            "smart_auto_apply": self.chk_smart_auto.isChecked(),
            "smart_auto_preset": self.smart_combo.currentText(),
            "speed_graph_enabled": self.chk_speed_graph.isChecked() if hasattr(self, 'chk_speed_graph') else False,
            "background_mode": self.chk_background.isChecked() if hasattr(self, 'chk_background') else False,
            "scheduler_enabled": self.chk_scheduler.isChecked() if hasattr(self, 'chk_scheduler') else False,
            "scheduler_mode": ["daily", "weekly", "custom"][self.scheduler_mode_combo.currentIndex()] if hasattr(self, 'scheduler_mode_combo') else "daily",
            "scheduler_interval": int(self.scheduler_interval_input.text()) if hasattr(self, 'scheduler_interval_input') and self.scheduler_interval_input.text().strip().isdigit() else 60,
            "log_file_enabled": self.chk_log_file.isChecked() if hasattr(self, 'chk_log_file') else self._log_file_enabled,
            "log_file_path": self._get_log_file_path(),
        })
        settings.pop("manual_format_id", None)
        settings.pop("manual_format_kind", None)
        settings.pop("manual_format_context", None)
        self.settings_manager.save(settings)
    
    # ══════════════════════════════════════════════════════════════════════════
    #  SYSTEM TRAY
    # ══════════════════════════════════════════════════════════════════════════
    
    def _setup_tray_icon(self):
        """Create persistent system tray icon with context menu."""
        if not QSystemTrayIcon.isSystemTrayAvailable():
            return
        
        app_icon = QApplication.instance().windowIcon()
        if app_icon.isNull():
            pxm = QPixmap(64, 64)
            pxm.fill(QColor("#4CAF50"))
            painter = QPainter(pxm)
            painter.setPen(QColor("white"))
            f = painter.font()
            f.setPixelSize(48)
            f.setBold(True)
            painter.setFont(f)
            painter.drawText(pxm.rect(), Qt.AlignCenter, "A")
            painter.end()
            app_icon = QIcon(pxm)
        
        self._tray_icon = QSystemTrayIcon(app_icon, self)
        
        # Context menu (right-click)
        tray_menu = QMenu(self)
        act_reset = tray_menu.addAction(self.t.get("tray_reset", "Reset settings"))
        act_reset.triggered.connect(self._reset_settings)
        tray_menu.addSeparator()
        act_close = tray_menu.addAction(self.t.get("tray_close", "Close Aura Video Downloader"))
        act_close.triggered.connect(self._request_app_close)
        self._tray_icon.setContextMenu(tray_menu)
        
        # Left-click — show and focus window
        self._tray_icon.activated.connect(self._on_tray_activated)
        
        self._tray_icon.setToolTip("Aura Video Downloader")
        self._tray_icon.show()
    
    def _on_tray_activated(self, reason):
        if reason == QSystemTrayIcon.Trigger:  # Left-click
            self.showNormal()
            self.activateWindow()
            self.raise_()

    def _request_app_close(self):
        self._force_close = True
        self.close()

    def _clear_thread_worker_ref(self, attr_name, worker):
        if getattr(self, attr_name, None) is worker:
            setattr(self, attr_name, None)

    def _forget_sub_worker(self, worker):
        self._sub_workers = [active for active in self._sub_workers if active is not worker]

    def _shutdown_thread_worker(self, worker, context, wait_ms=1500):
        if worker is None:
            return None

        try:
            stop = getattr(worker, "stop", None)
            if callable(stop):
                stop()
            else:
                request_interruption = getattr(worker, "requestInterruption", None)
                if callable(request_interruption):
                    request_interruption()
        except Exception as exc:
            log_error(f"{context}_stop", exc)

        is_running = getattr(worker, "isRunning", None)
        wait = getattr(worker, "wait", None)
        try:
            if callable(is_running) and is_running():
                if callable(wait):
                    wait(wait_ms)
        except Exception as exc:
            log_error(f"{context}_wait", exc)
        return None

    def _replace_thread_worker(self, attr_name, worker, context):
        previous = getattr(self, attr_name, None)
        if previous is not None and previous is not worker:
            self._shutdown_thread_worker(previous, f"{context}_replace", wait_ms=750)

        try:
            worker.setParent(self)
        except Exception as exc:
            log_error(f"{context}_parent", exc)

        finished_signal = getattr(worker, "finished", None)
        if hasattr(finished_signal, "connect"):
            try:
                finished_signal.connect(
                    lambda attr_name=attr_name, worker=worker: self._clear_thread_worker_ref(attr_name, worker)
                )
            except Exception as exc:
                log_error(f"{context}_finished_connect", exc)

        setattr(self, attr_name, worker)
        return worker

    def _shutdown_background_workers(self):
        self.deps_worker = self._shutdown_thread_worker(self.deps_worker, "shutdown_deps_worker")
        self._format_worker = self._shutdown_thread_worker(self._format_worker, "shutdown_format_worker")
        self._preview_worker = self._shutdown_thread_worker(self._preview_worker, "shutdown_preview_worker")
        self._playlist_entries_worker = self._shutdown_thread_worker(
            self._playlist_entries_worker, "shutdown_playlist_entries_worker"
        )

        active_sub_workers = list(self._sub_workers)
        self._sub_workers = []
        self._sub_pending_queue = []
        for index, worker in enumerate(active_sub_workers):
            self._shutdown_thread_worker(worker, f"shutdown_sub_worker_{index}")

    def closeEvent(self, event):
        # Background mode: minimize to tray instead of closing
        if (hasattr(self, 'chk_background') and self.chk_background.isChecked()
                and not getattr(self, '_resetting', False)
                and not self._force_close
                and hasattr(self, '_tray_icon') and self._tray_icon.isVisible()):
            event.ignore()
            self.hide()
            return
        self._closing = True
        # Stop scheduler on real close
        if hasattr(self, '_scheduler_timer') and self._scheduler_timer:
            self._scheduler_timer.stop()
        if hasattr(self, "_crash_recovery_timer") and self._crash_recovery_timer:
            self._crash_recovery_timer.stop()
        # Don't re-save settings if we're in the middle of a full reset
        if not getattr(self, '_resetting', False):
            self._save_settings()
            self._save_download_history()
        self._persist_session_snapshot()
        # Hide tray icon before exit
        if hasattr(self, '_tray_icon'):
            self._tray_icon.hide()
        self.stop_event.set()
        if self.worker and self.worker.isRunning():
            self.worker.stop()
            self.worker.wait(3000)
        for w in getattr(self, '_parallel_workers', []):
            w.stop()
            w.wait(3000)
            if w.isRunning():
                try:
                    w.terminate()
                except Exception as e:
                    log_error("close_terminate_worker", e)
        self._shutdown_background_workers()
        # Kill restart mode subprocess (prevents orphan yt-dlp processes)
        if self._restart_process:
            try:
                self._restart_process.terminate()
                self._restart_process.wait(timeout=PROCESS_TERMINATE_TIMEOUT)
            except Exception:
                try:
                    self._restart_process.kill()
                except Exception as e:
                    log_error("close_kill_restart_process", e)
        event.accept()
    
    # ══════════════════════════════════════════════════════════════════════════
    #  UI EVENT HANDLERS
    # ══════════════════════════════════════════════════════════════════════════
    
    def _on_mode_change(self, btn=None):
        try:
            mode = self._get_mode()
            self._update_mode_visibility()
            self._refresh_workspace_subnav("setup")
            self._ensure_workspace_page_visible("setup")
            self._update_url_examples()
            self._refresh_hero_banner()
            if mode == self.MODE_AUDIO:
                src = self._get_audio_source()
                hint = self._pc_audio_url_hint(src)
            else:
                hint = self._pc_url_hint(mode)
            self.url_input.setPlaceholderText(hint)
            self._refresh_primary_action_state()
        except Exception as e:
            import traceback
            self.log(f"\n⚠️ ERROR in _on_mode_change:\n{traceback.format_exc()}")
    
    def _update_url_examples(self):
        """Update visible URL examples label based on current mode."""
        mode = self._get_mode()
        examples = self.pc.get("url_examples", {})
        if mode == self.MODE_AUDIO:
            src = self._get_audio_source()
            if src == self.AUDIO_SOURCE_PLAYLIST:
                ex = examples.get("playlist", "")
            elif src == self.AUDIO_SOURCE_CHANNEL:
                ex = examples.get("channel", "")
            else:
                ex = examples.get("video", "")
        else:
            ex = examples.get(mode, "")
        
        if ex:
            self.url_examples_label.setText(ex)
            self.url_examples_label.setVisible(True)
        else:
            self.url_examples_label.setVisible(False)
    
    def _update_mode_visibility(self):
        mode = self._get_mode()
        is_audio = (mode == self.MODE_AUDIO)
        self.quality_group.setVisible(not is_audio)
        self.audio_group.setVisible(is_audio)
        if hasattr(self, "search_limit_lbl"):
            self.search_limit_lbl.setVisible(mode == self.MODE_SEARCH)
        if hasattr(self, "search_limit_combo"):
            self.search_limit_combo.setVisible(mode == self.MODE_SEARCH)
        if hasattr(self, "chk_embed_subs"):
            self.chk_embed_subs.setEnabled(not is_audio)
        if hasattr(self, "chk_all_audio_tracks") and self.chk_all_audio_tracks:
            allow_multi_audio = mode == self.MODE_VIDEO and self.pc.get("has_audio_lang", False)
            self.chk_all_audio_tracks.setEnabled(bool(allow_multi_audio))
            if not allow_multi_audio:
                self.chk_all_audio_tracks.setChecked(False)
        if hasattr(self, "dubbed_audio_group") and self.dubbed_audio_group:
            self.dubbed_audio_group.setEnabled(not is_audio)
        if hasattr(self, "chk_dubbed_audio"):
            self._on_dubbed_audio_toggle()
        self._refresh_workspace_subnav(self._active_workspace_category or None)
        self._ensure_workspace_page_visible("setup")
        self._refresh_primary_action_label()
        self._refresh_primary_action_state()
        if self._runtime_state in {"idle", "finished", "stopped"} and hasattr(self, "sidebar_meta") and hasattr(self, "workspace_tabs"):
            current_page = self._workspace_page_key_by_index(self.workspace_tabs.currentIndex())
            if current_page:
                self.sidebar_meta.setText(self._workspace_page_description(current_page))
        self._refresh_download_ux_state()
    
    def _on_source_change(self, btn=None):
        src = self._get_audio_source()
        self.url_input.setPlaceholderText(self._pc_audio_url_hint(src))
        self._update_url_examples()
        self._refresh_hero_banner()
    
    def _on_format_change(self, btn=None):
        fmt = self._get_audio_format()
        is_lossless = fmt in ("wav", "flac")
        self.bitrate_widget.setVisible(not is_lossless)
        self.bitrate_label.setVisible(not is_lossless)
    
    def _on_subs_toggle(self, state):
        self.sub_lang_combo.setVisible(self.chk_subs.isChecked())
        if hasattr(self, "chk_embed_subs"):
            self.chk_embed_subs.setVisible(self.chk_subs.isChecked())
        if hasattr(self, "sub_format_combo"):
            self.sub_format_combo.setVisible(self.chk_subs.isChecked())

    def _on_dubbed_audio_toggle(self, state=None):
        enabled = self._get_dubbed_audio_export_enabled()
        mode = self._get_dubbed_audio_mode()
        custom_mode = enabled and mode == "custom"
        allow_all = self._get_mode() == self.MODE_VIDEO
        if hasattr(self, "dubbed_audio_mode_combo"):
            all_index = self.dubbed_audio_mode_combo.findData("all")
            if all_index >= 0:
                model = self.dubbed_audio_mode_combo.model()
                item = model.item(all_index) if hasattr(model, "item") else None
                if item is not None:
                    item.setEnabled(allow_all)
                if mode == "all" and not allow_all:
                    self._set_combo_by_data(self.dubbed_audio_mode_combo, "selected")
                    mode = "selected"
        if hasattr(self, "dubbed_audio_mode_combo"):
            self.dubbed_audio_mode_combo.setEnabled(self._get_mode() != self.MODE_AUDIO and hasattr(self, "chk_dubbed_audio") and self.chk_dubbed_audio.isChecked())
        if hasattr(self, "dubbed_audio_format_combo"):
            self.dubbed_audio_format_combo.setEnabled(enabled)
        if hasattr(self, "dubbed_audio_languages_input"):
            self.dubbed_audio_languages_input.setVisible(custom_mode)
            self.dubbed_audio_languages_input.setEnabled(custom_mode)
        if hasattr(self, "dubbed_audio_hint_label"):
            if enabled and mode == "all" and not allow_all:
                self.dubbed_audio_hint_label.setText(
                    self.t.get("dubbed_audio_all_single_only", "All available tracks can be detected automatically only for single video mode.")
                )
            else:
                self.dubbed_audio_hint_label.setText(
                    self.t.get(
                        "dubbed_audio_hint",
                        "Use the audio language selector for one track, enter comma-separated codes for several tracks, or let Aura detect all available languages for single videos.",
                    )
                )
        self._refresh_download_ux_state()

    def _set_combo_item_enabled(self, combo, data_value, enabled):
        if combo is None:
            return
        index = combo.findData(data_value)
        if index < 0:
            return
        model = combo.model()
        item = model.item(index) if hasattr(model, "item") else None
        if item is not None:
            item.setEnabled(bool(enabled))

    def _refresh_download_ux_state(self):
        mode = self._get_mode() if hasattr(self, "mode_buttons") else self.MODE_VIDEO
        is_video_mode = mode != self.MODE_AUDIO
        keep_all_audio = self._get_download_all_audio_tracks() if hasattr(self, "chk_all_audio_tracks") else False
        playback_target = self._get_playback_target() if hasattr(self, "playback_target_combo") else "auto"
        selected_audio_lang = self._get_audio_language() if hasattr(self, "audio_lang_combo") else "any"

        for attr in ("output_container_label", "container_combo", "video_codec_label", "video_codec_combo", "playback_target_label", "playback_target_combo"):
            widget = getattr(self, attr, None)
            if widget is not None:
                widget.setVisible(is_video_mode)

        if hasattr(self, "video_codec_combo") and self.video_codec_combo:
            codec_enabled = is_video_mode and playback_target == "auto"
            self.video_codec_combo.setEnabled(codec_enabled)
            self.video_codec_combo.setToolTip(
                self.t.get(
                    "video_codec_policy_disabled_hint",
                    "Pick Auto target to control codecs manually, or choose a playback target and Aura will prioritize compatibility for you.",
                ) if not codec_enabled else self.t.get(
                    "video_codec_policy_hint",
                    "Bias automatic format selection toward broad H.264 compatibility or newer VP9/AV1 codecs.",
                )
            )

        if hasattr(self, "chk_all_audio_tracks") and self.chk_all_audio_tracks:
            allow_multi_audio = mode == self.MODE_VIDEO and self.pc.get("has_audio_lang", False)
            self.chk_all_audio_tracks.setVisible(bool(allow_multi_audio))

        if hasattr(self, "container_combo") and self.container_combo:
            self._set_combo_item_enabled(self.container_combo, "mp4", not keep_all_audio)
            current_container = self.container_combo.currentData() or "auto"
            if keep_all_audio:
                if current_container == "mp4":
                    self._container_before_multi_audio = "mp4"
                    self._container_forced_by_multi_audio = True
                    mkv_index = self.container_combo.findData("mkv")
                    if mkv_index >= 0:
                        self.container_combo.setCurrentIndex(mkv_index)
                elif current_container != "mkv":
                    self._container_before_multi_audio = current_container
                    self._container_forced_by_multi_audio = False
            elif self._container_forced_by_multi_audio and current_container == "mkv":
                restore_value = self._container_before_multi_audio or "auto"
                restore_index = self.container_combo.findData(restore_value)
                if restore_index >= 0:
                    self.container_combo.setCurrentIndex(restore_index)
                self._container_forced_by_multi_audio = False

        if hasattr(self, "audio_lang_hint_label") and self.audio_lang_hint_label:
            if mode == self.MODE_AUDIO:
                text = self.t.get(
                    "audio_language_hint_audio_mode",
                    "Pick the one track you want to extract. Multi-track video options are hidden in Audio mode.",
                )
            elif keep_all_audio:
                text = self.t.get(
                    "audio_language_hint_all_tracks",
                    "Aura will keep one best separate track per language in one MKV. The selected language still stays first in priority.",
                )
            elif selected_audio_lang not in {"", "any"}:
                text = self.t.get(
                    "audio_language_hint_selected_track",
                    "Aura will merge the best video with the selected language and use fallbacks only when that exact track is unavailable.",
                )
            else:
                text = self.t.get(
                    "audio_language_hint_video_mode",
                    "Choose one preferred track for the final video, or enable all audio tracks when you want a multi-language MKV.",
                )
            self.audio_lang_hint_label.setText(text)

        if hasattr(self, "compatibility_hint_label") and self.compatibility_hint_label:
            if not is_video_mode:
                self.compatibility_hint_label.setVisible(False)
            else:
                self.compatibility_hint_label.setVisible(True)
                if keep_all_audio:
                    text = self.t.get(
                        "compatibility_hint_multi_audio",
                        "Multiple final audio tracks require MKV, so MP4 is hidden while this option is on.",
                    )
                elif playback_target != "auto":
                    text = self.t.get(
                        "compatibility_hint_target",
                        "Playback target is active: Aura now prioritizes widely playable H.264/AAC-style formats for the selected device.",
                    )
                elif self._get_video_codec_policy() == "modern":
                    text = self.t.get(
                        "compatibility_hint_modern",
                        "Modern codec mode prefers VP9/AV1 when available. This can improve efficiency but may reduce compatibility on older players.",
                    )
                elif self._get_video_codec_policy() == "h264":
                    text = self.t.get(
                        "compatibility_hint_h264",
                        "Compatibility codec mode prefers H.264 so files open more reliably across devices and editors.",
                    )
                else:
                    text = self.t.get(
                        "compatibility_hint_auto",
                        "Auto keeps the interface simple: Aura picks the best source and only remuxes when your container choice requires it.",
                    )
                self.compatibility_hint_label.setText(text)
    
    def _on_aria2c_toggle(self, state):
        visible = self.chk_aria2c.isChecked()
        self.aria2c_threads_combo.setVisible(visible)
        self.aria2c_threads_lbl.setVisible(visible)
    
    def _on_sb_toggle(self, state=None):
        """Show/hide SponsorBlock controls (YouTube only)."""
        if not self.chk_sb:
            return
        visible = self.chk_sb.isChecked()
        self.sb_action_lbl.setVisible(visible)
        self.sb_action_combo.setVisible(visible)
        self.sb_cats_row.setVisible(visible)
        is_remove = self.sb_action_combo.currentData() == "remove"
        self.chk_sb_keyframes.setVisible(visible and is_remove)
    
    def _on_sb_action_change(self, index=None):
        """Show/hide force-keyframes checkbox depending on action type."""
        if not self.chk_sb:
            return
        is_remove = self.sb_action_combo.currentData() == "remove"
        self.chk_sb_keyframes.setVisible(self.chk_sb.isChecked() and is_remove)
    
    def _on_audio_lang_change(self, index):
        pass  # Just stored by combo
    
    def _set_private_url(self, url):
        self.url_input.setText(url)
        self.log(f"🔒 {url}")
    
    # ══════════════════════════════════════════════════════════════════════════
    #  LOG
    # ══════════════════════════════════════════════════════════════════════════
    
    def log(self, message):
        """Buffer log messages and flush in batches (reduces QPlainTextEdit repaints)."""
        if not hasattr(self, '_log_buffer'):
            self._log_buffer = []
            self._log_timer = QTimer(self)
            self._log_timer.setInterval(150)  # Flush every 150ms
            self._log_timer.timeout.connect(self._flush_log_buffer)
            self._log_timer.start()
        self._log_buffer.append(message)
    
    def _flush_log_buffer(self):
        """Flush buffered log lines to QPlainTextEdit in a single operation."""
        if not self._log_buffer:
            return
        batch = self._log_buffer
        self._log_buffer = []
        
        # Single insert — one repaint instead of N
        self.log_text.appendPlainText('\n'.join(batch))
        self._append_log_batch_to_file(batch)
        
        # Trim if too long (once per batch, not per line)
        if self.log_text.blockCount() > LOG_MAX_LINES:
            cursor = self.log_text.textCursor()
            cursor.movePosition(cursor.MoveOperation.Start)
            cursor.movePosition(cursor.MoveOperation.Down, cursor.MoveMode.KeepAnchor, 500)
            cursor.removeSelectedText()
        scrollbar = self.log_text.verticalScrollBar()
        scrollbar.setValue(scrollbar.maximum())
    
    def clear_log(self):
        if hasattr(self, '_log_buffer'):
            self._log_buffer.clear()
        self.log_text.clear()
        self._show_welcome()

    def _default_log_file_path(self):
        """Return the default per-platform log file path."""
        return str(get_settings_dir() / f"log_{self.platform}.txt")

    def _get_log_file_path(self):
        """Return the normalized target log file path."""
        raw_path = ""
        if hasattr(self, "log_file_input"):
            raw_path = self.log_file_input.text().strip()
        elif getattr(self, "_log_file_path", ""):
            raw_path = self._log_file_path.strip()
        return raw_path or self._default_log_file_path()

    def _update_log_file_ui(self):
        """Keep log-file controls consistent with the enabled state."""
        enabled = self.chk_log_file.isChecked() if hasattr(self, "chk_log_file") else self._log_file_enabled
        if hasattr(self, "log_file_input"):
            self.log_file_input.setEnabled(enabled)
        if hasattr(self, "log_file_hint"):
            self.log_file_hint.setEnabled(enabled)

    def _on_log_file_toggled(self, checked):
        """Toggle log-file persistence and save the preference."""
        self._log_file_enabled = bool(checked)
        if hasattr(self, "log_file_input") and not self.log_file_input.text().strip():
            self.log_file_input.setText(self._default_log_file_path())
        self._update_log_file_ui()
        if self._log_file_enabled:
            self._seed_log_file_from_current_view()
        self._save_settings()

    def _on_log_file_path_changed(self):
        """Persist a new log-file path after inline editing."""
        self._log_file_path = self._get_log_file_path()
        self._save_settings()

    def _browse_log_file(self):
        """Choose a .txt file for optional log persistence."""
        initial = self._get_log_file_path()
        path, _ = QFileDialog.getSaveFileName(
            self,
            self.t.get("log_file_dialog_title", "Choose log file"),
            initial,
            self.t.get("log_file_filter", "Text files (*.txt);;All files (*)"),
        )
        if path:
            self.log_file_input.setText(path)
            if not self.chk_log_file.isChecked():
                self.chk_log_file.setChecked(True)
            else:
                self._on_log_file_path_changed()

    def _append_log_batch_to_file(self, batch):
        """Append new log lines to disk when log-file mode is enabled."""
        if not batch or self._writing_log_file:
            return
        if hasattr(self, "chk_log_file"):
            self._log_file_enabled = self.chk_log_file.isChecked()
        if not self._log_file_enabled:
            return
        path_str = self._get_log_file_path()
        try:
            self._writing_log_file = True
            path_obj = Path(path_str)
            path_obj.parent.mkdir(parents=True, exist_ok=True)
            with path_obj.open("a", encoding="utf-8", errors="ignore") as handle:
                handle.write("\n".join(batch) + "\n")
            self._log_file_path = str(path_obj)
        except Exception as exc:
            log_error("log_file_append", exc)
        finally:
            self._writing_log_file = False

    def _seed_log_file_from_current_view(self):
        """Write current visible log once when the feature is enabled for a new file."""
        text = self.log_text.toPlainText().strip() if hasattr(self, "log_text") else ""
        if not text:
            return
        try:
            path_obj = Path(self._get_log_file_path())
            if path_obj.exists() and path_obj.stat().st_size > 0:
                return
            path_obj.parent.mkdir(parents=True, exist_ok=True)
            path_obj.write_text(text + "\n", encoding="utf-8", errors="ignore")
            self._log_file_path = str(path_obj)
        except Exception as exc:
            log_error("log_file_seed", exc)
    
    def _show_welcome(self):
        platform_name = get_platform_name(self.platform, self.lang)
        self.log("")
        self.log("  ═══════════════════════════════════════════════════")
        self.log("            ✦  AURA VIDEO DOWNLOADER  ✦")
        self.log(f"            {platform_name}")
        self.log("  ═══════════════════════════════════════════════════")
        self.log("")
        self.log(f"  {self.t['welcome_line2']}")
        self.log("")
        jokes = self.t.get("joke_welcome", [])
        if jokes:
            self.log(f"  {random.choice(jokes)}")
            self.log("")
        if is_debug_mode():
            self.log(f"  🐛 {self.t.get('debug_banner', 'DEBUG MODE — settings will NOT be saved')}")
            self.log("")
        self._set_runtime_state("idle", self.t.get("log_panel_hint", "Live activity, queue state, and execution output appear here."))
    
    # ══════════════════════════════════════════════════════════════════════════
    #  PROGRESS
    # ══════════════════════════════════════════════════════════════════════════
    
    def _reset_progress(self):
        self.total_videos = 0
        self.downloaded_videos = 0
        self._last_destination = ""
        self._last_destination_path = ""
        self._pending_history = False  # Deferred: True when 100% seen, flushed on Merger/next video/finish
        self.current_speed = ""
        self.current_eta = ""
        self._completed_output_paths = []
        self._buffered_progress_pct = 0
        self._progress_ui_dirty = False
        if getattr(self, "speed_graph", None):
            self.speed_graph.clear_data()
        self._parallel_state = {}  # worker_id -> {total, downloaded, pct, speed, eta}
        self._is_parallel_mode = False
        self.progress_label.setText(self.t["progress_idle"])
        self.speed_label.setText(self.t["speed_idle"])
        self.progress_bar.setValue(0)
    
    def _update_progress_display(self):
        if self.total_videos > 0:
            text = self.t["progress_format"].format(downloaded=self.downloaded_videos, total=self.total_videos)
            self.progress_label.setText(text)
            # Update progress bar for playlists when video count changes
            if self.total_videos > 1:
                overall = int(self.downloaded_videos * 100 / self.total_videos)
                self.progress_bar.setValue(overall)
        else:
            self.progress_label.setText(self.t["progress_scanning"])
    
    def _update_speed_display(self):
        if self.current_speed:
            text = f"{self.current_speed}  ETA {self.current_eta}" if self.current_eta else self.current_speed
            self.speed_label.setText(text)
            self._feed_speed_graph(self.current_speed)
        else:
            self.speed_label.setText(self.t["speed_idle"])
        self._sync_execution_metrics()
    
    def _flush_progress_ui(self):
        """Timer-driven UI update: flushes buffered progress to widgets.
        
        Called at 10Hz (100ms) instead of 100+ Hz per yt-dlp line.
        Reduces QProgressBar/QLabel repaints by ~10x.
        """
        if not self._progress_ui_dirty:
            return
        self._progress_ui_dirty = False
        # Flush progress bar
        pct = getattr(self, '_buffered_progress_pct', 0)
        if pct != self.progress_bar.value():
            self.progress_bar.setValue(pct)
        # Flush speed/ETA label
        self._update_speed_display()
        self._sync_execution_metrics()
    
    def _handle_progress_line(self, line):
        """Called from worker signal for each output line — runs on main thread."""
        try:
            self._handle_progress_line_impl(line)
        except Exception:
            pass  # Never crash on progress parsing
    
    def _handle_progress_line_impl(self, line):
        # ── Speed & ETA (native yt-dlp) ──
        speed_match = SPEED_REGEX.search(line)
        if speed_match:
            self.current_speed = speed_match.group(1)
            self.current_eta = speed_match.group(2)
            self._progress_ui_dirty = True
        else:
            speed_only = SPEED_ONLY_REGEX.search(line)
            if speed_only:
                self.current_speed = speed_only.group(1)
                self.current_eta = ""
                self._progress_ui_dirty = True
            else:
                # ── Speed & ETA (aria2c) ──
                aria_speed = ARIA2C_SPEED_REGEX.search(line)
                if aria_speed:
                    raw = aria_speed.group(1).strip()
                    # aria2c omits "/s" — add it for display consistency
                    self.current_speed = raw if '/s' in raw else f"{raw}/s"
                    aria_eta = ARIA2C_ETA_REGEX.search(line)
                    self.current_eta = aria_eta.group(1) if aria_eta else ""
                    self._progress_ui_dirty = True
        
        # ── Percent bar (native yt-dlp) ──
        current_file_pct = None
        pct_match = PERCENT_REGEX.search(line)
        if pct_match:
            try:
                current_file_pct = float(pct_match.group(1))
            except (ValueError, TypeError):
                pass
        else:
            # ── Percent bar (aria2c) ──
            aria_pct = ARIA2C_PROGRESS_REGEX.search(line)
            if aria_pct:
                try:
                    current_file_pct = float(aria_pct.group(1))
                except (ValueError, TypeError):
                    pass
        
        if current_file_pct is not None:
            if self.total_videos > 1:
                overall = (self.downloaded_videos * 100 + current_file_pct) / self.total_videos
                self._buffered_progress_pct = int(overall)
            else:
                self._buffered_progress_pct = int(current_file_pct)
            self._progress_ui_dirty = True
        
        # ── Video counter ("Downloading item X of Y") ──
        match = PROGRESS_REGEX.search(line)
        if match:
            # Flush previous video's pending history before starting new one
            self._flush_pending_history()
            self.total_videos = int(match.group(2))
            self.downloaded_videos = min(int(match.group(1)) - 1, self.total_videos)
            self._update_progress_display()
        
        # ── Track destinations ──
        if '[download] Destination:' in line:
            dest = line.split('Destination:', 1)[-1].strip()
            self._last_destination = Path(dest).stem if dest else ""
            self._last_destination_path = dest  # Full path for integrity check
            # Reset bar for new file part (e.g. video→audio of same video)
            if self.total_videos <= 1:
                self._buffered_progress_pct = 0
                self._progress_ui_dirty = True
        elif '[Merger] Merging formats into' in line:
            # Merger = final product. Update name to merged file, then flush.
            m = re.search(r'Merging formats into ["\'](.+?)["\']', line)
            if m:
                try:
                    self._last_destination = Path(m.group(1)).stem
                    self._last_destination_path = m.group(1)  # Full merged path
                except (ValueError, TypeError):
                    pass
            self._pending_history = True
            self._flush_pending_history()
            return  # Already flushed, skip duplicate check below
        
        # Download 100% — mark pending (may be intermediate format, not final)
        if self._is_download_complete_line(line):
            self._pending_history = True
        
        # Archive skip — video is done for sure, flush immediately
        if self._is_archive_skip_line(line):
            self._pending_history = True
            self._flush_pending_history()
    
    def _flush_pending_history(self):
        """Flush pending history entry. Called when we're sure one video is fully done:
        after [Merger], when next video starts, on archive skip, or on download finish."""
        if not self._pending_history:
            return
        self._pending_history = False
        
        # Increment video counter
        if self.total_videos > 0 and self.downloaded_videos < self.total_videos:
            self.downloaded_videos = min(self.downloaded_videos + 1, self.total_videos)
            self._update_progress_display()
        
        name = self._last_destination or "Unknown"
        dtype = "audio" if self._get_effective_download_mode() == self.MODE_AUDIO else "video"
        self._track_completed_output_path(self._last_destination_path)
        self._add_to_history(name, "done", "", dtype, platform_id=self._active_download_platform)
    
    def _is_download_complete_line(self, line):
        return (DOWNLOAD_COMPLETE_100_REGEX.search(line) is not None or 
                any(p in line for p in DOWNLOAD_COMPLETE_PATTERNS) or
                ARIA2C_COMPLETE_PATTERN in line)
    
    def _is_archive_skip_line(self, line):
        return any(p in line for p in ARCHIVE_SKIP_PATTERNS)
    
    def _handle_parallel_progress(self, worker_id, line):
        """Handle progress from one parallel worker — aggregates across all workers."""
        try:
            state = self._parallel_state.get(worker_id)
            if not state:
                return
            
            # Per-worker speed/ETA (native yt-dlp)
            speed_match = SPEED_REGEX.search(line)
            if speed_match:
                state['speed'] = speed_match.group(1)
                state['eta'] = speed_match.group(2)
            else:
                speed_only = SPEED_ONLY_REGEX.search(line)
                if speed_only:
                    state['speed'] = speed_only.group(1)
                    state['eta'] = ''
                else:
                    # aria2c speed/ETA
                    aria_speed = ARIA2C_SPEED_REGEX.search(line)
                    if aria_speed:
                        raw = aria_speed.group(1).strip()
                        state['speed'] = raw if '/s' in raw else f"{raw}/s"
                        aria_eta = ARIA2C_ETA_REGEX.search(line)
                        state['eta'] = aria_eta.group(1) if aria_eta else ''
            
            # Per-worker percent (native yt-dlp)
            pct_match = PERCENT_REGEX.search(line)
            if pct_match:
                try:
                    state['pct'] = float(pct_match.group(1))
                except (ValueError, TypeError):
                    pass
            else:
                # aria2c percent
                aria_pct = ARIA2C_PROGRESS_REGEX.search(line)
                if aria_pct:
                    try:
                        state['pct'] = float(aria_pct.group(1))
                    except (ValueError, TypeError):
                        pass
            
            # Per-worker video counter — new video starting, flush previous
            match = PROGRESS_REGEX.search(line)
            if match:
                self._flush_parallel_pending(state)
                state['total'] = int(match.group(2))
                state['downloaded'] = min(int(match.group(1)) - 1, state['total'])
            
            # Track destinations
            if '[download] Destination:' in line:
                dest = line.split('Destination:', 1)[-1].strip()
                state['last_dest'] = Path(dest).stem if dest else ''
                state['last_dest_path'] = dest
                state['pct'] = 0  # Reset for new file part
            elif '[Merger] Merging formats into' in line:
                m = re.search(r'Merging formats into ["\'](.+?)["\']', line)
                if m:
                    try:
                        state['last_dest'] = Path(m.group(1)).stem
                        state['last_dest_path'] = m.group(1)
                    except (ValueError, TypeError):
                        pass
                state['pending'] = True
                self._flush_parallel_pending(state)
            elif self._is_download_complete_line(line):
                state['pending'] = True
            elif self._is_archive_skip_line(line):
                state['pending'] = True
                self._flush_parallel_pending(state)
            
            # Aggregate and display
            self._update_parallel_display()
        except Exception:
            pass
    
    def _flush_parallel_pending(self, state):
        """Flush pending history for one parallel worker."""
        if not state.get('pending'):
            return
        state['pending'] = False
        
        if state['total'] > 0 and state['downloaded'] < state['total']:
            state['downloaded'] = min(state['downloaded'] + 1, state['total'])
        
        dest = state.get('last_dest', '') or 'Unknown'
        dtype = "audio" if self._get_mode() == self.MODE_AUDIO else "video"
        self._track_completed_output_path(state.get('last_dest_path', ''))
        self._add_to_history(dest, "done", "", dtype)
    
    def _update_parallel_display(self):
        """Aggregate all parallel workers' progress into unified display."""
        try:
            self._update_parallel_display_impl()
        except Exception:
            pass  # Never crash on progress display
    
    def _update_parallel_display_impl(self):
        states = self._parallel_state.values()
        if not states:
            return
        
        # Video counter: sum across workers
        total = sum(s['total'] for s in states)
        downloaded = sum(s['downloaded'] for s in states)
        
        if total > 0:
            text = self.t["progress_format"].format(downloaded=downloaded, total=total)
            self.progress_label.setText(text)
            # Weighted overall progress: completed videos + current files across workers
            avg_pct = 0
            active_workers = [s for s in states if s['pct'] > 0 and s['downloaded'] < s['total']]
            if active_workers:
                avg_pct = sum(s['pct'] for s in active_workers) / len(active_workers)
            overall = (downloaded * 100 + avg_pct) / total
            self._buffered_progress_pct = int(min(overall, 100))
            self._progress_ui_dirty = True
        else:
            # No totals yet — average current file percentages across workers
            pcts = [s['pct'] for s in states if s['pct'] > 0]
            if pcts:
                self._buffered_progress_pct = int(sum(pcts) / len(pcts))
                self._progress_ui_dirty = True
            self.progress_label.setText(self.t["progress_scanning"])
        
        # Speed: show sum of all workers' speeds
        total_speed = self._aggregate_speeds(states)
        if total_speed:
            self.current_speed = total_speed
            self.current_eta = ""
            self._progress_ui_dirty = True
    
    @staticmethod
    def _aggregate_speeds(states):
        """Sum speeds across workers, e.g. '1.5MiB/s' + '800KiB/s' → '2.3MiB/s'."""
        total_bytes = 0.0
        for s in states:
            raw = s.get('speed', '')
            if not raw:
                continue
            try:
                # Parse: "1.5MiB/s", "800KiB/s", "2.3GiB/s"
                num_str = ''
                unit = ''
                for j, c in enumerate(raw):
                    if c.isdigit() or c == '.':
                        num_str += c
                    else:
                        unit = raw[j:].split('/')[0].strip()
                        break
                val = float(num_str) if num_str else 0
                multipliers = {'B': 1, 'KiB': 1024, 'MiB': 1024**2, 'GiB': 1024**3,
                               'KB': 1000, 'MB': 1000**2, 'GB': 1000**3,
                               'K': 1024, 'M': 1024**2, 'G': 1024**3}
                total_bytes += val * multipliers.get(unit, 1)
            except (ValueError, IndexError):
                continue
        
        if total_bytes <= 0:
            return ''
        
        # Format back to human-readable
        if total_bytes >= 1024**3:
            return f"⚡ {total_bytes / (1024**3):.1f}GiB/s"
        elif total_bytes >= 1024**2:
            return f"⚡ {total_bytes / (1024**2):.1f}MiB/s"
        elif total_bytes >= 1024:
            return f"⚡ {total_bytes / 1024:.0f}KiB/s"
        else:
            return f"⚡ {total_bytes:.0f}B/s"
    
    # ══════════════════════════════════════════════════════════════════════════
    #  BROWSE / DEPS
    # ══════════════════════════════════════════════════════════════════════════
    
    def _browse_folder(self):
        folder = QFileDialog.getExistingDirectory(self, self.t.get("select_folder_title", "Select folder"),
                                                   self.outdir_input.text() or str(Path.home()))
        if folder:
            display_folder = self._display_path(folder)
            self._set_line_edit_path(self.outdir_input, display_folder)
            self.log(f"{self.t.get('folder_selected', 'Folder: ')}{display_folder}")
    
    def _browse_cookies(self):
        f, _ = QFileDialog.getOpenFileName(self, self.t.get("select_file_title", "Select file"),
                                            str(Path.home()), "Text files (*.txt);;All (*)")
        if f:
            self.cookies_input.setText(f)
            self.log(f"{self.t.get('file_selected', 'File: ')}{f}")
    
    def _browser_login(self):
        """Open in-app browser for platform login → auto-extract cookies."""
        if not _HAS_WEBENGINE:
            QMessageBox.warning(self, self.t.get("error_title", "Error"),
                                self.t.get("auth_webengine_missing", "PySide6-WebEngine is required."))
            return
        
        pc = PLATFORM_CONFIGS.get(self.platform, {})
        login_url = pc.get("login_url")
        if not login_url:
            self.log(f"⚠️ No login URL configured for {self.platform}")
            return
        
        platform_name = pc.get("name", self.platform)
        output_path = get_settings_dir() / f"cookies_{self.platform}.txt"
        lang = self.lang
        
        dlg = CookieBrowserDialog(
            self, platform_name, login_url, output_path, lang, self.theme_id,
            profile=self._get_shared_browser_profile(),
        )
        dlg.exec()
        
        if dlg.success:
            n = len(dlg.cookies)
            self.cookies_input.setText(str(output_path))
            # Auto-switch auth to cookies_file
            self._set_combo_by_data(self.auth_combo, "cookies_file")
            self.log(self.t.get("auth_login_success", "✅ Cookies extracted! ({n}) Saved to:\n   {path}").format(
                n=n, path=output_path))
            self._save_settings()
        elif dlg.result() == QDialog.Accepted:
            # User pressed Done but no cookies
            self.log(self.t.get("auth_login_no_cookies", "⚠️ No cookies extracted."))
    
    def _get_platform_browse_url(self):
        url = self.pc.get("browse_url")
        if isinstance(url, str) and url.strip():
            return url.strip()
        domains = self.pc.get("domains", [])
        if domains:
            return f"https://{domains[0]}"
        return "https://www.youtube.com/"

    def _get_platform_search_url_template(self):
        tpl = self.pc.get("search_url")
        if isinstance(tpl, str) and "{query}" in tpl:
            return tpl
        return ""

    def _get_shared_browser_profile(self):
        if not _HAS_WEBENGINE:
            return None
        if self._browser_profile is not None:
            return self._browser_profile
        from PySide6.QtWebEngineCore import QWebEngineProfile

        profile_dir = get_settings_dir() / "web_profile" / self.platform
        cache_dir = profile_dir / "cache"
        profile_dir.mkdir(parents=True, exist_ok=True)
        cache_dir.mkdir(parents=True, exist_ok=True)

        profile = QWebEngineProfile(f"aura-{self.platform}", self)
        profile.setPersistentStoragePath(str(profile_dir))
        profile.setCachePath(str(cache_dir))
        profile.setPersistentCookiesPolicy(QWebEngineProfile.ForcePersistentCookies)
        self._browser_profile = profile
        return profile

    def _open_media_browser(self):
        """Open a built-in browser for in-app media discovery."""
        if not _HAS_WEBENGINE:
            QMessageBox.warning(
                self,
                self.t.get("error_title", "Error"),
                self.t.get("auth_webengine_missing", "PySide6-WebEngine is required."),
            )
            return

        pc = PLATFORM_CONFIGS.get(self.platform, {})
        platform_name = pc.get("name", self.platform)
        domains = pc.get("domains", [])
        current_url = self.url_input.text().strip()
        dlg = DiscoveryBrowserDialog(
            self,
            platform_name=platform_name,
            start_url=current_url or self._get_platform_browse_url(),
            home_url=self._get_platform_browse_url(),
            search_url_template=self._get_platform_search_url_template(),
            domain_hint=domains[0] if domains else "",
            lang=self.lang,
            theme_id=self.theme_id,
            profile=self._get_shared_browser_profile(),
        )
        if dlg.exec() == QDialog.Accepted and dlg.selected_url:
            selected_value = dlg.selected_url
            if self._get_mode() == self.MODE_SEARCH:
                extracted_query = self._get_search_query_from_url(selected_value, platform_id=self.platform)
                if extracted_query:
                    selected_value = extracted_query
                elif selected_value.startswith(("http://", "https://")):
                    self._set_radio_group(self.mode_buttons, "mode_value", self.MODE_VIDEO)
                    self._on_mode_change()
            self.url_input.setText(selected_value)
            self.log(self.t.get("browser_selected_log", "Browser selected URL: {url}").format(url=selected_value))
            if dlg.download_requested:
                self.start_download()

    def _current_similar_query(self):
        raw_url = self.url_input.text().strip()
        if not raw_url:
            return ""
        if self._get_mode() == self.MODE_SEARCH:
            return self._get_search_query_from_url(raw_url, platform_id=self.platform) or raw_url

        cache_key = self._media_info_cache_key(
            raw_url,
            cookies=self.cookies_input.text().strip(),
            platform_id=self.platform,
        )
        media_info = self._media_info_cache.get(cache_key) or self._probe_media_info(
            raw_url,
            cookies=self.cookies_input.text().strip(),
            platform_id=self.platform,
            log_errors=False,
        )
        title = (media_info.get("title") or "").strip()
        uploader = (media_info.get("uploader") or "").strip()
        if title and uploader and uploader.lower() not in title.lower():
            return f"{title} {uploader}"
        return title

    def _find_similar_media(self):
        raw_url = self.url_input.text().strip()
        mode = self._get_mode()
        direct_page_open = bool(raw_url) and raw_url.startswith(("http://", "https://")) and mode != self.MODE_SEARCH

        query = ""
        if not raw_url and not direct_page_open:
            query = self._current_similar_query()
        if not raw_url and not query:
            self.log(self.t.get("similar_no_query", "⚠️ Could not build a similar-search query for the current item."))
            return

        if not _HAS_WEBENGINE:
            query = query or self._current_similar_query()
            self._set_radio_group(self.mode_buttons, "mode_value", self.MODE_SEARCH)
            self._on_mode_change()
            self.url_input.setText(query)
            self.log(
                self.t.get(
                    "similar_search_fallback",
                    "🔎 Similar search prepared in Search mode: {query}",
                ).format(query=query)
            )
            return

        pc = PLATFORM_CONFIGS.get(self.platform, {})
        platform_name = pc.get("name", self.platform)
        domains = pc.get("domains", [])
        if not direct_page_open:
            query = query or self._current_similar_query()
        start_target = raw_url if direct_page_open else query
        dlg = DiscoveryBrowserDialog(
            self,
            platform_name=platform_name,
            start_url=start_target,
            home_url=self._get_platform_browse_url(),
            search_url_template=self._get_platform_search_url_template(),
            domain_hint=domains[0] if domains else "",
            lang=self.lang,
            theme_id=self.theme_id,
            profile=self._get_shared_browser_profile(),
        )
        if start_target == raw_url and raw_url:
            self.log(
                self.t.get(
                    "recommended_browser_hint",
                    "🎯 Opening the current page so you can browse recommended and related videos directly.",
                )
            )
        if dlg.exec() == QDialog.Accepted and dlg.selected_url:
            self.url_input.setText(dlg.selected_url)
            self.log(
                self.t.get("similar_browser_selected", "🔎 Similar item selected: {url}").format(
                    url=dlg.selected_url
                )
            )
            if dlg.download_requested:
                self.start_download()

    def _open_download_folder(self):
        """Open the download folder in system file manager."""
        folder = self._active_download_outdir if self._runtime_state == "running" and self._active_download_outdir else self.outdir_input.text().strip()
        if folder and Path(folder).is_dir():
            if sys.platform == 'win32':
                os.startfile(folder)  # Reliable Explorer opening on Windows
            else:
                webbrowser.open(folder)
        else:
            self.log(self.t.get("open_folder_err", "❌ Folder not found"))
    
    def _get_default_outdir(self):
        """Get default output directory, ensuring it exists."""
        # On Windows, user may have moved Downloads via Settings → use shell API
        if sys.platform == 'win32':
            try:
                import ctypes
                from ctypes import wintypes
                GUID = ctypes.c_char_p(
                    b'\xe3\x9c\x45\x37\x4d\xd1\xd0\x42\xba\x46\x98\x65\xc6\xb4\x48\x40')
                SHGetKnownFolderPath = ctypes.windll.shell32.SHGetKnownFolderPath
                SHGetKnownFolderPath.argtypes = [ctypes.c_char_p, ctypes.c_uint32,
                                                   ctypes.c_void_p, ctypes.POINTER(ctypes.c_wchar_p)]
                path_ptr = ctypes.c_wchar_p()
                if SHGetKnownFolderPath(GUID, 0, None, ctypes.byref(path_ptr)) == 0:
                    result = Path(path_ptr.value)
                    ctypes.windll.ole32.CoTaskMemFree(path_ptr)
                    if result.is_dir():
                        return result
            except Exception:
                pass  # Fallback below
        downloads = Path.home() / "Downloads"
        if downloads.is_dir():
            return downloads
        return Path.home()
    
    def _check_dependencies_bg(self):
        """Check dependencies using proper QThread + Signal."""
        if self._closing:
            return
        worker = DepsWorker(self.pc)
        worker.results_ready.connect(self._apply_dep_results)
        self._replace_thread_worker("deps_worker", worker, "deps_worker")
        worker.start()
    
    def _apply_dep_results(self, results):
        self.log(self.t["checking_deps"])
        self.log("")
        
        # Store resolved binary paths for later use
        s, v, p = results.get('ytdlp', ('error', '', ''))
        self._ytdlp_bin = p if p else "yt-dlp"
        if s == 'ok':
            self.ytdlp_status_label.setText(f"✅ {v}")
            self._set_status_badge(self.ytdlp_status_label, self.ytdlp_status_label.text(), "ok")
            self.log(f"{self.t['ytdlp_found']}{v}")
            self.log(f"    PATH: {p}")
        else:
            self.ytdlp_status_label.setText(self.t["not_found"])
            self._set_status_badge(self.ytdlp_status_label, self.ytdlp_status_label.text(), "error")
            self.log(self.t["ytdlp_not_found"])
        
        s, v, p = results.get('ffmpeg', ('error', '', ''))
        self._ffmpeg_bin = p if p else "ffmpeg"
        if s == 'ok':
            self.ffmpeg_status_label.setText(self.t["installed"])
            self._set_status_badge(self.ffmpeg_status_label, self.ffmpeg_status_label.text(), "ok")
            self.log(self.t["ffmpeg_found"])
            self.log(f"    PATH: {p}")
        else:
            self.ffmpeg_status_label.setText(self.t["not_found"])
            self._set_status_badge(self.ffmpeg_status_label, self.ffmpeg_status_label.text(), "error")
            self.log(self.t["ffmpeg_not_found"])
        
        s, v, p = results.get('nodejs', ('error', '', ''))
        self._node_bin = p if p else "node"
        if s == 'ok':
            self.nodejs_status_label.setText(f"✅ {v}")
            self._set_status_badge(self.nodejs_status_label, self.nodejs_status_label.text(), "ok")
        elif s == 'notneeded':
            lbl = "не требуется" if self.lang == "ru" else "not required"
            self.nodejs_status_label.setText(f"ℹ️ {lbl}")
            self._set_status_badge(self.nodejs_status_label, self.nodejs_status_label.text(), "optional")
        else:
            self.nodejs_status_label.setText(self.t["not_found"])
            self._set_status_badge(self.nodejs_status_label, self.nodejs_status_label.text(), "warning")
        
        s, v, p = results.get('aria2c', ('error', '', ''))
        self._aria2c_bin = p if p else "aria2c"
        if s == 'ok':
            self.aria2c_status_label.setText(f"✅ {v}")
            self._set_status_badge(self.aria2c_status_label, self.aria2c_status_label.text(), "ok")
            self.log(self.t.get("aria2c_found", "  ✅ aria2c:     found"))
            self.log(f"    PATH: {p}")
        else:
            opt = self.t.get("optional", "optional")
            self.aria2c_status_label.setText(f"ℹ️ {self.t['not_found']} ({opt})")
            self._set_status_badge(self.aria2c_status_label, self.aria2c_status_label.text(), "optional")
            self.log(self.t.get("aria2c_missing_log", "  ℹ️ aria2c:     not found (optional)"))

        s, v, p = results.get('everything', ('error', '', ''))
        self._everything_bin = p if p else ""
        if s == 'ok':
            self.everything_status_label.setText(self.t["installed"])
            self._set_status_badge(self.everything_status_label, self.everything_status_label.text(), "ok")
            self.log(self.t.get("everything_found", "  ✅ Everything: installed"))
            self.log(f"    PATH: {p}")
        else:
            opt = self.t.get("optional", "optional")
            self.everything_status_label.setText(f"ℹ️ {self.t['not_found']} ({opt})")
            self._set_status_badge(self.everything_status_label, self.everything_status_label.text(), "optional")
            self.log(self.t.get("everything_missing_log", "  ℹ️ Everything: not found (optional)"))
        
        if self.pc.get("use_ytdlp_config", False):
            ensure_ytdlp_config()
        self._maybe_show_missing_dependencies_dialog(results)
        
        self.log("")
        self.log("-" * 50)
        self.log("")

    def _missing_dependency_alert_items(self, results):
        items = []
        specs = [
            (
                "ytdlp",
                "yt-dlp",
                "critical",
                self.t.get(
                    "deps_startup_impact_ytdlp",
                    "Core downloads cannot start until yt-dlp is installed or fixed.",
                ),
            ),
            (
                "ffmpeg",
                "FFmpeg",
                "high",
                self.t.get(
                    "deps_startup_impact_ffmpeg",
                    "Post-processing, stream merging, remuxing, and many audio/video conversions will fail.",
                ),
            ),
            (
                "nodejs",
                "Node.js",
                "medium",
                self.t.get(
                    "deps_startup_impact_nodejs",
                    "Browser-cookie login and cookie extraction features will be unavailable.",
                ),
            ),
            (
                "aria2c",
                "aria2c",
                "low",
                self.t.get(
                    "deps_startup_impact_aria2c",
                    "Accelerated multi-connection downloads will be disabled, but regular downloads still work.",
                ),
            ),
            (
                "everything",
                "Everything CLI",
                "low",
                self.t.get(
                    "deps_startup_impact_everything",
                    "Fast Windows file search integration will be unavailable.",
                ),
            ),
        ]
        for dep_key, name, severity, impact in specs:
            status, _version, _path = results.get(dep_key, ("missing", "", ""))
            if status in {"ok", "notneeded"}:
                continue
            items.append(
                {
                    "key": dep_key,
                    "name": name,
                    "severity": severity,
                    "impact": impact,
                    "status": status,
                }
            )
        return items

    def _maybe_show_missing_dependencies_dialog(self, results):
        if self._deps_startup_dialog_shown or self._closing:
            return
        items = self._missing_dependency_alert_items(results)
        if not items:
            return
        self._deps_startup_dialog_shown = True

        def _show_dialog(attempts_left=6):
            if self._closing:
                return
            if not self.isVisible():
                if attempts_left > 0:
                    QTimer.singleShot(150, lambda: _show_dialog(attempts_left - 1))
                return
            dialog = MissingDependenciesDialog(self, items, t=self.t, theme_id=self.theme_id)
            dialog.exec()
            if getattr(dialog, "open_system", False):
                self._activate_workspace_category("system")
                self._activate_workspace_page("system_tools", scroll_top=True)

        QTimer.singleShot(0, _show_dialog)
    
    def _update_ytdlp(self):
        self.log(self.t["updating_ytdlp"])
        ytdlp_bin = getattr(self, '_ytdlp_bin', find_binary("yt-dlp"))
        self.log(f"   {self.t['updating_cmd']}")
        def _run():
            try:
                # Use yt-dlp's own self-update (system PATH binary, not pip)
                r = subprocess.run([ytdlp_bin, "-U", "--update-to", "master"],
                                    capture_output=True, text=True,
                                    encoding='utf-8', errors='surrogateescape',
                                    env=_get_subprocess_env(),
                                    creationflags=SUBPROCESS_FLAGS, timeout=120)
                output = _fix_encoding((r.stdout or '') + (r.stderr or '')).strip()
                if output:
                    self._sig_log.emit(output)
                if r.returncode == 0:
                    self._sig_log.emit(self.t.get("update_ytdlp_ok", "✅ yt-dlp updated"))
                else:
                    self._sig_log.emit(f"⚠️ Exit code: {r.returncode}")
            except Exception as e:
                self._sig_log.emit(f"❌ {e}")
        threading.Thread(target=_run, daemon=True).start()
    
    def _download_nodejs(self):
        webbrowser.open("https://nodejs.org/")
        self.log(self.t.get("nodejs_opening_browser", "Opening Node.js download page..."))
    
    def _reset_settings(self):
        reply = QMessageBox.question(self, self.t["error_title"],
                                      self.t["reset_confirm"],
                                      QMessageBox.Yes | QMessageBox.No)
        if reply == QMessageBox.Yes:
            # Set flag FIRST — prevents closeEvent from re-saving settings
            self._resetting = True
            
            # Stop any active download before deleting files
            self.stop_event.set()
            if self.worker and self.worker.isRunning():
                self.worker.stop()
                self.worker.wait(3000)
            for w in getattr(self, '_parallel_workers', []):
                w.stop()
                w.wait(3000)
                if w.isRunning():
                    try:
                        w.terminate()
                    except Exception:
                        pass
            self._shutdown_background_workers()
            # Kill restart mode subprocess
            if self._restart_process:
                try:
                    self._restart_process.terminate()
                    self._restart_process.wait(timeout=PROCESS_TERMINATE_TIMEOUT)
                except Exception:
                    try:
                        self._restart_process.kill()
                    except Exception:
                        pass
            
            self.log(self.t.get("reset_log_header", "🗑️ === FULL SETTINGS RESET ==="))
            
            dirs_to_nuke, files_to_nuke = self._collect_reset_targets()
            es_path = self._find_everything_cli()
            if es_path:
                es_reply = QMessageBox.question(
                    self,
                    self.t.get("reset_everything_title", "Extended cleanup"),
                    self.t.get(
                        "reset_everything_prompt",
                        "Everything CLI was found.\n\nUse it to search the whole computer for extra Aura Video Downloader save files before deletion?\n\nOnly known save files inside aura_video_downloader_settings folders will be removed.",
                    ),
                    QMessageBox.Yes | QMessageBox.No,
                    QMessageBox.Yes,
                )
                if es_reply == QMessageBox.Yes:
                    extra_dirs, extra_files, _ = self._collect_everything_reset_targets()
                    dirs_to_nuke.update(extra_dirs)
                    files_to_nuke.update(extra_files)
                    self.log(
                        self.t.get(
                            "reset_everything_found",
                            "  🔎 Everything: found {files} files and {dirs} folders for additional cleanup",
                        ).format(files=len(extra_files), dirs=len(extra_dirs))
                    )

            # Remove files first so DB/cookies/archive leftovers do not survive a partial rmtree
            for f in sorted(files_to_nuke, key=lambda p: str(p)):
                self.log(f"  🗑️ → {f}")
                try:
                    if f.exists():
                        f.unlink()
                except Exception as e:
                    self.log(f"    ⚠️ {e}")

            # Then remove directories from deepest to shallowest
            for d in sorted(dirs_to_nuke, key=lambda p: len(str(p)), reverse=True):
                self.log(f"  🗑️ → {d}")
                try:
                    if d.exists():
                        shutil.rmtree(d, ignore_errors=False)
                except Exception as e:
                    self.log(f"    ⚠️ {e}")
            
            self.log("")
            self.log(self.t["settings_reset"])
            
            # Exit app
            QTimer.singleShot(500, lambda: QApplication.instance().quit())
    
    def _change_theme(self):
        dlg = ThemeSelector(self.lang, self)
        result = dlg.run()
        if result:
            QMessageBox.information(self, self.t.get("theme_title", "🎨"),
                self.t.get("theme_restart", "Theme saved. Restart app to apply."))
    
    def _change_platform(self):
        """Save current settings, show platform picker, restart with new platform."""
        # Save settings for current platform FIRST
        self._save_settings()
        self._save_download_history()
        
        dlg = PlatformSelector(self.lang, self.theme_id, self)
        new_platform = dlg.run()
        if new_platform and new_platform != self.platform:
            self._next_platform = new_platform
            self._request_app_close()
    
    # ══════════════════════════════════════════════════════════════════════════
    #  AUTH
    # ══════════════════════════════════════════════════════════════════════════

    @staticmethod
    def _upsert_youtube_extractor_param(params, key, value):
        prefix = f"{key}="
        updated = [param for param in (params or []) if not str(param).startswith(prefix)]
        if value:
            updated.append(f"{key}={value}")
        return updated

    def _runtime_audio_language(self, runtime_settings=None):
        settings = runtime_settings if isinstance(runtime_settings, dict) else {}
        return str(settings["audio_language"] if "audio_language" in settings else self._get_audio_language()).strip()

    def _runtime_meta_language(self, runtime_settings=None):
        settings = runtime_settings if isinstance(runtime_settings, dict) else {}
        return str(settings["meta_language"] if "meta_language" in settings else self._get_meta_language()).strip()

    def _resolve_youtube_request_language(self, runtime_settings=None):
        audio_lang = self._normalize_language_code(self._runtime_audio_language(runtime_settings))
        if audio_lang == "default":
            preferred = self._preferred_default_language_code(self._plain_language_codes(self._audio_language_choices()))
            return self._normalize_language_code(preferred).split("-", 1)[0]
        if audio_lang and audio_lang not in {"any", "original"}:
            return audio_lang.split("-", 1)[0]
        if audio_lang == "original":
            return ""
        meta_lang = self._normalize_language_code(self._runtime_meta_language(runtime_settings))
        if meta_lang and meta_lang != "any":
            return meta_lang.split("-", 1)[0]
        return ""

    @staticmethod
    def _build_accept_language_header(language_code):
        normalized = str(language_code or "").strip().replace("_", "-")
        if not normalized:
            return ""
        base = normalized.split("-", 1)[0].lower()
        if base == "ru":
            return "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7"
        if base == "en":
            return "en-US,en;q=0.9"
        region = normalized.split("-", 1)[1].upper() if "-" in normalized else base.upper()
        primary = f"{base}-{region}"
        return f"{primary},{base};q=0.9,en-US;q=0.8,en;q=0.7"

    def _should_force_youtube_audio_client_workaround(self, runtime_settings=None):
        audio_lang = self._normalize_language_code(self._runtime_audio_language(runtime_settings))
        return audio_lang not in {"", "any", "original"}

    @staticmethod
    def _runtime_settings_match(left, right):
        left_data = left if isinstance(left, dict) else {}
        right_data = right if isinstance(right, dict) else {}
        keys = ("auth_method", "cookies", "audio_language", "meta_language", "proxy")
        return all(str(left_data.get(key) or "").strip() == str(right_data.get(key) or "").strip() for key in keys)

    def _clone_runtime_settings(self, runtime_settings=None, **overrides):
        if isinstance(runtime_settings, dict):
            base = self._clone_json_value(runtime_settings)
        else:
            base = self._clone_json_value(self._collect_runtime_settings_snapshot())
        for key, value in overrides.items():
            base[key] = value
        return base

    def _youtube_audio_browser_fallbacks(self):
        if sys.platform == "win32":
            return ["edge", "chrome", "brave", "firefox", "chromium", "opera"]
        if sys.platform == "darwin":
            return ["safari", "chrome", "edge", "brave", "firefox", "chromium", "opera"]
        return ["chrome", "chromium", "edge", "brave", "firefox", "opera"]

    def _youtube_audio_browser_profile_fallbacks(self):
        profile_specs = []
        if sys.platform != "win32":
            return profile_specs

        waterfox_profiles = Path.home() / "AppData" / "Roaming" / "Waterfox" / "Profiles"
        if not waterfox_profiles.exists():
            return profile_specs

        for profile_dir in sorted(waterfox_profiles.iterdir()):
            if not profile_dir.is_dir():
                continue
            if not (profile_dir / "cookies.sqlite").exists():
                continue
            profile_specs.append(f"firefox:{profile_dir}")
        return profile_specs

    def _youtube_audio_runtime_candidates(self, cookies="", platform_id=None, runtime_settings=None):
        platform_id, _ = self._resolve_platform_context(platform_id)
        base = self._clone_runtime_settings(runtime_settings)
        candidates = [base]
        if platform_id != "youtube":
            return candidates

        selected_audio_lang = self._normalize_language_code(self._runtime_audio_language(base))
        if selected_audio_lang in {"", "any", "default", "original"}:
            return candidates
        if str(base.get("auth_method") or "none").strip() != "none":
            return candidates

        saved_cookies = get_settings_dir() / f"cookies_{platform_id}.txt"
        if saved_cookies.exists():
            candidates.append(
                self._clone_runtime_settings(
                    base,
                    auth_method="cookies_file",
                    cookies=str(saved_cookies),
                )
            )

        for browser in self._youtube_audio_browser_fallbacks():
            candidates.append(
                self._clone_runtime_settings(
                    base,
                    auth_method=browser,
                    cookies="",
                )
            )
        for browser_spec in self._youtube_audio_browser_profile_fallbacks():
            candidates.append(
                self._clone_runtime_settings(
                    base,
                    auth_method=browser_spec,
                    cookies="",
                )
            )

        unique = []
        for candidate in candidates:
            if any(self._runtime_settings_match(candidate, existing) for existing in unique):
                continue
            unique.append(candidate)
        return unique

    def _media_info_matches_requested_audio_language(self, requested_audio_lang, media_info=None):
        selected = self._normalize_language_code(requested_audio_lang)
        if selected in {"", "any", "default", "original"}:
            return True
        available = self._extract_audio_languages_from_info(media_info or {})
        if not available:
            return False
        return bool(self._match_language_code([selected], available))

    def _resolve_media_info_for_requested_audio_language(self, url, cookies="", platform_id=None,
                                                         runtime_settings=None, log_errors=False):
        platform_id, _ = self._resolve_platform_context(platform_id)
        effective_settings = self._clone_runtime_settings(runtime_settings)
        selected_audio_lang = self._runtime_audio_language(effective_settings)
        effective_cookies = str(cookies or effective_settings.get("cookies") or "").strip()

        media_info = self._probe_media_info(
            url,
            cookies=effective_cookies,
            platform_id=platform_id,
            log_errors=log_errors,
            runtime_settings=effective_settings,
        )
        if self._media_info_matches_requested_audio_language(selected_audio_lang, media_info=media_info):
            return media_info, effective_settings, False

        if platform_id != "youtube":
            return media_info, effective_settings, False

        for candidate in self._youtube_audio_runtime_candidates(
            cookies=effective_cookies,
            platform_id=platform_id,
            runtime_settings=effective_settings,
        ):
            if self._runtime_settings_match(candidate, effective_settings):
                continue
            candidate_cookies = str(candidate.get("cookies") or cookies or "").strip()
            candidate_info = self._probe_media_info(
                url,
                cookies=candidate_cookies,
                platform_id=platform_id,
                log_errors=log_errors,
                runtime_settings=candidate,
            )
            if self._media_info_matches_requested_audio_language(selected_audio_lang, media_info=candidate_info):
                return candidate_info, candidate, True

        return media_info, effective_settings, False

    def _get_auth_args(self, runtime_settings=None, cookies_override=""):
        settings = runtime_settings if isinstance(runtime_settings, dict) else {}
        method = settings["auth_method"] if "auth_method" in settings else self._get_auth_method()
        if method == "none":
            return []
        if method == "cookies_file":
            if cookies_override:
                cookies = str(cookies_override).strip()
            elif "cookies" in settings:
                cookies = str(settings.get("cookies") or "").strip()
            else:
                cookies = self.cookies_input.text().strip()
            return ["--cookies", cookies] if cookies else []
        return ["--cookies-from-browser", method]

    def _resolve_platform_context(self, platform_id=None):
        pid = platform_id or self._active_download_platform or self.platform
        return pid, PLATFORM_CONFIGS.get(pid, PLATFORM_CONFIGS["youtube"])

    def _get_effective_download_mode(self):
        return self._active_download_mode or self._get_mode()

    def _get_effective_download_quality(self):
        return self._active_download_quality or self._get_quality()

    def _build_ytdlp_runtime_args(self, cookies="", platform_id=None, runtime_settings=None):
        platform_id, pc = self._resolve_platform_context(platform_id)
        args = []
        settings = runtime_settings if isinstance(runtime_settings, dict) else {}

        if pc.get("use_ytdlp_config", False):
            ytdlp_conf = get_ytdlp_config_path()
            if ytdlp_conf and ytdlp_conf.exists():
                args.extend(["--config-location", str(ytdlp_conf)])

        if platform_id == "youtube" and self._binary_available(getattr(self, "_node_bin", find_binary("node"))):
            args.extend(["--js-runtimes", "node"])

        yt_extractor_params = []
        request_lang = self._resolve_youtube_request_language(settings) if platform_id == "youtube" else ""
        if request_lang:
            yt_extractor_params = self._upsert_youtube_extractor_param(yt_extractor_params, "lang", request_lang)
            accept_language = self._build_accept_language_header(request_lang)
            if accept_language:
                args.extend(["--add-header", f"Accept-Language:{accept_language}"])

        effective_cookies = str(cookies or settings.get("cookies") or "").strip()
        auth_args = self._get_auth_args(runtime_settings=settings, cookies_override=effective_cookies)
        has_cookies_or_auth = bool(auth_args)

        if not has_cookies_or_auth and effective_cookies and os.path.isfile(effective_cookies):
            args.extend(["--cookies", effective_cookies])
            has_cookies_or_auth = True
        elif auth_args:
            args.extend(auth_args)

        if (
            platform_id == "youtube"
            and request_lang
            and not has_cookies_or_auth
            and self._should_force_youtube_audio_client_workaround(settings)
        ):
            yt_extractor_params = self._upsert_youtube_extractor_param(
                yt_extractor_params,
                "player_client",
                "web_embedded,default",
            )

        ea_source = pc.get("cookies_args", []) if has_cookies_or_auth else pc.get("no_cookies_args", [])
        if ea_source:
            i = 0
            while i < len(ea_source):
                if ea_source[i] == "--extractor-args" and i + 1 < len(ea_source):
                    ea_val = ea_source[i + 1]
                    if ea_val.startswith("youtube:"):
                        params_str = ea_val[len("youtube:"):]
                        for p in params_str.split(";"):
                            p = p.strip()
                            if p:
                                yt_extractor_params.append(p)
                    else:
                        args.extend(["--extractor-args", ea_val])
                    i += 2
                else:
                    args.append(ea_source[i])
                    i += 1

        if yt_extractor_params:
            args.extend(["--extractor-args", f"youtube:{';'.join(yt_extractor_params)}"])

        proxy = str(settings["proxy"]).strip() if "proxy" in settings else self.proxy_input.text().strip()
        if proxy:
            args.extend(["--proxy", proxy])

        extra = pc.get("extra_args", [])
        if extra:
            args.extend(extra)

        return args

    def _media_info_cache_key(self, url, cookies="", platform_id=None, runtime_settings=None):
        platform_id, _ = self._resolve_platform_context(platform_id)
        normalized_url = str(url or "").strip()
        normalized_cookies = str(cookies or "").strip()
        runtime_args = tuple(
            self._build_ytdlp_runtime_args(
                cookies=normalized_cookies,
                platform_id=platform_id,
                runtime_settings=runtime_settings,
            )
        )
        return (platform_id, normalized_url, normalized_cookies, runtime_args)

    @staticmethod
    def _clone_json_value(value):
        try:
            return json.loads(json.dumps(value, ensure_ascii=False))
        except Exception:
            return value

    def _collect_runtime_settings_snapshot(self):
        return {
            "mode": self._get_mode(),
            "outdir": self.outdir_input.text().strip(),
            "cookies": self.cookies_input.text().strip(),
            "proxy": self.proxy_input.text().strip(),
            "search_results_limit": self._get_search_results_limit(),
            "video_quality": self._get_quality(),
            "audio_format": self._get_audio_format(),
            "audio_bitrate": self._get_audio_bitrate(),
            "audio_source": self._get_audio_source(),
            "audio_language": self._get_audio_language(),
            "download_all_audio_tracks": self._get_download_all_audio_tracks(),
            "dubbed_audio_export": self._get_dubbed_audio_export_enabled(),
            "dubbed_audio_mode": self._get_dubbed_audio_mode(),
            "dubbed_audio_languages": self._get_dubbed_audio_languages_text(),
            "dubbed_audio_format": self._get_dubbed_audio_format(),
            "meta_language": self._get_meta_language(),
            "restart_each_video": self.chk_restart.isChecked(),
            "no_numbering": self.chk_nonumber.isChecked(),
            "reverse_playlist": self.chk_reverse.isChecked(),
            "use_archive": self.chk_archive.isChecked(),
            "download_subtitles": self.chk_subs.isChecked(),
            "subtitle_language": self._get_sub_language(),
            "embed_subtitles": self._get_embed_subtitles(),
            "subtitle_format": self._get_subtitle_format(),
            "auth_method": self._get_auth_method(),
            "use_aria2c": self.chk_aria2c.isChecked(),
            "aria2c_threads": self.aria2c_threads_combo.currentText(),
            "concurrent_videos": self.concurrent_combo.currentText(),
            "manual_item_selection": self.chk_manual_selection.isChecked() if hasattr(self, "chk_manual_selection") else self._manual_item_selection,
            "sb_enabled": self.chk_sb.isChecked() if self.chk_sb else False,
            "sb_action": self._get_sb_action(),
            "sb_categories": self._get_sb_categories(),
            "sb_force_keyframes": self.chk_sb_keyframes.isChecked() if self.chk_sb else False,
            "speed_limit": int(self.speed_limit_input.text()) if hasattr(self, "speed_limit_input") and self.speed_limit_input.text().strip().isdigit() else 0,
            "speed_limit_unit": "kbs" if hasattr(self, "speed_limit_unit") and self.speed_limit_unit.currentIndex() == 0 else "mbs",
            "output_container": ["auto", "mp4", "mkv"][self.container_combo.currentIndex()] if hasattr(self, "container_combo") else "auto",
            "video_codec_policy": self._get_video_codec_policy(),
            "playback_target": self._get_playback_target(),
            "immersive_safe_container": self._get_immersive_safe_container_enabled(),
            "manual_format_id": getattr(self, "_manual_format_id", ""),
            "manual_format_kind": getattr(self, "_manual_format_kind", ""),
            "manual_format_context": self._clone_json_value(getattr(self, "_manual_format_context", {})),
            "generate_m3u": self._get_generate_m3u_enabled(),
            "auto_remove_completed": self.chk_auto_remove_completed.isChecked() if hasattr(self, "chk_auto_remove_completed") else self._auto_remove_completed,
            "history_auto_remove_completed": self.chk_auto_remove_completed.isChecked() if hasattr(self, "chk_auto_remove_completed") else self._auto_remove_completed,
        }

    def _apply_runtime_settings_snapshot(self, data):
        if not isinstance(data, dict):
            return

        if "outdir" in data:
            self._set_line_edit_path(self.outdir_input, data.get("outdir", ""))
        if "cookies" in data:
            self.cookies_input.setText(data.get("cookies", ""))
        if "proxy" in data:
            self.proxy_input.setText(data.get("proxy", ""))
        if "mode" in data:
            self._set_radio_group(self.mode_buttons, "mode_value", data["mode"])
        if "search_results_limit" in data and hasattr(self, "search_limit_combo"):
            self.search_limit_combo.setCurrentText(str(data["search_results_limit"]))
        if "video_quality" in data:
            self._set_radio_group(self.quality_buttons, "q_value", data["video_quality"])
        if "audio_format" in data:
            self._set_radio_group(self.format_buttons, "fmt_value", data["audio_format"])
        if "audio_bitrate" in data:
            self._set_radio_group(self.bitrate_buttons, "br_value", data["audio_bitrate"])
        if "audio_source" in data:
            self._set_radio_group(self.source_buttons, "src_value", data["audio_source"])
        if "audio_language" in data and self.audio_lang_combo:
            self._set_combo_by_data(self.audio_lang_combo, data["audio_language"])
        if "download_all_audio_tracks" in data and self.chk_all_audio_tracks:
            self.chk_all_audio_tracks.setChecked(bool(data["download_all_audio_tracks"]))
        if "dubbed_audio_export" in data and hasattr(self, "chk_dubbed_audio"):
            self.chk_dubbed_audio.setChecked(bool(data["dubbed_audio_export"]))
        if "dubbed_audio_mode" in data and hasattr(self, "dubbed_audio_mode_combo"):
            self._set_combo_by_data(self.dubbed_audio_mode_combo, data["dubbed_audio_mode"])
        if "dubbed_audio_languages" in data and hasattr(self, "dubbed_audio_languages_input"):
            self.dubbed_audio_languages_input.setText(data["dubbed_audio_languages"])
        if "dubbed_audio_format" in data and hasattr(self, "dubbed_audio_format_combo"):
            self._set_combo_by_data(self.dubbed_audio_format_combo, data["dubbed_audio_format"])
        if "meta_language" in data and self.meta_lang_combo:
            self._set_combo_by_data(self.meta_lang_combo, data["meta_language"])
        if "restart_each_video" in data:
            self.chk_restart.setChecked(bool(data["restart_each_video"]))
        if "no_numbering" in data:
            self.chk_nonumber.setChecked(bool(data["no_numbering"]))
        if "reverse_playlist" in data:
            self.chk_reverse.setChecked(bool(data["reverse_playlist"]))
        if "use_archive" in data:
            self.chk_archive.setChecked(bool(data["use_archive"]))
        if "download_subtitles" in data:
            self.chk_subs.setChecked(bool(data["download_subtitles"]))
        if "subtitle_language" in data:
            self._set_combo_by_data(self.sub_lang_combo, data["subtitle_language"])
        if "embed_subtitles" in data and hasattr(self, "chk_embed_subs"):
            self.chk_embed_subs.setChecked(bool(data["embed_subtitles"]))
        if "subtitle_format" in data and hasattr(self, "sub_format_combo"):
            self._set_combo_by_data(self.sub_format_combo, data["subtitle_format"])
        if "auth_method" in data:
            self._set_combo_by_data(self.auth_combo, data["auth_method"])
        if "use_aria2c" in data:
            self.chk_aria2c.setChecked(bool(data["use_aria2c"]))
        if "aria2c_threads" in data:
            self.aria2c_threads_combo.setCurrentText(str(data["aria2c_threads"]))
        if "concurrent_videos" in data:
            self.concurrent_combo.setCurrentText(str(data["concurrent_videos"]))
        if "manual_item_selection" in data and hasattr(self, "chk_manual_selection"):
            self.chk_manual_selection.setChecked(bool(data["manual_item_selection"]))
        if "sb_enabled" in data and self.chk_sb:
            self.chk_sb.setChecked(bool(data["sb_enabled"]))
        if "sb_action" in data and self.chk_sb:
            self._set_combo_by_data(self.sb_action_combo, data["sb_action"])
        if "sb_categories" in data and self.chk_sb:
            categories = set(data.get("sb_categories") or [])
            for cat_id, chk in self.sb_cat_checks.items():
                chk.setChecked(cat_id in categories)
        if "sb_force_keyframes" in data and self.chk_sb:
            self.chk_sb_keyframes.setChecked(bool(data["sb_force_keyframes"]))
        if "speed_limit" in data and hasattr(self, "speed_limit_input"):
            value = int(data.get("speed_limit", 0) or 0)
            self.speed_limit_input.setText(str(value) if value else "")
        if "speed_limit_unit" in data and hasattr(self, "speed_limit_unit"):
            self.speed_limit_unit.setCurrentIndex(0 if data.get("speed_limit_unit") == "kbs" else 1)
        if "output_container" in data and hasattr(self, "container_combo"):
            self.container_combo.setCurrentIndex({"auto": 0, "mp4": 1, "mkv": 2}.get(data.get("output_container"), 0))
        if "video_codec_policy" in data and hasattr(self, "video_codec_combo"):
            self._set_combo_by_data(self.video_codec_combo, data["video_codec_policy"])
        if "playback_target" in data and hasattr(self, "playback_target_combo"):
            self._set_combo_by_data(self.playback_target_combo, data["playback_target"])
        if "immersive_safe_container" in data and hasattr(self, "chk_immersive_safe"):
            self.chk_immersive_safe.setChecked(bool(data["immersive_safe_container"]))
        if "manual_format_id" in data:
            self._manual_format_id = data.get("manual_format_id", "")
        if "manual_format_kind" in data:
            self._manual_format_kind = data.get("manual_format_kind", "")
        if "manual_format_context" in data:
            context = data.get("manual_format_context")
            self._manual_format_context = context if isinstance(context, dict) else {}
        if "generate_m3u" in data and hasattr(self, "chk_generate_m3u"):
            self.chk_generate_m3u.setChecked(bool(data["generate_m3u"]))
        auto_remove_value = None
        if "history_auto_remove_completed" in data:
            auto_remove_value = bool(data["history_auto_remove_completed"])
        elif "auto_remove_completed" in data:
            auto_remove_value = bool(data["auto_remove_completed"])
        if auto_remove_value is not None and hasattr(self, "chk_auto_remove_completed"):
            self.chk_auto_remove_completed.setChecked(auto_remove_value)

        self._update_mode_visibility()
        self._on_format_change()
        self._update_url_examples()
        if hasattr(self, "chk_dubbed_audio"):
            self._on_dubbed_audio_toggle()
        if self.chk_sb:
            self._on_sb_toggle()
        self._on_mode_change()

    def _mode_uses_multi_items(self, mode=None, audio_source=None):
        effective_mode = mode or self._get_mode()
        source = audio_source or self._get_audio_source()
        return effective_mode in (self.MODE_PLAYLIST, self.MODE_CHANNEL, self.MODE_SEARCH) or (
            effective_mode == self.MODE_AUDIO and source in (self.AUDIO_SOURCE_PLAYLIST, self.AUDIO_SOURCE_CHANNEL)
        )

    def _manual_selection_enabled(self):
        return self.chk_manual_selection.isChecked() if hasattr(self, "chk_manual_selection") else self._manual_item_selection

    def _coerce_playlist_indices(self, playlist_items):
        if playlist_items is None or playlist_items == "":
            return []
        if isinstance(playlist_items, int):
            return [playlist_items] if playlist_items > 0 else []
        if isinstance(playlist_items, (list, tuple, set)):
            values = []
            for item in playlist_items:
                try:
                    value = int(item)
                except (TypeError, ValueError):
                    continue
                if value > 0 and value not in values:
                    values.append(value)
            return sorted(values)
        if isinstance(playlist_items, str):
            values = []
            for part in playlist_items.split(","):
                chunk = part.strip()
                if not chunk:
                    continue
                if "-" in chunk:
                    left, _, right = chunk.partition("-")
                    try:
                        start = int(left)
                        end = int(right)
                    except ValueError:
                        continue
                    lo, hi = sorted((start, end))
                    for value in range(lo, hi + 1):
                        if value > 0 and value not in values:
                            values.append(value)
                else:
                    try:
                        value = int(chunk)
                    except ValueError:
                        continue
                    if value > 0 and value not in values:
                        values.append(value)
            return sorted(values)
        return []

    def _playlist_items_to_spec(self, playlist_items):
        values = self._coerce_playlist_indices(playlist_items)
        if not values:
            return ""
        parts = []
        start = prev = values[0]
        for value in values[1:]:
            if value == prev + 1:
                prev = value
                continue
            parts.append(f"{start}-{prev}" if start != prev else str(start))
            start = prev = value
        parts.append(f"{start}-{prev}" if start != prev else str(start))
        return ",".join(parts)

    def _split_playlist_indices(self, playlist_items, worker_id, total_workers):
        values = self._coerce_playlist_indices(playlist_items)
        if not values:
            return []
        offset = max(0, int(worker_id) - 1)
        step = max(1, int(total_workers))
        return values[offset::step]

    def _should_prompt_manual_selection(self, mode=None, playlist_items=None):
        if playlist_items:
            return False
        return self._manual_selection_enabled() and self._mode_uses_multi_items(mode=mode)

    def _queue_entry_to_session_payload(self, entry):
        if not entry:
            return None
        return entry.to_dict()

    def _active_download_session_payload(self, status="downloading"):
        if not self._active_download_url:
            return None
        options = {
            "settings": self._clone_json_value(self._active_runtime_settings or {}),
            "playlist_items": self._coerce_playlist_indices(self._active_download_playlist_items),
        }
        if self._active_download_subscription:
            options["subscription"] = self._clone_json_value(self._active_download_subscription)
        return {
            "url": self._active_download_url,
            "mode": self._active_download_mode or self.MODE_VIDEO,
            "platform": self._active_download_platform or self.platform,
            "quality": self._active_download_quality or self._get_quality(),
            "priority": int(getattr(self, "_active_download_priority", Priority.HIGH)),
            "status": status,
            "options": options,
        }

    def _persist_session_snapshot(self):
        try:
            entries = []
            active_status = "paused" if self._downloads_paused else "downloading"
            active = self._active_download_session_payload(status=active_status)
            if active and not (self._downloads_paused and self._pause_requested):
                entries.append(active)
            entries.extend(self._download_queue.to_list())
            if entries:
                self.db.save_session(entries)
            else:
                self.db.clear_session()
        except Exception as e:
            log_error("session_persist", e)

    def _run_with_runtime_settings(self, settings_snapshot, callback):
        if not settings_snapshot:
            return callback()
        original_snapshot = self._collect_runtime_settings_snapshot()
        original_url = self.url_input.text()
        try:
            self._apply_runtime_settings_snapshot(settings_snapshot)
            return callback()
        finally:
            self._apply_runtime_settings_snapshot(original_snapshot)
            self.url_input.setText(original_url)
    
    # ══════════════════════════════════════════════════════════════════════════
    #  SMART MODE PRESETS
    # ══════════════════════════════════════════════════════════════════════════
    
    def _get_presets_file(self):
        return get_settings_dir() / f"presets_{self.platform}.json"
    
    def _load_all_presets(self):
        try:
            f = self._get_presets_file()
            if f.exists():
                return json.loads(f.read_text(encoding='utf-8'))
        except Exception:
            pass
        return {}
    
    def _save_all_presets(self, presets):
        if is_debug_mode():
            return
        try:
            atomic_write_json(self._get_presets_file(), presets or {})
        except Exception as e:
            self.log(f"❌ {e}")
    
    def _get_presets_file_for_platform(self, platform_id):
        return get_settings_dir() / f"presets_{platform_id}.json"

    def _load_presets_for_platform(self, platform_id):
        try:
            f = self._get_presets_file_for_platform(platform_id)
            if f.exists():
                data = json.loads(f.read_text(encoding='utf-8'))
                if isinstance(data, dict):
                    return data
        except Exception:
            pass
        return {}

    def _save_presets_for_platform(self, platform_id, presets):
        if is_debug_mode():
            return
        try:
            atomic_write_json(self._get_presets_file_for_platform(platform_id), presets or {})
        except Exception as e:
            self.log(f"❌ {e}")

    def _refresh_smart_presets(self):
        presets = self._load_all_presets()
        self.smart_combo.clear()
        self.smart_combo.addItems(sorted(presets.keys()))
        if hasattr(self, "smart_stats_label"):
            self.smart_stats_label.setText(self.t.get("smart_stats", "Presets: {n}").format(n=len(presets)))
        self._refresh_smart_summary()
        self._refresh_workspace_insights()
    
    def _get_current_preset_data(self):
        return self._collect_runtime_settings_snapshot()
    
    def _apply_preset_data(self, data):
        translated = dict(data or {})
        if "quality" in translated and "video_quality" not in translated:
            translated["video_quality"] = translated["quality"]
        self._apply_runtime_settings_snapshot(translated)
    
    def _smart_save(self):
        name, ok = QInputDialog.getText(self, self.t["smart_mode_label"],
                                         self.t["smart_name_prompt"])
        if ok and name.strip():
            presets = self._load_all_presets()
            presets[name.strip()] = self._get_current_preset_data()
            self._save_all_presets(presets)
            self._refresh_smart_presets()
            self.smart_combo.setCurrentText(name.strip())
            self.log(f"{self.t['smart_saved']} '{name.strip()}'")
    
    def _smart_load(self):
        name = self.smart_combo.currentText()
        if not name:
            return
        presets = self._load_all_presets()
        if name in presets:
            self._apply_preset_data(presets[name])
            self.log(f"{self.t['smart_loaded']} '{name}'")
    
    def _smart_delete(self):
        name = self.smart_combo.currentText()
        if not name:
            return
        presets = self._load_all_presets()
        if name in presets:
            del presets[name]
            self._save_all_presets(presets)
            self._refresh_smart_presets()
            self.log(f"{self.t['smart_deleted']} '{name}'")
    
    # ══════════════════════════════════════════════════════════════════════════
    #  IMPORT / EXPORT
    # ══════════════════════════════════════════════════════════════════════════
    
    def _collect_app_state(self):
        self._save_settings()
        self._save_download_history()

        state = {
            "schema": "aura-app-state-v1",
            "app": "Aura Video Downloader",
            "version": APP_VERSION,
            "exported_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            "current_platform": self.platform,
            "theme_id": self.theme_id,
            "platforms": {},
            "database": self.db.export_state(),
        }

        for platform_id in PLATFORM_CONFIGS:
            manager = SettingsManager(platform=platform_id)
            state["platforms"][platform_id] = {
                "settings": manager.load(),
                "history": self.download_history if platform_id == self.platform else self._load_history_data(platform_id),
                "presets": self._load_presets_for_platform(platform_id),
            }

        return state

    @staticmethod
    def _sanitize_imported_settings(settings):
        defaults = SettingsManager.DEFAULT_SETTINGS.copy()
        if not isinstance(settings, dict):
            return defaults
        clean = defaults.copy()
        for key in defaults:
            if key in settings:
                clean[key] = settings[key]
        return clean

    def _apply_app_state(self, state):
        if not isinstance(state, dict):
            raise ValueError("Invalid state payload")
        if state.get("schema") != "aura-app-state-v1":
            raise ValueError("Unsupported state schema")

        platforms = state.get("platforms", {})
        imported_platforms = 0
        for platform_id, payload in platforms.items():
            if platform_id not in PLATFORM_CONFIGS or not isinstance(payload, dict):
                continue

            settings = self._sanitize_imported_settings(payload.get("settings"))
            SettingsManager(platform=platform_id).save(settings)

            history = payload.get("history", [])
            if isinstance(history, list):
                self._save_download_history(platform_id=platform_id, history_data=[row for row in history if isinstance(row, dict)])

            presets = payload.get("presets", {})
            if isinstance(presets, dict):
                self._save_presets_for_platform(platform_id, presets)

            imported_platforms += 1

        db_state = state.get("database", {})
        if isinstance(db_state, dict):
            self.db.import_state(db_state)

        self._load_settings()
        self._load_download_history()
        self._refresh_smart_presets()
        self._refresh_subscriptions()
        self._refresh_workspace_insights()
        self._refresh_execution_blueprint()
        return imported_platforms

    def _export_app_state(self):
        f, _ = QFileDialog.getSaveFileName(
            self,
            self.t.get("export_state_btn", "Export full state"),
            str(Path.home() / "aura_state.json"),
            "JSON (*.json)",
        )
        if not f:
            return
        try:
            from aura.utils import atomic_write_json

            atomic_write_json(Path(f), self._collect_app_state())
            self.log(self.t.get("export_state_success", "Full app state exported: {path}").format(path=f))
        except Exception as e:
            self.log(self.t.get("export_state_error", "Full state export failed: {error}").format(error=e))

    def _import_app_state(self):
        f, _ = QFileDialog.getOpenFileName(
            self,
            self.t.get("import_state_btn", "Import full state"),
            str(Path.home()),
            "JSON (*.json);;All (*)",
        )
        if not f:
            return

        reply = QMessageBox.question(
            self,
            self.t.get("import_state_btn", "Import full state"),
            self.t.get(
                "import_state_confirm",
                "Replace the saved Aura app state for all platforms from this JSON backup?",
            ),
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )
        if reply != QMessageBox.Yes:
            return

        try:
            payload = json.loads(Path(f).read_text(encoding='utf-8'))
            imported_platforms = self._apply_app_state(payload)
            self.log(
                self.t.get(
                    "import_state_success",
                    "Full app state imported from {path} ({count} platform snapshots)",
                ).format(path=f, count=imported_platforms)
            )
        except Exception as e:
            self.log(self.t.get("import_state_error", "Full state import failed: {error}").format(error=e))

    def _import_links(self):
        f, _ = QFileDialog.getOpenFileName(self, self.t.get("import_btn", "Import"),
                                            str(Path.home()),
                                            "JSON/CSV/TXT (*.json *.csv *.txt);;All (*)")
        if not f:
            return
        try:
            text = Path(f).read_text(encoding='utf-8')
            urls = []
            if f.endswith('.json'):
                data = json.loads(text)
                if isinstance(data, list):
                    for item in data:
                        urls.append(item['url'] if isinstance(item, dict) else str(item))
                elif isinstance(data, dict) and 'urls' in data:
                    urls = data['urls']
            else:
                for line in text.splitlines():
                    line = line.strip()
                    if line and not line.startswith('#'):
                        urls.append(line.split(',')[0].strip() if f.endswith('.csv') else line)
            
            if urls:
                added = self._queue_urls_for_download(urls, priority=Priority.HIGH)
                self.log(self.t['import_success'].format(count=added))
                self.log(self.t.get("batch_links_queued", "Queued {count} link(s) for download.").format(count=added))
        except Exception as e:
            self.log(f"{self.t.get('import_error', '❌ Import error')}: {e}")

    def _batch_paste_links(self):
        dlg = BatchLinksDialog(self)
        try:
            clip_text = QApplication.clipboard().text().strip()
        except Exception:
            clip_text = ""
        if clip_text:
            dlg.editor.setPlainText(clip_text)
        if dlg.exec() != QDialog.Accepted:
            return
        urls = dlg.links()
        if not urls:
            return
        added = self._queue_urls_for_download(urls, priority=Priority.HIGH)
        self.log(self.t.get("batch_links_queued", "Queued {count} link(s) for download.").format(count=added))

    def _queue_urls_for_download(self, urls, priority=Priority.NORMAL, settings_snapshot=None):
        snapshot = self._clone_json_value(settings_snapshot or self._collect_runtime_settings_snapshot())
        quality = snapshot.get("video_quality", self._get_quality())
        mode = snapshot.get("mode", self._get_mode())
        added = 0
        seen = set()
        for raw_url in urls or []:
            url = str(raw_url or "").strip()
            if not url or url in seen:
                continue
            seen.add(url)
            platform_id = self._detect_platform_from_url(url)
            entry_mode = mode
            if entry_mode == self.MODE_SEARCH and url.startswith(("http://", "https://")):
                entry_mode = self.MODE_VIDEO
            self._download_queue.add(
                url,
                mode=entry_mode,
                platform=platform_id,
                quality=quality,
                priority=priority,
                options={"settings": self._clone_json_value(snapshot)},
            )
            added += 1
        if added:
            self._refresh_runtime_badges()
            self._persist_session_snapshot()
            if not self._downloads_paused:
                QTimer.singleShot(0, self._sub_process_download_queue)
        return added
    
    def _export_history(self):
        if not self.download_history:
            QMessageBox.information(self, self.t.get("export_btn", "Export"), self.t.get("export_empty", "No history to export"))
            return
        f, _ = QFileDialog.getSaveFileName(self, self.t.get("export_btn", "Export"),
                                            str(Path.home() / "aura_history.json"),
                                            "JSON (*.json);;Text (*.txt)")
        if not f:
            return
        try:
            if f.endswith('.json'):
                Path(f).write_text(json.dumps(self.download_history, ensure_ascii=False, indent=2), encoding='utf-8')
            else:
                lines = [f"{e.get('date','')} | {e.get('name','')} | {e.get('status','')}"
                         for e in self.download_history]
                Path(f).write_text('\n'.join(lines), encoding='utf-8')
            self.log(f"{self.t['export_success']} {f}")
        except Exception as e:
            self.log(f"❌ {e}")
    
    # ══════════════════════════════════════════════════════════════════════════
    #  DOWNLOAD HISTORY
    # ══════════════════════════════════════════════════════════════════════════
    
    def _get_history_file(self, platform_id=None):
        pid = platform_id or self.platform
        return get_settings_dir() / f"history_{pid}.json"

    def _load_history_data(self, platform_id=None):
        history = []
        f = self._get_history_file(platform_id)
        if not f.exists():
            return history
        try:
            history = json.loads(f.read_text(encoding='utf-8'))
        except (json.JSONDecodeError, UnicodeDecodeError):
            bak = f.with_suffix('.bak')
            if bak.exists():
                history = json.loads(bak.read_text(encoding='utf-8'))
        return history
    
    def _load_download_history(self):
        try:
            f = self._get_history_file()
            if f.exists():
                try:
                    self.download_history = json.loads(f.read_text(encoding='utf-8'))
                except (json.JSONDecodeError, UnicodeDecodeError):
                    bak = f.with_suffix('.bak')
                    if bak.exists():
                        self.download_history = json.loads(bak.read_text(encoding='utf-8'))
                        self.log("⚠️ History file corrupted — restored from backup")
                    else:
                        self.download_history = []
                        self.log("⚠️ History file corrupted — no backup available")
                if self.download_history and self.db.get_download_count() == 0:
                    n = self.db.migrate_json_history(self.download_history, self.platform)
                    if n > 0:
                        self.log(self.t.get("db_migrated", "History migrated ({n})").format(n=n))
        except Exception as e:
            log_error("load_download_history", e)
            self.download_history = []
        self._dm_refresh_tree()

    def _save_download_history(self, platform_id=None, history_data=None):
        if is_debug_mode():
            return
        try:
            f = self._get_history_file(platform_id)
            f.parent.mkdir(parents=True, exist_ok=True)
            data_source = self.download_history if history_data is None else history_data
            data = data_source[-1000:]
            from aura.utils import atomic_write_json
            atomic_write_json(f, data)
        except Exception as e:
            log_error("save_download_history", e)

    def _add_to_history(self, name, status="done", size="", dtype="video", platform_id=None):
        pid = platform_id or self._active_download_platform or self.platform
        entry = {
            "name": name, "status": status, "size": size, "type": dtype,
            "date": datetime.datetime.now().strftime("%Y-%m-%d %H:%M"),
            "platform": pid,
        }
        auto_remove = (
            status == "done"
            and hasattr(self, "chk_auto_remove_completed")
            and self.chk_auto_remove_completed.isChecked()
        )
        if not auto_remove:
            if pid == self.platform:
                self.download_history.append(entry)
                self._save_download_history(platform_id=pid, history_data=self.download_history)
            else:
                history = self._load_history_data(pid)
                history.append(entry)
                self._save_download_history(platform_id=pid, history_data=history)
        try:
            self.db.add_download(name=name, status=status, size=size,
                                 dtype=dtype, platform=pid)
        except Exception as e:
            log_error("db_add_download", e)
        if pid == self.platform:
            self._dm_refresh_tree()
    
    def _dm_refresh_tree(self):
        self.dm_tree.clear()
        filt = "all"
        btn = self.dm_filter_group.checkedButton()
        if btn:
            filt = btn.property("filter") or "all"
        search = self.dm_search.text().lower().strip() if hasattr(self, 'dm_search') else ""
        visible_count = 0
        
        for entry in reversed(self.download_history):
            if filt != "all" and entry.get("type") != filt:
                continue
            if search and search not in entry.get("name", "").lower():
                continue
            item = QTreeWidgetItem([
                entry.get("status", ""),
                entry.get("name", ""),
                entry.get("size", ""),
                entry.get("date", ""),
            ])
            self.dm_tree.addTopLevelItem(item)
            visible_count += 1
        if hasattr(self, "history_stats_label"):
            self.history_stats_label.setText(
                self.t.get("history_stats", "Visible: {shown} / Total: {total}").format(
                    shown=visible_count, total=len(self.download_history)
                )
            )
        self._refresh_workspace_insights()
    
    def _dm_apply_filter(self, *args):
        self._dm_refresh_tree()
    
    def _dm_sort(self, key):
        # Toggle direction on repeated click
        if getattr(self, '_last_sort_key', None) == key:
            self._sort_reverse = not getattr(self, '_sort_reverse', True)
        else:
            self._sort_reverse = True
        self._last_sort_key = key
        self.download_history.sort(key=lambda e: e.get(key, ""), reverse=self._sort_reverse)
        self._dm_refresh_tree()
    
    def _dm_clear_completed(self):
        self.download_history = [e for e in self.download_history if e.get("status") != "done"]
        self._save_download_history()
        self._dm_refresh_tree()

    def _refresh_queue_manager(self):
        if not hasattr(self, "queue_tree"):
            return
        self.queue_tree.clear()
        entries = self._download_queue.all_entries() if hasattr(self, "_download_queue") else []
        pending_entries = [entry for entry in entries if entry.status in ("pending", "paused")]
        priority_labels = {
            Priority.HIGH: self.t.get("queue_priority_high", "High"),
            Priority.NORMAL: self.t.get("queue_priority_normal", "Normal"),
            Priority.LOW: self.t.get("queue_priority_low", "Low"),
        }
        for entry in pending_entries:
            mode_label = self._format_mode_label(entry.mode)
            if entry.status == "paused":
                mode_label += f" ({self.t.get('pause_btn', 'Pause').lower()})"
            item = QTreeWidgetItem([
                mode_label,
                self._shorten_display_text(entry.url, 82),
                get_platform_name(entry.platform, self.lang),
                priority_labels.get(entry.priority, str(int(entry.priority))),
                entry.added,
            ])
            item.setToolTip(1, entry.url)
            item.setData(0, Qt.UserRole, entry)
            self.queue_tree.addTopLevelItem(item)
        if hasattr(self, "queue_stats_label"):
            self.queue_stats_label.setText(
                self.t.get("queue_stats", "Pending: {n}").format(n=len(pending_entries))
            )

    def _queue_selected_entry(self):
        if not hasattr(self, "queue_tree"):
            return None
        item = self.queue_tree.currentItem()
        if not item:
            return None
        return item.data(0, Qt.UserRole)

    def _queue_remove_selected(self):
        entry = self._queue_selected_entry()
        if not entry:
            return
        self._download_queue.remove(entry)
        self._refresh_runtime_badges()
        self._persist_session_snapshot()
        self.log(self.t.get("queue_removed", "Removed from queue: {url}").format(url=self._shorten_display_text(entry.url, 80)))

    def _queue_clear_pending(self):
        pending = self._download_queue.pending_count()
        if pending <= 0:
            return
        self._download_queue.clear()
        self._refresh_runtime_badges()
        self._persist_session_snapshot()
        self.log(self.t.get("queue_cleared", "Queue cleared ({n} pending item(s) removed).").format(n=pending))

    def _queue_move_selected(self, direction):
        entry = self._queue_selected_entry()
        if not entry:
            return
        if self._download_queue.move(entry, direction):
            self._refresh_runtime_badges()
            self._persist_session_snapshot()
            for index in range(self.queue_tree.topLevelItemCount()):
                item = self.queue_tree.topLevelItem(index)
                if item.data(0, Qt.UserRole) is entry:
                    self.queue_tree.setCurrentItem(item)
                    break
            log_key = "queue_moved_up" if direction < 0 else "queue_moved_down"
            self.log(self.t.get(log_key, "Queue order updated: {url}").format(url=self._shorten_display_text(entry.url, 80)))
    

    # ══════════════════════════════════════════════════════════════════════════
    #  FORMAT PANEL
    # ══════════════════════════════════════════════════════════════════════════
    
    def _show_format_panel(self):
        if self._closing:
            return
        url = self.url_input.text().strip()
        if not url:
            self.log(self.t.get("format_no_url", "Enter URL first"))
            return
        self.log(self.t.get("format_loading", "Loading formats..."))
        ytdlp_bin = getattr(self, '_ytdlp_bin', find_binary("yt-dlp"))
        extra_args = self._build_ytdlp_runtime_args(
            cookies=self.cookies_input.text().strip(),
            platform_id=self.platform,
        )
        worker = FormatListWorker(url, ytdlp_bin, extra_args=extra_args)
        worker.result_signal.connect(self._on_formats_loaded)
        worker.error_signal.connect(self._on_formats_error)
        self._replace_thread_worker("_format_worker", worker, "format_worker")
        worker.start()

    @staticmethod
    def _format_prefers_mkv(fmt_info):
        codec_blob = " ".join(
            [
                str(fmt_info.get("ext", "")),
                str(fmt_info.get("codec", "")),
                str(fmt_info.get("vcodec", "")),
                str(fmt_info.get("acodec", "")),
            ]
        ).lower()
        return "webm" in codec_blob or "vp9" in codec_blob or "vp8" in codec_blob or "opus" in codec_blob or "vorbis" in codec_blob
    
    def _on_formats_loaded(self, payload):
        formats = payload.get("formats", []) if isinstance(payload, dict) else (payload or [])
        if not formats:
            self.log("⚠️ No formats found")
            return
        container = "auto"
        if hasattr(self, "container_combo"):
            container = ["auto", "mp4", "mkv"][self.container_combo.currentIndex()]
        dlg = FormatDialog(self, payload, self.t, mode=self._get_mode(), container=container)
        dlg.format_selected.connect(self._on_format_selected)
        dlg.exec()
    
    def _on_formats_error(self, err):
        self.log(self.t.get("format_error", "Error: {error}").format(error=err))
    
    def _on_format_selected(self, fmt_id, fmt_info=None):
        fmt_info = fmt_info or {}
        if fmt_id:
            mode = self._get_mode()
            kind = fmt_info.get("kind", "")
            self._set_manual_format_selection(
                fmt_id,
                fmt_kind=kind,
                mode=mode,
                platform_id=self.platform,
            )
            if mode != self.MODE_AUDIO and kind == "video-only":
                self.log(
                    self.t.get(
                        "format_selected_with_audio",
                        "Selected: {fmt} (the selected audio track will be merged automatically)",
                    ).format(fmt=fmt_id)
                )
            else:
                self.log(self.t.get("format_selected", "Selected: {fmt}").format(fmt=fmt_id))

            if mode != self.MODE_AUDIO and kind == "audio-only":
                self.log(
                    self.t.get(
                        "format_audio_only_warning",
                        "⚠️ Selected format contains only audio. Use Audio mode if this was intentional.",
                    )
                )

            if (
                mode != self.MODE_AUDIO
                and hasattr(self, "container_combo")
                and self.container_combo.currentIndex() == 1
                and self._format_prefers_mkv(fmt_info)
            ):
                self.container_combo.setCurrentIndex(2)
                self.log(
                    self.t.get(
                        "format_container_auto_adjusted",
                        "📦 Container switched to MKV for better codec compatibility with the selected format.",
                    )
                )
        else:
            self._set_manual_format_selection("")
            self.log(self.t.get("format_cleared", "Format selection cleared"))
    
    # ══════════════════════════════════════════════════════════════════════════
    #  VIDEO PREVIEW
    # ══════════════════════════════════════════════════════════════════════════
    
    def _show_preview(self):
        if self._closing:
            return
        url = self.url_input.text().strip()
        if not url:
            self.log(self.t.get("preview_no_url", "Enter URL first"))
            return
        self.log(self.t.get("preview_loading", "Loading metadata..."))
        ytdlp_bin = getattr(self, '_ytdlp_bin', find_binary("yt-dlp"))
        extra_args = self._build_ytdlp_runtime_args(
            cookies=self.cookies_input.text().strip(),
            platform_id=self.platform,
        )
        worker = PreviewWorker(url, ytdlp_bin, extra_args=extra_args)
        worker.result_signal.connect(self._on_preview_loaded)
        worker.error_signal.connect(self._on_preview_error)
        self._replace_thread_worker("_preview_worker", worker, "preview_worker")
        worker.start()
    
    def _on_preview_loaded(self, data):
        cache_key = self._media_info_cache_key(
            self.url_input.text().strip(),
            cookies=self.cookies_input.text().strip(),
            platform_id=self.platform,
        )
        self._media_info_cache[cache_key] = data
        enriched = dict(data or {})
        enriched["_aura_immersive"] = self._detect_immersive_profile(data)
        enriched["_aura_audio_languages"] = self._extract_audio_languages_from_info(data)
        enriched["_aura_subtitle_languages"] = sorted(k for k in (data.get("subtitles") or {}).keys() if k)
        enriched["_aura_auto_subtitle_languages"] = sorted(k for k in (data.get("automatic_captions") or {}).keys() if k)
        dlg = PreviewDialog(self, self.t)
        dlg.set_metadata(enriched)
        dlg.exec()
    
    def _on_preview_error(self, err):
        self.log(self.t.get("preview_error", "Error: {error}").format(error=err))

    def _begin_manual_item_selection(self, params, platform_id=None, quality_override=None,
                                     save_settings=True, allow_queue=True):
        if self._closing:
            return
        mode = params.get("mode", self._get_mode())
        url = params.get("url", "").strip()
        cookies = params.get("cookies", "").strip()
        platform_id, _ = self._resolve_platform_context(platform_id)
        ytdlp_bin = getattr(self, "_ytdlp_bin", find_binary("yt-dlp"))
        extra_args = self._build_ytdlp_runtime_args(cookies=cookies, platform_id=platform_id)

        self.log(self.t.get("manual_selection_loading", "Loading list of items for manual selection..."))
        self._manual_selection_context = {
            "params": self._clone_json_value(params),
            "platform_id": platform_id,
            "quality_override": quality_override,
            "save_settings": save_settings,
            "allow_queue": allow_queue,
            "mode": mode,
        }
        worker = PlaylistEntriesWorker(url, ytdlp_bin, extra_args=extra_args)
        worker.result_signal.connect(self._on_manual_selection_loaded)
        worker.error_signal.connect(self._on_manual_selection_error)
        self._replace_thread_worker("_playlist_entries_worker", worker, "playlist_entries_worker")
        worker.start()

    def _on_manual_selection_loaded(self, payload):
        ctx = self._manual_selection_context or {}
        self._manual_selection_context = None
        entries = payload.get("entries", []) if isinstance(payload, dict) else []
        if not entries:
            self.log(self.t.get("manual_selection_empty", "No items selected for download"))
            return

        dlg = ItemPickerDialog(
            self,
            title=self.t.get("manual_selection_title", "Manual selection"),
        )
        dlg.set_entries(entries, source_title=payload.get("title", ""))
        if dlg.exec() != QDialog.Accepted:
            return

        selected = dlg.selected_indices()
        if not selected:
            self.log(self.t.get("manual_selection_empty", "No items selected for download"))
            return

        playlist_items = None if len(selected) >= len(entries) else selected
        params = ctx.get("params") or {}
        self._start_download_request(
            params,
            platform_id=ctx.get("platform_id"),
            quality_override=ctx.get("quality_override"),
            save_settings=ctx.get("save_settings", True),
            allow_queue=ctx.get("allow_queue", True),
            playlist_items=playlist_items,
            manual_selection_resolved=True,
        )

    def _on_manual_selection_error(self, err):
        self._manual_selection_context = None
        self.log(self.t.get("manual_selection_error", "Manual selection failed: {error}").format(error=err))
    
    # ══════════════════════════════════════════════════════════════════════════
    #  VIDEO PLAYER
    # ══════════════════════════════════════════════════════════════════════════
    
    def _open_player(self):
        if not _HAS_MULTIMEDIA:
            QMessageBox.warning(self, self.t.get("error_title", "Error"),
                                self.t.get("player_no_multimedia", "PySide6-Multimedia required."))
            return
        dlg = VideoPlayerDialog(self, self.t)
        dlg.exec()
    
    # ══════════════════════════════════════════════════════════════════════════
    #  SPEED GRAPH
    # ══════════════════════════════════════════════════════════════════════════
    
    def _on_speed_graph_toggle(self, state):
        self._sync_speed_graph_visibility()
    
    def _feed_speed_graph(self, speed_str):
        """Parse speed string and feed to graph. Called from progress handler."""
        if not self.chk_speed_graph.isChecked():
            return
        # Parse "1.5MiB/s" or "500KiB/s" or "7.8MiB"
        try:
            s = speed_str.strip().replace(',', '.')
            bps = 0
            if 'GiB' in s or 'GB' in s:
                num = float(re.search(r'[\d.]+', s).group())
                bps = num * 1024 * 1024 * 1024
            elif 'MiB' in s or 'MB' in s:
                num = float(re.search(r'[\d.]+', s).group())
                bps = num * 1024 * 1024
            elif 'KiB' in s or 'KB' in s:
                num = float(re.search(r'[\d.]+', s).group())
                bps = num * 1024
            elif 'B' in s:
                num = float(re.search(r'[\d.]+', s).group())
                bps = num
            if bps > 0:
                self._ensure_speed_graph_widget().add_point(bps)
        except Exception:
            pass
    
    # ══════════════════════════════════════════════════════════════════════════
    #  SUBSCRIPTIONS
    # ══════════════════════════════════════════════════════════════════════════
    
    def _build_subscription_preset_payload(self, platform_id, preset_choice):
        presets = self._load_presets_for_platform(platform_id)
        if preset_choice in presets:
            data = SettingsManager(platform=platform_id).load()
            data.update(self._clone_json_value(presets[preset_choice]))
            label = preset_choice
        else:
            data = self._collect_runtime_settings_snapshot()
            label = self.t.get("sub_preset_current", "Current workspace settings")
        data["mode"] = data.get("mode") or self.MODE_VIDEO
        return json.dumps(
            {"label": label, "data": self._clone_json_value(data)},
            ensure_ascii=False,
        )

    def _select_subscription_preset(self, platform_id, current_label=""):
        default_label = self.t.get("sub_preset_current", "Current workspace settings")
        options = [default_label] + sorted(self._load_presets_for_platform(platform_id).keys())
        current_index = options.index(current_label) if current_label in options else 0
        choice, ok = QInputDialog.getItem(
            self,
            self.t.get("sub_preset_title", "Subscription preset"),
            self.t.get("sub_preset_label", "Download profile:"),
            options,
            current_index,
            False,
        )
        if not ok:
            return None
        return self._build_subscription_preset_payload(platform_id, choice)

    def _subscription_preset_info(self, sub):
        payload = {}
        raw = (sub or {}).get("preset_json") or ""
        if raw:
            try:
                payload = json.loads(raw)
            except Exception:
                payload = {}
        if not isinstance(payload, dict):
            payload = {}
        label = (payload.get("label") or "").strip()
        data = payload.get("data")
        if not isinstance(data, dict):
            data = {}
        return label, data

    def _subscription_runtime_settings(self, sub):
        platform_id = (sub or {}).get("platform", self.platform)
        base = SettingsManager(platform=platform_id).load()
        _, data = self._subscription_preset_info(sub)
        if data:
            base.update(data)
        return base

    def _subscription_item_runtime_settings(self, sub):
        settings = self._clone_json_value(self._subscription_runtime_settings(sub))
        mode = settings.get("mode") or self.MODE_VIDEO
        if mode in (self.MODE_CHANNEL, self.MODE_PLAYLIST, self.MODE_SEARCH):
            settings["mode"] = self.MODE_VIDEO
        elif mode == self.MODE_AUDIO:
            settings["audio_source"] = self.AUDIO_SOURCE_VIDEO
        return settings

    def _subscription_queue_options(self, sub, runtime_settings):
        sub_data = sub or {}
        target_kind = (
            sub_data.get("target_kind")
            or self._detect_subscription_target_kind(sub_data.get("channel_url", ""))
            or "channel"
        )
        subscription_name = (
            sub_data.get("channel_name")
            or sub_data.get("channel_url")
            or self._subscription_kind_label(target_kind)
        )
        return {
            "settings": self._clone_json_value(runtime_settings),
            "subscription": {
                "id": sub_data.get("id"),
                "name": subscription_name,
                "url": sub_data.get("channel_url", ""),
                "platform": sub_data.get("platform", self.platform),
                "target_kind": target_kind,
            },
        }

    def _refresh_subscriptions(self):
        self.sub_tree.clear()
        subs = self.db.get_subscriptions()
        enabled_count = 0
        for s in subs:
            enabled_text = self.t.get("sub_enabled", "✅") if s['enabled'] else self.t.get("sub_disabled", "⏸️")
            pc = PLATFORM_CONFIGS.get(s['platform'], {})
            pname = pc.get('name', s['platform'])
            preset_label, _ = self._subscription_preset_info(s)
            kind_label = self._subscription_kind_label(s.get("target_kind", "channel"))
            item = QTreeWidgetItem([
                enabled_text,
                kind_label,
                s.get('channel_name', '') or s['channel_url'],
                pname,
                preset_label or self.t.get("sub_preset_current", "Current workspace settings"),
                f"{s['interval_minutes']} min",
                s.get('last_check', '—'),
            ])
            item.setData(0, Qt.UserRole, s['id'])
            self.sub_tree.addTopLevelItem(item)
            if s['enabled']:
                enabled_count += 1
        if hasattr(self, "sub_stats_label"):
            self.sub_stats_label.setText(
                self.t.get("sub_stats", "Enabled: {enabled} / Total: {total}").format(
                    enabled=enabled_count, total=len(subs)
                )
            )
        self._refresh_workspace_insights()

    def _selected_subscription(self):
        item = self.sub_tree.currentItem() if hasattr(self, "sub_tree") else None
        if not item:
            return None
        sub_id = item.data(0, Qt.UserRole)
        if not sub_id:
            return None
        for sub in self.db.get_subscriptions():
            if sub.get("id") == sub_id:
                return sub
        return None

    def _detect_platform_from_url(self, url):
        platform = self.platform
        url_lower = url.strip().lower()
        for pid, pc in PLATFORM_CONFIGS.items():
            for domain in pc.get("domains", []):
                if domain in url_lower:
                    return pid
        return platform

    def _detect_subscription_target_kind(self, url):
        url_lower = (url or "").strip().lower()
        playlist_markers = (
            "list=",
            "/playlist",
            "/playlists",
            "/album/",
            "/showcase/",
            "/medialist/",
            "/sets/",
            "/collection/",
            "/collections/",
            "/favorites/videos/",
            ":ytwatchlater",
            "/feed/history",
        )
        return "playlist" if any(marker in url_lower for marker in playlist_markers) else "channel"

    def _subscription_kind_choices(self):
        return [
            ("channel", self.t.get("sub_kind_channel", "Channel")),
            ("playlist", self.t.get("sub_kind_playlist", "Playlist")),
        ]

    def _subscription_kind_label(self, target_kind):
        target_kind = (target_kind or "channel").strip().lower()
        if target_kind == "playlist":
            return self.t.get("sub_kind_playlist", "Playlist")
        return self.t.get("sub_kind_channel", "Channel")

    def _subscription_url_label(self, target_kind):
        if (target_kind or "channel").strip().lower() == "playlist":
            return self.t.get("sub_add_playlist_url_label", "Playlist URL:")
        return self.t.get("sub_add_url_label", "Channel URL:")

    def _subscription_is_due(self, sub, now=None):
        now = now or datetime.datetime.now()
        last_check = (sub.get("last_check") or "").strip()
        if not last_check:
            return True
        try:
            last_dt = datetime.datetime.strptime(last_check, "%Y-%m-%d %H:%M")
        except ValueError:
            return True
        interval_minutes = int(sub.get("interval_minutes", 60) or 60)
        return (now - last_dt).total_seconds() >= max(5, interval_minutes) * 60
    
    def _sub_add(self):
        kind_choices = self._subscription_kind_choices()
        current_url = self.url_input.text().strip()
        default_kind = self._detect_subscription_target_kind(current_url)
        labels = [label for _kind, label in kind_choices]
        kind_map = {label: kind for kind, label in kind_choices}
        current_index = next(
            (index for index, (kind, _label) in enumerate(kind_choices) if kind == default_kind),
            0,
        )
        chosen_label, ok_kind = QInputDialog.getItem(
            self,
            self.t.get("sub_add_title", "Subscribe"),
            self.t.get("sub_kind_label", "Subscription type:"),
            labels,
            current_index,
            False,
        )
        if not ok_kind:
            return
        target_kind = kind_map.get(chosen_label, default_kind)

        url, ok = QInputDialog.getText(
            self,
            self.t.get("sub_add_title", "Subscribe"),
            self._subscription_url_label(target_kind),
            text=current_url,
        )
        if not ok or not url.strip():
            return
        interval, ok2 = QInputDialog.getInt(self, self.t.get("sub_add_title", "Subscribe"),
                                            self.t.get("sub_add_interval_label", "Interval (min):"),
                                            60, 5, 10080)
        if not ok2:
            return
        max_new, ok3 = QInputDialog.getInt(self, self.t.get("sub_add_title", "Subscribe"),
                                           self.t.get("sub_add_max_label", "Max new:"),
                                           5, 1, 50)
        if not ok3:
            return
        
        platform = self._detect_platform_from_url(url)
        preset_json = self._select_subscription_preset(platform)
        if preset_json is None:
            return
        
        self.db.add_subscription(platform, url.strip(), channel_name="",
                                 interval_minutes=interval, max_new=max_new, preset_json=preset_json,
                                 target_kind=target_kind)
        self._refresh_subscriptions()
        self.log(f"📡 Subscribed: {url.strip()}")

    def _sub_edit(self):
        sub = self._selected_subscription()
        if not sub:
            return

        kind_choices = self._subscription_kind_choices()
        labels = [label for _kind, label in kind_choices]
        kind_map = {label: kind for kind, label in kind_choices}
        current_kind = (sub.get("target_kind") or self._detect_subscription_target_kind(sub.get("channel_url", "")) or "channel")
        current_index = next(
            (index for index, (kind, _label) in enumerate(kind_choices) if kind == current_kind),
            0,
        )
        chosen_label, ok_kind = QInputDialog.getItem(
            self,
            self.t.get("sub_edit_title", "Edit subscription"),
            self.t.get("sub_kind_label", "Subscription type:"),
            labels,
            current_index,
            False,
        )
        if not ok_kind:
            return
        target_kind = kind_map.get(chosen_label, current_kind)

        url, ok_url = QInputDialog.getText(
            self,
            self.t.get("sub_edit_title", "Edit subscription"),
            self._subscription_url_label(target_kind),
            text=sub.get("channel_url", ""),
        )
        if not ok_url or not url.strip():
            return

        current_name = sub.get("channel_name", "") or ""
        name, ok = QInputDialog.getText(
            self,
            self.t.get("sub_edit_title", "Edit subscription"),
            self.t.get("sub_edit_name_label", "Display name:"),
            text=current_name,
        )
        if not ok:
            return

        interval, ok2 = QInputDialog.getInt(
            self,
            self.t.get("sub_edit_title", "Edit subscription"),
            self.t.get("sub_add_interval_label", "Interval (min):"),
            int(sub.get("interval_minutes", 60) or 60),
            5,
            10080,
        )
        if not ok2:
            return

        max_new, ok3 = QInputDialog.getInt(
            self,
            self.t.get("sub_edit_title", "Edit subscription"),
            self.t.get("sub_add_max_label", "Max new:"),
            int(sub.get("max_new", 5) or 5),
            1,
            50,
        )
        if not ok3:
            return

        platform = self._detect_platform_from_url(url)
        current_label, _ = self._subscription_preset_info(sub)
        preset_json = self._select_subscription_preset(platform, current_label=current_label)
        if preset_json is None:
            return

        self.db.update_subscription(
            sub["id"],
            platform=platform,
            channel_url=url.strip(),
            channel_name=name.strip(),
            target_kind=target_kind,
            interval_minutes=interval,
            max_new=max_new,
            preset_json=preset_json,
        )
        self._refresh_subscriptions()
        label = name.strip() or url.strip()
        self.log(self.t.get("sub_updated", "Subscription updated: {name}").format(name=label))
    
    def _sub_remove(self):
        item = self.sub_tree.currentItem()
        if not item:
            return
        sub_id = item.data(0, Qt.UserRole)
        if sub_id:
            self.db.delete_subscription(sub_id)
            self._refresh_subscriptions()
    
    def _sub_toggle_enabled(self, item, col):
        sub_id = item.data(0, Qt.UserRole)
        if not sub_id:
            return
        subs = self.db.get_subscriptions()
        for s in subs:
            if s['id'] == sub_id:
                new_state = not bool(s['enabled'])
                self.db.toggle_subscription(sub_id, new_state)
                break
        self._refresh_subscriptions()
    
    def _sub_check_all(self, force=False):
        """Check enabled subscriptions, optionally respecting individual intervals."""
        # Guard: don't re-enter while previous check is running
        active = [w for w in self._sub_workers if w.isRunning()]
        if active:
            self.log(f"📡 Check already in progress ({len(active)} active)")
            return
        
        subs = self.db.get_subscriptions()
        enabled = [s for s in subs if s['enabled']]
        if not enabled:
            self.log("📡 No enabled subscriptions")
            return

        if force:
            to_check = enabled
        else:
            now = datetime.datetime.now()
            to_check = [s for s in enabled if self._subscription_is_due(s, now=now)]

        if not to_check:
            self.log(self.t.get("sub_no_due", "📡 No subscriptions are due yet"))
            return

        self.log(f"📡 Checking {len(to_check)} subscription(s)...")
        self._sub_pending_queue = list(to_check)
        self._sub_workers = []
        # Start up to 3 concurrent checks
        for _ in range(min(3, len(self._sub_pending_queue))):
            self._sub_start_next()
    
    def _sub_start_next(self):
        """Start next subscription check from pending queue (max 3 concurrent)."""
        if self._closing:
            return
        if not getattr(self, '_sub_pending_queue', []):
            return
        s = self._sub_pending_queue.pop(0)
        ytdlp_bin = getattr(self, '_ytdlp_bin', find_binary("yt-dlp"))
        archive_path = get_settings_dir() / f"archive_{s['platform']}.txt"
        runtime_settings = self._subscription_runtime_settings(s)
        extra_args = self._build_ytdlp_runtime_args(
            cookies=str(runtime_settings.get("cookies", "") or "").strip(),
            platform_id=s['platform'],
            runtime_settings=runtime_settings,
        )
        worker = SubCheckWorker(
            s['id'], s['channel_url'], s.get('max_new', 5),
            ytdlp_bin=ytdlp_bin,
            archive_path=str(archive_path),
            extra_args=extra_args,
            target_kind=s.get("target_kind", "channel"),
        )
        worker.result_signal.connect(self._on_sub_check_result)
        worker.error_signal.connect(self._on_sub_check_error)
        try:
            worker.setParent(self)
        except Exception as exc:
            log_error("sub_worker_parent", exc)
        finished_signal = getattr(worker, "finished", None)
        if hasattr(finished_signal, "connect"):
            finished_signal.connect(lambda worker=worker: self._forget_sub_worker(worker))
        self._sub_workers.append(worker)
        worker.start()
    
    def _sub_process_download_queue(self):
        """Process download queue: download one URL at a time.
        
        Called when new URLs are added to queue and when a download finishes.
        Only starts if no download is currently running.
        """
        if self._closing:
            return
        if self._download_queue.is_empty():
            return
        if self._downloads_paused:
            return
        # Don't start if a download is already running
        if self._download_prep_worker and self._download_prep_worker.isRunning():
            return
        if self.worker and self.worker.isRunning():
            return
        if self._restart_thread and self._restart_thread.is_alive():
            return
        for w in getattr(self, '_parallel_workers', []):
            if w.isRunning():
                return
        
        entry = self._download_queue.next()
        if not entry:
            return
        entry.status = "downloading"
        remaining = self._download_queue.pending_count()
        self.log(f"📥 Queue: downloading {entry.url[:60]}" + (f" ({remaining} queued)" if remaining else ""))
        self._set_runtime_state("running", self.t.get("queue_active_summary", "Queue active, remaining items: {n}").format(n=remaining))
        
        requested_mode = entry.mode if entry.mode in (
            self.MODE_AUDIO, self.MODE_VIDEO, self.MODE_PLAYLIST, self.MODE_CHANNEL, self.MODE_SEARCH
        ) else self.MODE_VIDEO
        entry_options = entry.options or {}
        entry_settings = entry_options.get("settings") if isinstance(entry_options, dict) else {}
        playlist_items = entry_options.get("playlist_items") if isinstance(entry_options, dict) else None
        subscription_context = entry_options.get("subscription") if isinstance(entry_options, dict) else None

        def _start_from_entry():
            self.url_input.setText(entry.url)
            self._set_radio_group(self.mode_buttons, "mode_value", requested_mode)
            self._on_mode_change()
            return self._start_download_request(
                {
                    "mode": requested_mode,
                    "url": entry.url,
                    "cookies": self.cookies_input.text().strip(),
                    "outdir": self.outdir_input.text().strip(),
                },
                platform_id=entry.platform,
                quality_override=entry.quality,
                save_settings=False,
                allow_queue=False,
                playlist_items=playlist_items,
                manual_selection_resolved=True,
                queue_priority=entry.priority,
                subscription_context=subscription_context,
            )

        started = self._run_with_runtime_settings(entry_settings, _start_from_entry)
        if started:
            self._download_queue.remove(entry)
            self._refresh_runtime_badges()
        else:
            entry.status = "paused" if self._downloads_paused else "pending"
        self._persist_session_snapshot()
    
    def _on_sub_check_result(self, sub_id, urls):
        now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
        self.db.update_subscription(sub_id, last_check=now)
        
        subs = self.db.get_subscriptions()
        name = ""
        for s in subs:
            if s['id'] == sub_id:
                name = s.get('channel_name') or s['channel_url'][:40]
                break
        
        if urls:
            self.log(self.t.get("sub_new_found", "Found {n} new").format(name=name, n=len(urls)))
            sub_data = next((s for s in subs if s['id'] == sub_id), {}) or {}
            sub_platform = sub_data.get('platform', self.platform)
            runtime_settings = self._subscription_item_runtime_settings(sub_data)
            quality = runtime_settings.get("video_quality", self._get_quality())
            queue_options = self._subscription_queue_options(sub_data, runtime_settings)
            for url in urls:
                self.log(f"  📥 {url}")
                self._download_queue.add(
                    url,
                    mode=runtime_settings.get("mode", "video"),
                    platform=sub_platform,
                    quality=quality,
                    priority=Priority.LOW,
                    options=self._clone_json_value(queue_options),
                )
            self._persist_session_snapshot()
            self._sub_process_download_queue()
        else:
            self.log(self.t.get("sub_no_new", "No new videos").format(name=name))

        self._refresh_subscriptions()
        self._refresh_runtime_badges()
        self._sub_workers = [w for w in self._sub_workers if w.isRunning()]
        self._sub_start_next()
    
    def _on_sub_check_error(self, sub_id, err):
        subs = self.db.get_subscriptions()
        name = ""
        for s in subs:
            if s['id'] == sub_id:
                name = s.get('channel_name') or s['channel_url'][:40]
                break
        self.log(self.t.get("sub_error", "Error").format(name=name, error=err))
        self._sub_workers = [w for w in self._sub_workers if w.isRunning()]
        self._sub_start_next()
    
    # ══════════════════════════════════════════════════════════════════════════
    #  SCHEDULER
    # ══════════════════════════════════════════════════════════════════════════
    
    def _on_scheduler_toggle(self, state):
        if state:
            self._start_scheduler()
        else:
            self._stop_scheduler()

    def _on_scheduler_config_changed(self, *_args):
        if hasattr(self, "chk_scheduler") and self.chk_scheduler.isChecked():
            self._start_scheduler()
    
    def _start_scheduler_if_enabled(self):
        if self._scheduler_enabled and self.chk_scheduler.isChecked():
            self._start_scheduler()
    
    def _start_scheduler(self):
        self._stop_scheduler()
        interval_ms = self._get_scheduler_interval_ms()
        self._scheduler_timer = QTimer(self)
        self._scheduler_timer.timeout.connect(self._scheduler_tick)
        self._scheduler_timer.start(interval_ms)
        self.log(self.t.get("scheduler_running", "Scheduler started"))
    
    def _stop_scheduler(self):
        if self._scheduler_timer:
            self._scheduler_timer.stop()
            self._scheduler_timer = None
    
    def _get_scheduler_interval_ms(self):
        mode_idx = self.scheduler_mode_combo.currentIndex()
        if mode_idx == 0:  # Daily
            return 24 * 60 * 60 * 1000
        elif mode_idx == 1:  # Weekly
            return 7 * 24 * 60 * 60 * 1000
        else:  # Custom
            try:
                mins = int(self.scheduler_interval_input.text())
                return max(5, mins) * 60 * 1000
            except ValueError:
                return 60 * 60 * 1000  # fallback 1h
    
    def _scheduler_tick(self):
        self.log(f"⏰ Scheduler: checking subscriptions ({datetime.datetime.now().strftime('%H:%M')})")
        self._sub_check_all()
    
    # ══════════════════════════════════════════════════════════════════════════
    #  SESSION RECOVERY
    # ══════════════════════════════════════════════════════════════════════════
    
    def _session_save(self):
        entries = []
        active_status = "paused" if self._downloads_paused else "downloading"
        active = self._active_download_session_payload(status=active_status)
        if active:
            entries.append(active)
        entries.extend(self._download_queue.to_list())

        if not entries:
            url = self.url_input.text().strip()
            if not url:
                return
            entries = [{
                "url": url,
                "mode": self._get_mode(),
                "platform": self.platform,
                "quality": self._get_quality(),
                "status": "pending",
                "options": {"settings": self._collect_runtime_settings_snapshot()},
            }]
        self.db.save_session(entries)
        self.log(self.t.get("session_saved", "Session saved ({n})").format(n=len(entries)))
    
    def _session_restore(self):
        entries = self.db.load_session()
        if not entries:
            self.log(self.t.get("session_empty", "No saved session"))
            return
        self._restore_session_entries(entries, auto_start=False)
        self.log(self.t.get("session_restored", "Session restored ({n})").format(n=len(entries)))

    def _restore_session_entries(self, entries, auto_start=False):
        restored = []
        paused = False
        for entry in entries or []:
            payload = self._clone_json_value(entry)
            if payload.get("status") == "downloading":
                payload["status"] = "pending"
            if payload.get("status") == "paused":
                paused = True
            restored.append(payload)

        self._download_queue.load_from_list(restored)
        self._downloads_paused = paused

        if restored:
            first = restored[0]
            options = first.get("options", {}) if isinstance(first, dict) else {}
            settings = options.get("settings") if isinstance(options, dict) else {}
            if settings:
                self._apply_runtime_settings_snapshot(settings)
            self.url_input.setText(first.get("url", ""))

        self._refresh_runtime_badges()
        self._persist_session_snapshot()
        if auto_start and not self._downloads_paused and not self._download_queue.is_empty():
            QTimer.singleShot(0, self._sub_process_download_queue)
    
    def _check_crash_recovery(self):
        """Check if a previous session was interrupted (crash/kill).
        
        If an auto-saved session exists with status 'downloading', offer to restore it.
        """
        try:
            if self._closing or not self.isVisible():
                return
            entries = self.db.load_session()
            if not entries:
                return
            # Only offer recovery if the session has 'downloading' status (auto-saved)
            downloading = [e for e in entries if e.get('status') in ('downloading', 'paused')]
            if not downloading:
                return
            url = downloading[0].get('url', '')
            if not url:
                self.db.clear_session()
                return
            reply = QMessageBox.question(
                self, "💾",
                self.t.get("session_crash_recover",
                           "A previous download was interrupted:\n{url}\n\nRestore and continue?").format(
                    url=url[:80]),
                QMessageBox.Yes | QMessageBox.No)
            if reply == QMessageBox.Yes:
                self._restore_session_entries(entries, auto_start=True)
                self.log(f"💾 Session restored: {url}")
            else:
                self.db.clear_session()
        except Exception as e:
            log_error("crash_recovery_check", e)

    # ══════════════════════════════════════════════════════════════════════════
    #  DOWNLOAD LOGIC (Core backend)
    # ══════════════════════════════════════════════════════════════════════════
    
    def _get_search_query_from_url(self, raw_text, platform_id=None):
        raw_text = (raw_text or "").strip()
        if not raw_text:
            return ""
        platform_id, pc = self._resolve_platform_context(platform_id)
        search_prefix = pc.get("search_prefix", "")
        if search_prefix and raw_text.lower().startswith(f"{search_prefix}"):
            _, _, query = raw_text.partition(":")
            return query.strip()
        if not raw_text.startswith(("http://", "https://")):
            return ""
        parsed = urlparse(raw_text)
        if platform_id == "youtube" and parsed.netloc.lower() in {"youtube.com", "www.youtube.com", "m.youtube.com"}:
            if parsed.path == "/results":
                return parse_qs(parsed.query).get("search_query", [""])[0].strip()
        return ""

    def normalize_url(self, url, mode, platform_id=None):
        url = url.strip().rstrip('/')
        if not url:
            return ""
        platform_id, pc = self._resolve_platform_context(platform_id)
        if mode == self.MODE_SEARCH:
            search_prefix = pc.get("search_prefix", "")
            if not search_prefix:
                return url
            if url.lower().startswith(f"{search_prefix}"):
                return url
            query = self._get_search_query_from_url(url, platform_id=platform_id) or url
            return f"{search_prefix}{self._get_search_results_limit()}:{query}"
        if not pc.get("normalize_channel_url", False):
            return url
        if mode == self.MODE_CHANNEL:
            known_suffixes = ['/videos', '/shorts', '/streams', '/playlists',
                            '/community', '/about', '/featured', '/channels']
            url_lower = url.lower()
            has_suffix = any(url_lower.endswith(s) for s in known_suffixes)
            has_special_path = '/watch?' in url or '/playlist?' in url
            if not has_suffix and not has_special_path:
                url += '/videos'
                self.log(self.t["url_videos_added"])
        return url

    def _language_display_name(self, code):
        code = (code or "").strip()
        if not code:
            return "—"
        if code == "default":
            return self.t.get("dubbed_audio_default_track", "Default track")
        normalized = code.lower().replace("_", "-")
        base = normalized.split("-", 1)[0]
        return (
            self.t.get(f"lang_{normalized}")
            or self.t.get(f"sub_lang_{normalized}")
            or self.t.get(f"lang_{base}")
            or self.t.get(f"sub_lang_{base}")
            or code
        )

    def _split_language_codes(self, text):
        codes = []
        for part in re.split(r"[,\s;]+", (text or "").strip()):
            code = part.strip()
            if code and code not in codes:
                codes.append(code)
        return codes

    def _extract_audio_languages_from_info(self, info):
        langs = []
        seen = set()
        for fmt in (info or {}).get("formats", []):
            acodec = (fmt.get("acodec") or "none").strip()
            language = (fmt.get("language") or "").strip()
            if acodec != "none" and language and language not in seen:
                seen.add(language)
                langs.append(language)
        return langs

    @staticmethod
    def _audio_only_formats_from_info(info):
        audio_formats = []
        for fmt in (info or {}).get("formats", []):
            acodec = (fmt.get("acodec") or "none").strip()
            vcodec = (fmt.get("vcodec") or "none").strip()
            if acodec != "none" and vcodec == "none":
                audio_formats.append(fmt)
        return audio_formats

    @staticmethod
    def _video_with_audio_formats_from_info(info):
        video_formats = []
        for fmt in (info or {}).get("formats", []):
            acodec = (fmt.get("acodec") or "none").strip()
            vcodec = (fmt.get("vcodec") or "none").strip()
            if acodec != "none" and vcodec != "none":
                video_formats.append(fmt)
        return video_formats

    @staticmethod
    def _video_only_formats_from_info(info):
        video_formats = []
        for fmt in (info or {}).get("formats", []):
            acodec = (fmt.get("acodec") or "none").strip()
            vcodec = (fmt.get("vcodec") or "none").strip()
            if acodec == "none" and vcodec != "none":
                video_formats.append(fmt)
        return video_formats

    def _language_codes_match(self, left, right):
        left_normalized = self._normalize_language_code(left)
        right_normalized = self._normalize_language_code(right)
        if not left_normalized or not right_normalized:
            return False
        left_base = left_normalized.split("-", 1)[0]
        right_base = right_normalized.split("-", 1)[0]
        return (
            left_normalized == right_normalized
            or left_normalized == right_base
            or right_normalized == left_base
            or left_base == right_base
        )

    def _audio_format_rank(self, fmt, prefer_original=False, prefer_default=False, prefer_compatibility=False):
        note = str(fmt.get("format_note") or "").lower()
        language_preference = int(fmt.get("language_preference") or 0)
        channels = int(fmt.get("audio_channels") or 0)
        abr = float(fmt.get("abr") or 0.0)
        tbr = float(fmt.get("tbr") or 0.0)
        source_preference = int(fmt.get("source_preference") or -1)
        quality = int(fmt.get("quality") or -1)
        codec = str(fmt.get("acodec") or "").lower()
        ext = str(fmt.get("ext") or "").lower()
        return (
            1 if prefer_original and "original" in note else 0,
            1 if prefer_default and "default" in note else 0,
            1 if prefer_compatibility and (ext == "m4a" or "mp4a" in codec or "aac" in codec) else 0,
            language_preference,
            channels,
            abr,
            tbr,
            source_preference,
            quality,
            1 if "opus" in codec else 0,
            str(fmt.get("format_id") or ""),
        )

    def _video_with_audio_format_rank(self, fmt, prefer_default=False, prefer_compatibility=False):
        note = str(fmt.get("format_note") or "").lower()
        language_preference = int(fmt.get("language_preference") or 0)
        height = int(fmt.get("height") or 0)
        fps = float(fmt.get("fps") or 0.0)
        tbr = float(fmt.get("tbr") or 0.0)
        source_preference = int(fmt.get("source_preference") or -1)
        quality = int(fmt.get("quality") or -1)
        protocol = str(fmt.get("protocol") or "").lower()
        vcodec = str(fmt.get("vcodec") or "").lower()
        acodec = str(fmt.get("acodec") or "").lower()
        ext = str(fmt.get("ext") or "").lower()
        return (
            1 if prefer_default and "default" in note else 0,
            1 if prefer_compatibility and ext == "mp4" and ("avc" in vcodec or "h264" in vcodec) and ("mp4a" in acodec or "aac" in acodec) else 0,
            language_preference,
            height,
            fps,
            tbr,
            source_preference,
            quality,
            1 if protocol == "m3u8_native" else 0,
            str(fmt.get("format_id") or ""),
        )

    def _video_selector_candidates(self):
        policy = self._get_video_codec_policy()
        if policy == "h264":
            return ["bv[vcodec~='^(avc|avc1|h264)']", "bv"]
        if policy == "modern":
            return ["bv[vcodec~='^(av01|vp9|vp09)']", "bv"]
        if self._prefers_compatibility_target():
            return ["bv[vcodec~='^(avc|avc1|h264)']", "bv"]
        return ["bv"]

    def _build_single_video_selector(self, audio_selector):
        selector_list = audio_selector if isinstance(audio_selector, (list, tuple)) else [audio_selector]
        selectors = []
        for video_selector in self._video_selector_candidates():
            for candidate_audio in selector_list:
                preferred = f"{video_selector}+{candidate_audio}" if candidate_audio else f"{video_selector}+ba"
                if preferred not in selectors:
                    selectors.append(preferred)
            if "ba" not in selector_list:
                fallback_audio = f"{video_selector}+ba"
                if fallback_audio not in selectors:
                    selectors.append(fallback_audio)
        if "b" not in selectors:
            selectors.append("b")
        return "/".join(selectors)

    def _audio_selector_candidates(self, audio_lang=None, media_info=None, prefer_exact_audio=True):
        requested_audio_lang = audio_lang if audio_lang is not None else self._get_audio_language()
        exact_audio_format_id = self._get_selected_audio_format_id(
            requested_audio_lang,
            media_info=media_info,
        ) if prefer_exact_audio else ""
        if exact_audio_format_id:
            return [exact_audio_format_id]

        resolved_audio_lang = self._get_audio_language_filter_code(
            requested_audio_lang,
            media_info=media_info,
            exact_match=prefer_exact_audio,
        )
        selectors = []
        if requested_audio_lang == "original":
            selectors.append("ba[format_note*=original]")
        if resolved_audio_lang:
            if self._prefers_compatibility_target():
                selectors.append(f"ba[language={resolved_audio_lang}][ext=m4a]")
            selectors.append(f"ba[language={resolved_audio_lang}]")
        elif self._prefers_compatibility_target():
            selectors.append("ba[ext=m4a]")
        selectors.append("ba")

        ordered = []
        seen = set()
        for selector in selectors:
            selector_text = str(selector or "").strip()
            if selector_text and selector_text not in seen:
                seen.add(selector_text)
                ordered.append(selector_text)
        return ordered

    def _get_multistream_audio_format_ids(self, audio_lang=None, media_info=None):
        info = media_info or {}
        audio_formats = self._audio_only_formats_from_info(info)
        if not audio_formats:
            return []

        requested_audio_lang = audio_lang if audio_lang is not None else self._get_audio_language()
        best_by_language = {}
        for fmt in audio_formats:
            format_id = str(fmt.get("format_id") or "").strip()
            if not format_id:
                continue
            language_key = self._normalize_language_code(fmt.get("language")) or f"und:{format_id}"
            current = best_by_language.get(language_key)
            if current is None or self._audio_format_rank(
                fmt,
                prefer_original=requested_audio_lang == "original",
                prefer_default=requested_audio_lang == "default",
                prefer_compatibility=self._prefers_compatibility_target(),
            ) > self._audio_format_rank(
                current,
                prefer_original=requested_audio_lang == "original",
                prefer_default=requested_audio_lang == "default",
                prefer_compatibility=self._prefers_compatibility_target(),
            ):
                best_by_language[language_key] = fmt

        ordered = sorted(
            best_by_language.values(),
            key=lambda fmt: self._audio_format_rank(
                fmt,
                prefer_original=requested_audio_lang == "original",
                prefer_default=requested_audio_lang == "default",
                prefer_compatibility=self._prefers_compatibility_target(),
            ),
            reverse=True,
        )

        selected_id = self._get_selected_audio_format_id(requested_audio_lang, media_info=info)
        selected_fmt = None
        if selected_id:
            selected_fmt = next(
                (fmt for fmt in audio_formats if str(fmt.get("format_id") or "").strip() == selected_id),
                None,
            )

        ordered_ids = []
        seen = set()
        if selected_fmt is not None:
            selected_format_id = str(selected_fmt.get("format_id") or "").strip()
            if selected_format_id:
                ordered_ids.append(selected_format_id)
                seen.add(selected_format_id)
        for fmt in ordered:
            format_id = str(fmt.get("format_id") or "").strip()
            if format_id and format_id not in seen:
                seen.add(format_id)
                ordered_ids.append(format_id)
        return ordered_ids

    def _get_video_multistream_format_string(self, quality, audio_lang=None, media_info=None):
        info = media_info or {}
        audio_ids = self._get_multistream_audio_format_ids(audio_lang, media_info=info)
        if len(audio_ids) < 2 or not self._video_only_formats_from_info(info):
            return ""

        selectors = []
        audio_chain = "+".join(audio_ids)
        for video_selector in self._video_selector_candidates():
            candidate = f"{video_selector}+{audio_chain}"
            if candidate not in selectors:
                selectors.append(candidate)

        fallback = self._get_video_format_string(
            quality,
            audio_lang,
            all_audio_tracks=False,
            media_info=info,
            prefer_exact_audio=True,
        )
        if fallback and fallback not in selectors:
            selectors.append(fallback)
        return "/".join(selectors)

    def _get_audio_language_filter_code(self, audio_lang=None, media_info=None, exact_match=True):
        requested_audio_lang = audio_lang if audio_lang is not None else self._get_audio_language()
        if requested_audio_lang in {"", "any"}:
            return ""
        if not exact_match:
            if requested_audio_lang == "default":
                return self._preferred_default_language_code(self._plain_language_codes(self._audio_language_choices()))
            if requested_audio_lang == "original":
                return ""
            return self._normalize_language_code(requested_audio_lang)
        return self._resolve_audio_language_selector(requested_audio_lang, media_info=media_info)

    def _get_selected_audio_format_id(self, audio_lang=None, media_info=None):
        info = media_info or {}
        audio_formats = self._audio_only_formats_from_info(info)
        if not audio_formats:
            return ""

        requested_audio_lang = audio_lang if audio_lang is not None else self._get_audio_language()
        target_language = self._resolve_audio_language_selector(requested_audio_lang, media_info=info)
        if requested_audio_lang not in {"", "any"} and not target_language:
            return ""

        candidates = []
        for fmt in audio_formats:
            if target_language and not self._language_codes_match(fmt.get("language"), target_language):
                continue
            candidates.append(fmt)

        if not candidates:
            return ""

        best = max(
            candidates,
            key=lambda fmt: self._audio_format_rank(
                fmt,
                prefer_original=requested_audio_lang == "original",
                prefer_default=requested_audio_lang == "default",
                prefer_compatibility=self._prefers_compatibility_target(),
            ),
        )
        return str(best.get("format_id") or "")

    def _get_selected_video_with_audio_format_id(self, audio_lang=None, media_info=None):
        info = media_info or {}
        combined_formats = self._video_with_audio_formats_from_info(info)
        if not combined_formats:
            return ""

        requested_audio_lang = audio_lang if audio_lang is not None else self._get_audio_language()
        target_language = self._resolve_audio_language_selector(requested_audio_lang, media_info=info)
        if requested_audio_lang not in {"", "any"} and not target_language:
            return ""

        candidates = []
        for fmt in combined_formats:
            if target_language and not self._language_codes_match(fmt.get("language"), target_language):
                continue
            candidates.append(fmt)

        if not candidates:
            return ""

        best = max(
            candidates,
            key=lambda fmt: self._video_with_audio_format_rank(
                fmt,
                prefer_default=requested_audio_lang == "default",
                prefer_compatibility=self._prefers_compatibility_target(),
            ),
        )
        return str(best.get("format_id") or "")

    def _detect_immersive_profile(self, info):
        if not isinstance(info, dict):
            return {"is_360": False, "is_3d": False, "is_immersive": False, "label": self.t.get("immersive_standard", "Standard video"), "projection": ""}
        projection = str(info.get("projection") or "")
        title = str(info.get("title") or "")
        notes = " ".join(str(fmt.get("format_note") or "") for fmt in info.get("formats", [])[:12])
        blob = " ".join([projection, title, notes]).lower()
        is_360 = bool(re.search(r"(^|\W)(360(?:°|º)?|vr180|spherical|equirectangular)(\W|$)", blob))
        is_3d = bool(re.search(r"(^|\W)(3d|stereoscopic|stereo|sbs|side[- ]by[- ]side|top[- ]?bottom|tab)(\W|$)", blob))
        if is_360 and is_3d:
            label = self.t.get("immersive_both", "360° / 3D video")
        elif is_360:
            label = self.t.get("immersive_360", "360° / VR video")
        elif is_3d:
            label = self.t.get("immersive_3d", "3D / stereoscopic video")
        else:
            label = self.t.get("immersive_standard", "Standard video")
        return {
            "is_360": is_360,
            "is_3d": is_3d,
            "is_immersive": is_360 or is_3d,
            "label": label,
            "projection": projection,
        }

    def _probe_media_info(self, url, cookies="", platform_id=None, log_errors=False, runtime_settings=None):
        platform_id, _ = self._resolve_platform_context(platform_id)
        key = self._media_info_cache_key(url, cookies=cookies, platform_id=platform_id, runtime_settings=runtime_settings)
        if key in self._media_info_cache:
            return self._media_info_cache[key]

        ytdlp_bin = getattr(self, "_ytdlp_bin", find_binary("yt-dlp"))
        cmd = [ytdlp_bin, "--dump-json", "--no-warnings", "--no-playlist"]
        cmd.extend(self._build_ytdlp_runtime_args(cookies=cookies, platform_id=platform_id, runtime_settings=runtime_settings))
        cmd.append(url)
        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=45,
                encoding="utf-8",
                errors="replace",
                env=_get_subprocess_env(),
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
            if result.returncode != 0 or not result.stdout.strip():
                if log_errors and result.stderr.strip():
                    self.log(self.t.get("media_probe_failed", "⚠️ Metadata probe failed: {error}").format(error=result.stderr.strip()[:240]))
                return {}
            data = json.loads(result.stdout)
            if isinstance(data, dict):
                self._media_info_cache[key] = data
                return data
        except Exception as e:
            if log_errors:
                self.log(self.t.get("media_probe_failed", "⚠️ Metadata probe failed: {error}").format(error=str(e)))
        return {}

    def _resolve_dubbed_audio_languages(self, mode, url, cookies="", platform_id=None, media_info=None):
        if not self._get_dubbed_audio_export_enabled() or mode == self.MODE_AUDIO:
            return []
        selection_mode = self._get_dubbed_audio_mode()
        if selection_mode == "selected":
            chosen = self._get_audio_language()
            if chosen in {"default", "original"}:
                info = media_info or self._probe_media_info(url, cookies=cookies, platform_id=platform_id, log_errors=False)
                resolved = self._resolve_audio_language_selector(chosen, media_info=info)
                return [resolved or "default"]
            return [chosen if chosen and chosen != "any" else "default"]
        if selection_mode == "custom":
            return self._split_language_codes(self._get_dubbed_audio_languages_text())
        if selection_mode == "all":
            if mode != self.MODE_VIDEO:
                return []
            return self._extract_audio_languages_from_info(media_info or {})
        return []

    def _get_dubbed_audio_output_template(self, outdir, language_code):
        folder = self.t.get("dubbed_audio_folder", "Dubbed Audio")
        label = "default" if language_code == "default" else re.sub(r"[^A-Za-z0-9._-]+", "_", language_code)
        return str(Path(outdir) / folder / label / "%(title)s [%(id)s].%(ext)s")

    def _get_dubbed_audio_archive_path(self, platform_id, language_code):
        safe_code = "default" if language_code == "default" else re.sub(r"[^A-Za-z0-9._-]+", "_", language_code)
        return get_settings_dir() / f"archive_{platform_id}_dub_{safe_code}.txt"

    def _track_completed_output_path(self, raw_path):
        if self._active_followup_task:
            return
        path_str = str(raw_path or "").strip()
        if not path_str:
            return
        if path_str not in self._completed_output_paths:
            self._completed_output_paths.append(path_str)

    @staticmethod
    def _m3u_sort_key(path_str):
        path = Path(path_str)
        parts = re.split(r"(\d+)", path.stem.lower())
        return [int(part) if part.isdigit() else part for part in parts]

    @staticmethod
    def _safe_manifest_name(name):
        cleaned = re.sub(r'[<>:"/\\|?*]+', "_", str(name or "").strip())
        cleaned = cleaned.rstrip(". ").strip()
        return cleaned or "Aura Playlist"

    def _should_generate_m3u(self, mode, runtime_settings, completed_paths):
        if not self._get_generate_m3u_enabled():
            return False
        normalized = [str(path).strip() for path in completed_paths if str(path).strip()]
        if len(normalized) < 2:
            return False
        if mode in (self.MODE_PLAYLIST, self.MODE_CHANNEL, self.MODE_SEARCH):
            return True
        source_mode = str((runtime_settings or {}).get("audio_source") or "")
        return mode == self.MODE_AUDIO and source_mode in (self.AUDIO_SOURCE_PLAYLIST, self.AUDIO_SOURCE_CHANNEL)

    def _write_m3u_manifest(self, completed_paths, manifest_name=None, manifest_dir=None, minimum_items=2):
        normalized = []
        seen = set()
        for raw_path in completed_paths or []:
            value = str(raw_path or "").strip()
            if not value or value in seen:
                continue
            seen.add(value)
            normalized.append(value)
        min_items = max(1, int(minimum_items or 1))
        if len(normalized) < min_items:
            return None

        ordered_paths = sorted(normalized, key=self._m3u_sort_key)
        if manifest_dir is None:
            parent_candidates = [str(Path(path).parent) for path in ordered_paths]
            manifest_dir = Path(os.path.commonpath(parent_candidates))
        else:
            manifest_dir = Path(manifest_dir)
        manifest_dir.mkdir(parents=True, exist_ok=True)
        display_name = str(manifest_name or manifest_dir.name).strip() or "Aura Playlist"
        manifest_path = manifest_dir / f"{self._safe_manifest_name(display_name)}.m3u"

        lines = ["#EXTM3U", f"#PLAYLIST:{display_name}"]
        for path_str in ordered_paths:
            try:
                entry = os.path.relpath(path_str, manifest_dir)
            except ValueError:
                entry = path_str
            lines.append(entry)
        manifest_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
        return manifest_path

    def _update_subscription_playlist_manifest(self, subscription_context, outdir, completed_paths):
        if not self._get_generate_m3u_enabled():
            return None
        if not isinstance(subscription_context, dict):
            return None
        if (subscription_context.get("target_kind") or "").strip().lower() != "playlist":
            return None

        normalized = []
        for raw_path in completed_paths or []:
            value = str(raw_path or "").strip()
            if value:
                normalized.append(value)
        if not normalized:
            return None

        key_outdir = str(outdir or "").strip()
        sub_id = subscription_context.get("id")
        key = f"{sub_id}:{key_outdir}" if sub_id else key_outdir
        if not key:
            return None

        state = self._subscription_playlist_manifests.setdefault(key, {"paths": []})
        for path_str in normalized:
            if path_str not in state["paths"]:
                state["paths"].append(path_str)

        manifest_name = (subscription_context.get("name") or "").strip() or self._subscription_kind_label("playlist")
        manifest_dir = Path(key_outdir) if key_outdir else None
        return self._write_m3u_manifest(
            state["paths"],
            manifest_name=manifest_name,
            manifest_dir=manifest_dir,
            minimum_items=1,
        )
    
    def _is_valid_url_format(self, url, platform_id=None):
        url = url.strip().lower()
        if not url:
            return False
        if url.startswith(('http://', 'https://')):
            return True
        _, pc = self._resolve_platform_context(platform_id)
        domains = pc.get("domains", [])
        return any(d in url for d in domains)
    
    def validate_inputs(self):
        try:
            return self._validate_inputs_impl()
        except Exception as e:
            import traceback
            self.log(f"\n❌ ERROR in validate_inputs:\n{traceback.format_exc()}")
            return None
    
    def _validate_inputs_impl(self):
        t = self.t
        mode = self._get_mode()
        url = self.url_input.text().strip()
        outdir = self.outdir_input.text().strip()
        
        if not url:
            QMessageBox.warning(self, t.get("error_title", "Error"), t["error_no_url"])
            return None
        
        if not outdir:
            QMessageBox.warning(self, t.get("error_title", "Error"), t["error_no_outdir"])
            return None
        
        if mode != self.MODE_SEARCH and not self._is_valid_url_format(url):
            result = QMessageBox.question(self, t.get("error_title", "Error"),
                                           t["error_invalid_url"],
                                           QMessageBox.Yes | QMessageBox.No)
            if result != QMessageBox.Yes:
                return None
        
        outdir_issue = self._check_output_directory(outdir, create=True)
        if outdir_issue:
            QMessageBox.warning(self, t.get("error_title", "Error"), outdir_issue)
            return None

        url = self.normalize_url(url, mode)
        cookies = self.cookies_input.text().strip()
        
        return {
            "mode": mode, "url": url, "outdir": outdir, "cookies": cookies,
        }
    
    def _get_output_template(self, outdir, mode, platform_id=None):
        pid, _ = self._resolve_platform_context(platform_id)
        platform_name = get_platform_name(pid, self.lang)
        base = str(Path(outdir) / platform_name)
        numbering = "" if self.chk_nonumber.isChecked() else "%(playlist_index)s_"
        
        # Truncate directory names to 60 chars to prevent Windows MAX_PATH (260) overflow.
        # --trim-filenames only trims the filename, not directory components.
        # A 100+ char channel name + 150 char filename + deep base path → OSError.
        uploader = "%(uploader).60s"
        playlist = "%(playlist_title).60s"
        
        if mode == self.MODE_CHANNEL:
            return str(Path(base) / uploader / f"{numbering}%(title)s.%(ext)s")
        elif mode == self.MODE_PLAYLIST:
            return str(Path(base) / playlist / f"{numbering}%(title)s.%(ext)s")
        elif mode == self.MODE_SEARCH:
            return str(Path(base) / "Search Results" / f"{numbering}%(title)s.%(ext)s")
        elif mode == self.MODE_AUDIO:
            source = self._get_audio_source()
            if source == self.AUDIO_SOURCE_CHANNEL:
                return str(Path(base) / "Audio" / uploader / f"{numbering}%(title)s.%(ext)s")
            elif source == self.AUDIO_SOURCE_PLAYLIST:
                return str(Path(base) / "Audio" / playlist / f"{numbering}%(title)s.%(ext)s")
            return str(Path(base) / "Audio" / "%(title)s.%(ext)s")
        return str(Path(base) / "%(title)s.%(ext)s")
    
    def _build_base_command(self, cookies, output_template, archive_path, platform_id=None, runtime_settings=None):
        platform_id, _ = self._resolve_platform_context(platform_id)
        ytdlp_bin = getattr(self, '_ytdlp_bin', find_binary("yt-dlp"))
        cmd = [ytdlp_bin]

        ffmpeg_bin = getattr(self, '_ffmpeg_bin', find_binary("ffmpeg"))
        ffmpeg_dir = str(Path(ffmpeg_bin).parent) if ffmpeg_bin and ffmpeg_bin != "ffmpeg" else None
        if ffmpeg_dir:
            cmd.extend(["--ffmpeg-location", ffmpeg_dir])

        cmd.extend(["-o", output_template])
        cmd.append("--newline")

        if sys.platform == 'win32':
            cmd.append("--windows-filenames")
            cmd.extend(["--trim-filenames", "150"])

        if self.chk_archive.isChecked() and archive_path:
            cmd.extend(["--download-archive", str(archive_path)])

        cmd.extend(self._build_ytdlp_runtime_args(cookies=cookies, platform_id=platform_id, runtime_settings=runtime_settings))
        return cmd

    def _build_load_info_json_base_command(self, output_template, archive_path):
        ytdlp_bin = getattr(self, "_ytdlp_bin", find_binary("yt-dlp"))
        cmd = [ytdlp_bin]

        ffmpeg_bin = getattr(self, "_ffmpeg_bin", find_binary("ffmpeg"))
        ffmpeg_dir = str(Path(ffmpeg_bin).parent) if ffmpeg_bin and ffmpeg_bin != "ffmpeg" else None
        if ffmpeg_dir:
            cmd.extend(["--ffmpeg-location", ffmpeg_dir])

        cmd.extend(["-o", output_template])
        cmd.append("--newline")

        if sys.platform == "win32":
            cmd.append("--windows-filenames")
            cmd.extend(["--trim-filenames", "150"])

        if self.chk_archive.isChecked() and archive_path:
            cmd.extend(["--download-archive", str(archive_path)])

        return cmd

    @staticmethod
    def _format_id_is_combined_stream(format_id, media_info=None):
        target = str(format_id or "").strip()
        if not target:
            return False
        for fmt in (media_info or {}).get("formats", []):
            if str(fmt.get("format_id") or "").strip() != target:
                continue
            acodec = (fmt.get("acodec") or "none").strip()
            vcodec = (fmt.get("vcodec") or "none").strip()
            return acodec != "none" and vcodec != "none"
        return False

    def _create_temporary_info_json(self, media_info, platform_id="youtube"):
        payload = self._clone_json_value(media_info or {})
        if not isinstance(payload, dict) or not payload:
            return None

        temp_dir = get_settings_dir() / "runtime"
        temp_name = f"{platform_id}_{int(time.time() * 1000)}_{random.randint(1000, 9999)}.info.json"
        temp_path = temp_dir / temp_name
        if atomic_write_json(temp_path, payload):
            return temp_path
        return None

    def _cleanup_temp_download_files(self, paths=None):
        cleanup_paths = list(paths if paths is not None else self._active_temp_download_files)
        for raw_path in cleanup_paths:
            try:
                Path(raw_path).unlink(missing_ok=True)
            except Exception as exc:
                log_error("temp_download_cleanup", exc)
        if paths is None:
            self._active_temp_download_files = []

    def _get_video_format_string(self, quality, audio_lang=None, all_audio_tracks=False, media_info=None, prefer_exact_audio=True):
        if all_audio_tracks:
            multistream_selector = self._get_video_multistream_format_string(
                quality,
                audio_lang,
                media_info=media_info,
            )
            if multistream_selector:
                return multistream_selector
        audio_selector = self._get_preferred_video_audio_selector(
            audio_lang,
            media_info=media_info,
            prefer_exact_audio=prefer_exact_audio,
        )
        return self._build_single_video_selector(audio_selector or "ba")
    
    def _get_audio_format_string(self, audio_lang=None, media_info=None, prefer_exact_audio=True):
        selectors = self._audio_selector_candidates(
            audio_lang,
            media_info=media_info,
            prefer_exact_audio=prefer_exact_audio,
        )
        if len(selectors) == 1 and not str(selectors[0]).startswith("ba"):
            return selectors[0]
        return "/".join(selectors + ["b"])

    def _get_preferred_video_audio_selector(self, audio_lang=None, media_info=None, prefer_exact_audio=True):
        return self._audio_selector_candidates(
            audio_lang,
            media_info=media_info,
            prefer_exact_audio=prefer_exact_audio,
        )

    def _get_manual_format_override(self, url, mode, platform_id=None, media_info=None):
        if not self._manual_format_matches_context(
            url=url,
            mode=mode,
            platform_id=platform_id,
        ):
            return ""
        manual_format_id = str(getattr(self, "_manual_format_id", "") or "").strip()
        if not manual_format_id:
            return ""
        manual_kind = str(getattr(self, "_manual_format_kind", "") or "").strip()
        if mode != self.MODE_AUDIO and manual_kind == "video-only":
            audio_selectors = self._get_preferred_video_audio_selector(
                media_info=media_info,
                prefer_exact_audio=self._should_use_exact_audio_format_ids(mode),
            )
            selector_list = audio_selectors if isinstance(audio_selectors, (list, tuple)) else [audio_selectors]
            candidates = []
            for audio_selector in selector_list:
                candidate = f"{manual_format_id}+{audio_selector}" if audio_selector else f"{manual_format_id}+ba"
                if candidate not in candidates:
                    candidates.append(candidate)
            if f"{manual_format_id}+ba" not in candidates:
                candidates.append(f"{manual_format_id}+ba")
            candidates.append("b")
            return "/".join(candidates)
        return manual_format_id
    
    def _build_command(self, mode, url, cookies, output_template, archive_path,
                       max_downloads=None, platform_id=None, quality_override=None, playlist_items=None,
                       allow_metadata_probe=True, runtime_settings=None,
                       preloaded_media_info=None, load_info_json_path="", forced_format_id=""):
        try:
            return self._build_command_impl(
                mode, url, cookies, output_template, archive_path,
                max_downloads=max_downloads,
                platform_id=platform_id,
                quality_override=quality_override,
                playlist_items=playlist_items,
                allow_metadata_probe=allow_metadata_probe,
                runtime_settings=runtime_settings,
                preloaded_media_info=preloaded_media_info,
                load_info_json_path=load_info_json_path,
                forced_format_id=forced_format_id,
            )
        except Exception as e:
            import traceback
            self.log(f"\n❌ ERROR in _build_command:\n{traceback.format_exc()}")
            raise

    def _build_command_impl(self, mode, url, cookies, output_template, archive_path,
                            max_downloads=None, platform_id=None, quality_override=None, playlist_items=None,
                            allow_metadata_probe=True, runtime_settings=None,
                            preloaded_media_info=None, load_info_json_path="", forced_format_id=""):
        platform_id, pc = self._resolve_platform_context(platform_id)
        if load_info_json_path:
            cmd = self._build_load_info_json_base_command(output_template, archive_path)
            cmd.extend(["--load-info-json", str(load_info_json_path)])
        else:
            cmd = self._build_base_command(
                cookies,
                output_template,
                archive_path,
                platform_id=platform_id,
                runtime_settings=runtime_settings,
            )
        
        audio_lang = self._get_audio_language()
        subtitle_lang = self._get_sub_language()
        prefer_exact_audio = self._should_use_exact_audio_format_ids(mode)
        media_info = self._clone_json_value(preloaded_media_info or {})
        if not media_info and allow_metadata_probe and self._should_probe_media_info_for_command(
            mode,
            audio_lang=audio_lang,
            subtitle_lang=subtitle_lang,
            prefer_exact_audio=prefer_exact_audio,
        ):
            media_info = self._probe_media_info(
                url,
                cookies=cookies,
                platform_id=platform_id,
                log_errors=False,
                runtime_settings=runtime_settings,
            )

        multistream_selector = ""

        if mode == self.MODE_AUDIO:
            fmt = self._get_audio_format()
            bitrate = self._get_audio_bitrate()
            cmd.extend(["-f", self._get_audio_format_string(
                audio_lang,
                media_info=media_info,
                prefer_exact_audio=prefer_exact_audio,
            )])
            cmd.extend(["-x", "--audio-format", fmt])
            if bitrate != "max" and fmt not in ("wav", "flac"):
                cmd.extend(["--audio-quality", bitrate])
            # Single audio — prevent downloading entire playlist
            src = self._get_audio_source()
            if src == self.AUDIO_SOURCE_VIDEO:
                cmd.append("--no-playlist")
        else:
            quality = quality_override or self._get_quality()
            keep_all_audio_tracks = (
                mode == self.MODE_VIDEO
                and self._get_download_all_audio_tracks()
                and not forced_format_id
            )
            multistream_selector = ""
            if keep_all_audio_tracks:
                multistream_selector = self._get_video_multistream_format_string(
                    quality,
                    audio_lang,
                    media_info=media_info,
                )
            if forced_format_id:
                cmd.extend(["-f", str(forced_format_id)])
                if not self._format_id_is_combined_stream(forced_format_id, media_info=media_info):
                    cmd.append("--no-keep-video")
            else:
                cmd.extend(["-f", multistream_selector or self._get_video_format_string(
                    quality,
                    audio_lang,
                    all_audio_tracks=keep_all_audio_tracks,
                    media_info=media_info,
                    prefer_exact_audio=prefer_exact_audio,
                )])
                if multistream_selector:
                    cmd.append("--audio-multistreams")
                cmd.append("--no-keep-video")
            # Single video — prevent downloading entire playlist
            if mode == self.MODE_VIDEO:
                cmd.append("--no-playlist")
        
        # Subtitles
        if self.chk_subs.isChecked():
            sub_lang = self._resolve_subtitle_language_selector(media_info=media_info)
            cmd.extend(["--write-sub", "--sub-lang", sub_lang])
            cmd.extend(["--convert-subs", self._get_subtitle_format()])
            # Auto-generated subtitles only exist on YouTube
            if platform_id == "youtube":
                cmd.append("--write-auto-sub")
            if mode != self.MODE_AUDIO and self._get_embed_subtitles():
                cmd.append("--embed-subs")
        
        # SponsorBlock (YouTube only)
        if platform_id == "youtube" and self.chk_sb and self.chk_sb.isChecked():
            cats = self._get_sb_categories()
            if cats:
                cats_str = ",".join(cats)
                action = self._get_sb_action()
                if action == "remove":
                    cmd.extend(["--sponsorblock-remove", cats_str])
                    if self.chk_sb_keyframes.isChecked():
                        cmd.append("--force-keyframes-at-cuts")
                else:
                    cmd.extend(["--sponsorblock-mark", cats_str])
        
        # Reverse
        if self.chk_reverse.isChecked() and mode in (self.MODE_PLAYLIST, self.MODE_CHANNEL, self.MODE_SEARCH):
            cmd.append("--playlist-reverse")

        playlist_spec = self._playlist_items_to_spec(playlist_items)
        if playlist_spec:
            cmd.extend(["--playlist-items", playlist_spec])

        # aria2c
        if self.chk_aria2c.isChecked():
            threads = self.aria2c_threads_combo.currentText()
            cmd.extend(["--downloader", "aria2c",
                        "--downloader-args", f"aria2c:-x {threads} -s {threads} -k 1M --check-certificate=false"])
        
        # Max downloads
        if max_downloads:
            cmd.extend(["--max-downloads", str(max_downloads)])
        
        # Manual format override
        manual_format_override = self._get_manual_format_override(
            url=url,
            mode=mode,
            platform_id=platform_id,
            media_info=media_info,
        )
        if manual_format_override and not forced_format_id:
            # Override -f with manual selection
            new_cmd = []
            skip_next = False
            for i, arg in enumerate(cmd):
                if skip_next:
                    skip_next = False
                    continue
                if arg == '-f' and i + 1 < len(cmd):
                    skip_next = True
                    continue
                new_cmd.append(arg)
            cmd = new_cmd
            cmd.extend(["-f", manual_format_override])
        
        # Speed limit
        try:
            limit_val = int(self.speed_limit_input.text()) if hasattr(self, 'speed_limit_input') and self.speed_limit_input.text().strip() else 0
        except ValueError:
            limit_val = 0
        if limit_val > 0:
            unit_idx = self.speed_limit_unit.currentIndex() if hasattr(self, 'speed_limit_unit') else 1
            suffix = "K" if unit_idx == 0 else "M"
            cmd.extend(["--limit-rate", f"{limit_val}{suffix}"])
        
        # Output container (remux)
        container_idx = self.container_combo.currentIndex() if hasattr(self, 'container_combo') else 0
        if mode == self.MODE_VIDEO and self._get_download_all_audio_tracks() and multistream_selector:
            cmd.extend(["--merge-output-format", "mkv"])
        elif container_idx == 1:
            cmd.extend(["--remux-video", "mp4"])
        elif container_idx == 2:
            cmd.extend(["--remux-video", "mkv"])
        
        # Network resilience: longer timeout, infinite retries
        cmd.extend(["--socket-timeout", "60",
                     "--retries", "inf",
                     "--fragment-retries", "inf",
                     "--extractor-retries", "inf",
                     "--file-access-retries", "inf",
                     "--retry-sleep", "exp=1:10"])
        
        if not load_info_json_path:
            cmd.append(url)
        return cmd

    def _build_dubbed_audio_command(self, source_mode, url, cookies, outdir, platform_id, language_code, runtime_settings=None):
        archive_path = self._get_dubbed_audio_archive_path(platform_id, language_code)
        output_template = self._get_dubbed_audio_output_template(outdir, language_code)
        cmd = self._build_base_command(
            cookies,
            output_template,
            archive_path,
            platform_id=platform_id,
            runtime_settings=runtime_settings,
        )

        audio_selector = "ba/b" if language_code == "default" else self._get_audio_format_string(language_code)
        cmd.extend(["-f", audio_selector, "-x", "--audio-format", self._get_dubbed_audio_format()])
        cmd.extend(["--ignore-errors", "--ignore-no-formats-error"])

        if source_mode == self.MODE_VIDEO:
            cmd.append("--no-playlist")
        elif self.chk_reverse.isChecked() and source_mode in (self.MODE_PLAYLIST, self.MODE_CHANNEL, self.MODE_SEARCH):
            cmd.append("--playlist-reverse")

        if self.chk_aria2c.isChecked():
            threads = self.aria2c_threads_combo.currentText()
            cmd.extend(["--downloader", "aria2c",
                        "--downloader-args", f"aria2c:-x {threads} -s {threads} -k 1M --check-certificate=false"])

        try:
            limit_val = int(self.speed_limit_input.text()) if hasattr(self, 'speed_limit_input') and self.speed_limit_input.text().strip() else 0
        except ValueError:
            limit_val = 0
        if limit_val > 0:
            unit_idx = self.speed_limit_unit.currentIndex() if hasattr(self, 'speed_limit_unit') else 1
            suffix = "K" if unit_idx == 0 else "M"
            cmd.extend(["--limit-rate", f"{limit_val}{suffix}"])

        cmd.extend(["--socket-timeout", "60",
                     "--retries", "inf",
                     "--fragment-retries", "inf",
                     "--extractor-retries", "inf",
                     "--file-access-retries", "inf",
                     "--retry-sleep", "exp=1:10"])
        cmd.append(url)
        return cmd

    def _build_followup_tasks(self, mode, url, cookies, outdir, platform_id, media_info=None, runtime_settings=None):
        tasks = []
        for language_code in self._resolve_dubbed_audio_languages(
            mode, url, cookies=cookies, platform_id=platform_id, media_info=media_info
        ):
            cmd = self._build_dubbed_audio_command(
                mode,
                url,
                cookies,
                outdir,
                platform_id,
                language_code,
                runtime_settings=runtime_settings,
            )
            tasks.append({
                "kind": "dubbed_audio",
                "language": language_code,
                "label": self._language_display_name(language_code),
                "cmd": cmd,
            })
        return tasks
    
    def start_download(self):
        try:
            self._start_download_impl()
        except Exception as e:
            import traceback
            tb = traceback.format_exc()
            self.log(f"\n❌ CRITICAL ERROR in start_download:\n{tb}")
            self.start_btn.setEnabled(True)
            self.stop_btn.setEnabled(False)
    
    def _start_download_impl(self):
        params = self.validate_inputs()
        if not params:
            return
        self._start_download_request(
            params,
            platform_id=self.platform,
            quality_override=self._get_quality(),
            save_settings=True,
            allow_queue=True,
        )

    def _is_download_busy(self):
        if self._download_prep_worker and self._download_prep_worker.isRunning():
            return True
        if self.worker and self.worker.isRunning():
            return True
        if self._restart_thread and self._restart_thread.is_alive():
            return True
        for w in getattr(self, '_parallel_workers', []):
            if w.isRunning():
                return True
        return False

    def _download_needs_media_probe(self, mode):
        return bool(
            mode == self.MODE_VIDEO and (
                self._get_download_all_audio_tracks()
                or
                (self._get_dubbed_audio_export_enabled() and self._get_dubbed_audio_mode() == "all")
                or self._get_immersive_safe_container_enabled()
            )
        )

    def _needs_background_download_preparation(self, mode, selected_audio_lang=None):
        selected = str(selected_audio_lang if selected_audio_lang is not None else self._get_audio_language()).strip()
        if mode == self.MODE_VIDEO and selected not in {"", "any", "default", "original"}:
            return True
        return self._download_needs_media_probe(mode)

    def _cancel_download_preparation(self):
        worker = self._download_prep_worker
        self._download_prep_token += 1
        self._download_prep_worker = None
        self._pending_download_context = None
        if worker:
            try:
                worker.stop()
            except Exception as e:
                log_error("cancel_download_preparation", e, level="debug")

    def _reset_after_preparation_abort(self, summary, *, refresh_blueprint=True):
        self.start_btn.setEnabled(True)
        self.stop_btn.setEnabled(False)
        self._set_runtime_state("error", summary)
        if refresh_blueprint:
            self._refresh_execution_blueprint()

    def _on_download_preparation_finished(self, token, worker):
        if token != self._download_prep_token:
            return
        if self._download_prep_worker is worker:
            self._download_prep_worker = None

    def _on_download_preparation_error(self, token, message):
        if token != self._download_prep_token:
            return
        self._pending_download_context = None
        self._download_prep_worker = None
        summary = self.t.get("download_prepare_failed", "Download preparation failed.")
        details = str(message or "").strip()
        if details:
            summary = self.t.get("media_probe_failed", "⚠️ Metadata probe failed: {error}").format(error=details[:240])
            self.log(summary)
        self._reset_after_preparation_abort(summary)

    def _begin_download_preparation(self, context):
        self._cancel_download_preparation()
        self.stop_event.clear()
        self.start_btn.setEnabled(False)
        self.stop_btn.setEnabled(True)
        self._downloads_paused = False
        self._pause_requested = False
        self._set_runtime_state("running", self.t.get("download_prepare_summary", "Preparing download..."))
        self.log(self.t.get("download_prepare_log", "⏳ Preparing download..."))

        self._download_prep_token += 1
        token = self._download_prep_token
        self._pending_download_context = self._clone_json_value(context)

        worker = DownloadPreparationWorker(
            self,
            mode=context["mode"],
            url=context["url"],
            cookies=context["cookies"],
            platform_id=context["platform_id"],
            runtime_settings=context["current_settings"],
            selected_audio_lang=context["selected_audio_lang"],
            needs_probe=context["needs_probe"],
        )
        self._download_prep_worker = worker
        worker.result_signal.connect(lambda payload, prep_token=token: self._on_download_preparation_ready(prep_token, payload))
        worker.error_signal.connect(lambda error, prep_token=token: self._on_download_preparation_error(prep_token, error))
        worker.finished.connect(lambda prep_token=token, w=worker: self._on_download_preparation_finished(prep_token, w))
        worker.start()
        return True

    def _on_download_preparation_ready(self, token, payload):
        if token != self._download_prep_token:
            return
        context = self._pending_download_context or {}
        self._pending_download_context = None
        self._download_prep_worker = None

        mode = context.get("mode", self.MODE_VIDEO)
        selected_audio_lang = str(context.get("selected_audio_lang") or "").strip()
        media_info = payload.get("media_info") if isinstance(payload, dict) else {}
        current_settings = payload.get("runtime_settings") if isinstance(payload, dict) else None
        used_audio_runtime_fallback = bool(payload.get("used_audio_runtime_fallback")) if isinstance(payload, dict) else False

        if mode == self.MODE_VIDEO and selected_audio_lang not in {"", "any", "default", "original"}:
            if self._selected_audio_language_missing(selected_audio_lang, media_info=media_info):
                issue = self.t.get(
                    "execution_issue_audio_language_unavailable",
                    "The selected audio language is not available for this video.",
                )
                QMessageBox.warning(
                    self,
                    self.t.get("execution_preflight_title", "Preflight check"),
                    issue,
                )
                self._reset_after_preparation_abort(issue)
                return

        self._continue_start_download_request(
            context["params"],
            platform_id=context["platform_id"],
            quality_override=context["quality"],
            save_settings=context["save_settings"],
            playlist_items=context["playlist_items"],
            queue_priority=context["queue_priority"],
            subscription_context=context["subscription_context"],
            media_info=media_info or {},
            current_settings=current_settings or context.get("current_settings") or {},
            used_audio_runtime_fallback=used_audio_runtime_fallback,
        )

    def _continue_start_download_request(self, params, platform_id=None, quality_override=None,
                                         save_settings=True, playlist_items=None,
                                         queue_priority=Priority.HIGH, subscription_context=None,
                                         media_info=None, current_settings=None,
                                         used_audio_runtime_fallback=False):
        mode = params["mode"]
        url = params["url"].strip()
        cookies = params.get("cookies", "").strip()
        outdir = params["outdir"].strip()
        platform_id, pc = self._resolve_platform_context(platform_id)
        quality = quality_override or self._get_quality()
        media_info = media_info or {}
        current_settings = self._clone_runtime_settings(current_settings)
        selected_audio_lang = self._get_audio_language()

        if self._download_needs_media_probe(mode) and media_info:
            immersive = self._detect_immersive_profile(media_info)
            if immersive["is_immersive"]:
                self.log(self.t.get("immersive_detected_log", "🎥 Detected {label}").format(label=immersive["label"]))
                if hasattr(self, "container_combo") and self.container_combo.currentIndex() == 1 and self._get_immersive_safe_container_enabled():
                    self.container_combo.setCurrentIndex(2)
                    self.log(
                        self.t.get(
                            "immersive_container_adjusted",
                            "📦 Container switched to MKV for safer 360° / 3D compatibility.",
                        )
                    )
            if self._get_download_all_audio_tracks() and hasattr(self, "container_combo") and self.container_combo.currentIndex() == 1:
                self.container_combo.setCurrentIndex(2)
                self.log(
                    self.t.get(
                        "all_audio_tracks_mkv_forced",
                        "📦 Container switched to MKV to keep multiple audio tracks in one final video.",
                    )
                )

        if mode == self.MODE_AUDIO:
            src = self._get_audio_source()
            if src in (self.AUDIO_SOURCE_CHANNEL, self.AUDIO_SOURCE_PLAYLIST):
                warn = pc.get("warn_mass_audio", {})
                warn_msg = warn.get(self.lang, warn.get("en", ""))
                if warn_msg:
                    reply = QMessageBox.question(self, "⚠️", warn_msg,
                                                  QMessageBox.Yes | QMessageBox.No)
                    if reply != QMessageBox.Yes:
                        self._reset_after_preparation_abort(
                            self.t.get("download_cancelled_summary", "Download start was cancelled."),
                            refresh_blueprint=False,
                        )
                        return False

        output_template = self._get_output_template(outdir, mode, platform_id=platform_id)
        translated_load_info_json_path = None
        translated_forced_format_id = ""
        pending_temp_download_files = []

        if (
            mode == self.MODE_VIDEO
            and platform_id == "youtube"
            and selected_audio_lang not in {"", "any", "default", "original"}
            and media_info
            and not self._get_manual_format_override(
                url=url,
                mode=mode,
                platform_id=platform_id,
                media_info=media_info,
            )
        ):
            translated_forced_format_id = self._get_selected_video_with_audio_format_id(
                selected_audio_lang,
                media_info=media_info,
            )
            if translated_forced_format_id:
                translated_load_info_json_path = self._create_temporary_info_json(
                    media_info,
                    platform_id=platform_id,
                )
                if translated_load_info_json_path:
                    pending_temp_download_files.append(str(translated_load_info_json_path))
                else:
                    translated_forced_format_id = ""

        if (platform_id == "youtube" and self.chk_sb and self.chk_sb.isChecked()
                and self._get_sb_action() == "remove"
                and self.chk_sb_keyframes.isChecked()):
            reply = QMessageBox.question(
                self,
                "⚠️",
                self.t.get("sb_reencode_warn", "SponsorBlock + Precise cuts will re-encode the entire video. Continue?"),
                QMessageBox.Yes | QMessageBox.No,
            )
            if reply != QMessageBox.Yes:
                self._cleanup_temp_download_files(pending_temp_download_files)
                self._reset_after_preparation_abort(
                    self.t.get("download_cancelled_summary", "Download start was cancelled."),
                    refresh_blueprint=False,
                )
                return False

        refreshed_settings = self._collect_runtime_settings_snapshot()
        if used_audio_runtime_fallback:
            refreshed_settings["auth_method"] = current_settings.get("auth_method", refreshed_settings.get("auth_method", "none"))
            refreshed_settings["cookies"] = current_settings.get("cookies", refreshed_settings.get("cookies", ""))
        current_settings = refreshed_settings
        settings_dir = get_settings_dir()
        settings_dir.mkdir(parents=True, exist_ok=True)
        archive_path = settings_dir / f"archive_{platform_id}.txt"

        self._active_download_platform = platform_id
        self._active_download_mode = mode
        self._active_download_quality = quality
        self._active_download_url = url
        self._active_download_outdir = outdir
        self._active_download_cookies = cookies
        self._active_download_playlist_items = self._coerce_playlist_indices(playlist_items)
        self._active_download_priority = queue_priority
        self._active_runtime_settings = self._clone_json_value(current_settings)
        self._active_download_subscription = self._clone_json_value(subscription_context or {})
        self._active_temp_download_files = []
        self._pending_followup_tasks = self._build_followup_tasks(
            mode,
            url,
            cookies,
            outdir,
            platform_id,
            media_info=media_info,
            runtime_settings=current_settings,
        )
        self._active_followup_task = None
        if self._get_dubbed_audio_export_enabled() and self._get_dubbed_audio_mode() == "all" and mode == self.MODE_VIDEO and not self._pending_followup_tasks:
            self.log(self.t.get("dubbed_audio_none_found", "⚠️ No separate dubbed audio tracks were detected for this video."))

        self._reset_progress()
        self.start_btn.setEnabled(False)
        self.stop_btn.setEnabled(True)
        self.stop_event.clear()
        self._download_generation += 1
        self._restart_process = None
        self._restart_thread = None
        self._downloads_paused = False
        self._pause_requested = False
        self._set_runtime_state("running", self.t.get("download_summary", "Active download: {mode}").format(mode=mode))
        self._persist_session_snapshot()

        self.log("")
        self.log("=" * 50)
        self.log(f"  ▶ {self.t['download_started']}")
        self.log(f"  URL: {url}")
        self.log(self.t.get("log_mode", "  Mode: {mode}").format(mode=mode))
        if used_audio_runtime_fallback:
            runtime_auth = str(current_settings.get("auth_method") or "none").strip()
            if runtime_auth == "cookies_file":
                self.log(self.t.get("log_audio_session_saved_cookies", "  🍪 YouTube audio check switched to saved cookies for the selected language."))
            else:
                self.log(self.t.get("log_audio_session_browser_auth", "  🔐 YouTube audio check switched to browser session auth for the selected language."))
        if translated_forced_format_id:
            self.log(
                self.t.get(
                    "log_youtube_translated_combo_stream",
                    "  🎬 YouTube translated stream: using exact language-ready video format {fmt}.",
                ).format(fmt=translated_forced_format_id)
            )
        if self._pending_followup_tasks:
            tracks = ", ".join(task["label"] for task in self._pending_followup_tasks)
            self.log(self.t.get("dubbed_audio_log_plan", "  🎧 Separate dubbed audio: {tracks}").format(tracks=tracks))
        if self._get_download_all_audio_tracks() and mode == self.MODE_VIDEO:
            self.log(
                self.t.get(
                    "all_audio_tracks_log_plan",
                    "  🎚️ Final file: keep one best audio track per available language in MKV when possible.",
                )
            )
        meta_lang = self._get_meta_language()
        if meta_lang != "any" and platform_id == "youtube":
            self.log(self.t.get("log_title_lang", "  🏷️ Title language: {lang}").format(lang=meta_lang))
            self.log(self.t.get("log_ytdlp_titles_note", "  ⚠️ Translated titles broken in yt-dlp (bug #13363)"))
            self.log(self.t.get("log_ytdlp_titles_note2", "     Will work when yt-dlp fixes it"))
        if platform_id == "youtube" and self.chk_sb and self.chk_sb.isChecked():
            sb_cats = self._get_sb_categories()
            if sb_cats:
                sb_action = self._get_sb_action()
                action_name = self.t.get(f"sb_action_{sb_action}", sb_action)
                cats_str = ", ".join(sb_cats)
                self.log(f"  {self.t['sb_enabled_log'].format(action=action_name, cats=cats_str)}")
                if sb_action == "remove" and self.chk_sb_keyframes.isChecked():
                    self.log(f"  {self.t.get('sb_force_keyframes', '🔑 Precise cuts')}")
        self.log("=" * 50)
        self.log("")

        if save_settings:
            self._save_settings()

        concurrent = 1
        is_multi = mode in (self.MODE_PLAYLIST, self.MODE_CHANNEL, self.MODE_SEARCH)
        if not is_multi and mode == self.MODE_AUDIO:
            src = self._get_audio_source()
            is_multi = src in (self.AUDIO_SOURCE_CHANNEL, self.AUDIO_SOURCE_PLAYLIST)

        if is_multi:
            try:
                concurrent = int(self.concurrent_combo.currentText())
            except (ValueError, AttributeError):
                concurrent = 1

        try:
            if self.chk_restart.isChecked() and mode in (self.MODE_PLAYLIST, self.MODE_CHANNEL, self.MODE_SEARCH):
                self._set_live_command_preview(
                    self.t.get("execution_live_command", "Live command"),
                    self._build_restart_command_preview(
                        mode, url, cookies, output_template, archive_path,
                        platform_id, quality, playlist_items=playlist_items,
                    ),
                )
                self._download_with_restart(
                    mode, url, cookies, output_template, archive_path,
                    platform_id=platform_id, quality_override=quality, playlist_items=playlist_items,
                )
            elif concurrent > 1 and is_multi:
                self._set_live_command_preview(
                    self.t.get("execution_live_command", "Live command"),
                    self._build_parallel_command_preview(
                        mode, url, cookies, output_template, archive_path,
                        concurrent, platform_id, quality, playlist_items=playlist_items,
                    ),
                )
                self._download_parallel(
                    mode, url, cookies, output_template, archive_path, concurrent,
                    platform_id=platform_id, quality_override=quality, playlist_items=playlist_items,
                )
            else:
                cmd = self._build_command(
                    mode, url, cookies, output_template, archive_path,
                    platform_id=platform_id, quality_override=quality, playlist_items=playlist_items,
                    runtime_settings=current_settings,
                    preloaded_media_info=media_info,
                    load_info_json_path=translated_load_info_json_path,
                    forced_format_id=translated_forced_format_id,
                )
                self._active_temp_download_files = list(pending_temp_download_files)
                self.log(f"$ {subprocess.list2cmdline(cmd)}")
                self.log("")
                self._set_live_command_preview(
                    self.t.get("execution_live_command", "Live command"),
                    subprocess.list2cmdline(cmd),
                )
                self._run_worker(cmd)
        except Exception:
            self._active_download_platform = None
            self._active_download_mode = None
            self._active_download_quality = None
            self._active_download_url = ""
            self._active_download_outdir = ""
            self._active_download_cookies = ""
            self._active_download_playlist_items = []
            self._active_download_subscription = {}
            self._active_runtime_settings = {}
            self._cleanup_temp_download_files(pending_temp_download_files)
            self.start_btn.setEnabled(True)
            self.stop_btn.setEnabled(False)
            raise
        return True

    def _start_download_request(self, params, platform_id=None, quality_override=None,
                                save_settings=True, allow_queue=True, playlist_items=None,
                                manual_selection_resolved=False, queue_priority=Priority.HIGH,
                                subscription_context=None):
        mode = params["mode"]
        url = params["url"].strip()
        cookies = params.get("cookies", "").strip()
        outdir = params["outdir"].strip()
        platform_id, pc = self._resolve_platform_context(platform_id)
        quality = quality_override or self._get_quality()

        if not url:
            QMessageBox.warning(self, self.t.get("error_title", "Error"), self.t["error_no_url"])
            return False
        if not outdir:
            QMessageBox.warning(self, self.t.get("error_title", "Error"), self.t["error_no_outdir"])
            return False

        outdir_issue = self._check_output_directory(outdir, create=True)
        if outdir_issue:
            QMessageBox.warning(
                self,
                self.t.get("execution_preflight_title", "Preflight check"),
                outdir_issue,
            )
            self._set_runtime_state("error", outdir_issue)
            self._refresh_execution_blueprint()
            return False

        url = self.normalize_url(url, mode, platform_id=platform_id)
        current_settings = self._collect_runtime_settings_snapshot()

        readiness = self._evaluate_execution_readiness(
            params={"mode": mode, "url": url, "outdir": outdir, "cookies": cookies},
            platform_id=platform_id,
            quality_override=quality,
        )
        if readiness["issues"]:
            details = "\n".join(f"• {issue}" for issue in readiness["issues"])
            QMessageBox.warning(
                self,
                self.t.get("execution_preflight_title", "Preflight check"),
                details,
            )
            self._set_runtime_state("error", readiness["summary"])
            self._refresh_execution_blueprint()
            return False

        if self._should_prompt_manual_selection(mode=mode, playlist_items=playlist_items) and not manual_selection_resolved:
            self._begin_manual_item_selection(
                {"mode": mode, "url": url, "cookies": cookies, "outdir": outdir},
                platform_id=platform_id,
                quality_override=quality,
                save_settings=save_settings,
                allow_queue=allow_queue,
            )
            return False

        if allow_queue and self._is_download_busy():
            queued_options = {
                "settings": self._clone_json_value(current_settings),
                "playlist_items": self._coerce_playlist_indices(playlist_items),
            }
            if subscription_context:
                queued_options["subscription"] = self._clone_json_value(subscription_context)
            self._download_queue.add(
                url,
                mode=mode,
                platform=platform_id,
                quality=quality,
                priority=Priority.NORMAL,
                options=queued_options,
            )
            n = self._download_queue.pending_count()
            self.log(f"📋 Added to queue ({n} pending): {url[:60]}")
            self._set_runtime_state("queued", self.t.get("queue_summary", "Items waiting in queue: {n}").format(n=n))
            self._refresh_runtime_badges()
            self._persist_session_snapshot()
            return False

        selected_audio_lang = self._get_audio_language()
        needs_probe = self._download_needs_media_probe(mode)
        if self._needs_background_download_preparation(mode, selected_audio_lang):
            return self._begin_download_preparation(
                {
                    "params": {"mode": mode, "url": url, "cookies": cookies, "outdir": outdir},
                    "mode": mode,
                    "url": url,
                    "cookies": cookies,
                    "outdir": outdir,
                    "platform_id": platform_id,
                    "quality": quality,
                    "save_settings": save_settings,
                    "playlist_items": self._coerce_playlist_indices(playlist_items),
                    "queue_priority": queue_priority,
                    "subscription_context": self._clone_json_value(subscription_context or {}),
                    "current_settings": current_settings,
                    "selected_audio_lang": selected_audio_lang,
                    "needs_probe": needs_probe,
                }
            )

        return self._continue_start_download_request(
            {"mode": mode, "url": url, "cookies": cookies, "outdir": outdir},
            platform_id=platform_id,
            quality_override=quality,
            save_settings=save_settings,
            playlist_items=playlist_items,
            queue_priority=queue_priority,
            subscription_context=subscription_context,
            media_info={},
            current_settings=current_settings,
            used_audio_runtime_fallback=False,
        )
    
    def _run_worker(self, cmd):
        self.worker = DownloadWorker(cmd, self.stop_event)
        self.worker.log_signal.connect(self.log)
        self.worker.progress_signal.connect(self._handle_progress_line)
        self.worker.finished_signal.connect(self._download_finished)
        self.worker.start()
    
    def _download_parallel(self, mode, url, cookies, output_template, archive_path, concurrent,
                           platform_id=None, quality_override=None, playlist_items=None):
        """Download multiple videos simultaneously using N interleaved yt-dlp processes."""
        self.log(self.t.get("log_parallel", "🚀 Parallel download: {n} videos at once").format(n=concurrent))
        self.log("")
        
        self._parallel_workers = []
        self._parallel_codes = []
        self._is_parallel_mode = True
        self._parallel_state = {}
        self._parallel_archive_main = archive_path  # Main archive file
        self._parallel_archive_parts = []  # Per-worker archive files
        selected = self._coerce_playlist_indices(playlist_items)
        effective_workers = min(concurrent, len(selected)) if selected else concurrent
        
        for i in range(effective_workers):
            worker_id = i + 1
            items_arg = f"{worker_id}::{effective_workers}"

            cmd, worker_archive = self._build_parallel_worker_command(
                mode, url, cookies, output_template, archive_path,
                worker_id, effective_workers, platform_id, quality_override,
                playlist_items=playlist_items,
            )
            if not cmd:
                continue
            if worker_archive:
                self._parallel_archive_parts.append(worker_archive)
                # Copy main archive to each worker so they all know what's already downloaded
                try:
                    ap = Path(archive_path)
                    if ap.exists():
                        shutil.copy2(str(ap), worker_archive)
                except Exception as e:
                    log_error("parallel_archive_copy", e)
            
            if playlist_items:
                items_arg = self._playlist_items_to_spec(
                    self._split_playlist_indices(playlist_items, worker_id, effective_workers)
                )
            self.log(self.t.get("log_worker_task", "  Worker {id}/{total}: --playlist-items {items}").format(
                id=worker_id, total=effective_workers, items=items_arg))
            
            self._parallel_state[worker_id] = {
                'total': 0, 'downloaded': 0, 'pct': 0,
                'speed': '', 'eta': '', 'last_dest': '', 'last_dest_path': '', 'pending': False
            }
            
            worker = DownloadWorker(cmd, self.stop_event)
            worker.log_signal.connect(lambda line, n=worker_id: self.log(f"[W{n}] {line}"))
            worker.progress_signal.connect(lambda line, n=worker_id: self._handle_parallel_progress(n, line))
            worker.finished_signal.connect(self._parallel_worker_finished)
            self._parallel_workers.append(worker)
        
        self.log("")
        self._parallel_total = len(self._parallel_workers)
        if self._parallel_total <= 0:
            self._is_parallel_mode = False
            self.log(self.t.get("manual_selection_empty", "No items selected for download"))
            self.start_btn.setEnabled(True)
            self.stop_btn.setEnabled(False)
            return
        
        for w in self._parallel_workers:
            w.start()
    
    def _parallel_worker_finished(self, return_code):
        """Called when one parallel worker finishes. When all done, signal completion."""
        self._parallel_codes.append(return_code)
        remaining = self._parallel_total - len(self._parallel_codes)
        
        if remaining > 0:
            self.log(self.t.get("log_worker_done", "  ℹ️ Worker finished (code {code}), {remaining} still running...").format(
                code=return_code, remaining=remaining))
            return
        
        # All workers done — merge per-worker archive files into main archive
        main_archive = getattr(self, '_parallel_archive_main', None)
        parts = getattr(self, '_parallel_archive_parts', [])
        if main_archive and parts:
            try:
                # Collect all unique video IDs from per-worker archives
                all_ids = set()
                if Path(main_archive).exists():
                    all_ids.update(Path(main_archive).read_text(encoding='utf-8').strip().splitlines())
                for part in parts:
                    p = Path(part)
                    if p.exists():
                        all_ids.update(p.read_text(encoding='utf-8').strip().splitlines())
                        try:
                            p.unlink()  # Clean up per-worker file
                        except Exception as e:
                            log_error("parallel_archive_merge", e)
                # Write merged archive
                if all_ids:
                    Path(main_archive).write_text('\n'.join(sorted(all_ids)) + '\n', encoding='utf-8')
            except Exception as e:
                self.log(f"⚠️ Archive merge: {e}")
        
        # All workers done — report overall result
        worst_code = max(self._parallel_codes) if self._parallel_codes else 0
        self._parallel_workers = []
        self._download_finished(worst_code)
    
    def _download_finished(self, return_code):
        try:
            self._download_finished_impl(return_code)
        except Exception as e:
            import traceback
            self.log(f"\n⚠️ ERROR in _download_finished:\n{traceback.format_exc()}")
            self.start_btn.setEnabled(True)
            self.stop_btn.setEnabled(False)
    
    def _download_finished_impl(self, return_code):
        if self._closing:
            return
        if return_code == 0 and not self.stop_event.is_set() and self._pending_followup_tasks:
            task = self._pending_followup_tasks.pop(0)
            self._active_followup_task = task
            self.log("")
            self.log(self.t.get("dubbed_audio_starting", "🎧 Exporting dubbed audio track: {track}").format(track=task["label"]))
            self.log(f"$ {subprocess.list2cmdline(task['cmd'])}")
            self.log("")
            self._set_live_command_preview(
                self.t.get("execution_live_command", "Live command"),
                subprocess.list2cmdline(task["cmd"]),
            )
            self._set_runtime_state(
                "running",
                self.t.get("dubbed_audio_running_summary", "Exporting separate dubbed audio files..."),
            )
            self._run_worker(task["cmd"])
            return

        # Flush any pending history entry from last video (single mode)
        if hasattr(self, '_pending_history') and self._pending_history:
            self._flush_pending_history()
        
        # Flush any pending entries from parallel workers
        for state in getattr(self, '_parallel_state', {}).values():
            self._flush_parallel_pending(state)

        finished_mode = self._active_download_mode or self._get_mode()
        finished_runtime_settings = self._clone_json_value(self._active_runtime_settings or {})
        finished_outdir = self._active_download_outdir
        finished_subscription = self._clone_json_value(self._active_download_subscription or {})
        completed_output_paths = list(self._completed_output_paths)
        was_pause_request = self._pause_requested
        self._active_download_platform = None
        self._active_download_mode = None
        self._active_download_quality = None
        self._active_download_url = ""
        self._active_download_outdir = ""
        self._active_download_cookies = ""
        self._active_download_playlist_items = []
        self._active_download_subscription = {}
        self._active_runtime_settings = {}
        self._cleanup_temp_download_files()
        self._clear_live_command_preview()
        self._active_followup_task = None
        self._pending_followup_tasks = []
        self._pause_requested = False
        
        self.start_btn.setEnabled(True)
        self.stop_btn.setEnabled(False)
        self._is_parallel_mode = False
        self._parallel_state = {}
        self._refresh_runtime_badges()
        
        # Reset progress indicators
        self.progress_bar.setValue(100 if return_code == 0 else 0)
        self.speed_label.setText(self.t["speed_idle"])
        self.current_speed = ""
        self.current_eta = ""
        
        self.log("")
        
        # Finalize runtime state before deciding whether the queue should continue.
        if return_code == 0:
            manifest_path = None
            if self._should_generate_m3u(finished_mode, finished_runtime_settings, completed_output_paths):
                try:
                    manifest_path = self._write_m3u_manifest(completed_output_paths)
                except Exception as exc:
                    log_error("m3u_manifest_write", exc)
                    self.log(
                        self.t.get(
                            "generate_m3u_error",
                            "⚠️ M3U playlist generation failed: {error}",
                        ).format(error=exc)
                    )
            if manifest_path is None:
                try:
                    manifest_path = self._update_subscription_playlist_manifest(
                        finished_subscription,
                        finished_outdir,
                        completed_output_paths,
                    )
                except Exception as exc:
                    log_error("subscription_m3u_manifest_write", exc)
                    self.log(
                        self.t.get(
                            "generate_m3u_error",
                            "⚠️ M3U playlist generation failed: {error}",
                        ).format(error=exc)
                    )
            self.log(f"✅ {self.t['download_complete']}")
            if manifest_path is not None:
                self.log(
                    self.t.get(
                        "generate_m3u_success",
                        "🎵 M3U playlist created: {path}",
                    ).format(path=manifest_path)
                )
            # Zero-byte file integrity check
            if self._last_destination_path:
                try:
                    p = Path(self._last_destination_path)
                    if p.exists() and p.stat().st_size == 0:
                        self.log(
                            self.t.get(
                                "download_zero_bytes_warning",
                                "⚠️ Warning: downloaded file is 0 bytes (possibly corrupted)",
                            )
                        )
                except Exception:
                    pass
            jokes = self.t.get("joke_finish", [])
            if jokes:
                self.log(f"  {random.choice(jokes)}")
            self.progress_label.setText(self.t.get("progress_done", "✅"))
            self._show_finish_notification(True)
            self._set_runtime_state("finished", self.t.get("done_summary", "Last operation completed successfully."))
        elif self.stop_event.is_set():
            if was_pause_request:
                self.progress_label.setText(self.t.get("pause_btn", "Pause"))
                self._set_runtime_state("queued", self.t.get("paused_summary", "Downloads are paused. Resume to continue the queue."))
                self.stop_event.clear()
            else:
                self.progress_label.setText(f"⏹")
                self._set_runtime_state("stopped", self.t.get("stopped_summary", "The current operation was stopped by the user."))
        else:
            self.log(f"⚠️ {self.t.get('download_error', 'Download finished with errors')} (code: {return_code})")
            self.progress_label.setText(
                self.t.get("progress_error_code", "⚠️ Code {code}").format(code=return_code)
            )
            self._show_finish_notification(False)
            self._set_runtime_state("error", self.t.get("error_summary", "The last operation finished with errors. Check the execution log."))
        self.log("")
        self._persist_session_snapshot()
        
        # Process download queue (if any URLs waiting)
        if not self.stop_event.is_set() and not self._downloads_paused and not self._download_queue.is_empty():
            # Slight delay to let UI settle before starting next
            QTimer.singleShot(1000, self._sub_process_download_queue)
    
    def _show_finish_notification(self, success):
        """Show system tray notification when download finishes."""
        if not self.chk_notify.isChecked():
            return
        if self.isActiveWindow():
            return
        if not hasattr(self, '_tray_icon'):
            return
        try:
            title = "✦ AURA ✦"
            if success:
                msg = self.t.get("notify_title_done", "✅ Download complete")
                icon_type = QSystemTrayIcon.Information
            else:
                msg = self.t.get("notify_title_error", "⚠️ Download finished with errors")
                icon_type = QSystemTrayIcon.Warning
            self._tray_icon.showMessage(title, msg, icon_type, 5000)
        except Exception as e:
            log_error("finish_notification", e)

    def _update_pause_button_state(self):
        if not hasattr(self, "pause_btn"):
            return
        can_pause = self._downloads_paused or self._is_download_busy() or not self._download_queue.is_empty()
        self.pause_btn.setEnabled(can_pause)
        self.pause_btn.setText(
            self.t.get("resume_btn", "Resume") if self._downloads_paused else self.t.get("pause_btn", "Pause")
        )

    def _toggle_pause_downloads(self):
        if self._downloads_paused:
            self._resume_downloads()
        else:
            self._pause_downloads()

    def _pause_downloads(self):
        if self._downloads_paused:
            return
        has_running = self._is_download_busy()
        has_queue = not self._download_queue.is_empty()
        if not has_running and not has_queue:
            return

        self._downloads_paused = True
        self._pause_requested = has_running

        if has_running:
            payload = self._active_download_session_payload(status="paused")
            if payload:
                self._download_queue.prepend_entry(payload)
            self.stop_event.set()
            if self.worker:
                self.worker.stop()
            for w in getattr(self, "_parallel_workers", []):
                w.stop()
            if self._restart_process:
                try:
                    self._restart_process.terminate()
                except Exception as e:
                    log_error("pause_restart_process", e)
            self.log(self.t.get("pause_requested_log", "⏸ Pause requested. The current item will be re-queued."))
        else:
            for entry in self._download_queue.all_entries():
                if entry.status == "pending":
                    entry.status = "paused"
            self._set_runtime_state("queued", self.t.get("paused_summary", "Downloads are paused. Resume to continue the queue."))

        self._refresh_runtime_badges()
        self._persist_session_snapshot()

    def _resume_downloads(self):
        if not self._downloads_paused:
            return
        self._downloads_paused = False
        self._pause_requested = False
        self.stop_event.clear()
        for entry in self._download_queue.all_entries():
            if entry.status == "paused":
                entry.status = "pending"
        self._set_runtime_state("queued", self.t.get("queue_summary", "Items waiting in queue: {n}").format(n=self._download_queue.pending_count()))
        self._refresh_runtime_badges()
        self._persist_session_snapshot()
        self.log(self.t.get("resume_requested_log", "▶ Resume requested. Queue processing continues."))
        if not self._is_download_busy() and not self._download_queue.is_empty():
            QTimer.singleShot(0, self._sub_process_download_queue)
    
    def stop_download(self):
        has_running = False
        if self._download_prep_worker and self._download_prep_worker.isRunning():
            has_running = True
        if self.worker and self.worker.isRunning():
            has_running = True
        for w in getattr(self, '_parallel_workers', []):
            if w.isRunning():
                has_running = True
                break
        # Restart mode uses threading.Thread + subprocess, not QThread workers
        if self._restart_thread and self._restart_thread.is_alive():
            has_running = True
        
        if has_running:
            reply = QMessageBox.question(self, "⏹", self.t.get("stop_confirm", "Stop download?"),
                                          QMessageBox.Yes | QMessageBox.No)
            if reply != QMessageBox.Yes:
                return
        
        self.stop_event.set()
        self._downloads_paused = False
        self._pause_requested = False
        # Clear download queue on manual stop
        self._sub_download_queue.clear()
        self._download_queue.clear()
        self._pending_followup_tasks = []
        self._active_followup_task = None
        self._active_download_playlist_items = []
        self._active_runtime_settings = {}
        self._cleanup_temp_download_files()
        self._cancel_download_preparation()
        self._refresh_runtime_badges()
        self._persist_session_snapshot()
        self._download_prep_worker = None
        if self.worker:
            self.worker.stop()
        for w in getattr(self, '_parallel_workers', []):
            w.stop()
        self._parallel_workers = []
        # Kill restart mode subprocess directly (don't wait for stdout loop to notice)
        if self._restart_process:
            try:
                self._restart_process.terminate()
                self._restart_process.wait(timeout=PROCESS_TERMINATE_TIMEOUT)
            except Exception:
                try:
                    self._restart_process.kill()
                except Exception as e:
                    log_error("stop_kill_restart_process", e)
            self._restart_process = None
        
        self.log(f"\n⏹ {self.t['download_stopped']}\n")
        self.start_btn.setEnabled(True)
        self.stop_btn.setEnabled(False)
        self._clear_live_command_preview()
        self._set_runtime_state("stopped", self.t.get("stopped_summary", "The current operation was stopped by the user."))
    
    def _download_with_restart(self, mode, url, cookies, output_template, archive_path,
                               platform_id=None, quality_override=None, playlist_items=None):
        """Download with restart-each-video mode (sequential runs)."""
        self.log(f"🔄 {self.t.get('restart_mode', 'Restart mode: downloading one at a time...')}")
        
        # Build command on main thread (widgets accessed safely)
        base_cmd = self._build_restart_command(
            mode, url, cookies, output_template, archive_path,
            platform_id, quality_override, playlist_items=playlist_items,
        )
        generation = self._download_generation  # Capture — ignore stale callbacks
        
        def _restart_loop():
            empty_runs = 0
            run_number = 0
            final_return_code = 0
            while not self.stop_event.is_set() and empty_runs < MAX_CONSECUTIVE_EMPTY_RUNS:
                run_number += 1
                self._sig_log.emit(f"\n{'='*40}\n  Run #{run_number}\n{'='*40}")
                
                cmd = list(base_cmd)  # copy of pre-built command
                
                try:
                    return_code, found_new = self._execute_restart_command(cmd)
                    if return_code is None:
                        return
                    if return_code != 0:
                        final_return_code = return_code
                        self._sig_log.emit(self.t.get(
                            "restart_run_failed",
                            "Restart mode aborted: yt-dlp exited with code {code} on run #{run}.",
                        ).format(code=return_code, run=run_number))
                        break
                    
                    if found_new:
                        empty_runs = 0
                    else:
                        empty_runs += 1
                
                except Exception as e:
                    self._sig_log.emit(f"❌ {e}")
                    final_return_code = 1
                    break
            
            # Only emit finished if this is still the current download
            # (user may have stopped and started a new one)
            if self._download_generation == generation:
                self._sig_finished.emit(final_return_code)
        
        t = threading.Thread(target=_restart_loop, daemon=True)
        self._restart_thread = t
        t.start()

    def _execute_restart_command(self, cmd):
        process = None
        found_new = False
        try:
            process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                encoding='utf-8',
                errors='surrogateescape',
                creationflags=SUBPROCESS_FLAGS,
                env=_get_subprocess_env(),
                bufsize=1,
            )
            tracked_processes.add(process)
            self._restart_process = process
            for line in process.stdout:
                if self.stop_event.is_set():
                    process.terminate()
                    try:
                        process.wait(timeout=5)
                    except Exception:
                        process.kill()
                    return None, found_new
                line = _fix_encoding(line.rstrip('\n\r'))
                if line:
                    self._sig_log.emit(line)
                    self._sig_progress.emit(line)
                    if self._is_download_complete_line(line):
                        found_new = True
            return process.wait(), found_new
        finally:
            if process is not None:
                tracked_processes.discard(process)
            self._restart_process = None


# ══════════════════════════════════════════════════════════════════════════════
#  CONFIG LOCATION DIALOG
# ══════════════════════════════════════════════════════════════════════════════
