#!/usr/bin/env python3
from __future__ import annotations

"""Utility functions — paths, encoding, binary resolution."""
import atexit
import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

from aura.constants import (
    CONFIG_FILENAME,
    POINTER_FILE_NAME,
    SETTINGS_FOLDER_NAME,
    YTDLP_CONFIG_FILENAME,
)

_DEBUG_MODE = False
_DEBUG_SETTINGS_DIR: Path | None = None
_DEBUG_SETTINGS_HANDLE = None

def resource_path(relative_path: str) -> str:
    """Get absolute path to resource — works for dev and PyInstaller bundle."""
    raw_path = Path(relative_path)
    if raw_path.is_absolute():
        return str(raw_path)

    bundle_root = getattr(sys, "_MEIPASS", None)
    if bundle_root:
        return str(Path(bundle_root) / raw_path)

    project_root = Path(__file__).resolve().parent.parent
    package_relative = project_root / raw_path
    if package_relative.exists():
        return str(package_relative)

    if sys.argv and sys.argv[0]:
        argv_relative = Path(sys.argv[0]).resolve().parent / raw_path
        if argv_relative.exists():
            return str(argv_relative)

    return str(package_relative)



def find_binary(name: str) -> str:
    """Find external binary in PATH, excluding current Python runtime directories."""
    path = _find_external_binary(name)
    return path if path else name  # fallback to bare name for subprocess


def _python_runtime_dirs() -> set[Path]:
    """Directories that belong to the current Python runtime and should be ignored."""
    dirs: set[Path] = set()
    candidates = [
        Path(sys.executable).resolve().parent,
        Path(sys.prefix).resolve(),
        Path(sys.base_prefix).resolve(),
        Path(sys.exec_prefix).resolve(),
    ]
    for candidate in candidates:
        dirs.add(candidate)
        dirs.add(candidate / "Scripts")
        dirs.add(candidate / "bin")
        dirs.add(candidate / "Lib")
        dirs.add(candidate / "Lib" / "site-packages")
        dirs.add(candidate / "lib")
        dirs.add(candidate / "lib" / "site-packages")
    return {d for d in dirs if str(d)}


def _is_python_runtime_path(path_str: str) -> bool:
    """Return True when the path points into the current Python runtime."""
    try:
        candidate = Path(path_str).resolve()
    except Exception:
        return False
    for runtime_dir in _PYTHON_RUNTIME_DIRS:
        try:
            candidate.relative_to(runtime_dir)
            return True
        except ValueError:
            continue
    lower_parts = {part.lower() for part in candidate.parts}
    return "site-packages" in lower_parts


def _find_external_binary(name: str) -> str | None:
    """Resolve binary from PATH but reject paths inside the current Python runtime."""
    path_env = os.environ.get("PATH", "")
    for raw_dir in path_env.split(os.pathsep):
        if not raw_dir:
            continue
        try:
            dir_path = Path(raw_dir).expanduser()
        except Exception:
            continue
        if _is_python_runtime_path(str(dir_path)):
            continue
        direct = dir_path / name
        pathexts = os.environ.get("PATHEXT", ".EXE;.BAT;.CMD;.COM").split(os.pathsep if os.pathsep != ";" else ";")
        candidates = [direct]
        if os.name == "nt" and not direct.suffix:
            candidates.extend(dir_path / f"{name}{ext}" for ext in pathexts if ext)
        for candidate in candidates:
            try:
                if candidate.exists() and candidate.is_file():
                    return str(candidate.resolve())
            except Exception:
                continue
    return None


def get_pointer_file() -> Path:
    """Pointer is a SINGLE FILE in user's home dir — no extra folders created."""
    return Path.home() / POINTER_FILE_NAME


def _get_legacy_pointer():
    """Old location: ~/aura_video_downloader_settings/pointer.txt"""
    return Path.home() / SETTINGS_FOLDER_NAME / "pointer.txt"


def _migrate_pointer():
    """Migrate old pointer.txt → new single file in home dir."""
    new_pointer = get_pointer_file()
    if new_pointer.exists():
        return  # already migrated
    old_pointer = _get_legacy_pointer()
    if old_pointer.exists():
        try:
            content = old_pointer.read_text(encoding='utf-8').strip()
            new_pointer.write_text(content, encoding='utf-8')
            old_pointer.unlink()
            # Remove old container if now empty
            old_dir = old_pointer.parent
            if old_dir.exists() and not any(old_dir.iterdir()):
                old_dir.rmdir()
        except Exception:
            pass


def _resolve_settings_candidate(raw_value: str | None) -> Path:
    """Resolve pointer text to a concrete settings directory."""
    raw_value = str(raw_value or "").strip()
    if not raw_value or raw_value.lower() == "default":
        return Path.home() / SETTINGS_FOLDER_NAME
    base = Path(raw_value).expanduser()
    return base if base.name == SETTINGS_FOLDER_NAME else (base / SETTINGS_FOLDER_NAME)


def get_settings_dir() -> Path:
    """Get the settings directory. ALL settings live here — nothing in home dir."""
    if _DEBUG_MODE and _DEBUG_SETTINGS_DIR is not None:
        return _DEBUG_SETTINGS_DIR
    _migrate_pointer()
    pointer_file = get_pointer_file()
    if pointer_file.exists():
        try:
            custom_path = pointer_file.read_text(encoding='utf-8').strip()
            return _resolve_settings_candidate(custom_path)
        except Exception:
            pass
    return Path.home() / SETTINGS_FOLDER_NAME


def is_debug_mode() -> bool:
    return _DEBUG_MODE


def activate_debug_mode(settings_dir: Path | str | None = None) -> Path:
    """Enable ephemeral debug mode and return its runtime settings directory."""
    global _DEBUG_MODE, _DEBUG_SETTINGS_DIR, _DEBUG_SETTINGS_HANDLE

    _DEBUG_MODE = True
    if settings_dir is None:
        if _DEBUG_SETTINGS_HANDLE is None:
            _DEBUG_SETTINGS_HANDLE = tempfile.TemporaryDirectory(prefix="aura-debug-")
        _DEBUG_SETTINGS_DIR = Path(_DEBUG_SETTINGS_HANDLE.name)
    else:
        _DEBUG_SETTINGS_DIR = Path(settings_dir).expanduser()
        _DEBUG_SETTINGS_DIR.mkdir(parents=True, exist_ok=True)
    return _DEBUG_SETTINGS_DIR


def _cleanup_debug_runtime() -> None:
    global _DEBUG_SETTINGS_DIR, _DEBUG_SETTINGS_HANDLE
    handle = _DEBUG_SETTINGS_HANDLE
    _DEBUG_SETTINGS_HANDLE = None
    _DEBUG_SETTINGS_DIR = None
    if handle is not None:
        try:
            handle.cleanup()
        except Exception:
            pass


atexit.register(_cleanup_debug_runtime)


def get_config_path():
    return get_settings_dir() / CONFIG_FILENAME


def get_ytdlp_config_path():
    return get_settings_dir() / YTDLP_CONFIG_FILENAME


def ensure_ytdlp_config():
    if is_debug_mode():
        return None
    config_path = get_ytdlp_config_path()
    try:
        config_path.parent.mkdir(parents=True, exist_ok=True)
        if not config_path.exists():
            config_content = "# yt-dlp config (Aura)\n--js-runtimes node\n"
            config_path.write_text(config_content, encoding='utf-8')
        return config_path
    except Exception:
        return None


def _get_subprocess_env():
    """Get environment with forced UTF-8 encoding and unbuffered output for yt-dlp.
    On Windows, yt-dlp (Python script) defaults to console codepage (cp1251/cp866),
    which produces garbled text when we read stdout as UTF-8."""
    env = os.environ.copy()
    env["PYTHONUTF8"] = "1"
    env["PYTHONIOENCODING"] = "utf-8"
    env["PYTHONUNBUFFERED"] = "1"  # Force line-by-line output from pip-installed yt-dlp
    return env


def _get_system_encoding():
    """Get the real Windows system encoding (e.g. cp1251), ignoring PYTHONUTF8.
    Used as fallback when yt-dlp.EXE (standalone PyInstaller binary) ignores
    our PYTHONUTF8/PYTHONIOENCODING env vars and outputs in the system codepage."""
    try:
        import locale
        # getpreferredencoding(False) returns the ACTUAL system encoding,
        # not affected by Python UTF-8 mode or PYTHONUTF8 env var
        return locale.getpreferredencoding(False) or 'utf-8'
    except Exception:
        return 'utf-8'


def _fix_encoding(line: str) -> str:
    """Fix encoding of a text line read with errors='surrogateescape'.
    
    When yt-dlp.EXE (standalone PyInstaller) outputs in system codepage (cp1251),
    Python reads it as UTF-8 with surrogateescape — non-UTF-8 bytes become
    surrogate characters (U+DC80..U+DCFF). We detect these and re-decode
    the original bytes using the system encoding.
    
    For pip-installed yt-dlp (which respects PYTHONUTF8=1), output is valid UTF-8
    and passes through unchanged.
    """
    if not line:
        return ""
    try:
        # If the line can be encoded to UTF-8, it's already valid — no surrogates
        line.encode('utf-8')
        return line
    except UnicodeEncodeError:
        # Contains surrogate characters → original bytes weren't valid UTF-8
        # Re-encode to get original raw bytes, then decode with system encoding
        try:
            raw = line.encode('utf-8', errors='surrogateescape')
            return raw.decode(_SYSTEM_ENCODING, errors='replace')
        except (UnicodeEncodeError, UnicodeDecodeError, LookupError):
            return line.encode('utf-8', errors='replace').decode('utf-8')



_SYSTEM_ENCODING = _get_system_encoding()
_PYTHON_RUNTIME_DIRS = _python_runtime_dirs()


# ══════════════════════════════════════════════════════════════════════════════
#  ERROR LOGGING
# ══════════════════════════════════════════════════════════════════════════════

import logging
import traceback as _tb

_logger = logging.getLogger("aura")
if not _logger.handlers:
    _handler = logging.StreamHandler()
    _handler.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(message)s", "%H:%M:%S"))
    _logger.addHandler(_handler)
    _logger.setLevel(logging.DEBUG if _DEBUG_MODE else logging.WARNING)


def log_error(context: str, exc: BaseException | None = None, level: str = "warning") -> None:
    """Log an error with context. Used instead of bare 'except: pass'.
    
    Args:
        context: Where the error occurred (e.g. "save_history", "close_worker")
        exc: The exception object (optional — auto-captured if None)
        level: "warning", "error", or "debug"
    """
    if exc is None:
        msg = f"[{context}] {_tb.format_exc().strip()}"
    else:
        msg = f"[{context}] {type(exc).__name__}: {exc}"
    getattr(_logger, level, _logger.warning)(msg)


def safe_call(func, context, default=None):
    """Call func(), log any exception, return default on failure.
    
    Replaces the pattern:
        try: result = something()
        except Exception: pass
    With:
        result = safe_call(something, "context")
    """
    try:
        return func()
    except Exception as e:
        log_error(context, e)
        return default


def atomic_write_json(path: Path | str, data, indent: int = 2) -> bool:
    """Write JSON data to file atomically (write→rename).
    
    Prevents corruption if app crashes during write.
    Creates backup of previous version as .bak.
    """
    path = Path(path)
    tmp_path = path.with_suffix('.tmp')
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        # Write to temp file
        tmp_path.write_text(
            json.dumps(data, ensure_ascii=False, indent=indent),
            encoding='utf-8'
        )
        # Backup existing file
        if path.exists():
            bak_path = path.with_suffix('.bak')
            try:
                from shutil import copy2
                copy2(str(path), str(bak_path))
            except Exception:
                pass  # backup is best-effort
        # Atomic rename (on same filesystem this is atomic on POSIX)
        tmp_path.replace(path)
        return True
    except Exception as e:
        log_error(f"atomic_write:{path.name}", e)
        # Try to clean up temp file
        try:
            tmp_path.unlink(missing_ok=True)
        except Exception:
            pass
        return False


# ══════════════════════════════════════════════════════════════════════════════
#  SUBPROCESS TRACKING (for atexit emergency cleanup)
# ══════════════════════════════════════════════════════════════════════════════

import atexit

tracked_processes: set[subprocess.Popen[str]] = set()  # Active subprocess.Popen objects


def _atexit_kill_subprocesses():
    """Kill any tracked subprocesses on interpreter exit."""
    for proc in list(tracked_processes):
        try:
            if proc.poll() is None:
                proc.terminate()
                try:
                    proc.wait(timeout=2)
                except Exception:
                    proc.kill()
        except Exception:
            pass
    tracked_processes.clear()


atexit.register(_atexit_kill_subprocesses)
