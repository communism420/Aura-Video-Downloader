#!/usr/bin/env python3
from __future__ import annotations

"""Canonical settings schema and normalization helpers."""

from copy import deepcopy
from typing import Any, Mapping


SETTINGS_DEFAULTS: dict[str, Any] = {
    "mode": "video",
    "url": "",
    "outdir": "",
    "cookies": "",
    "proxy": "",
    "search_results_limit": "25",
    "video_quality": "max",
    "audio_format": "wav",
    "audio_bitrate": "max",
    "audio_source": "audio_video",
    "audio_language": "any",
    "download_all_audio_tracks": False,
    "dubbed_audio_export": False,
    "dubbed_audio_mode": "selected",
    "dubbed_audio_languages": "",
    "dubbed_audio_format": "best",
    "meta_language": "any",
    "restart_each_video": False,
    "notify_on_finish": True,
    "no_numbering": False,
    "reverse_playlist": True,
    "use_archive": True,
    "download_subtitles": False,
    "subtitle_language": "all",
    "embed_subtitles": False,
    "subtitle_format": "srt",
    "auth_method": "none",
    "use_aria2c": False,
    "aria2c_threads": "8",
    "concurrent_videos": "1",
    "smart_auto_apply": False,
    "smart_auto_preset": "",
    "manual_item_selection": False,
    "sb_enabled": False,
    "sb_action": "mark",
    "sb_categories": ["sponsor", "intro", "outro", "selfpromo"],
    "sb_force_keyframes": False,
    "speed_limit": 0,
    "speed_limit_unit": "mbs",
    "output_container": "auto",
    "video_codec_policy": "auto",
    "playback_target": "auto",
    "immersive_safe_container": True,
    "generate_m3u": False,
    "history_auto_remove_completed": False,
    "speed_graph_enabled": False,
    "background_mode": False,
    "enable_4kvd_shaming": False,
    "scheduler_enabled": False,
    "scheduler_mode": "daily",
    "scheduler_interval": 60,
    "log_file_enabled": False,
    "log_file_path": "",
    "auto_remove_completed": False,
}


def clone_settings_value(value: Any) -> Any:
    """Return a detached copy of a JSON-compatible settings value."""
    return deepcopy(value)


def build_default_settings() -> dict[str, Any]:
    """Return a fresh copy of the canonical settings defaults."""
    return clone_settings_value(SETTINGS_DEFAULTS)


def normalize_settings(
    saved: Any,
    defaults: Mapping[str, Any] | None = None,
) -> tuple[dict[str, Any], dict[str, Any] | None]:
    """Normalize arbitrary settings data against the schema."""

    schema = (
        clone_settings_value(defaults)
        if defaults is not None
        else build_default_settings()
    )
    if not isinstance(schema, dict):
        raise TypeError("Settings defaults must be a mapping")

    report = {"added": {}, "removed": [], "reset": {}}

    if not isinstance(saved, dict):
        normalized = clone_settings_value(schema)
        report["reset"]["<root>"] = clone_settings_value(schema)
        return normalized, report

    normalized = _normalize_mapping(saved, schema, "", report)
    report["removed"].sort()
    if report["added"] or report["removed"] or report["reset"]:
        return normalized, report
    return normalized, None


def _normalize_mapping(
    saved: Mapping[str, Any],
    defaults: Mapping[str, Any],
    prefix: str,
    report: dict[str, Any],
) -> dict[str, Any]:
    normalized: dict[str, Any] = {}
    for key, default_value in defaults.items():
        path = _join_path(prefix, key)
        if key not in saved:
            normalized[key] = clone_settings_value(default_value)
            report["added"][path] = clone_settings_value(default_value)
            continue
        normalized[key] = _normalize_value(saved[key], default_value, path, report)

    for key in saved:
        if key not in defaults:
            report["removed"].append(_join_path(prefix, key))

    return normalized


def _normalize_value(value: Any, default: Any, path: str, report: dict[str, Any]) -> Any:
    if isinstance(default, dict):
        if not isinstance(value, dict):
            return _reset_value(path, default, report)
        return _normalize_mapping(value, default, path, report)

    if isinstance(default, list):
        if not isinstance(value, list):
            return _reset_value(path, default, report)
        return clone_settings_value(value)

    if default is None:
        return clone_settings_value(value)

    if not _matches_default_type(value, default):
        return _reset_value(path, default, report)

    return clone_settings_value(value)


def _matches_default_type(value: Any, default: Any) -> bool:
    if isinstance(default, bool):
        return type(value) is bool
    if isinstance(default, int):
        return type(value) is int
    if isinstance(default, float):
        return isinstance(value, (int, float)) and not isinstance(value, bool)
    return isinstance(value, type(default))


def _reset_value(path: str, default: Any, report: dict[str, Any]) -> Any:
    cloned = clone_settings_value(default)
    report["reset"][path] = clone_settings_value(default)
    return cloned


def _join_path(prefix: str, key: str) -> str:
    return f"{prefix}.{key}" if prefix else key
