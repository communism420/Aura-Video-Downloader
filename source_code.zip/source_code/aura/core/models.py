#!/usr/bin/env python3
"""Typed data models for Aura Video Downloader.

Replaces anonymous dicts with documented, auto-completing dataclasses.
All fields have explicit types and defaults.
"""
from __future__ import annotations

import datetime
from dataclasses import asdict, dataclass

# ══════════════════════════════════════════════════════════════════════════════
#  DOWNLOAD HISTORY
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class DownloadEntry:
    """A single download in the history."""
    name: str = ""
    status: str = "done"          # "done" | "error" | "downloading"
    size: str = ""
    type: str = "video"           # "video" | "audio" | "playlist"
    date: str = ""
    platform: str = ""
    url: str = ""
    filepath: str = ""
    format_id: str = ""
    duration: str = ""

    def __post_init__(self) -> None:
        if not self.date:
            self.date = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> DownloadEntry:
        # Accept both old format (without url/filepath) and new
        known = {f.name for f in cls.__dataclass_fields__.values()}
        return cls(**{k: v for k, v in d.items() if k in known})


# ══════════════════════════════════════════════════════════════════════════════
#  FORMAT INFO
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class FormatInfo:
    """A single format from yt-dlp format list."""
    id: str = ""
    ext: str = ""
    resolution: str = ""
    fps: str = ""
    codec: str = ""
    bitrate: str = ""
    size: str = ""
    note: str = ""

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> FormatInfo:
        known = {f.name for f in cls.__dataclass_fields__.values()}
        return cls(**{k: v for k, v in d.items() if k in known})


# ══════════════════════════════════════════════════════════════════════════════
#  VIDEO METADATA
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class VideoMetadata:
    """Video metadata from yt-dlp --dump-json."""
    title: str = ""
    duration: int = 0             # seconds
    filesize: int = 0             # bytes (estimated)
    uploader: str = ""
    upload_date: str = ""
    view_count: int = 0
    thumbnail: str = ""           # URL
    webpage_url: str = ""
    format_id: str = ""

    @classmethod
    def from_ytdlp_json(cls, data: dict) -> VideoMetadata:
        return cls(
            title=data.get("title", ""),
            duration=data.get("duration", 0) or 0,
            filesize=data.get("filesize") or data.get("filesize_approx", 0) or 0,
            uploader=data.get("uploader", ""),
            upload_date=data.get("upload_date", ""),
            view_count=data.get("view_count", 0) or 0,
            thumbnail=data.get("thumbnail", ""),
            webpage_url=data.get("webpage_url", ""),
            format_id=data.get("format_id", ""),
        )

    @property
    def duration_str(self) -> str:
        if not self.duration:
            return ""
        m, s = divmod(self.duration, 60)
        h, m = divmod(m, 60)
        return f"{h}:{m:02d}:{s:02d}" if h else f"{m}:{s:02d}"

    @property
    def filesize_str(self) -> str:
        if not self.filesize:
            return ""
        mb = self.filesize / (1024 * 1024)
        return f"~{mb:.1f} MB"


# ══════════════════════════════════════════════════════════════════════════════
#  PARALLEL WORKER STATE
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class ParallelWorkerState:
    """Tracks progress of one parallel download worker."""
    total: int = 0
    downloaded: int = 0
    pct: float = 0.0
    speed: str = ""
    eta: str = ""
    last_dest: str = ""
    pending: bool = False


# ══════════════════════════════════════════════════════════════════════════════
#  DOWNLOAD PARAMS (passed from UI to download logic)
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class DownloadParams:
    """Validated parameters for a download, extracted from UI widgets."""
    mode: str = "video"           # "channel" | "playlist" | "video" | "audio"
    url: str = ""
    cookies: str = ""
    outdir: str = ""
    quality: str = "max"
    audio_format: str = "wav"
    audio_bitrate: str = "max"
    platform: str = "youtube"
