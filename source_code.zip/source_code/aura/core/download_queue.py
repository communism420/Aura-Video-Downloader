#!/usr/bin/env python3
from __future__ import annotations

"""Centralized download queue with priority support.

Manages pending download tasks with:
- Priority levels (subscriptions < manual)
- Persistent storage via AuraDatabase
- Concurrent download limiting
- FIFO within same priority
"""
import datetime
from enum import IntEnum


class Priority(IntEnum):
    """Download priority. Lower value = higher priority."""
    HIGH = 0       # User-initiated manual downloads
    NORMAL = 10    # Queued by user (added while another download is active)
    LOW = 20       # Auto-downloads from subscriptions


class QueueEntry:
    """Single download task in the queue."""
    __slots__ = ('url', 'mode', 'platform', 'quality', 'priority', 'added', 'status', 'options')

    def __init__(self, url, mode="video", platform="youtube",
                 quality="max", priority=Priority.NORMAL, options=None):
        self.url = url
        self.mode = mode
        self.platform = platform
        self.quality = quality
        self.priority = priority
        self.added = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.status = "pending"  # pending | downloading | done | error
        self.options = dict(options or {})

    def to_dict(self):
        return {
            "url": self.url, "mode": self.mode, "platform": self.platform,
            "quality": self.quality, "priority": int(self.priority),
            "status": self.status, "added": self.added,
            "options": dict(self.options or {}),
        }

    @classmethod
    def from_dict(cls, d):
        entry = cls(
            url=d.get("url", ""),
            mode=d.get("mode", "video"),
            platform=d.get("platform", "youtube"),
            quality=d.get("quality", "max"),
            priority=d.get("priority", Priority.NORMAL),
            options=d.get("options", {}),
        )
        entry.status = d.get("status", "pending")
        entry.added = d.get("added", "")
        return entry


class DownloadQueue:
    """Thread-safe download queue with priority ordering.
    
    Usage:
        queue = DownloadQueue()
        queue.add("https://youtube.com/...", priority=Priority.NORMAL)
        
        entry = queue.next()  # Returns highest-priority pending entry
        if entry:
            entry.status = "downloading"
            # ... start download ...
            queue.remove(entry)
    """

    def __init__(self):
        self._queue = []  # List[QueueEntry], sorted by priority then FIFO

    def add(self, url, mode="video", platform="youtube",
            quality="max", priority=Priority.NORMAL, options=None):
        """Add a download task to the queue. Returns the entry."""
        entry = QueueEntry(url, mode, platform, quality, priority, options=options)
        self._queue.append(entry)
        self._queue.sort(key=lambda e: (e.priority, e.added))
        return entry

    def next(self) -> QueueEntry | None:
        """Get the next pending entry (highest priority, oldest).
        Returns None if queue is empty or all entries are non-pending."""
        for entry in self._queue:
            if entry.status == "pending":
                return entry
        return None

    def remove(self, entry: QueueEntry) -> None:
        """Remove an entry from the queue."""
        try:
            self._queue.remove(entry)
        except ValueError:
            pass

    def prepend_entry(self, entry: QueueEntry | dict) -> QueueEntry:
        """Insert an entry at the very front of the queue."""
        if isinstance(entry, dict):
            entry = QueueEntry.from_dict(entry)
        if not entry.status:
            entry.status = "pending"
        self._queue.insert(0, entry)
        return entry

    def remove_url(self, url: str) -> None:
        """Remove all entries with a given URL."""
        self._queue = [e for e in self._queue if e.url != url]

    def clear(self) -> None:
        """Remove all pending entries."""
        self._queue = [e for e in self._queue if e.status == "downloading"]

    def move(self, entry: QueueEntry, direction: int) -> bool:
        """Move an entry up/down inside the current queue order."""
        if entry not in self._queue or direction == 0:
            return False
        index = self._queue.index(entry)
        target = index + (-1 if direction < 0 else 1)
        if target < 0 or target >= len(self._queue):
            return False
        self._queue[index], self._queue[target] = self._queue[target], self._queue[index]
        return True

    def pending_count(self) -> int:
        """Number of pending or paused entries."""
        return sum(1 for e in self._queue if e.status in ("pending", "paused"))

    def all_entries(self):
        """Return list of all entries (for UI display)."""
        return list(self._queue)

    def is_empty(self) -> bool:
        """True if no pending or paused entries."""
        return self.pending_count() == 0

    def to_list(self) -> list[dict]:
        """Serialize queue for DB persistence."""
        return [e.to_dict() for e in self._queue if e.status in ("pending", "paused")]

    def load_from_list(self, data: list[dict]) -> None:
        """Restore queue from serialized data."""
        self._queue = [
            QueueEntry.from_dict(d)
            for d in data
            if d.get("status") in ("pending", "paused")
        ]
        self._queue.sort(key=lambda e: (e.priority, e.added))
