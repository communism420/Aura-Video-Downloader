# Contributing to Aura Video Downloader

Thank you for your interest in contributing! This guide will help you get started.

---

## Getting started

### Setup

```bash
git clone https://github.com/your-repo/aura-video-downloader.git
cd aura-video-downloader
pip install PySide6 yt-dlp pytest
```

### Run the app

```bash
python Aura_Video_Downloader.py
```

### Run tests

```bash
python -m pytest aura/tests/ -v
```

All 194 tests must pass before submitting a PR.

---

## Development workflow

1. **Create a branch** from `main`
2. **Make changes** — follow the architecture rules below
3. **Run tests** — all must pass
4. **Submit a PR** with a clear description

---

## Architecture rules

These rules keep the codebase maintainable. Please read [ARCHITECTURE.md](ARCHITECTURE.md) for the full picture.

### Module boundaries

- **Foundation modules** (`constants.py`, `utils.py`, `platforms.py`, `database.py`, `settings.py`, `translations/`) must **never** import from Qt or UI modules
- **Workers** (`workers/`) may import from foundation + `PySide6.QtCore` (for QThread/Signal) but **never** from dialogs, widgets, or main_window
- **Dialogs** (`dialogs/`) are self-contained UI components — they don't import from `main_window.py`
- **`main_window.py`** is the only module that imports from all layers

### Threading

- **Never block the main thread.** Any subprocess, network, or file I/O that takes >50ms must run in a QThread worker
- **Use Qt signals** for worker→UI communication. Never access widgets from a worker thread
- **Track subprocesses** via `utils.tracked_processes` so they're cleaned up on exit

### Error handling

- Use `log_error(context, exception)` instead of `except: pass`
- Critical paths (settings save, history, download completion) must log errors, not swallow them

### Settings

- New settings must be added to `SettingsManager.DEFAULT_SETTINGS`
- The migration system handles old configs automatically — users don't lose their settings

---

## Common tasks

### Adding a new platform

See the "Adding a new platform" section in [ARCHITECTURE.md](ARCHITECTURE.md). It's just a dict entry in `platforms.py` — no other code changes needed.

### Adding a new translation

Copy `translations/en.json`, translate all values, save as `translations/xx.json`. The loader auto-discovers it.

### Adding a new setting

1. Add the key + default value to `SettingsManager.DEFAULT_SETTINGS` in `settings.py`
2. Add the UI widget in the appropriate `_build_section_*` method in `main_window.py`
3. Add save/load logic in `_save_settings_impl` / `_load_settings_impl`
4. The migration system handles existing user configs automatically

### Adding a new worker

1. Create `workers/new_worker.py` with a `QThread` subclass
2. Use `Signal` for all communication back to the main thread
3. Add to `workers/__init__.py`
4. Connect signals in `main_window.py`

---

## Testing

### Test structure

| File | Tests | Target |
|---|---|---|
| `test_models.py` | Dataclass serialization | `core/models.py` |
| `test_download_queue.py` | Queue priority + ordering | `core/download_queue.py` |
| `test_database.py` | SQLite CRUD | `database.py` |
| `test_settings.py` | Config migration + corruption | `settings.py` |
| `test_utils.py` | Encoding, atomic write | `utils.py` |
| `test_constants.py` | Regex pattern matching | `constants.py` |
| `test_translations.py` | RU/EN key parity | `translations/` |
| `test_platforms.py` | Platform schema validation | `platforms.py` |
| `test_smoke.py` | App creation + widgets | `main_window.py` |

### Writing tests

- Tests for foundation modules (no Qt) go in `test_*.py` as regular pytest
- Tests that need Qt use the `offscreen` platform and a module-scoped `QApplication` fixture
- Use `tmp_path` fixture for file-based tests (auto-cleanup)
- Use `unittest.mock.patch` for isolating settings paths

---

## Code style

- **PEP 8** for naming and formatting
- **Type hints** on all new public functions
- **Docstrings** on all new public methods
- Avoid methods longer than 80 lines — split into sub-methods
- Use `from __future__ import annotations` in typed modules

---

## Commit messages

Use clear, descriptive commit messages:

```
fix: restore history from backup on JSON corruption
feat: add Rutube platform support
test: add regex pattern matching tests for aria2c output
docs: update architecture diagram
refactor: extract _build_section_options from _build_all_sections
```

---

## Questions?

Open an issue on GitHub. We're happy to help!
