# ✦ Aura Video Downloader

**Free, open-source GUI video downloader** built with Python, PySide6 (Qt6), and yt-dlp.

Everything that paid tools do for $45 — for free, without hiding that it's powered by yt-dlp.

![Python](https://img.shields.io/badge/python-3.9+-blue)
![License](https://img.shields.io/badge/license-MIT-green)
![Tests](https://img.shields.io/badge/tests-194%20passed-brightgreen)
![Platforms](https://img.shields.io/badge/platforms-17-orange)

---

## Features

**17 platforms:** YouTube, VK Video, Rutube, Twitch, Dailymotion, Vimeo, Bilibili, OK.ru, Дзен, TikTok, Instagram, Twitter/X, Facebook, Reddit, Pornhub, XVideos, xHamster

**Download modes:** Channel · Playlist · Single video · Audio extraction

**Core features:**
- Quality selector (8K → 144p) + manual format picker
- Audio extraction (WAV, MP3, OGG) with bitrate control
- aria2c accelerated downloads (16-thread parallel)
- SponsorBlock integration (skip/remove sponsors)
- Subtitle download with language selection
- Proxy support (SOCKS5/HTTP)
- Cookie-based auth (in-app browser login or cookies.txt)

**Advanced:**
- Channel subscription system with background scheduler
- Download queue with priority ordering
- Real-time speed graph
- Smart Mode presets (save/load download configs)
- Session crash recovery
- SQLite download database
- Built-in video player
- Video metadata preview with thumbnails
- Speed limiter
- Force container format (MP4/MKV remux)
- Background tray mode

**Quality:**
- 3 visual themes (Dark, Gray, Light)
- Full bilingual UI (English + Russian)
- 194 automated tests
- Atomic writes for crash-safe settings
- Modular architecture (42 source files)

---

## Installation

### Requirements

- **Python 3.9+**
- **PySide6:** `pip install PySide6`
- **yt-dlp:** `pip install yt-dlp`
- **ffmpeg:** [ffmpeg.org](https://ffmpeg.org/download.html) — must be in PATH

### Optional

- **aria2c:** For accelerated downloads — [aria2.github.io](https://aria2.github.io/)
- **Node.js:** Required for YouTube (n-challenge solving) — [nodejs.org](https://nodejs.org/)
- **PySide6-WebEngine:** For in-app browser login — `pip install PySide6-WebEngine`
- **PySide6-Multimedia:** For built-in video player — `pip install PySide6-Multimedia`

### Quick start

```bash
git clone https://github.com/your-repo/aura-video-downloader.git
cd aura-video-downloader
pip install PySide6 yt-dlp
python Aura_Video_Downloader.py
```

Or as a package:

```bash
python -m aura
```

---

## Project structure

```
aura/
├── app.py                  Entry point + startup logic
├── main_window.py          Main application window (AuraDownloader)
├── constants.py            Regex patterns, limits, quality tables
├── utils.py                Paths, encoding, atomic write, logging
├── platforms.py            17 platform configurations
├── themes.py               Visual themes + QSS generation
├── database.py             SQLite persistence layer
├── settings.py             Per-platform JSON configuration
├── core/
│   ├── models.py           Typed dataclasses (DownloadEntry, FormatInfo, ...)
│   └── download_queue.py   Priority download queue
├── translations/
│   ├── ru.json             Russian (536 keys)
│   └── en.json             English (536 keys)
├── workers/                Background QThread workers
│   ├── download.py         yt-dlp subprocess runner
│   ├── deps.py             Dependency checker
│   ├── formats.py          Format list fetcher
│   ├── preview.py          Metadata + thumbnail fetcher
│   └── subscriptions.py    Channel subscription checker
├── dialogs/                UI dialogs
│   ├── format_dialog.py    Format selection table
│   ├── preview_dialog.py   Video preview with thumbnail
│   ├── player_dialog.py    Built-in media player
│   ├── cookie_browser.py   In-app browser login
│   ├── selectors.py        Language/theme/platform pickers
│   └── config_location.py  First-run settings path dialog
├── widgets/
│   └── speed_graph.py      Real-time speed graph (QPainter)
└── tests/                  194 automated tests
```

See [ARCHITECTURE.md](ARCHITECTURE.md) for detailed design documentation.

---

## Running tests

```bash
# All tests (requires PySide6)
python -m pytest aura/tests/ -v

# Pure Python tests only (no Qt dependency)
python -m pytest aura/tests/ -v --ignore=aura/tests/test_smoke.py

# With coverage report
pip install pytest-cov
python -m pytest aura/tests/ --cov=aura --cov-report=term-missing
```

---

## Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines.

---

## License

MIT License. See [LICENSE](LICENSE).
