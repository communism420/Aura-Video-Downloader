"""Aura Video Downloader - modular package."""

import os
from pathlib import Path


def _configure_qt_fontdir(env=None, platform=None):
    env = os.environ if env is None else env
    platform = platform or os.sys.platform

    current = str(env.get("QT_QPA_FONTDIR") or "").strip()
    if current:
        return current

    candidates = []
    if platform.startswith("win"):
        windir = str(env.get("WINDIR") or "").strip()
        if windir:
            candidates.append(Path(windir) / "Fonts")
    elif platform == "darwin":
        candidates.extend([Path("/System/Library/Fonts"), Path("/Library/Fonts")])
    else:
        candidates.extend(
            [
                Path("/usr/share/fonts"),
                Path("/usr/local/share/fonts"),
                Path.home() / ".local" / "share" / "fonts",
            ]
        )

    for candidate in candidates:
        if candidate.is_dir():
            env["QT_QPA_FONTDIR"] = str(candidate)
            return str(candidate)
    return ""


_configure_qt_fontdir()

__version__ = "2.1"
