# Code of Conduct

## Our pledge

We are committed to making participation in this project a welcoming experience for everyone, regardless of background or identity.

## Our standards

**Positive behavior:**
- Being respectful and constructive
- Accepting feedback gracefully
- Focusing on what is best for the project
- Showing empathy towards other contributors

**Unacceptable behavior:**
- Harassment, insults, or personal attacks
- Trolling or deliberately inflammatory comments
- Publishing others' private information
- Any conduct that would be considered inappropriate in a professional setting

## Enforcement

Project maintainers may remove, edit, or reject contributions that violate this code of conduct. Repeated violations may result in a temporary or permanent ban.

## Scope

This code of conduct applies within all project spaces — issues, pull requests, discussions, and any other communication channels.

## Attribution

This Code of Conduct is adapted from the [Contributor Covenant](https://www.contributor-covenant.org/), version 2.1.
